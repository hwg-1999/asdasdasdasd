# 第十部分 · clangd 智能提示

> [← 返回索引](00-索引.md) ｜ [上一篇](09-第九部分-资产与配置.md) ｜ [下一篇](11-第十一部分-实测数据.md)

> **🎓 L2 · 能改** ｜ 前置：L1（必须已有构建树） ｜ 读完能做什么：clangd 能跳转、有补全 ｜ 下一站 → **第十一部分（L4）**

## 10.1 核心难点：unity build 会废掉 clangd

O3DE 默认 `LY_UNITY_BUILD=ON`，编译的是：

```
Code/Framework/AzCore/CMakeFiles/AzCore.dir/Unity/unity_34_cxx.cxx
```

内容只有 `#include` 列表。所以 `compile_commands.json` 里**只有 unity 文件条目，没有单个 `.cpp`** → clangd 找不到参数，智能提示严重退化。

### 实测对比

| 阶段 | 覆盖源文件 |
|---|---|
| 直接 `ninja -t compdb` | **1454**（全是 unity 文件） |
| 展开 unity 后 | **7977** |

**提升 5.5 倍。**

## 10.2 解决方案：不重配 CMake

```bash
ninja -C /workspaces/o3de-build -t compdb    # 2 秒，从现成 build.ninja 导出
```

**为什么不加 `-DCMAKE_EXPORT_COMPILE_COMMANDS=ON` 重配**：

- 会撞 googletest FetchContent 问题
- 配置一次 18 秒到 3 分钟
- 有破坏已有构建树的风险

### 展开算法

```mermaid
flowchart TD
  A["ninja -C build -t compdb"] --> B["8268 条原始条目"]
  B --> C["过滤 command 为空的<br/>（CUSTOM_COMMAND/phony）"]
  C --> D["3605 条有效"]
  D --> E["识别 unity_N_cxx.cxx"]
  E --> F["正则提取 #include &quot;绝对路径&quot;"]
  F --> G["为每个 .cpp 复制 unity 的 command"]
  G --> H["8081 条"]
```

## 10.3 已完成的配置

| 位置 | 内容 |
|---|---|
| `/workspaces/o3de-build/compile_commands.json` | 8081 条 → 7977 文件 |
| `/workspaces/MyProject/build/linux/compile_commands.json` | 8055 条 → 7951 文件 |
| `/workspaces/o3de/compile_commands.json` | → 符号链接 |
| `/workspaces/MyProject/compile_commands.json` | → 符号链接 |
| `/workspaces/o3de/.clangd` | 参数修正 + 诊断抑制 + 索引策略 |
| `/workspaces/MyProject/.clangd` | 同上 |
| `.vscode/settings.json` | `clangd.arguments` |
| `o3de-src` / `myproject-src` | 工作区符号链接入口 |
| `tools/gen-compdb.py` / `refresh-compdb.sh` | 生成与刷新 |

## 10.4 `.clangd` 关键配置

```yaml
CompileFlags:
  Compiler: /usr/bin/clang++-18
  Remove:
    - -MD
    - -MT
    - -MF
    - -o
    - -fstack-check
    - -g
  Add:
    - -fno-modules
    - -Wno-error
    - -Wno-unused-parameter
    - -Wno-unused-variable
    - -Wno-unused-private-field

Diagnostics:
  Suppress:
    - undeclared_var_use
    - unknown_typename
    - deprecated_declarations

Index:
  Background: Skip      # 本机 7.7 GB 内存，全量索引吃 1-2 GB

InlayHints:
  ParameterNames: Yes
  DeducedTypes: No
```

⚠️ **clangd 18 不支持 `Completion.ArgumentLists`**（更新版本的键），写了会报 `Unknown Completion key`。

## 10.5 VS Code 设置

```json
"clangd.arguments": [
    "--header-insertion=iwyu",
    "--query-driver=/usr/bin/clang++-18,/usr/bin/clang-18",
    "--background-index=false",
    "--all-scopes-completion",
    "--suggest-missing-includes",
    "--clang-tidy=false"
],
"C_Cpp.intelliSenseEngine": "disabled"
```

`--query-driver` 让 clangd 能查询编译器拿系统头文件路径。路径必须与 `compile_commands.json` 里记录的一致。

`C_Cpp.intelliSenseEngine: disabled` 因为 cpptools 会和 clangd 抢 IntelliSense。

## 10.6 验证

```bash
clangd --check=/workspaces/o3de/Code/Framework/AzCore/AzCore/Math/Vector3.cpp
```

期望两行：

```
I[...] Loaded compilation database from /workspaces/o3de/compile_commands.json
I[...] Compile command from CDB is: [/workspaces/o3de-build] /usr/lib/llvm-18/bin/clang++-18 ...
```

⚠️ 结尾的 `All checks completed, 28 errors` **不是代码错误**，是 clangd 在跑自己的重构自检（`tweak: ExtractFunction` / `AddUsing`）。真实诊断会带诊断码（如 `[undeclared_var_use]`）。

## 10.7 何时重新生成

| 改了什么 | 需要重跑 |
|---|---|
| `.cpp` / `.h` | ❌ 不需要 |
| `CMakeLists.txt` / `*.cmake` / `project.json` | ✅ |
| 重新 configure 过 | ✅ |

```bash
/home/hwg/tmp/ai/tmp/O3DE-学习文档/tools/refresh-compdb.sh
```

## 10.8 内存权衡

| `Index.Background` | 内存 | 跨文件跳转 | 建议 |
|---|---|---|---|
| **`Skip`**（当前） | 低 | ❌ | 内存紧张 |
| `Build` | +1~2 GB | ✅ | 内存充裕 |

改 `.clangd` 的 `Background: Build`，同时删 `settings.json` 里的 `--background-index=false`，然后 `clangd: Restart language server`。

---

## 10.9 工作区里的 `o3de-src` / `myproject-src` 是什么

工作区根 `/home/hwg/tmp/ai/tmp` 下有两个符号链接：

```bash
$ ls -la /home/hwg/tmp/ai/tmp/o3de-src /home/hwg/tmp/ai/tmp/myproject-src
myproject-src -> /workspaces/MyProject
o3de-src      -> /workspaces/o3de
```

**它们不是"架子"，是两个真实目录的只读入口。** 为什么需要它们：workspace 根在
`/home/hwg/tmp/ai/tmp`，而源码在 `/workspaces/`——**在 workspace 之外**，
VS Code 的资源管理器和 clangd 的后台索引都看不到。加两个链接就能看到。

### 关键区分：源码在这，产物不在这

| | 路径 | 内容 | 本机实测体积 |
|---|---|---|---|
| **源码** | `o3de-src` → `/workspaces/o3de` | 只读代码，**零产物** | 448 MB（含 `.git` 58 MB） |
| **引擎构建树** | `/workspaces/o3de-build` | `bin/profile/` 的 11 个可执行 + `.so` | **12 GB** |
| **项目源码** | `myproject-src` → `/workspaces/MyProject` | 项目配置 + `Gem/` 源码 | < 5 MB |
| **项目构建树** | `/workspaces/MyProject/build/linux` | 项目自己的 `bin/profile/` | 1.2 GB |
| **资产缓存** | `/workspaces/MyProject/Cache` | AP 生成的产品资产 | 111 MB |

验证"源码树里确实没有产物"：

```bash
find /workspaces/o3de -maxdepth 2 -name "*.so" -o -maxdepth 2 -name "bin" | head
# → 只有 /workspaces/o3de/scripts/build（那是个脚本目录，不是构建树）
```

### 经符号链接打开，clangd 依然命中

clangd 会把路径**规范化**（跟随符号链接）后再去 compdb 里找。实测（`clangd --check`）：

| 打开方式 | 结果 |
|---|---|
| `o3de-src/Code/Framework/AtomCore/.../InstanceId.cpp` | `Loaded compilation database from /workspaces/o3de/compile_commands.json` → **0 errors** |
| `myproject-src/Gem/Source/MyProjectSystemComponent.cpp` | 命中项目 compdb → **0 errors** |
| `myproject-src/Gem/Source/MyProjectModule.cpp` | 命中项目 compdb → **0 errors** |
| `myproject-src/Gem/Source/HeartbeatComponent.cpp` | ⚠️ **Compile command inferred from MyProjectModule.cpp** → 0 errors |

**最后一行是个真实陷阱**：`HeartbeatComponent.cpp` 是后来新增的文件，而
`compile_commands.json` 是新增之前生成的——**compdb 里没有它**。clangd 只好
"照着同目录的邻居推断"，靠猜。

> **经验**：新增 `.cpp` 之后，重新跑一次 `ninja`（或 `./tools/refresh-compdb.sh`）
> 让 compdb 收录它。推断虽然大多能歪打正着，但一旦参数不同（比如该文件用了
> 别的编译选项），你会看到假的报错或假的正常。

本机两个 compdb 的实测规模：

| compdb | 条目 | 其中引擎源码 | 其中构建树生成物 | 其中项目源码 |
|---|---|---|---|---|
| `/workspaces/o3de/compile_commands.json` | **8081** | 6755 | 1326 | 0 |
| `/workspaces/MyProject/compile_commands.json` | **8055** | 6755 | 1298 | **2** |

**注意项目 compdb 已经包含引擎源码条目**，所以读引擎代码时用哪一个都行。

### ⚠️ 不要经符号链接去构建

链接是给**读**用的，不是给**构建**用的。原因：CMake 会把源码路径
`realpath` 解析后写进构建树，而现有构建树里记录的、以及 compdb 的 `directory`
字段，全是真实路径（如 `/workspaces/o3de-build`）。用链接路径去 configure 会得到一套
路径不一致的新构建树，轻则全部重编，重则和现有产物互相干扰。

**规律**：读代码 → 经链接（方便）；跑 `ninja` / `cmake` / `o3de.sh` → 用真实路径。

---
