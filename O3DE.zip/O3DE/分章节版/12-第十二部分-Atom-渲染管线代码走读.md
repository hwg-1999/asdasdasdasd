# 第十二部分 · Atom 渲染管线代码走读

> [← 返回索引](00-索引.md) ｜ [上一篇](11-第十一部分-实测数据.md) ｜ [下一篇](13-第十三部分-多人网络架构.md)

> **🎓 L4 · 读源码 ★核心** ｜ 前置：L3 ｜ 读完能做什么：看懂 RHI 抽象与 Pass 系统 ｜ 下一站 → **第十三部分（L4）**

> 基于 `Gems/Atom/` 实际源码。RHI 共 **171 个头文件**，4 个后端（Vulkan / DX12 / Metal / Null）。

## 12.1 四层架构

```mermaid
flowchart TD
  A["你的代码 / Gem<br/>Component · Script Canvas"] --> B["Feature Processor<br/>Mesh / Light / Decal / PostProcess<br/>28 个实现"]
  B --> C["RPI<br/>Scene · RenderPipeline · Pass · View"]
  C --> D["RHI<br/>Device · Buffer · Image · CommandList · PipelineState"]
  D --> E1["Vulkan"]
  D --> E2["DX12"]
  D --> E3["Metal"]
  D --> E4["Null<br/>（无渲染，跑逻辑用）"]
```

| 层 | 目录 | 职责 | 可替换性 |
|---|---|---|---|
| **Feature** | `Gems/Atom/Feature/` | 具体功能：网格、光照、贴花、后处理 | 完全可换（连渲染器都能整个换掉） |
| **RPI**（Render Pipeline Interface） | `Gems/Atom/RPI/` | 场景、渲染管线、Pass、材质、Shader | 可换管线（多个 `.azasset` 管线描述） |
| **RHI**（Render Hardware Interface） | `Gems/Atom/RHI/` | 缓冲、纹理、命令列表、管线状态 | 4 个后端任选 |
| **后端** | `RHI/Vulkan` 等 | 具体图形 API | — |

**关键设计：RHI 把"图形 API 差异"隔离在 171 个头文件之后。** 上层写一次，四个后端都能跑。

## 12.2 ⭐ FeatureProcessor：渲染的插件扩展点

### 接口定义（`RPI.Public/FeatureProcessor.h`）

```cpp
class ATOM_RPI_PUBLIC_API FeatureProcessor
    : public SceneNotificationBus::Handler
{
public:
    AZ_RTTI(FeatureProcessor, "{B8027170-C65C-4237-964D-B557FC9D7575}");
    AZ_CLASS_ALLOCATOR(FeatureProcessor, AZ::SystemAllocator);

    // 生命周期
    virtual void Activate() {}
    virtual void Deactivate() {}

    // 每帧（三阶段）
    virtual void PrepareViews(const PrepareViewsPacket&, AZStd::vector<AZStd::pair<PipelineViewTag, ViewPtr>>& outViews) {}
    virtual void Simulate(const SimulatePacket&) {}
    virtual void Render(const RenderPacket&) {}
    virtual void OnEndCulling(const RenderPacket&) {}
    virtual void OnRenderEnd() {}

    // 管线构建时
    virtual void AddRenderPasses(RenderPipeline* pipeline) {}
};
```

### 官方注释里的关键设计说明（原文摘录）

> `Simulate()` is called from the simulation graph preparing and publishing data for use by the asynchronous rendering execution graph.
> `Render()` is called from the render graph, converting state data to GPU/rendering state and submitting to the pipeline coordinator.
> **Feature processors will contain or derive from listeners with a data buffers as needed to minimize contention.**

**翻译**：`Simulate` 在**模拟线程**准备数据，`Render` 在**渲染线程**消费数据。两者之间用**双缓冲/多缓冲**隔离，避免锁竞争。

### 三阶段调用时机

| 阶段 | 线程 | 频率 | 典型工作 |
|---|---|---|---|
| `PrepareViews` | 主线程 | 每帧 | 声明需要哪些额外 View（阴影图、反射探针） |
| `Simulate` | **并行 Job** | 每帧（可能跳过） | 更新 CPU 侧数据（粒子状态、动画） |
| `Render` | 并行 Job | 每帧 | 提交 DrawPacket 到 DrawList |
| `OnEndCulling` | — | 每帧 | 使用 VisibilityList（若不走默认剔除） |
| `OnRenderEnd` | — | 每帧 | 清理 |

### 28 个实际实现

以下列表由 `ls Gems/Atom/Feature/Common/Code/Source/*/*FeatureProcessor.h` 实测得出（**28 个**）：

```
MeshFeatureProcessor                    网格渲染
SkinnedMeshFeatureProcessor             蒙皮网格
TransformServiceFeatureProcessor        变换服务
AuxGeomFeatureProcessor                 调试几何体
SilhouetteFeatureProcessor              描边/剪影
DirectionalLightFeatureProcessor        平行光
PointLightFeatureProcessor              点光源
DiskLightFeatureProcessor               圆盘光
CapsuleLightFeatureProcessor            胶囊光
QuadLightFeatureProcessor               面光源
PolygonLightFeatureProcessor            多边形光
SimplePointLightFeatureProcessor        简化点光
SimpleSpotLightFeatureProcessor         简化聚光
ProjectedShadowFeatureProcessor         投影阴影
ImageBasedLightFeatureProcessor         IBL
ReflectionProbeFeatureProcessor         反射探针
DecalTextureArrayFeatureProcessor       贴花（纹理数组）
CubeMapCaptureFeatureProcessor          立方体捕获
SkyBoxFeatureProcessor                  天空盒
OcclusionCullingPlaneFeatureProcessor   遮挡剔除
PostProcessFeatureProcessor             后处理
SpecularReflectionsFeatureProcessor     镜面反射
SMAAFeatureProcessor                    抗锯齿
RayTracingFeatureProcessor              光追
RayTracingDebugFeatureProcessor         光追调试
DeferredMaterialFeatureProcessor        延迟材质
RenderDebugFeatureProcessor             调试渲染
SplashScreenFeatureProcessor            启动画面
```

> ⚠️ **注意没有 `DecalFeatureProcessor`**：真实类名是 `DecalTextureArrayFeatureProcessor`。
> 也没有 `DisplayMapperFeatureProcessor`——DisplayMapper 是 `Code/Source/DisplayMapper/`
> 下的独立模块，不是 FeatureProcessor。**类名靠猜会错，`ls` 一下最省事。**

**这就是渲染侧的插件式**：想加一个新特效，写一个 `FeatureProcessor` 子类，注册到 Scene 即可，不用改 RPI 核心。

## 12.3 走读案例：TransformServiceFeatureProcessor

选它是因为**简单且典型**（只有变换数据，没有复杂着色逻辑）。

### 头文件（`Feature/Common/Code/Source/TransformService/TransformServiceFeatureProcessor.h`）

```cpp
class TransformServiceFeatureProcessor final
    : public TransformServiceFeatureProcessorInterface
{
public:
    AZ_CLASS_ALLOCATOR(TransformServiceFeatureProcessor, AZ::SystemAllocator);
    AZ_RTTI(AZ::Render::TransformServiceFeatureProcessor,
        "{D8A2C353-2850-42F8-AA21-3979CBECBF80}",
        AZ::Render::TransformServiceFeatureProcessorInterface);

    // FeatureProcessor overrides
    void Activate() override;      // 创建 GPU 缓冲
    void Deactivate() override;    // 释放 GPU 资源

    // SceneNotificationBus overrides
    void OnBeginPrepareRender() override;
    void OnEndPrepareRender() override;

    // 业务接口
    ObjectId ReserveObjectId();
    void ReleaseObjectId(ObjectId& id);
    void SetTransformForId(ObjectId id, const AZ::Transform& transform, ...);
    AZ::Transform GetTransformForId(ObjectId id) const;
};
```

### 三个值得学的设计

#### ① 用 `union` 复用内存（空闲链表）

```cpp
// Holds both regular 4x3 transforms and 3x3 normal transforms
union Float4x3
{
    float m_transform[12] = { 0.0f };
    uint32_t m_nextFreeSlot;      // ← 同一个 12 字节：要么存变换，要么存空闲链表指针
};
```

**为什么**：一块 GPU 缓冲，用过的 slot 存矩阵，空闲的 slot 存"下一个空闲索引"，形成**链表**。这样：
- 分配 O(1)
- 不需要额外的空闲列表结构
- 缓冲可以静态大小

原文注释：

> Used slots have float12(matrix3x4) values, empty slots have a uint32_t that points to the next empty slot like a linked list. This allows mesh object SRGs to be compiled once with an index to their transform, and updates to the transform just update the buffer, not individual mesh SRGs.

**关键收益**：**SRG（ShaderResourceGroup）可以只编译一次**。更新变换只改缓冲区内容，不重编 SRG。

#### ② 用 SRG 名字索引而不是硬编码槽位

```cpp
RHI::ShaderInputNameIndex m_objectToWorldBufferIndex = "m_objectToWorldBuffer";
RHI::ShaderInputNameIndex m_objectToWorldInverseTransposeBufferIndex = "m_objectToWorldInverseTransposeBuffer";
RHI::ShaderInputNameIndex m_objectToWorldHistoryBufferIndex = "m_objectToWorldHistoryBuffer";
```

**为什么**：Shader 的 SRG 布局由 `.azsl` 反射生成，槽位号在不同材质/管线间会变。用**名字**查索引，布局变了不用改 C++。

`m_objectToWorldHistoryBuffer` 是**上一帧的变换**——用于运动模糊和 TAA。

#### ③ 通过 SceneNotificationBus 而不是 Tick

```cpp
void OnBeginPrepareRender() override;
void OnEndPrepareRender() override;
```

它**没有**用 `AZ::TickBus`，而是挂了 `SceneNotificationBus`。因为渲染数据必须在**正确的渲染阶段**上传，而不是任意 Tick 时刻。

**这是渲染相关组件的通用原则：跟渲染挂钩用 Scene/RPI 的总线，不要用 TickBus。**

## 12.4 Scene：每帧的调度中心

### `Scene::Simulate()`（`RPI.Public/Scene.cpp:484`）

```cpp
void Scene::Simulate(RHI::JobPolicy jobPolicy, float simulationTime)
{
    if (!m_activated) return;

    m_prevSimulationTime = m_simulationTime;
    m_simulationTime = simulationTime;

    // 上一帧的模拟可能还在跑 —— 等它
    if (m_taskGraphActive) WaitAndCleanTGEvent();
    else                   WaitAndCleanCompletionJob(m_simulationCompletion);

    // 选择并行策略
    if (jobPolicy == RHI::JobPolicy::Serial)
    {
        for (auto& fp : m_featureProcessors)
            fp->Simulate(m_simulatePacket);
    }
    else
    {
        if (m_taskGraphActive) SimulateTaskGraph();   // 新式：AZ::TaskGraph
        else                   SimulateJobs();        // 旧式：AZ::Job
    }
}
```

### 两种并行方案（`Scene.cpp:440` / `:462`）

```cpp
void Scene::SimulateTaskGraph()
{
    static const AZ::TaskDescriptor simulationTGDesc{"RPI::Scene::Simulate", "Graphics"};
    AZ::TaskGraph simulationTG{ "RPI::Scene::Simulate" };

    for (FeatureProcessorPtr& fp : m_featureProcessors)
    {
        FeatureProcessor* featureProcessor = fp.get();
        simulationTG.AddTask(simulationTGDesc, [this, featureProcessor]()
        {
            FeatureProcessor::SimulatePacket jobPacket = m_simulatePacket;
            jobPacket.m_parentJob = nullptr;
            featureProcessor->Simulate(jobPacket);
        });
    }
    simulationTG.Submit(m_simulationFinishedTGEvent.get());
}
```

**注意**：每个 FeatureProcessor 一个**独立 Task**，彼此无依赖 → 可以全并行。

**所以 FeatureProcessor 的 `Simulate` 必须线程安全**（只碰自己的数据）。这也是为什么接口注释强调"维护 N 缓冲的数据"。

### `Scene::PrepareRender()`（`:710`）

```cpp
void Scene::PrepareRender(RHI::JobPolicy jobPolicy, float simulationTime)
{
    if (!m_activated) return;

    // 等模拟完成
    if (m_taskGraphActive) WaitAndCleanTGEvent();
    else                   WaitAndCleanCompletionJob(m_simulationCompletion);

    // 通知所有 FP：开始准备渲染
    SceneNotificationBus::Event(GetId(), &SceneNotification::OnBeginPrepareRender);

    // 收集需要渲染的管线
    AZStd::vector<RenderPipelinePtr> activePipelines;
    for (auto& pipeline : m_pipelines)
    {
        if (pipeline->NeedsRender())
        {
            activePipelines.push_back(pipeline);
            pipeline->OnStartFrame(simulationTime);
        }
    }
    // ...
}
```

**这就是"模拟图"和"渲染图"的同步点**：等 `Simulate` 全部完成，才进 `PrepareRender`。

## 12.5 完整帧流程

```mermaid
sequenceDiagram
    participant App as 应用主循环
    participant Scene
    participant FP as FeatureProcessor ×28
    participant RP as RenderPipeline
    participant RHI
    participant GPU

    App->>Scene: Simulate(jobPolicy, time)
    par 并行（TaskGraph）
        Scene->>FP: Simulate(packet) ×28
    end
    Note over FP: 准备 CPU 侧数据<br/>写入 N 缓冲

    App->>Scene: PrepareRender(jobPolicy, time)
    Scene->>FP: OnBeginPrepareRender() ×28
    Scene->>RP: OnStartFrame()
    Scene->>FP: PrepareViews() → 额外 View
    Scene->>FP: Render(packet) ×28
    Note over FP: 生成 DrawPacket<br/>提交到 DrawList
    Scene->>FP: OnEndCulling()
    Scene->>FP: OnRenderEnd()

    Scene->>RP: Render()
    RP->>RHI: 提交 CommandList
    RHI->>GPU: vkQueueSubmit / ExecuteCommandLists
```

## 12.6 写一个自定义 FeatureProcessor

### 骨架

```cpp
// MyEffectFeatureProcessor.h
#pragma once
#include <Atom/RPI.Public/FeatureProcessor.h>

namespace MyProject
{
    class MyEffectFeatureProcessor final : public AZ::RPI::FeatureProcessor
    {
    public:
        AZ_RTTI(MyEffectFeatureProcessor, "{换成一个新UUID}",
            AZ::RPI::FeatureProcessor);
        AZ_CLASS_ALLOCATOR(MyEffectFeatureProcessor, AZ::SystemAllocator);

        static void Reflect(AZ::ReflectContext* context);

        // FeatureProcessor overrides
        void Activate() override;
        void Deactivate() override;
        void Simulate(const SimulatePacket& packet) override;
        void Render(const RenderPacket& packet) override;
    };
}
```

### 注册到 Scene

```cpp
// 在自己的组件或 SystemComponent 里
#include <Atom/RPI.Public/Scene.h>
#include <Atom/RPI.Public/FeatureProcessorFactory.h>

AZ::RPI::Scene* scene = AZ::RPI::RPISystemInterface::Get()->GetDefaultScene().get();
auto fp = AZ::RPI::FeatureProcessorFactory::Get()->CreateFeatureProcessor(
    azrtti_typeid<MyEffectFeatureProcessor>());
scene->AddFeatureProcessor(AZStd::move(fp));
```

### 还必须编译期注册类型

```cpp
// 在 Reflect 里
if (auto* behaviorContext = azrtti_cast<AZ::BehaviorContext*>(context))
{
    // ...
}

// 在模块初始化时（或在 SystemComponent::Activate 里）
AZ::RPI::FeatureProcessorFactory::Get()->RegisterFeatureProcessor<MyEffectFeatureProcessor>();
```

### 线程安全要点

| 阶段 | 线程 | 能做什么 |
|---|---|---|
| `Simulate` | 并行 Job（可能同时有多个 FP 在跑） | 只碰**自己**的成员；写数据缓冲 |
| `Render` | 并行 Job | 只读自己的 CPU 数据；生成 DrawPacket |
| `Activate`/`Deactivate` | 主线程 | 创建/释放 RHI 资源 |

**绝对不能**在 `Simulate`/`Render` 里做全局状态修改（如 `AZ::Interface::Get()->SetXxx()`）。

## 12.7 本机为什么渲染跑不起来

实测崩溃堆栈：

```
#4  AZ::Debug::Trace::Assert    HphaAllocator.cpp:2079
#5  AZ::HphaSchemaBase<false>::HpAllocator::tree_free
#6  libvulkan_lvp.so            ← Mesa lavapipe（软件 Vulkan）
#10 AZ::Vulkan::AsyncUploadQueue::EmmitPrologueMemoryBarrier
```

`HPPA_ASSERT(bl->used())` 是**双重释放检测**。软件 Vulkan 驱动释放了不属于它的块。

### 一个有用的发现：RHI 有 Null 后端

```
Gems/Atom/RHI/Null/
```

理论上可以用 `-DLY_RHI_BACKEND=Null` 之类的配置切到空后端（只跑逻辑不渲染）。但：

- 需要重新 configure + 编译（3 小时）
- Null 后端不产出可显示画面，只能验证逻辑

**实用替代**：直接用 `O3DE.HeadlessServerLauncher`（已验证可用），它根本不初始化 RHI。

## 12.8 渲染层的关键接口索引

| 想了解 | 位置 |
|---|---|
| FeatureProcessor 接口 | `Gems/Atom/RPI/Code/Include/Atom/RPI.Public/FeatureProcessor.h` |
| FeatureProcessor 工厂 | `.../RPI.Public/FeatureProcessorFactory.h` |
| Scene 调度 | `Gems/Atom/RPI/Code/Source/RPI.Public/Scene.cpp` |
| RenderPipeline | `.../RPI.Public/RenderPipeline.cpp` |
| RHI 抽象（171 个头） | `Gems/Atom/RHI/Code/Include/Atom/RHI/` |
| Vulkan 后端 | `Gems/Atom/RHI/Vulkan/` |
| Null 后端 | `Gems/Atom/RHI/Null/` |
| 材质系统 | `Gems/Atom/RPI/Code/Include/Atom/RPI.Public/Material/` |
| 28 个 FP 实现 | `Gems/Atom/Feature/Common/Code/Source/` |

---
