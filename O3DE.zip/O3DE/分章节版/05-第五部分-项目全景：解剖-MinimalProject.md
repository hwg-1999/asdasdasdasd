# 第五部分 · 项目全景：解剖 MinimalProject

> [← 返回索引](00-索引.md) ｜ [上一篇](04-第四部分-插件式架构.md) ｜ [下一篇](06-第六部分-运行时链路.md)

> **🎓 L0 / L1 · 认识与跑起来** ｜ 前置：无 ｜ 读完能做什么：**说清 `myproject-src` 里每个文件的作用、"最小"具体小在哪、它是怎么被创建和编译出来的**
>
> 本章对象就是工作区里的 `myproject-src`（软链接 → `/workspaces/MyProject`）。
> 所有数字都在本机实测。原先分散在「第五部分 项目全景」与「原第二十七部分 解剖 MinimalProject」的
> 内容已合并到这一章。

## 5.1 先回答"为什么叫最小"

官方的定义就一句话（`Templates/MinimalProject/template.json` 的 `summary` 字段，原文）：

> **"Use this project template to create project that is the absolute minimum needed to get started in O3DE."**

即：**"起步所需的最小集合"**。注意它说的是"起步所需"，不是"能做出游戏"。这个区分很重要。

### "最小"的四个量化维度

| 维度 | MinimalProject | DefaultProject | 倍数 |
|---|---|---|---|
| **声明的 Gem 数** | **4** | 23 | 1 : 5.75 |
| **项目源码体积**（排除 `build`/`Cache`/`user`） | **564 KB** | — | — |
| **项目自己的 C++ 文件** | **7 个**（模板原本只有 **5 个**） | 更多（含 Editor 变体） | — |
| **`Assets/` 里的资产** | **0 个文件** | 有示例资产 | ∞ |

### 4 个 Gem 是哪些，各自为什么"非它不可"

```json
"gem_names": [
    "MyProject",          // ← 你的 Gem，必须有（哪怕空的）
    "Atom",               // ← 渲染器。去掉它，引擎没有 RHI，连窗口都开不了
    "CameraFramework",    // ← 相机。没有相机就没有"看"的角度
    "ImGui"               // ← 调试面板（可选，但 MinimalProject 保留了）
]
```

| Gem | 能不能去掉 | 去掉会怎样 |
|---|---|---|
| `MyProject` | ❌ 不能 | 项目没有自己的代码载体，`external_subdirectories` 里的 `Gem` 没人引用 |
| `Atom` | ⚠️ 理论上能（换 Null RHI） | 没有渲染管线，`Atom_RPI`/`RHI` 都不加载（但 [坑 19](14-第十四部分-踩坑与排错.md#坑-19headlessserver-并不是无渲染无-gpu-时会卡死) 说明连 Headless 都要它） |
| `CameraFramework` | ✅ 能（但没用） | 没有相机组件，看不到东西 |
| `ImGui` | ✅ 能 | 少一个调试 UI，其他照常 |

**所以"4 个"不是硬性下限，而是"官方认为再少就没意义了"的实用下限。**

## 5.2 564 KB 里到底有什么（逐文件）

`du -sh --exclude=build --exclude=Cache --exclude=user .` → **564 KB**。

**注意三个要排除的目录**，它们不是项目源码：

| 目录 | 体积 | 是什么 | 进版本控制吗 |
|---|---|---|---|
| `build/` | **1.6 GB** | 项目构建树 | ❌ |
| `Cache/` | **165 MB** | AP 生成的产品资产 | ❌ |
| `user/` | **89 MB** | 日志 / Metrics / `AssetProcessorTemp` / 会话状态 | ❌ |
| 剩下的 | **564 KB** | **真正的项目源码** | ✅ |

> 🔍 **564 KB vs 1.6 GB = 源码只占构建树的 0.035%**（约 1/2900）。
> 这个比例解释了一个常见误解："项目才 500 KB，为什么编译要几小时？"——
> 因为 99.96% 的编译产物来自**引擎**，不是你的代码（[3.8](03-第三部分-编译步骤与原理.md#38--为什么项目要重编引擎核心原理)）。

### 逐文件说明（15 个关键文件）

```
/workspaces/MyProject/                     564 KB
├── project.json                    ← ★ 项目身份证（CMake 和运行时都读它）
├── CMakeLists.txt                  ← ★ 项目构建入口（找引擎 + o3de_initialize）
├── CMakePresets.json               ← IDE / 命令行预设
├── gem.json?                       ← 没有！项目本身不是 Gem（见 27.5）
├── cmake/
│   └── EngineFinder.cmake          ← ★ 怎么找到引擎（读 ~/.o3de/o3de_manifest.json）
├── Gem/                    152 KB  ← ★ 你的代码（唯一需要长期维护的地方）
│   ├── gem.json                    ← Gem 清单（gem_name: MyProject）
│   ├── CMakeLists.txt              ← 两个目标：Private.Object（静态）+ MyProject（.so）
│   ├── myproject_files.cmake       ← 6 个条目（含我加的 Heartbeat）
│   ├── myproject_shared_files.cmake← 1 个条目（Module.cpp）
│   ├── Include/MyProject/          ← 公开头文件（Bus + TypeIds）
│   └── Source/                     ← 实现（Module / SystemComponent / Heartbeat）
├── Registry/                16 KB  ← .setreg 配置（AP 扫描、Assimp、启动关卡）
├── Levels/                  32 KB  ← DefaultLevel.prefab（唯一的"场景"）
├── Assets/                 4.0 KB  ← ⚠️ **空目录（0 个文件）**
├── ShaderLib/               16 KB  ← 全局 shader 资源组（.srgi）
├── Shaders/                8.0 KB  ← 你自己的 shader 放这
├── Config/                 8.0 KB  ← shader_global_build_options.json
├── Platform/                64 KB  ← 平台配置（Linux/Windows…）
├── Resources/              188 KB  ← 图标等资源
├── game.cfg / autoexec.cfg         ← CVar 配置（8 行都不到）
└── export.sh / export.bat          ← 发布脚本（缺 ExportScripts/，见 22.2）
```

### 三个"反直觉"的点

| 现象 | 实际情况 |
|---|---|
| `Assets/` 是**空目录**（0 文件） | 因为 MinimalProject 不含任何示例资产。你的场景只有一个 `DefaultLevel.prefab`（在 `Levels/` 里） |
| 项目根**没有** `gem.json` | 只有 `Gem/gem.json`。**项目 ≠ Gem**（27.5 详解） |
| `Gem/` 里只有 **5 个源文件**（模板原本） | 因为 MinimalProject 的 Gem 是"能编译通过的空壳"：一个 Module + 一个 SystemComponent |

## 5.3 "最小"意味着缺少什么（对照 DefaultProject）

DefaultProject 有 23 个 Gem，MinimalProject 缺了 **20 个**。按能力分类：

| 缺失能力 | 对应 Gem | 后果 |
|---|---|---|
| **物理** | `PhysX5` | 没有碰撞、刚体、角色控制器 |
| **动画** | `EMotionFX` | 没有骨骼动画、动画图 |
| **音频** | `AudioSystem` / `MiniAudio` | **完全没有声音** |
| **UI** | `LyShine` | 没有游戏内 UI（按钮/文本/血条） |
| **输入映射** | `StartingPointInput` | 没有"按键 → 动作"映射层（要自己连原始输入） |
| **存档** | `SaveData` | 没有跨平台存档 API |
| **可视化脚本** | `ScriptCanvasPhysics` / `ScriptEvents` | 没有节点式脚本 |
| **调试绘制** | `DebugDraw` | 不能在场景里画线/画球 |
| **地形/植被** | `LandscapeCanvas` | 没地形系统 |
| **关卡编辑辅助** | `WhiteBox` | 没有白盒快速建模 |
| **GI** | `DiffuseProbeGrid` | 没有漫反射全局光照 |
| **Python 绑定** | `EditorPythonBindings` | Editor 里不能跑 Python 脚本 |
| **远程工具** | `RemoteTools` | 没有 Editor ↔ 运行时 远程连接 |
| **基础几何体** | `PrimitiveAssets` | 没有现成的 cube/sphere 资产 |
| **Prefab 构建** | `PrefabBuilder` | — |
| **纹理图集** | `TextureAtlas` | — |

**所以"最小项目能做什么"的诚实答案是**：

| 能做 | 不能做 |
|---|---|
| ✅ 编译出 4 种 Launcher（Game / Server / HeadlessServer / Unified） | ❌ 没有物理 |
| ✅ 加载你的 Gem 与组件 | ❌ 没有声音 |
| ✅ 跑起渲染管线（有 GPU 时） | ❌ 没有 UI |
| ✅ 加载一个 Level（`DefaultLevel.prefab`） | ❌ 没有输入映射 |
| ✅ 作为你加功能的**干净起点** | ❌ 没有动画 |

> 💡 **这恰恰是它存在的意义**：一个**没有干扰的起点**。
> 你不会在排查"我的组件为什么不工作"时，被 20 个不相干的 Gem 干扰。

## 5.4 `Gem/` 深挖：最核心的目录与两个 `.cmake` 清单

```
Gem/
├── gem.json                     ★ Gem 身份证
├── CMakeLists.txt               ★ 定义 2 个构建目标（90 行）
├── myproject_files.cmake        ★ 静态库文件清单（4 项）
├── myproject_shared_files.cmake ★ 动态模块文件清单（1 项）
├── Include/MyProject/
│   ├── MyProjectTypeIds.h          ★ 3 个 UUID
│   └── MyProjectBus.h              对外接口（目前空的）
├── Source/
│   ├── MyProjectModule.cpp         ★ 模块入口
│   ├── MyProjectSystemComponent.h  ★ 全局服务声明
│   └── MyProjectSystemComponent.cpp★ 全局服务实现
└── Platform/
    ├── Linux/PAL_linux.cmake
    ├── Linux/myproject_linux_files.cmake
    ├── Linux/myproject_shared_linux_files.cmake
    └── ...（Mac / Windows / Android / iOS 同理）
```

### ⭐ 两个 `.cmake` 清单的区别（新手第一大坑）

一个 Gem 会被编成**两个**产物：

| 文件 | 登记内容 | 编成什么 | 谁用 |
|---|---|---|---|
| `myproject_files.cmake` | `MyProjectBus.h`、`MyProjectTypeIds.h`、`MyProjectSystemComponent.cpp/.h` | **静态库** `Gem::MyProject.Private.Object` | 其他 Gem 编译时链接 |
| `myproject_shared_files.cmake` | `MyProjectModule.cpp` | **动态模块** `libMyProject.so` | 引擎运行时 `dlopen` |

**为什么分开**：

- `libMyProject.so` 运行时加载，符号不对外暴露
- 但别的 Gem 想在编译期链接你的组件类，需要一个静态库
- 所以"会被外部引用"的放静态库，只把"入口"放动态模块

**实际影响：新增 `.cpp` 必须手动加进其中一个清单。漏了 CMake 不报错、不编译。**

判断规则：

| 新增文件 | 加到哪 |
|---|---|
| 新的组件类 `XxxComponent.cpp/.h` | `myproject_files.cmake`（90% 情况） |
| 新的公开头文件 `XxxBus.h` | `myproject_files.cmake` |
| 改 `MyProjectModule.cpp` | 已在 `shared` 里，不用动 |

### `Gem/CMakeLists.txt` 逐段解读

```cmake
o3de_gem_setup("MyProject")
```
设置 `gem_name`、`gem_path`、`gem_version`、`pal_dir`。

```cmake
include(${pal_dir}/PAL_${PAL_PLATFORM_NAME_LOWERCASE}.cmake)
if(NOT PAL_TRAIT_MYPROJECT_SUPPORTED)
    return()
endif()
```
平台抽象层。`Gem/Platform/Linux/PAL_linux.cmake` 内容就一行 `set(PAL_TRAIT_MYPROJECT_SUPPORTED TRUE)`。不支持的平台直接跳过。

```cmake
ly_add_target(
    NAME ${gem_name}.Private.Object STATIC        # ← 静态库
    NAMESPACE Gem
    FILES_CMAKE
        myproject_files.cmake
        ${pal_dir}/myproject_${PAL_PLATFORM_NAME_LOWERCASE}_files.cmake
    INCLUDE_DIRECTORIES
        PUBLIC Include
    BUILD_DEPENDENCIES
        PRIVATE
            AZ::AzGameFramework
            Gem::Atom_AtomBridge.Static
)
```

```cmake
ly_add_target(
    NAME ${gem_name} ${PAL_TRAIT_MONOLITHIC_DRIVEN_MODULE_TYPE}   # ← 动态模块
    NAMESPACE Gem
    FILES_CMAKE
        myproject_shared_files.cmake
        ${pal_dir}/myproject_shared_${PAL_PLATFORM_NAME_LOWERCASE}_files.cmake
    INCLUDE_DIRECTORIES
        PUBLIC Include
    BUILD_DEPENDENCIES
        PRIVATE
            Gem::${gem_name}.Private.Object     # ← 链接上面的静态库
            AZ::AzCore
)
```

```cmake
ly_add_source_properties(
SOURCES Source/MyProjectModule.cpp
PROPERTY COMPILE_DEFINITIONS
    VALUES
        O3DE_GEM_NAME=${gem_name}               # → "MyProject"
        O3DE_GEM_VERSION=${gem_version})
```
注入宏，拼出 `CreateModuleClass_Gem_MyProject()` 供 `dlsym`。

## 5.5 `project.json` 逐字段

```json
{
    "project_name": "MyProject",
    "version": "1.0.0",
    "project_id": "{9C02BE0C-840E-494D-9F5F-2090F1BC5067}",
    "engine": "o3de",
    "engine_version": "2.6.0",
    "external_subdirectories": [ "Gem" ],
    "gem_names": [ "MyProject", "Atom", "CameraFramework", "ImGui" ]
}
```

| 字段 | 作用 | 改了会怎样 |
|---|---|---|
| `engine` | 引擎注册名 | 找不到同名引擎 → configure 失败 |
| `external_subdirectories` | 额外的 Gem 目录 | **新建 Gem 必须加**，否则不参与构建 |
| `gem_names` | 启用列表 | 去掉 Atom → 没渲染；去掉 MyProject → 你的代码不加载 |
| `project_id` | 唯一 GUID | 用于资产标识，**不要改** |

对比：`DefaultProject` 的 `gem_names` 有 **23 个**，Minimal 只有 **4 个**。

### 为什么改 `project.json` 后 `ninja` 会自动重跑 cmake

`cmake/EngineFinder.cmake:17`：

```cmake
set_property(DIRECTORY APPEND PROPERTY CMAKE_CONFIGURE_DEPENDS ${CMAKE_CURRENT_SOURCE_DIR}/project.json)
```

注册成了配置依赖，所以不用手动重配。

## 5.6 它是怎么被创建出来的

### 一条命令（两步：找模板 → 实例化）

```bash
cd /workspaces/o3de
./scripts/o3de.sh create-project \
  -pp /workspaces/MyProject \
  -pn MyProject \
  -tn MinimalProject
```

| 参数 | 含义 |
|---|---|
| `-pp` | project path（创建到哪） |
| `-pn` | project name（项目名，会替换模板里的 `${Name}`） |
| `-tn` | **template name**（用哪个模板） |

### 实例化过程做了什么（第五部分 5.1 讲过，这里补关键细节）

```
1. 复制 Templates/MinimalProject/Template/ 的 19 项
   → 含 .gitignore / .command_settings 两个隐藏项
2. 把 ${Name} 全部替换成 MyProject
   → 文件名、文件内容、CMake 变量名都替换
3. 生成新的 GUID 写进 project.json 的 project_id
   → 每个项目必须有唯一 ID（{9C02BE0C-840E-494D-9F5F-2090F1BC5067}）
4. 记下 engine_version: "2.6.0"
5. 把路径写进 ~/.o3de/o3de_manifest.json 的 projects 数组
   → 这一步让引擎"知道"这个项目存在
```

**验证第 5 步**：

```bash
python3 -c "import json;d=json.load(open('$HOME/.o3de/o3de_manifest.json'));print(d.get('projects'))"
```

### 此时还没有任何编译产物

```bash
ninja -C /workspaces/MyProject/build -n 2>/dev/null
# 可能是 unknown target —— 因为还没 configure
```

`create-project` **只复制文件**，不编译、不 configure。这是最常见的误解。

## 5.7 它是怎么被编译出来的

**关键认知：项目不是"引擎的一部分"，而是一棵独立的构建树。**

### 三个层次

```mermaid
flowchart TD
    A["引擎构建树<br/>/workspaces/o3de-build<br/>12 GB<br/>12780 个目标"] -->|"已被编译，可复用"| C
    B["项目构建树<br/>/workspaces/MyProject/build/linux<br/>1.6 GB<br/>12759 个目标"] --> C
    C["你的产物<br/>libMyProject.so 302 KB<br/>4 种 Launcher"]

    style A fill:#ffe6cc
    style B fill:#d5e8d4
    style C fill:#c0ddec
```

**注意 12780 vs 12759**：项目构建树和引擎构建树的目标数**几乎一样多**。
这就是"项目为什么要重编引擎"的量化表现（[3.8](03-第三部分-编译步骤与原理.md#38--为什么项目要重编引擎核心原理)）。

### 前置条件：五项必须全绿

编译项目前，**引擎必须已经编好**。这不是可选步骤——项目构建树要链接引擎的库。

```bash
# ① 引擎已注册（create-project 的前提）
python3 -c "import json,os;d=json.load(open(os.path.expanduser('~/.o3de/o3de_manifest.json')));print('engines:',d.get('engines'))"
# 期望：['/workspaces/o3de']

# ② 引擎构建树可用（项目要链它的 .so / .a）
ls /workspaces/o3de-build/build.ninja && ninja -C /workspaces/o3de-build -n Editor | tail -1
# 期望：ninja: no work to do.

# ③ 三方包在位（4.2 GB）
du -sh /workspaces/o3de-packages
# 期望：4.2G

# ④ 编译工具链
which clang++-18 clang-scan-deps cmake ninja

# ⑤ 磁盘余量（项目构建树 1.6 GB 起，完整 4–6 GB）
df -h /workspaces | tail -1
```

| 前置 | 缺了会怎样 | 怎么办 |
|---|---|---|
| 引擎未注册 | `create-project` 报 `Could not find engine` | `./scripts/o3de.sh register --engines /workspaces/o3de` |
| 引擎没编 | configure 能找到引擎，但链接时缺 `libAzCore.so` | 先做[第三部分](03-第三部分-编译步骤与原理.md#第三部分--编译步骤与原理) |
| 三方包缺失 | configure 尝试下载（很慢/可能超时） | 传 `-DLY_3RDPARTY_PATH=` 指向正确位置 |
| 缺 `clang-scan-deps` | 编译期 `CLANG_SCAN_DEPS-NOTFOUND`（[坑 4](14-第十四部分-踩坑与排错.md#坑-4clang_scan_deps-notfound错误延迟暴露)） | 补软链 |
| 磁盘不足 | 链接阶段 `No space left on device`（[坑 5](14-第十四部分-踩坑与排错.md#坑-5磁盘耗尽)） | 清 `.dbg` / `.tar.xz` |

### 从零到能跑：八个步骤

```mermaid
flowchart TD
    S0["⓿ 确认引擎已编<br/>ninja -n Editor → no work"] --> S1["① create-project<br/>几秒<br/>→ 564 KB 源码"]
    S1 --> S2["② 检查实例化<br/>GUID 已替换<br/>→ 可 configure"]
    S2 --> S3["③ configure<br/>140 秒<br/>→ build.ninja (12759 目标)"]
    S3 --> S4["④ 编 Gem<br/>1–3 分钟<br/>→ libMyProject.so 302 KB"]
    S4 --> S5["⑤ 编 Launcher<br/>209 个边<br/>→ 可执行 + 24 个 .so"]
    S5 --> S6["⑥ 验证产物<br/>ldd / nm"]
    S6 --> S7["⑦ 运行<br/>→ 日志出现你的组件"]

    style S3 fill:#ffe6cc
    style S4 fill:#d5e8d4
    style S5 fill:#e1d5e7
```

#### ① 创建项目（几秒）

```bash
cd /workspaces/o3de
./scripts/o3de.sh create-project \
  -pp /workspaces/MyProject \
  -pn MyProject \
  -tn MinimalProject
```

**产物**：19 个顶层项、564 KB、**零编译产物**。

#### ② 检查实例化是否成功（30 秒）

**不要跳过这一步**——实例化有 10 个占位符要替换，任何一个没换成都不会立刻报错。

```bash
cd /workspaces/MyProject

# ① GUID 必须已替换（不是 ${SysCompClassId}）
grep -E "TypeId\s*=" Gem/Include/MyProject/MyProjectTypeIds.h
# 期望：三个不同的真实 UUID，形如 "{C429B730-364B-435A-AF7C-E5D78B3D2EAC}"

# ② project_id 必须已生成
python3 -c "import json;print(json.load(open('project.json'))['project_id'])"
# 期望：{9C02BE0C-840E-494D-9F5F-2090F1BC5067}（你的会不同）

# ③ 文件/目录名不能残留占位符
find . -name "*\${*" -not -path "./build/*" | head -3
# 期望：空

# ④ license 块应已被剥离（文件开头是空行，不是 # {BEGIN_LICENSE}）
head -2 Gem/CMakeLists.txt
```

| 检查失败 | 原因 | 解法 |
|---|---|---|
| GUID 还是 `${SysCompClassId}` | 模板实例化中断 | 删掉重来 |
| 三个 GUID 相同 | 手改过 | 重新生成（[3.11](03-第三部分-编译步骤与原理.md#311-如何添加或移除组件与-gem)） |
| 残留 `${Name}` | 文件名没替换 | 删掉重来（别手改，见 27.7） |

#### ③ configure（实测 **140 秒**）

```bash
cd /workspaces/MyProject
cmake -B build/linux -S . -G Ninja \
  -DCMAKE_BUILD_TYPE=Profile \
  -DLY_3RDPARTY_PATH=/workspaces/o3de-packages
```

**产物**：`build/linux/build.ninja`（**12 759 个目标**）。

**这一步在做什么**（见下一节逐行分析）：读 `project.json` → 找引擎 → `find_package(o3de)` →
`o3de_initialize()` 遍历 `gem_names` 为每个 Gem 建目标。

**验证**：

```bash
ls build/linux/build.ninja
grep "^CMAKE_BUILD_TYPE" build/linux/CMakeCache.txt     # Profile
ninja -C build/linux -t targets all | wc -l             # 约 12759
```

> ⚠️ **`bin/profile` 目录此时是空的**——configure 只生成规则，不编译。

#### ④ 先编 Gem（实测 1–3 分钟）· **最快的健康检查**

```bash
cd /workspaces/MyProject
ninja -C build/linux -j3 MyProject
```

**产物**（本机实测）：

| 文件 | 体积 | 内容 |
|---|---|---|
| `build/linux/lib/profile/libMyProject.Private.Object.a` | **2.1 MB** | 全部实现（含 225 个 Heartbeat 符号） |
| `build/linux/bin/profile/libMyProject.so` | **302 KB** | 可加载的模块（导出 `CreateModuleClass` 等 4 个入口） |

**为什么先编这个**：它**不依赖引擎的可执行**，只依赖引擎的库。
1–3 分钟就能知道"我的代码有没有语法/链接问题"，不用等 200 个边。

**验证**：

```bash
cd build/linux

# ① 符号编出来了（查 .a，不要查 .so！见下）
nm --defined-only lib/profile/libMyProject.Private.Object.a | grep -ci 你的类名

# ② .so 是合法的可加载模块
nm -D --defined-only bin/profile/libMyProject.so | grep -E "CreateModuleClass|InitializeDynamicModule"
# 期望 4 个 T 符号

# ③ 依赖隔离：runtime 不能拖进 Qt
ldd bin/profile/libMyProject.so | grep -ci qt
# 期望 0
```

> ⚠️ **不要在 `.so` 里 grep 你的类名**：`-fvisibility=hidden` 会把组件符号变成
> **local**，`nm -D` 一定返回 0 条。这是很多人误判"代码没编进去"的原因（[3.11.3](03-第三部分-编译步骤与原理.md#3113-移除一个组件实测三阶段失败)）。

#### ⑤ 编 Launcher（实测 **209 个边**）· 最慢的一步

```bash
cd /workspaces/MyProject
ninja -C build/linux -j3 MyProject.HeadlessServerLauncher
```

**这 209 个边在做什么**（这才是"为什么这么慢"的答案）：

本机实测中途采样（前 61 条边）的真实构成：

```
Building CXX : 40 条   （其中 30 条在 External/ = 传递依赖 Gem）
Linking      : 21 条
其他（生成/拷贝）: 0 条（在最后才出现）
```

按比例推算 193 个边：

| 阶段 | 占比 | 边数（推算） | 干什么 |
|---|---|---|---|
| **编译**（`Building CXX`） | ~65% | ~125 | 其中约 **3/4 在 `External/`**——`LmbrCentral` / `Camera` / `EMotionFX` / `GradientSignal` 等传递依赖 Gem |
| **链接**（`Linking`） | ~35% | ~68 | ⚠️ 比想象中多：**每个 Gem 都要链出 `.a` + `.so` 两份**（`Camera` → `libCamera.Static.a` + `libCamera.so`） |
| `runtime_dependencies` 收尾 | — | 1 | **把 24 个 `.so` 拷到 `bin/profile/` 并生成清单** |
| 生成 `Registry/*.setreg` | — | 2 | 插件清单（运行时据此加载模块） |

**关键洞察**：链接占了 35%，因为 O3DE 的每个 Gem 同时产出**静态库**（给 Launcher 链）
和**动态库**（给运行时加载）。这是"插件式架构"的直接成本。

**这解释了"我的 Gem 才 302 KB，为什么要等这么久"**：209 个边里只有 2 个是你的
（`MyProject.Private.Object` + `MyProject`），其余全是引擎侧依赖。

**验证**：

```bash
cd build/linux
ls -lh bin/profile/MyProject.HeadlessServerLauncher    # 期望约 21–25 KB
ldd bin/profile/MyProject.HeadlessServerLauncher | grep -c "not found"   # 期望 0
```

> 💡 **`MyProject.HeadlessServerLauncher` 只有 21–25 KB** 不是错误。
> 它只是"配置壳"——`Game.cpp` 全文只有 **30 行**，返回日志文件名、是否专用服务器等常量。
> 真正的 `main()` 在 `libLauncher.Headless.Static.a` 里（`Launcher.cpp`，654 行）。
> 详见 [3.10](03-第三部分-编译步骤与原理.md#310-编译产物结构)。

#### ⑥ 验证产物（1 分钟）

```bash
cd /workspaces/MyProject/build/linux

# ① 构建树干净（没有半途而废的目标）
ninja -n MyProject.HeadlessServerLauncher | tail -1      # ninja: no work to do.

# ② 依赖完整
ldd bin/profile/MyProject.HeadlessServerLauncher | grep -c "not found"   # 0

# ③ 运行时依赖清单已生成（24 个模块）
python3 - <<'EOF'
import re
t = open('runtime_dependencies/Profile/MyProject.HeadlessServerLauncher.cmake').read()
for k in ('target_target_files','target_link_files'):
    m = re.search(k + r'\s+"([^"]*)"', t)
    print(k, len([x for x in m.group(1).split(';') if x.strip()]) if m else '?')
EOF
# 期望：target_target_files 24 / target_link_files 8

# ④ 插件清单
ls bin/profile/Registry/cmake_dependencies.*.setreg | wc -l    # 若干（每个目标一份）
```

#### ⑦ 运行（本机的真实结果）

```bash
cd /workspaces/MyProject
timeout 70 ./build/linux/bin/profile/MyProject.HeadlessServerLauncher \
  --project-path /workspaces/MyProject > /tmp/run.log 2>&1

grep -E "Attempting to load module.*MyProject|Heartbeat|Enumerated physical" /tmp/run.log
```

**本机实测输出**：

```
Module: Attempting to load module:/workspaces/MyProject/build/linux/bin/profile/libMyProject.so
MyProject: [Heartbeat] component activated, interval=2.00s
MyProject: [MyProject] SystemComponent activated
RHISystem: Initializing RHI...
RHISystem:      Enumerated physical device:       ← 空（本机无 Vulkan 设备）
```

| 看到什么 | 说明 |
|---|---|
| `Attempting to load module:...libMyProject.so` | ✅ **你的 Gem 被加载了** |
| `[Heartbeat] component activated` | ✅ **组件跑起来了**（反射、EBus、注册全对） |
| `Enumerated physical device:` 为空 | ⚠️ 本机无 GPU → 进不了 tick 循环（[坑 19](14-第十四部分-踩坑与排错.md#坑-19headlessserver-并不是无渲染无-gpu-时会卡死)） |
| `count=N` 出现 | ✅ 有 GPU 时才出现 |

### 四个 Launcher 的区别（项目一次能产出四种可执行）

```bash
ninja -C build/linux -t targets all | grep -oE "bin/profile/MyProject\.[A-Za-z]+" | sort -u
```

实测四个目标：

| 目标 | 产物 | 用途 | 定义它的宏 |
|---|---|---|---|
| `MyProject.GameLauncher` | `bin/profile/MyProject.GameLauncher` | 玩家客户端（有渲染 + 输入） | `O3DE_GAME` |
| `MyProject.ServerLauncher` | 同上 | 专用服务器（无渲染，但要 RHI 初始化） | — |
| `MyProject.HeadlessServerLauncher` | 同上 | 无头服务器（最轻） | `O3DE_HEADLESS_SERVER=1` |
| `MyProject.UnifiedLauncher` | 同上 | 客户端+服务端合一 | — |

**四个 Launcher 共用同一套源码**，区别只在编译宏和链接的变体库：

```bash
# 实测：Headless 变体多了一个宏
ninja -t commands MyProject.HeadlessServerLauncher | grep -o "O3DE_HEADLESS_SERVER=1" | head -1
# → O3DE_HEADLESS_SERVER=1
```

**所以加载的模块也不同**（[4.3 变体](04-第四部分-插件式架构.md#43-变体系统5-种应用类型)）：

| Launcher | 加载的 Atom 变体 |
|---|---|
| Game / Server | `libAtom_Feature_Common.Public.so` |
| **Headless** | `libAtom_Feature_Common.**Headless**.so` |

### 一键全编 vs 分步编

```bash
# 一键全编（推荐：构建树健康时）
ninja -C build/linux -j3

# 分步（第一次编 / 排查问题时，能定位到层）
ninja -C build/linux -j3 MyProject                  # ① Gem，最快
ninja -C build/linux -j3 MyProject.HeadlessServerLauncher  # ② 无头服务器
ninja -C build/linux -j3 MyProject.GameLauncher     # ③ 客户端（需要更多 Atom 模块）
```

### 时间与空间总账（本机实测，4 核 / 3.7 GB 可用内存）

| 步骤 | 时间 | 新增磁盘 | 备注 |
|---|---|---|---|
| ① create-project | 几秒 | 564 KB | |
| ② 检查实例化 | 30 秒 | 0 | 别跳过 |
| ③ configure | **140 秒** | ~2 MB（build.ninja） | 主要耗时在读 Gem 依赖图 |
| ④ 编 Gem | 1–3 分钟 | ~2.4 MB（.a + .so） | 最快健康检查 |
| ⑤ 编 Launcher | 见下 | ~30 MB（+ 24 个 .so） | 209 个边 |
| ⑥ 验证 | 1 分钟 | 0 | |
| ⑦ 运行 | 秒级 | 日志 | |
| **项目构建树总计** | | **1.6 GB**（含引擎库的副本） | |

**内存**：实测单个 `clang++` 进程 **568–700 MB**。
按 **1 GB/进程** 规划并行度：`j = min(核数, 可用内存GB) - 1`。

### 失败排查（按步骤定位）

| 步骤 | 症状 | 原因 | 解法 |
|---|---|---|---|
| ① | `Could not find engine` | 引擎未注册 | `./scripts/o3de.sh register --engines /workspaces/o3de` |
| ① | `Invalid template name` | `-tn` 写错 | `ls /workspaces/o3de/Templates` |
| ② | GUID 还是占位符 | 实例化中断 | 删掉重来 |
| ③ | `Could NOT find LibUnwind` | 缺系统包 | [坑 1–3](14-第十四部分-踩坑与排错.md#坑-1-3-dev-包和运行时包是两回事) |
| ③ | `unknown target Gem::Xxx` | `gem_names` 里有但引擎没编 | 先编引擎，或去掉该 Gem |
| ③ | `Could not find a compatible engine` | manifest 路径失效 | `register` 重新注册 |
| ④ | `undefined reference to vtable` | 组件没实现 | 检查 `AZ_COMPONENT_IMPL` |
| ④ | 文件不编译（静默） | 没进 `*_files.cmake` | [3.11.1](03-第三部分-编译步骤与原理.md#3111-添加一个组件三处必改--一处可选) |
| ⑤ | `No space left on device` | 磁盘不足 | [坑 5](14-第十四部分-踩坑与排错.md#坑-5磁盘耗尽) |
| ⑤ | `Killed` | 内存不足 | `-j` 降到 2 |
| ⑥ | `ldd` 有 `not found` | 缺 `.so` | 重跑 ⑤（收尾步骤会拷） |
| ⑦ | `Failed to load module` | `.so` 不在 `bin/profile` | 同样重跑 ⑤ |

### `cmake` 那一步到底在做什么（`CMakeLists.txt` 逐行）

项目的 `CMakeLists.txt` 只有 40 行，核心是四件事：

```cmake
if(NOT PROJECT_NAME)                                  # ① 防止重复初始化
    cmake_minimum_required(VERSION 3.24)
    ...
    get_engine_finder_cmake_path(".../user/project.json" ...)   # ② 找 EngineFinder
    get_engine_finder_cmake_path(".../project.json" ...)
    if(NOT engine_finder_cmake_path)
        set(engine_finder_cmake_path cmake/EngineFinder.cmake)  # 默认路径
    endif()

    include(${engine_finder_cmake_path} OPTIONAL)     # ③ 执行引擎查找
    find_package(o3de REQUIRED)                       # ★ 找到引擎（关键一步）
    project(MyProject LANGUAGES C CXX VERSION 1.0.0.0)
    o3de_initialize()                                 # ④ 加载 Gem / 生成目标
endif()
```

| 步 | 做什么 | 失败会怎样 |
|---|---|---|
| ② | 读 `project.json` 的可选字段 `engine_finder_cmake_path` | 用默认的 `cmake/EngineFinder.cmake` |
| ③ | `EngineFinder.cmake` 读 `~/.o3de/o3de_manifest.json`，挑**版本最兼容**的引擎 | `Could not find a compatible engine` |
| **`find_package(o3de REQUIRED)`** | **把引擎的 CMake 规则装进来**（`o3deConfig.cmake`） | 整个 configure 失败 |
| ④ | `o3de_initialize()` 遍历 `gem_names`，为每个 Gem 生成目标 | 目标缺失 → `unknown target` |

**`EngineFinder.cmake` 的查找优先级**（源码实证，`cmake/EngineFinder.cmake`）：

```cmake
# Option 1/2: 环境变量 O3DE_ENGINE_PATH / 项目内 engine 目录
# Option 3: 找 ~/.o3de/o3de_manifest.json 里注册的引擎（本机走这条）
set(manifest_path $ENV{HOME}/.o3de/o3de_manifest.json)
...
# 然后在多个引擎里挑版本最兼容的（O3DE_MOST_COMPATIBLE_ENGINE_VERSION）
```

> 💡 **这就是为什么"移动引擎目录后项目编不了"**：manifest 里存的是**绝对路径**。
> 引擎一挪，路径失效，`find_package(o3de)` 找不到。

### 4 个 Gem 如何变成 25 个运行时模块

这是最值得理解的一步。**声明的 Gem 只是"直接依赖"，运行时要加载的是传递闭包。**

实测启动日志（`Attempting to load module`，共 **25 条**）：

```
libMyProject.so                       ← 你的 Gem（直接）
libAtom_Bootstrap.so                  ← Atom（直接）
libAtom_RPI.Private.so                ← Atom 的私有部分
libAtom_RHI.Private.so                ← Atom 的私有部分
libAtom_RHI_Null.Private.so           ← 4 个 RHI 后端都编了，运行时按平台选
libAtom_Feature_Common.Headless.so    ← Atom 的 Feature 库（Headless 变体！）
libAtom_AtomBridge.Headless.so        ← Atom 桥接（Headless 变体）
libAtomFont.so / libImguiAtom.so / libAtomImGuiTools.so
libCamera.so                          ← CameraFramework（直接）
libCameraFramework.so                 ← CameraFramework
libLmbrCentral.so                     ← 传递依赖（很多 Gem 的基础）
libGradientSignal.so                  ← 传递依赖
libSurfaceData.so                     ← 传递依赖
libMaestro.so                         ← 传递依赖（过场动画）
libEMotionFX.so / libEMotionFX_Atom.so← 传递依赖（动画！你没显式启，但被依赖带入）
libCommonFeaturesAtom.so / libCrySystem.so / libAtomViewportDisplayInfo.so / ...
```

**三个重要发现**：

| 发现 | 说明 |
|---|---|
| **`Headless` 变体** | `libAtom_Feature_Common.Headless.so` —— 因为你跑的是 `HeadlessServerLauncher`，加载的是 Headless 变体的模块（4.3 的变体机制） |
| **`EMotionFX` 被带进来了** | 你没在 `gem_names` 里写它，但某个直接 Gem 依赖它 → **传递依赖自动带入** |
| **4 个 RHI 后端都编了** | `libAtom_RHI_Null.Private.so` 也在（这就是 [坑 19](14-第十四部分-踩坑与排错.md#坑-19headlessserver-并不是无渲染无-gpu-时会卡死) 里能选 Null 的道理） |

### 机器可读的证据：生成的插件清单

```bash
cat build/linux/bin/profile/Registry/cmake_dependencies.*.setreg
```

```json
{
    "O3DE": {
        "Gems": {
            "AtomShader": {
                "Targets": {
                    "AtomShader.Builders": { "Modules":["libAtomShader.Builders.so"] }
                }
            },
            ...
        }
    }
}
```

**这是"Gem → Target → Module"的三级映射**（[4.2](04-第四部分-插件式架构.md#42--核心机制cmake-生成插件清单) 讲的就是它的生成过程）。
运行时读这个文件，才知道"该加载哪些 `.so`"。

## 5.8 工作区里的 `myproject-src` 是什么

```bash
$ ls -la /home/hwg/tmp/ai/tmp/myproject-src
myproject-src -> /workspaces/MyProject
```

**它是符号链接，不是副本。** 用途：

| 场景 | 为什么需要它 |
|---|---|
| VS Code 资源管理器 | 工作区根在 `~/tmp/ai/tmp`，源码在 `/workspaces` **之外**，看不到 |
| clangd 后台索引 | 同上，索引器只扫工作区内的文件 |
| 读代码 | 从 `myproject-src/Gem/Source/` 进去，比记绝对路径方便 |

**不是"架子"，也不是编译产物**——它直接指向 564 KB 的真实源码（含 1.6 GB 的 `build/` 和 165 MB 的 `Cache/`）。

> ⚠️ **不要经符号链接跑构建**：`build/linux/CMakeCache.txt` 里存的是 `/workspaces/MyProject` 绝对路径。
> 用链接路径 configure 会得到路径不一致的新构建树 → 全量重编。
> **读走链接，构建走真实路径**（10.9 详述）。

## 5.9 我对这个项目做过什么（当前状态）

你现在看到的 `MyProject` **已经不完全是 MinimalProject 了**：

| 项 | 模板原样 | 现在 |
|---|---|---|
| `Gem/Source/` 文件数 | 3（Module / SystemComponent.h / SystemComponent.cpp） | **5**（+ `HeartbeatComponent.h/.cpp`） |
| `Gem/Include/` | 2（Bus / TypeIds） | 2（内容扩展了：加了 Heartbeat 总线 + 2 个 GUID） |
| `myproject_files.cmake` 条目 | 4 | **6** |
| `libMyProject.so` | 未编译 | **302 KB**（已编） |
| `libMyProject.Private.Object.a` | 无 | **2.1 MB**，含 **225 个 Heartbeat 符号** |
| 4 种 Launcher | 未编译 | 仍未编译（只到 Gem 层） |

**改动清单**（都在 [第十九部分](19-第十九部分-端到端实战：从零做一个能跑的功能.md#第十九部分--端到端实战从零做一个能跑的功能) 里有完整代码）：

```diff
  # 1. Include/MyProject/MyProjectTypeIds.h
+ HeartbeatComponentTypeId / HeartbeatNotificationsTypeId

  # 2. Include/MyProject/MyProjectBus.h
+ MyProjectRequests 加了两个纯虚方法
+ 新增 HeartbeatNotifications（Multiple handler）+ 其 Traits

  # 3. Source/HeartbeatComponent.{h,cpp}       ← 全新文件
+ 继承 AZ::Component + AZ::TickBus::Handler

  # 4. Source/MyProjectSystemComponent.{h,cpp}
+ 实现两个请求方法 + OnHeartbeat
+ Activate 时程序化创建一个带 HeartbeatComponent 的 Entity

  # 5. Source/MyProjectModule.cpp
+ #include "HeartbeatComponent.h"
+ HeartbeatComponent::CreateDescriptor()

  # 6. myproject_files.cmake
+ Source/HeartbeatComponent.cpp
+ Source/HeartbeatComponent.h
```

**如果你想回到"纯净的最小项目"**：

> ⚠️ **不要试图手动复制模板目录**。本机实测（`grep -ohE '\$\{[A-Za-z_]+\}'` 去重后
> 排除 CMake 内置变量）发现 MinimalProject 模板里有 **10 个占位符**：
>
> | 类别 | 占位符 | 被替换成 |
> |---|---|---|
> | 命名 | `${Name}` / `${NameLower}` / `${NameUpper}` / `${SanitizedCppName}` | `MyProject` / `myproject` / `MYPROJECT` / `MyProject` |
> | 元信息 | `${Version}` / `${Platforms}` / `${ProjectId}` | `1.0.0` / 平台列表 / 生成的 UUID |
> | UUID | `${Random_Uuid}` / `${ModuleClassId}` / `${SysCompClassId}` | 各不相同的新 UUID |
>
> 而且它们**出现在文件名和目录名里**（如 `Source/${Name}Module.cpp`、`Include/${Name}/`、
> `${NameLower}_files.cmake`）。`sed` 只能改内容，改不了文件名——**手抄必然漏**。

```bash
# ✅ 方案 A：整个项目重新实例化（最干净，推荐）
cd /workspaces
mv MyProject MyProject.bak            # 先留备份
cd /workspaces/o3de
./scripts/o3de.sh create-project \
  -pp /workspaces/MyProject -pn MyProject -tn MinimalProject
# 然后重新 configure + 编译（build/ 是新的，要重来）

# ✅ 方案 B：只想还原 Gem（保留 project.json / Registry 等配置）
cd /workspaces/MyProject
mv Gem Gem.bak
cd /workspaces/o3de
./scripts/o3de.sh create-gem \
  -gp /workspaces/MyProject/Gem -gn MyProject -tg DefaultGem
# ⚠️ 注意：这会用 DefaultGem 模板（比 MinimalProject 的 Gem 多 Tests/ 和 Tools/）
#    想完全对齐，还是用方案 A
```

### 为什么不建议"手动改回去"

`create-project` 实例化时做了 **5 类**事（源码实证 `scripts/o3de/o3de/engine_template.py`）：

| # | 动作 | 代码位置 | 手动做的难度 |
|---|---|---|---|
| 1 | 替换 5 个命名占位符（`${Name}` 系列） | `engine_template.py:1475-1479` | 中（还要改文件名/目录名） |
| 2 | `${Version}` → `1.0.0` | `:1800` | 易 |
| 3 | `${Random_Uuid}` → 随机 UUID，**每次出现一个新值** | `:190-191` | 中 |
| 4 | `${ModuleClassId}` / `${SysCompClassId}` → **从模板里已有的 UUID 提取**，保证同一项目内一致 | `:752-765` | **难**（要读懂提取逻辑） |
| 5 | **剥离 `{BEGIN_LICENSE}` / `{END_LICENSE}` 之间的块** | `:113-122` | 易但容易忘 |

**第 5 条解释了一个现象**：真实项目里的 `CMakeLists.txt` **开头有一个空行**、没有 license 注释——
因为那段被剥离了，只留下空行。你在模板里看到的 license 块不会出现在你的项目里。

**第 3、4 条的坑**：三个 TypeId 必须是**三个不同的 UUID**，且 Module 与 SystemComponent 的
UUID 在 `.h` 和 `.cpp` 里必须**一致**。手改很容易写成同一个值 → 运行时"类型冲突"或"组件未注册"。

## 5.10 用 MinimalProject 当起点的推荐姿势

既然它是"干净起点"，正确用法是**增量长出来**，而不是先塞满 Gem：

| 阶段 | 加什么 | 为什么这时候加 |
|---|---|---|
| **起步（当前）** | 什么都不加 | 先把"组件 → EBus → 编译 → 验证"跑通（19 部） |
| **要物理** | `enable-gem -gn PhysX5` | 这时你需要碰撞检测了 |
| **要输入** | `+ StartingPointInput` | 需要"按键 → 动作" |
| **要 UI** | `+ LyShine` | 需要血条/菜单 |
| **要声音** | `+ MiniAudio`（轻量）或 `AudioSystem`（完整） | 需要音效 |
| **要动画** | `+ EMotionFX`（可能已被传递依赖带入） | 需要骨骼动画 |
| **要调试绘制** | `+ DebugDraw` | 需要画线看碰撞体 |

**每次只加一个，加完立刻验证**（26.3 的四环节）：
改 `gem_names` → **重新 configure** → 编译 → 看日志 `Attempting to load module` → 用它的组件。

> ⚠️ **反模式**：一次性把 DefaultProject 的 23 个 Gem 全抄过来。
> 你会立刻遇到：编译时间翻倍、配置冲突、资产处理变慢，而且**分不清哪个 Gem 带来的问题**。

## 5.11 自检

- [ ] 官方对"Minimal"的定义是什么？（提示：`template.json` 的 `summary`）
- [ ] 项目源码 564 KB，构建树 1.6 GB —— 这个比例说明了什么？
- [ ] `Assets/` 里有几个文件？（答案：0）
- [ ] 项目根的 `CMakeLists.txt` 里哪一行是"找到引擎"的关键？
- [ ] 4 个 Gem 为什么会在运行时加载 25 个模块？
- [ ] 为什么 `EMotionFX` 被加载了，而你没声明它？
- [ ] 为什么项目构建树的目标数（12759）几乎等于引擎（12780）？
- [ ] `myproject-src` 是什么？为什么不能经它跑构建？
- [ ] 想回到纯净状态，改哪几个文件就够？

## 5.12 相关章节

| 想深入 | 去哪 |
|---|---|
| 项目目录每个细节 | [5.2 564 KB 里到底有什么](#52-564-kb-里到底有什么逐文件) |
| 为什么项目要重编引擎 | [3.8](03-第三部分-编译步骤与原理.md#38--为什么项目要重编引擎核心原理) |
| Gem 如何变成插件清单 | [4.2](04-第四部分-插件式架构.md#42--核心机制cmake-生成插件清单) |
| 变体系统（Headless/Client/Server） | [4.3](04-第四部分-插件式架构.md#43-变体系统5-种应用类型) |
| 在它上面写第一个功能 | [19 端到端实战](19-第十九部分-端到端实战：从零做一个能跑的功能.md#第十九部分--端到端实战从零做一个能跑的功能) |
| 加/删组件与 Gem | [3.11](03-第三部分-编译步骤与原理.md#311-如何添加或移除组件与-gem) |
| 加 Gem 的四个环节 | [25.3](25-第二十五部分-自顶向下的改造路线.md#253-加-gem从想要一个能力到它真的在跑) |
| 想改造它的路线图 | [25 改造路线](25-第二十五部分-自顶向下的改造路线.md#第二十五部分--自顶向下的改造路线) |

---
