# 第二十三部分 · 迁移对照：从 Unity / Unreal 过来

> [← 返回索引](00-索引.md) ｜ [上一篇](22-第二十二部分-发布与打包.md) ｜ [下一篇](24-第二十四部分-引擎目录结构剖析.md)

> **🎓 L0 ｜ 前置：无 ｜ 读完能做什么：把已有经验映射到 O3DE，少走一周弯路 ｜ 下一站 → 第二部分**

## 23.1 概念对照

| 你熟悉的 | O3DE 对应 | 关键差异 |
|---|---|---|
| GameObject / Actor | **Entity** | Entity **没有行为**，只是 Id + 组件列表 |
| MonoBehaviour / ActorComponent | **Component**（`AZ::Component`） | 必须**成对**写编辑器版和运行时版（或用同一个） |
| Prefab / Blueprint | **Prefab** | 支持嵌套 + Override，**没有可视化脚本**（那是 ScriptCanvas） |
| Scene | **Level**（磁盘）+ **World**（内存）+ **Scene**（渲染） | 三层概念被拆开了（17.8） |
| Asset | **`AssetId` + 产品资产** | 运行时用 UUID 不是路径（17.4） |
| Asset Import Settings | **`.setreg` + Scene Processing** | 配置在 Gem/项目层，不在每个资产上 |
| Unity Package / UE Plugin | **Gem** | 更重：代码 + 资产 + 工具 + 清单 |
| Player Settings | **`project.json` + `.setreg`** | |
| `Debug.Log` | **`AZ_Printf` / `AZ_TracePrintf`** | 需要 category |
| `Update()` | **`AZ::TickBus::Handler::OnTick`** | 或者用 `AZ::TickBus::QueueFunction` |
| Singleton / Manager | **`AZ::Interface<T>`** 或 EBus | 有编译期策略可调 |
| Event System / Delegate | **EBus** | 策略是编译期的，不是运行时的 |
| `GetComponent<T>()` | **`entity->FindComponent<T>()`** | |
| ScriptableObject | **自定义资产类型**（`CustomAssetExample`） | 要写 Asset Builder |
| Build Settings | **Variant**（Editor/Game/Server/Headless） | 见 4.3 |
| Gizmo / Editor Extension | **`AzToolsFramework` + DocumentPropertyEditor** | |
| Timeline | **Maestro / Track View** | |
| NavMesh | **RecastNavigation** | |
| Shader Graph | **Atom 的 Material Canvas / `.azsl`** | |

## 23.2 五条心智差异（比概念表更重要）

| # | 你原来的习惯 | O3DE 的现实 | 为什么要这样 |
|---|---|---|---|
| 1 | 改引擎源码来定制 | **写 Gem，永远不改引擎** | 升级引擎时你的改动不会丢 |
| 2 | 运行时按路径加载 | **运行时只有 `AssetId`** | 重命名/移动不破坏引用 |
| 3 | 组件挂在 GameObject 上就会跑 | **必须先在模块里注册 descriptor** | 反射系统需要知道类型存在 |
| 4 | 新文件自动参与编译 | **必须加进 `*_files.cmake`** | unity build + 显式清单（坑 18） |
| 5 | 编译完就能跑 | **还要过 Asset Processor** | 资产是"编译"出来的（17.2） |

**第 4 条最坑人**：它静默失败，没有警告。这是从 Unity 过来的人第一周最常卡住的地方。

## 23.3 你原来的经验哪些还有效

| 仍然有效 | 需要重学 |
|---|---|
| C++ 基本功、调试技巧 | 构建系统（CMake + Ninja + unity build） |
| 图形学概念（PBR、阴影、后处理） | Atom 的 Pass/FeatureProcessor 组织方式 |
| 组件化思维 | 组件必须注册 + 成对写编辑器版 |
| 性能分析方法论 | O3DE 的剖析工具链 |
| 版本控制实践 | 哪些进版本控制（`Assets/` 进，`Cache/` 不进） |
| 网络同步的基本概念 | O3DE 的快照 + 增量模型（第十三部分） |

## 23.4 最容易踩的五个迁移陷阱

| 陷阱 | 表现 | 正确做法 |
|---|---|---|
| 想"先跑起来再理解" | 编译 3 小时就放弃了 | 先读第三部分，**分批编译** |
| 把 Gem 当 Unity Package | 期望拖进去就能用 | Gem 要 configure + 编译 |
| 改 `Cache/` 里的文件 | 一重编就被覆盖 | 只改 `Assets/` 源资产 |
| 用文件名找资产 | 换平台/重命名后崩 | 用 `AssetId` |
| 不看日志的 category | `AZ_Printf("MyProject", ...)` 被过滤掉 | 确认日志级别与 category |

## 23.5 最后一个建议

如果你已经会 Unity 或 Unreal，**不要试图用 O3DE 复刻你熟悉的工作流**。
O3DE 的设计选择（UUID 身份、编译期策略、Gem 隔离）是有代价的——它换来了**大团队协作和长期可维护性**。

先按它的方式做一遍（第十九部分的实战），再判断哪些地方你想改。**在理解之前改造，通常是在给自己挖坑。**

---
