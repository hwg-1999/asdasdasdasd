# O3DE 完全指南

> 基于本机 `/workspaces/` 实测环境编写。所有结论都能在对应源码或输出里验证。
> 环境：Ubuntu 24.04.5 · clang 18.1.3 · CMake 3.28.3 · Ninja 1.11.1 · O3DE 2605.0（引擎版本 2.6.0）

## 目录

> **这份文档不是线性读的。** 它按**五级阶梯**组织，每一级都建立在前一级的能力之上。
> 如果你跳过某一级直接读后面，会遇到大量"看不懂但不知道哪里不懂"的情况。

### 一、五级学习阶梯

| 级别 | 名称 | 目标状态（读完后你能做什么） | 建议投入 | 硬前置 |
|---|---|---|---|---|
| **L0** | 认识 | 说清楚 O3DE 是什么、你的代码放哪、为什么不能改引擎 | 半天 | 无 |
| **L1** | 跑起来 | 在**自己的机器**上从零编出 Editor，跑通一个项目 | 1 天操作 + 5 小时机器时间 | L0 |
| **L2** | 能改 | 写自己的 Gem、加组件、加 EBus 接口、让 clangd 有提示 | 1 周 | L1（**必须有能跑的环境**） |
| **L3** | 懂架构 | 解释清楚插件怎么装配、为什么这么慢、为什么这么分层 | 1 周 | L2（**必须先写过 Gem**） |
| **L4** | 读得懂源码 | 独立走读 AzCore / Atom / 网络的实现，看懂模板元编程 | 2–4 周 | L3 |
| **L5** | 能改引擎 | 修改引擎源码、验证影响面、定位分配器级崩溃 | 长期 | L4 |

**为什么是这个顺序？**

- L1 必须在 L2 之前：**没编过就没有构建树**，L2 的所有实验都依赖 `ninja` 能跑
- L2 必须在 L3 之前：没写过 Gem 就读"插件式架构"，你只能记住结论，无法判断对错
- L3 必须在 L4 之前：L4 是"看实现"，而实现是为 L3 的"设计"服务的。**先知道要解决什么问题，再看怎么解决**
- L4 和 L5 的区别：L4 是**读**，L5 是**改**。改引擎的风险来自"不知道影响面"，而这个知识只在 L4 建立

### 二、学习路径图

```mermaid
graph TD
    L0["<b>L0 · 认识</b><br/>心智模型：引擎 / Gem / 项目<br/>约半天"]
    L1["<b>L1 · 跑起来</b><br/>编出 Editor + 跑通项目<br/>1 天 + 5 小时编译"]
    L2["<b>L2 · 能改</b><br/>写 Gem / 组件 / EBus<br/>约 1 周"]
    L3["<b>L3 · 懂架构</b><br/>九条原则 / 插件装配 / 运行时链路<br/>约 1 周"]
    L4["<b>L4 · 读源码</b><br/>EBus 内部 / 反射三层 / Atom / 网络<br/>2–4 周"]
    L5["<b>L5 · 改引擎</b><br/>影响面分析 / 分配器级排错<br/>长期"]

    L0 --> L1 --> L2 --> L3 --> L4 --> L5

    L1 -.->|"⚠️ 编不过就停在这里<br/>先解决第十四部分"| FIX["第十四部分<br/>踩坑与排错"]
    FIX -.-> L1

    L2 -.->|"写完 Gem 后<br/>回头读设计"| L3
    L3 -.->|"想验证一个猜想<br/>做第十五部分的实验"| EXP["第十五部分<br/>动手实验"]
    EXP -.-> L4

    style L0 fill:#e8f4f8
    style L1 fill:#d4e9f2
    style L2 fill:#c0ddec
    style L3 fill:#a8d0e6
    style L4 fill:#8bb8d6
    style L5 fill:#6b9dc2
```

### 三、逐级详解

#### L0 · 认识（半天）

| 项 | 内容 |
|---|---|
| **学习目标** | 建立"引擎 / Gem / 项目"三层心智模型；理解为什么定制代码不能进 `AzCore`；**搞懂资产为什么必须被处理成另一种格式** |
| **前置** | 会 C++（模板能看懂）、用过 CMake |
| **读什么** | [第一部分 · 认识 O3DE](#第一部分--认识-o3de)（全部 12 节）→ [**第二十四部分 · 引擎目录结构剖析**](#第二十四部分--引擎目录结构剖析)（先知道东西在哪）→ [**第十七部分 · 概念地图**](#第十七部分--概念地图从资产讲起)（17.1–17.7 必读，17.8 之后当字典）→ [**第十八部分 · 子系统地图**](#第十八部分--子系统地图79-个-gem-都在干什么)（扫一遍分类，知道有什么）→ [**第五部分 · 项目全景：解剖 MinimalProject**](#第五部分--项目全景解剖-minimalproject)（你现在手上的项目到底是什么）→ [**第二十五部分 · 自顶向下的改造路线**](#第二十五部分--自顶向下的改造路线)（**把以上串成一条通往“能自己改造”的路径**） |
| **动手** | 打开 `/workspaces/MyProject`，数出它有几个 Gem 依赖（答案在 5.2）；进 `Cache/linux/` 数一下产品资产有几种扩展名 |
| **自检问题** | ① 你要加一个"角色跳跃"功能，代码放引擎还是 Gem？<br/>② 为什么 `libAzCore.so` 有 25 MB，而你的 `libMyProject.so` 只有几十 KB？<br/>③ 项目目录里为什么几乎没有 C++ 代码？<br/>④ 运行时为什么不直接读 `Assets/` 里的 `.fbx`？<br/>⑤ 想做存档/寻路/UI，分别该开哪个 Gem？ |
| **常见误区** | 以为 O3DE 像 Unreal 一样"改引擎源码来定制"——这是**最容易让人放弃 O3DE 的误解** |

#### L1 · 跑起来（1 天 + 5 小时机器时间）

| 项 | 内容 |
|---|---|
| **学习目标** | 从零源码到能运行的 `Editor` / `HeadlessServer`；理解每一步在做什么、为什么这么做 |
| **前置** | L0；Linux 机器 ≥ 4 核 / ≥ 8 GB 内存 / ≥ 40 GB 磁盘（实测数据见第十一部分） |
| **读什么** | [**第三部分 · 编译步骤与原理**](#第三部分--编译步骤与原理)（**先照这个做**，每步都有验证门）→ 3.8–3.10（为什么这么编 / 产物结构）→ [附录 A](#附录-a--常用命令速查)<br/>**边做边查**：[第十四部分](#第十四部分--踩坑与排错) 坑 1–11（全部是编译期问题）<br/>**同时**：[24.12 五条建议](#2412-五条建议按优先级)（建 compdb、从 AzCore 读起） |
| **动手** | 实验 1（环境体检）→ 实验 2（从零编译）<br/>**关键：分批编译**，别一次性 `ninja`（3.5 给了四层命令） |
| **自检问题** | ① `ninja -n Editor` 输出 `no work to do` 说明什么？<br/>② 为什么第一次 configure 要 20 分钟？<br/>③ `clang-scan-deps` 是干什么的？缺了会怎样？<br/>④ Editor 可执行文件只有 21 KB，程序逻辑在哪？ |
| **卡点预警** | 编译失败 90% 是缺 `-dev` 包或 `clang-scan-deps` 路径。**先查坑 4**，别急着重装 |

#### L2 · 能改（约 1 周）

| 项 | 内容 |
|---|---|
| **学习目标** | 独立创建一个 Gem、写一个能被编辑器识别的组件、暴露一个 EBus 接口、让别的代码调用它 |
| **前置** | **L1 已完成且构建树可用**（这是硬性要求） |
| **读什么** | 5.1–5.4（项目全景）→ [第七部分](#第七部分--组件开发手册)（组件开发，**核心**）→ [第八部分](#第八部分--通信机制)（EBus / Interface）→ 9.1–9.3（资产注册）→ 第十部分（clangd）→ [**第十九部分 · 端到端实战**](#第十九部分--端到端实战从零做一个能跑的功能)（**L2 毕业设计**）→ [第二十部分 · 自动化测试](#第二十部分--自动化测试) |
| **动手** | 实验 3（写第一个组件）→ 实验 4（暴露 EBus 接口）→ **19.3–19.8 完整实战**（150 行代码，含编译验证）→ 20.3–20.5 加测试 |
| **自检问题** | ① 新加的 `.cpp` 为什么没被编译？（答案：没进 `*_files.cmake`，见坑 18）<br/>② 组件的 `Reflect()` 里为什么要分 `SerializeContext` / `EditContext` 两个分支？<br/>③ `AZ::Interface<T>` 和 `EBus` 都能做单例，选哪个？<br/>④ clangd 报找不到 `AzCore/...` 怎么办？<br/>⑤ 加组件要改哪两处？漏了各自会怎样？ |
| **卡点预警** | "改了代码没生效" 是本级最高频问题，**先查坑 18**（文件没注册到 cmake 列表，静默失败） |

#### L3 · 懂架构（约 1 周）

| 项 | 内容 |
|---|---|
| **学习目标** | 能解释 O3DE 的 7 条底层设计决策；能画出插件从磁盘到内存的完整装配链路；能解释编译慢的根本原因 |
| **前置** | L2（**必须写过 Gem**，否则本章只是背诵） |
| **读什么** | [第二部分 · 整体设计架构](#第二部分--整体设计架构) ★（2.1 九条原则，**逐条读**）→ [第四部分 · 插件式架构](#第四部分--插件式架构) ★（4.2 / 4.5 最关键）→ [第六部分 · 运行时链路](#第六部分--运行时链路) → 3.8 + 3.9（为什么重编引擎 / unity build） |
| **动手** | 实验 6（观察 Gem 加载顺序）→ 实验 7（改 `gem_names` 看产物变化） |
| **自检问题** | ① 为什么用 `AZ::Uuid` 而不是 `typeid().name()`？（2.2）<br/>② 插件扫描为什么是"三趟横向"而不是"纵向走完一个再下一个"？（4.5）<br/>③ 项目构建为什么要重编引擎目标？（3.8）<br/>④ unity build 让编译变快还是变慢？在什么情况下变慢？（3.9）<br/>⑤ 引擎怎么做到"改了 Gem 的 `.cmake` 就自动生效"？ |
| **关键** | 这一级的产出不是"记住"，而是**能对设计提出质疑**。如果读完你觉得"某些地方设计得不好"，说明你真懂了 |

#### L4 · 读得懂源码（2–4 周）

| 项 | 内容 |
|---|---|
| **学习目标** | 独立走读引擎源码；看懂 O3DE 大量使用的模板元编程与策略模式；理解"零成本抽象"在 C++ 里如何落地 |
| **前置** | L3；能读 C++17 模板代码（特化、SFINAE、`if constexpr`） |
| **读什么** | [**第十六部分 · 深挖：策略驱动的零成本抽象**](#第十六部分--深挖策略驱动的零成本抽象) ★ **新增，本级的入口**<br/>→ [第十二部分 · Atom 渲染管线](#第十二部分--atom-渲染管线代码走读)<br/>→ [第十三部分 · 多人网络架构](#第十三部分--多人网络架构)<br/>→ [**第二十一部分 · 性能剖析**](#第二十一部分--性能剖析)<br/>→ 第十一部分（实测数据，用来校准你的性能直觉）<br/>→ [附录 B](#附录-b--关键源码位置索引)（源码地图） |
| **动手** | 实验 8（读 EBus 特化表）→ 实验 9（用 `nm` 验证符号数量） |
| **自检问题** | ① `EBusAddressPolicy::Single` + `EBusHandlerPolicy::Single` 的 EBus 在内存里占几个字节？<br/>② 为什么 `EditContext` 不继承 `ReflectContext`？<br/>③ `SerializeContext` / `EditContext` / `BehaviorContext` 三者各解决什么问题，为什么不能合并成一个？<br/>④ Atom 的 RHI 如何做到"同一份代码跑 Vulkan / DX12 / Metal"？<br/>⑤ 网络同步为什么选"快照 + 增量"而不是"指令重放"？ |
| **方法建议** | **别从头读文件**。带着一个具体问题去读（例如"一个 `Connect()` 调用最终落到哪个容器？"），用 `grep` 定位，再顺着调用链读。第十六部分就是按这个方法写的范例 |

#### L5 · 能改引擎（长期）

| 项 | 内容 |
|---|---|
| **学习目标** | 安全地修改引擎源码；准确评估改动影响面；定位内存/并发级崩溃 |
| **前置** | L4；理解分配器、ABI、符号可见性 |
| **读什么** | [第十四部分 · 踩坑与排错](#第十四部分--踩坑与排错)（**全部 19 坑**，尤其坑 12–19）→ 11.4–11.6（增量编译实测，建立"改一行要多久"的直觉）→ 2.4（分配器链）+ 2.5（状态机）→ [第二十部分 · 自动化测试](#第二十部分--自动化测试)（改完能验证）→ [第二十一部分 · 性能剖析](#第二十一部分--性能剖析) → [第二十二部分 · 发布与打包](#第二十二部分--发布与打包) |
| **动手** | 改 `AzCore` 里一个函数的实现，跑完 11.5 的完整影响面测量流程 |
| **自检问题** | ① 改了 `AzCore` 私有头文件，为什么可能导致全量重编？<br/>② `-fvisibility=hidden` 下新增一个导出函数要做哪两件事？<br/>③ 如何判断一个崩溃是"分配器检测到的 double free"而不是"普通野指针"？<br/>④ 增量编译"改了没反应"，可能是哪三个层面的问题？ |
| **风险提示** | 改引擎前先 `git stash` / 建分支。**O3DE 的构建树与源码路径强耦合**（3.8 讲过原因），移动目录会导致全量重编 |

### 四、三条替代路线（按你的背景选）

| 你的情况 | 建议路线 | 跳过 |
|---|---|---|
| **只想评估 O3DE 值不值得用** | L0 → [第十七部分](#第十七部分--概念地图从资产讲起)（17.2 / 17.6）→ [第十八部分](#第十八部分--子系统地图79-个-gem-都在干什么)（看有没有你要的子系统）→ 第二部分 2.14（与其他引擎对比）→ 2.15（权衡表）→ 第十一部分 | L1–L5 全部，**不用编译** |
| **要上手做项目**（有现成构建环境） | L0 → L2（含[第十九部分实战](#第十九部分--端到端实战从零做一个能跑的功能)）→ L3 → 用到时查 L4 | L1 的编译细节 |
| **已有源码、想自己改造项目/定制 Editor** | [第二十五部分](#第二十五部分--自顶向下的改造路线)（**先看这张路线图**）→ 按它的 ①②③④⑤ 顺序走 | L4/L5 全部 |
| **要深入引擎/做二次开发** | 完整 L0→L5 | 无 |
| **只想看架构设计**（架构师视角） | 第二部分 → [第二十四部分](#第二十四部分--引擎目录结构剖析)（目录即架构）→ 第四部分 → 第十六部分 → 第十二/十三部分 | 所有编译/实验章节 |

### 五、全部章节索引

**按级别归属标注（★ = 该级别的核心章节）**

| 章节 | 归属级别 | 一句话说明 |
|---|---|---|
| [第一部分 · 认识 O3DE](#第一部分--认识-o3de) | L0 ★ | 是什么 / 版本号怎么读 / 顶层 11 目录 / 4 个启动器 / 20 个名词 / 6 个误解 / 三条入门路线 |
| [**第二部分 · 整体设计架构**](#第二部分--整体设计架构) | L3 ★ | **九条底层设计原则** + 编译选项即架构 + 架构债务清单（全文最重要一章） |
| [**第三部分 · 编译步骤与原理**](#第三部分--编译步骤与原理) | L1 ★ | 15 节：六步流程 → 每步产物 → 为何重编引擎 → unity build → 加减组件与 Gem → 预算 → 重置 |
| [第四部分 · 插件式架构](#第四部分--插件式架构) | L3 ★ | CMake 生成清单、运行时五阶段、三趟横向扫描 |
| [**第五部分 · 项目全景：解剖 MinimalProject**](#第五部分--项目全景解剖-minimalproject) | L0 / L1 ★ | 564 KB 逐文件、为何"最小"、如何创建与编译、`Gem/` 深挖、`project.json` 逐字段 |
| [第六部分 · 运行时链路](#第六部分--运行时链路) | L3 | 从 `main()` 到第一帧的完整调用链 |
| [第七部分 · 组件开发手册](#第七部分--组件开发手册) | L2 ★ | 写组件、注册、反射、调试 |
| [第八部分 · 通信机制](#第八部分--通信机制) | L2 ★ | EBus 用法 + `AZ::Interface` + 事件队列 |
| [第九部分 · 资产与配置](#第九部分--资产与配置) | L2 | Asset Processor、Settings Registry、`.setreg` |
| [第十部分 · clangd 智能提示](#第十部分--clangd-智能提示) | L2 | compilation database 生成与刷新 |
| [第十一部分 · 实测数据](#第十一部分--实测数据) | L4 | 产物体积、编译耗时、增量影响面（校准性能直觉） |
| [第十二部分 · Atom 渲染管线代码走读](#第十二部分--atom-渲染管线代码走读) | L4 ★ | RHI 抽象、Pass 系统、Feature Processor |
| [第十三部分 · 多人网络架构](#第十三部分--多人网络架构) | L4 ★ | 快照 + 增量同步、Multiplayer Gem |
| [第十四部分 · 踩坑与排错](#第十四部分--踩坑与排错) | L1 / L5 ★ | **19 个**真实坑，按"编译期 / 运行期 / 逻辑"分类 |
| [第十五部分 · 动手实验](#第十五部分--动手实验) | 贯穿 L1–L4 | **11 个**可复现实验（实验 0–10），每个都标注所属级别 |
| [**第十六部分 · 深挖：策略驱动的零成本抽象**](#第十六部分--深挖策略驱动的零成本抽象) | L4 ★ | EBus 模板特化表、三套反射上下文、`if constexpr` 分发 |
| [**第十七部分 · 概念地图：从「资产」讲起**](#第十七部分--概念地图从资产讲起) | L0 ★ | 资产四形态/三身份、管线六步、场景与运行侧全部术语 |
| [**第十八部分 · 子系统地图：79 个 Gem 都在干什么**](#第十八部分--子系统地图79-个-gem-都在干什么) | L0 | 79 个 Gem 的分类、启用决策、三条查验命令 |
| [**第十九部分 · 端到端实战**](#第十九部分--端到端实战从零做一个能跑的功能) | L2 ★ | **L2 毕业设计**：150 行代码走通组件→EBus→编译→验证 |
| [第二十部分 · 自动化测试](#第二十部分--自动化测试) | L2 / L5 | AzTest 三件套、第一个真测试、ctest 接入 |
| [第二十一部分 · 性能剖析](#第二十一部分--性能剖析) | L4 / L5 | `AZ_PROFILE`、Profiler Gem、五步测量流程 |
| [第二十二部分 · 发布与打包](#第二十二部分--发布与打包) | L2 / L5 | `export-project`、seed、pak、发布检查清单 |
| [第二十三部分 · 迁移对照](#第二十三部分--迁移对照从-unity--unreal-过来) | L0 | Unity/Unreal 概念映射 + 五条心智差异 |
| [**第二十四部分 · 引擎目录结构剖析**](#第二十四部分--引擎目录结构剖析) | L0 / L1 | 各目录体积/行数实测、依赖方向、三条找代码路线 |
| [**第二十五部分 · 自顶向下的改造路线**](#第二十五部分--自顶向下的改造路线) | L0 → L2 ★ | 改造五层级、加 Gem 四环节、定制 Editor 四条路径、首个改造任务清单 |
| [附录 A · 常用命令速查](#附录-a--常用命令速查) | L1 | 编译/验证/排错命令 |
| [附录 B · 关键源码位置索引](#附录-b--关键源码位置索引) | L4 | 想看实现时去哪找 |
| [附录 C · 版本与链接](#附录-c--版本与链接) | — | 版本、官方文档、社区入口 |

> **27 → 25 部分的合并说明**（2026-09 整理）：
> 原「第二十五部分 · 从零编译完全指南」的独有内容（先做三个决定、磁盘/内存预算、
> 每阶段总表、干净重置）已并入 **第三部分 3.12–3.15**；
> 原「第二十七部分 · MinimalProject 解剖」已整体上提为 **第五部分**，
> 并吸收原「第五部分」的 `Gem/` 深挖与 `project.json` 逐字段两节。
> 三个版本关系见 [README.md](README.md#三个版本的关系)。

---

# 第一部分 · 认识 O3DE

> **🎓 L0 · 认识** ｜ 前置：无 ｜ 读完能做什么：说清「O3DE 由什么组成、我的代码该放哪、一个项目会产出哪几个可执行文件」 ｜ 下一站 → **第二十四部分（目录结构）** → **第三部分（编译）**

## 1.1 O3DE 是什么

仓库 `README.md` 的第一句就是官方定义：

> O3DE (Open 3D Engine) is an open-source, real-time, multi-platform 3D engine that enables
> developers and content creators to build AAA games, cinema-quality 3D worlds, and
> high-fidelity simulations without any fees or commercial obligations.

把它拆成四条**可验证**的事实：

| 断言 | 证据（都能在仓库里查到） |
|---|---|
| **开源、双许可** | 15 608 个 C++ 文件里 **15 512 个（99.4%）** 带 `SPDX-License-Identifier: Apache-2.0 OR MIT`；仓库根有 `LICENSE_APACHE2.TXT` + `LICENSE_MIT.TXT` 两份（**双许可 = 你可以二选一**，不是"两个都要遵守"） |
| **实时 / 3D / 多平台** | `cmake/Platform/` 下有 Linux、Windows、Mac、Android、iOS 的完整平台层 |
| **无版税、无商业义务** | 没有 runtime fee，没有席位限制，没有"营收超过 X 要交钱"条款 |
| **游戏 + 影视 + 仿真** | 官方定位不是"只做游戏"——这正是它敢把**渲染器也做成可替换 Gem** 的动机（2.14 会讲） |

### 三个地方看到的版本号不一样，别慌

第一次接触 O3DE 一定会被版本号搞晕：**同一个版本，三处写法不同**。

| 位置 | 值 | 含义 |
|---|---|---|
| Git 分支 / tag | `2605.0` | O3DE 发行版按 `<年><月>` 编号：2026 年 05 月 |
| 提交信息 | `(26050, v 2.6.0)` | 同一件事的另一种写法 |
| `engine.json` 的 `version` | `2.6.0` | 引擎**内部**语义版本，代码里判兼容用这个 |

本机实测：

```bash
$ git log -1 --format="%s"
(Release Day Only)( Merge stabilization to main 26.05 (26050, v 2.6.0)

$ git branch --show-current
2605.0

$ python3 -c "import json;print(json.load(open('engine.json'))['version'])"
2.6.0
```

`engine.json` 里还有一组**独立的 API 版本**，它们和引擎版本**不同步**：

```json
"api_versions": {
  "editor": "1.0.0",
  "framework": "1.2.1",
  "launcher": "1.0.0",
  "tools": "1.1.0"
}
```

> **实用结论**：查资料、提 issue、找社区帖子用 **`2605.0`**；
> 写代码 / CMake 里判兼容性用 **`2.6.0`**；`api_versions` 基本只有引擎自己关心。

### 先建立数量级直觉

| 顶层目录 | 体积 | 文件数 | 里面是什么 |
|---|---|---|---|
| `Gems/` | **244 MB** | **18 103** | 所有可插拔功能——**包括 Atom 渲染器本身** |
| `Code/` | 80 MB | 8 149 | 引擎框架、工具、编辑器源码 |
| `AutomatedTesting/` | 49 MB | — | 引擎自己的测试项目（想找用法范例来这里） |
| `Assets/` | 8.7 MB | 547 | 引擎自带的最小资产 |
| `scripts/` | 4.1 MB | 331 | `o3de` CLI、打包、工具脚本 |
| `Templates/` | 3.7 MB | 641 | 项目 / Gem 模板（含 MinimalProject） |
| `cmake/` | 2.0 MB | 228 | **全部构建逻辑**（第三、四部分的主战场） |
| `Registry/` | 208 KB | 40 | 引擎级 `.setreg` 配置（2.7 讲的依赖倒置就在这里） |

**`Gems/` 比 `Code/` 大 3 倍，文件数多 2 倍**——这不是偶然。它说明一件事：
在 O3DE 里，「功能」绝大多数住在 Gem 里，`Code/` 只留**框架和不属于任何功能的基础设施**。

## 1.2 你手里有什么

| 位置 | 内容 | 体积 |
|---|---|---|
| `/workspaces/o3de` | 引擎源码 | 448 MB |
| `/workspaces/o3de-packages` | 第三方包（Qt / PhysX / Python…） | 4.2 GB |
| `/workspaces/o3de-build` | **引擎构建树**（16 个可执行程序 / 81 个 `.so` / 58 个 `.a`） | 8.0 GB（含 `.dbg` 则 12 GB） |
| `/workspaces/MyProject` | **你的项目**（MinimalProject 实例） | 源码 564 KB + 构建树 1.6 GB + Cache 165 MB |
| `~/.o3de` | 用户级配置、manifest、Python venv | 1.2 GB |

**注意这几个路径的关系**：源码 ≠ 构建树 ≠ 项目。同一个引擎源码可以被**多个项目**分别构建
（每个项目自己的构建树里都有一份引擎产物的副本，原因见 [3.8](#38--为什么项目要重编引擎核心原理)）。

## 1.3 一条最重要的心智模型

```mermaid
graph TD
  A["引擎核心 AzCore / AzFramework / Atom<br/>❌ 你永远不改"] --> B["Gem 功能包<br/>✅ 你在这里工作"]
  B --> C["C++ 组件<br/>挂到 Entity 上"]
  C --> D["场景里的对象<br/>有行为了"]
  B --> E["EBus / AZ::Interface<br/>给别的 Gem 调用"]
```

**O3DE 的定制 = 往引擎里挂 Gem，而不是改引擎。**

你的代码编成 `libMyProject.so`（实测 302 KB），运行时由引擎动态加载：

```
Module: Attempting to load module:.../libMyProject.so
[Heartbeat] component activated, interval=2.00s
```

这个隔离是**机制强制**的，不是靠自觉：

| 机制 | 效果 |
|---|---|
| 类型 ID 用 UUID（2.2） | 跨 `.so` 的类型引用不依赖 C++ 符号名 |
| 模块加载器（第四部分） | 引擎先起，Gem 后加载；加载顺序不敏感 |
| `-fvisibility=hidden`（实测 2049 处） | 默认不导出符号，接口必须显式声明 |
| Gem 的 `*_files.cmake` 清单 | 没登记的文件根本不参与编译（3.11.1 的坑） |

## 1.4 三层职责划分

| 层 | 是什么 | 谁维护 | 编译频率 |
|---|---|---|---|
| **引擎（Engine）** | 核心框架 + 工具链 + 自带 Gem | O3DE 社区 | 一次，几小时 |
| **Gem** | 一组可复用功能（代码 + 资产 + 工具 + 模板） | 你或社区 | 每个 Gem 增量 |
| **项目（Project）** | 配置：启用哪些 Gem、资产在哪、入口是啥 | 你 | 几 MB 配置 |

类比：

- **引擎** = 工厂（机床、产线、仓库全齐）
- **Gem** = 可插拔的生产模块（激光切割机、喷涂线）
- **项目** = 车间配置单（用哪几台机器、生产什么）

### 为什么这条边界值得守

| 你的做法 | 首次成本 | 升级引擎时 | 出问题找谁 |
|---|---|---|---|
| 加 Gem / 写组件 | 小时级 | ✅ 直接换引擎版本 | 你自己 |
| 改引擎私有代码 | 天级（全量重编） | ❌ 手工解决冲突 | 你自己，且社区不认 |
| 提 PR 给引擎 | 天级 + 评审周期 | ✅ 官方维护 | 社区 |

> **判断标准**：如果你的需求"必须改 AzCore 才能实现"，
> 90% 的情况是**接口用错了**——先去第八部分确认 EBus / `AZ::Interface` 能不能满足。

## 1.5 引擎仓库顶层：11 个目录

```
o3de/
├── Code/            框架 + 工具 + 编辑器（80 MB）
├── Gems/            所有功能模块（244 MB）
├── Templates/       项目 / Gem 模板
├── cmake/           全部构建逻辑
├── scripts/         o3de CLI / 打包 / 工具
├── Registry/        引擎级 .setreg
├── Assets/          引擎自带最小资产
├── AutomatedTesting/ 引擎自己的测试项目
├── Tools/           独立小工具（10 个）
├── python/          Python 运行时引导
└── Docker/          官方构建镜像
```

| 目录 | 你该不该进 | 什么时候进 |
|---|---|---|
| `Code/Framework/` | ⚠️ **只读** | 想搞懂某个机制怎么实现（第十二、十六部分） |
| `Code/Editor/` | ⚠️ 只读 | 想做 Editor 插件（25.4） |
| `Gems/` | ✅ **主战场** | 找现成功能、抄写法、看官方怎么组织一个 Gem |
| `Templates/` | ✅ 读 | 想知道新项目里每个文件哪来的（5.6） |
| `cmake/` | ✅ 读 | 编译报错、加依赖、理解"项目重编引擎"（3.8 / 第四部分） |
| `scripts/` | ✅ 用 | `create-project`、`export-project` 等命令 |
| `Registry/` | ✅ 查 | 找引擎默认配置值 |
| `AutomatedTesting/` | ✅ 抄 | **最好的用法示例库**（比文档全） |
| `Tools/` | 🟡 偶尔 | `ClassCreationWizard` 能生成组件骨架 |
| `python/` / `Docker/` | ❌ 不用 | 除非你要做 CI |

> 更细的逐目录剖析（体积、行数、依赖方向、三条找代码路线）见 **[第二十四部分](#第二十四部分--引擎目录结构剖析)**。

## 1.6 一个 O3DE 应用由什么组成

很多人以为"项目 = 一个 exe"。**O3DE 的项目会产出 4 个启动器**，本机构建树里实测：

```bash
$ grep -o "build bin/profile/[A-Za-z.]*Launcher[A-Za-z.]*" build/linux/build.ninja | sort -u
build bin/profile/MyProject.GameLauncher
build bin/profile/MyProject.HeadlessServerLauncher
build bin/profile/MyProject.ServerLauncher
build bin/profile/MyProject.UnifiedLauncher
```

它们不是四份代码，而是**同一套 Gem 代码 + 四种不同的链接配置**。
来源在 `Code/LauncherUnified/launcher_generator.cmake`：

| 启动器 | 链接的静态库 | Gem 变体 | 用途 |
|---|---|---|---|
| `<项目>.GameLauncher` | `AZ::Launcher.Game.Static` | `Clients` | 客户端 |
| `<项目>.ServerLauncher` | `AZ::Launcher.Server.Static` | `Servers` | 专用服务器（**有窗口**，`APPLICATION`） |
| `<项目>.HeadlessServerLauncher` | `AZ::Launcher.Headless.Static` | `HeadlessServers` | 无窗口服务器（`EXECUTABLE`） |
| `<项目>.UnifiedLauncher` | `AZ::Launcher.Unified.Static` | — | 一个二进制按参数扮演 client / server |

三条关键证据：

```cmake
# 1) 两种 server 启动器的类型不同
set(SERVER_LAUNCHERTYPE_ServerLauncher APPLICATION)
set(SERVER_LAUNCHERTYPE_HeadlessServerLauncher EXECUTABLE)

# 2) Gem 变体决定"哪些 Gem 会加载"
ly_set_gem_variant_to_load(TARGETS ${project_name}.GameLauncher VARIANTS Clients)

# 3) 这个 define 让 Settings Registry 只加载对应启动器的 .setreg
COMPILE_DEFINITIONS LY_CMAKE_TARGET="${project_name}_${server_launcher_type}"
```

> 这就是为什么 `Registry/` 里同一份配置有 `streamer.launcher.setreg`、
> `streamer.editor.setreg`、`streamer.launcher.profile.setreg` 这么多名字——
> **配置按"加载它的那个目标"分流**。

### 为什么 `Editor` 只有 21 KB

```
-rwxr-xr-x  21K  bin/profile/Editor
-rwxr-xr-x  32M  bin/profile/libEditorLib.so
-rwxr-xr-x  12M  bin/profile/AssetProcessor
-rwxr-xr-x  25M  bin/profile/libAzCore.so
```

**`Editor` 是个"壳"**：它只做参数解析、加载 `libEditorLib.so`、然后调进去。
真正的编辑器逻辑在 32 MB 的共享库里。

这个模式在 O3DE 里反复出现：**小可执行文件 + 大共享库**。
好处是工具/插件可以复用同一份实现；代价是启动时要解析大量符号（这也是编辑器启动慢的原因之一）。

## 1.7 名词速查：20 个最小定义

| 名词 | 一句话定义 | 详见 |
|---|---|---|
| **Engine（引擎）** | 框架 + 工具链 + 自带 Gem，一次编译多处复用 | 1.4 |
| **Project（项目）** | 一份配置：启用哪些 Gem、资产在哪、入口是啥 | 5.5 |
| **Gem** | 可插拔功能包（代码 + 资产 + 工具 + 模板），**连渲染器都是 Gem** | 第四部分 |
| **Entity** | 一个 ID + 一组组件 + 一个状态机。**本身没有行为** | 2.6 |
| **Component** | 挂在 Entity 上的功能单元，是**行为的唯一载体** | 第七部分 |
| **EBus** | 引擎内的"总线"，按接口分发调用；同一接口可有多个处理器 | 第八部分 |
| **`AZ::Interface<T>`** | 单例式服务注册表，比 EBus 更轻，适合"一个实现"的场景 | 8.6 |
| **ReflectContext** | 反射注册的入口，Serialize / Edit / Behavior 三种上下文 | 2.10 |
| **Asset（资产）** | 源文件（`.fbx`/`.png`/`.scriptcanvas`…） | 17.2 |
| **Source Asset** | 美术/设计师给的原件 | 17.2 |
| **Product Asset** | Asset Processor 转换后的产物，运行时只读它 | 17.3 |
| **Asset Processor** | 后台服务：监听源资产变化 → 自动重新转换 | 第九部分 |
| **AP Cache** | 产物缓存目录（本项目 165 MB） | 9.2 |
| **Level** | 一个可加载的场景（现在本质上是 Prefab） | 17.5 |
| **Prefab** | 可嵌套复用的实体树模板，支持覆盖（override） | 17.5 |
| **`.setreg`** | JSON 格式的配置补丁，按加载顺序叠加 | 2.7 / 第九部分 |
| **Settings Registry** | 全局配置树，也是"事件总线"（生命周期事件走这里） | 2.7 |
| **AzCore / AzFramework** | 核心层 / 框架层，前者不依赖后者 | 2.12 |
| **AzToolsFramework** | 只在 Editor 里链接的工具框架（24 万行） | 2.12 |
| **Launcher** | 最终可执行程序，有 Game / Server / Headless / Unified 四种 | 1.6 |

> 完整的概念地图（资产四形态 / 三身份、管线六步、运行侧全术语）见 **[第十七部分](#第十七部分--概念地图从资产讲起)**。

## 1.8 环境能力现状

| 能力 | 状态 | 说明 |
|---|---|---|
| 命令行编译 | ✅ | |
| HeadlessServer / ServerLauncher 启动 | ⚠️ **部分** | **会初始化 RHI**（`RHISystem: Enumerated physical device:` 为空）→ 无 GPU 时卡在 shader 变体反序列化，进不了 tick 循环 |
| 自主逻辑 / 组件激活 | ✅ | 实测能加载自己的 Gem 并输出 `[Heartbeat] component activated` |
| ProjectManager GUI | ✅ | 纯 Qt，不碰 Vulkan |
| AssetProcessor | ✅ | |
| **Editor GUI** | ❌ | 本机只有软件 Vulkan（lavapipe），触发 HPHA 分配器断言崩溃 |

> ⚠️ **"Headless" 不等于 "无渲染"**（本机实测校正）：`O3DE.HeadlessServerLauncher`
> 仍会加载 `libAtom_RHI_*.so` 并枚举 Vulkan 设备，只是不开窗口。
> 无可用设备时它不会干净退出，而是倒在一堆 `ShaderStageFunction is not registered with the serializer` 错误上。
> 想真正不碰 RHI，需要一个**不启用 Atom** 的项目（或换 `Atom_RHI_Null` 平台配置）。

详见 [坑 15：Editor 段错误](#坑-15editor-段错误本机硬限制)。

## 1.9 六个常见误解

| # | 误解 | 实际 | 证据 |
|---|---|---|---|
| 1 | "O3DE 就是一个编辑器" | 引擎 = 框架 + 运行时 + 工具集；**Editor 只是其中一个工具**（21 KB 的壳） | 1.6 |
| 2 | "Headless 就是无渲染" | 仍初始化 RHI，只是不开窗口 → 无 GPU 时会卡住 | 1.8 / 坑 19 |
| 3 | "引擎编一次，项目直接用" | 项目有**自己的构建树**，会把引擎再编一遍 | 3.8 |
| 4 | "Gem 就是一个 DLL" | Gem 是**打包单元**：代码 + 资产 + 工具 + 模板 + `gem.json` 元数据 | 3.11.5 |
| 5 | "改了资产文件就能跑" | 运行时只读 **Product Asset**，必须经过 Asset Processor | 第九部分 |
| 6 | "改引擎最快" | 改引擎 → 全量重编（小时级）+ 升级冲突；加 Gem → 增量（分钟级） | 1.4 |

## 1.10 第一次打开该做什么：三条 15 分钟路线

| 你的目的 | 做什么 | 看哪 |
|---|---|---|
| **只想看看它长什么样** | 不编译，直接读代码：`ls Gems/`、打开 `Templates/MinimalProject/`、`git log --oneline -20` | 1.5 → 第二十四部分 |
| **想把它跑起来** | 直接照 [第三部分](#第三部分--编译步骤与原理) 做（先做 3.12 的三个决定） | 第三部分 |
| **手上已经有项目** | 先弄懂手上是什么：5.2 逐文件、5.7 编译八步、5.9 当前状态 | 第五部分 |

**别做的事**（新手三大时间黑洞）：

1. ❌ 一上来 `ninja` 全量编译——出错不知道错在哪，改用 3.5 的分批
2. ❌ 先从 `Code/Editor/`（13 万行）读起——先读 `AzCore` 的一个小机制（如 `TypeInfo`）
3. ❌ 直接改引擎源码试效果——先用 Gem 写一个组件（第七部分）

## 1.11 自检

读完这一部分，你应该能回答：

- [ ] `Gems/` 为什么比 `Code/` 还大？这说明 O3DE 的什么设计取向？
- [ ] `2605.0` 和 `2.6.0` 分别该在什么场合用？
- [ ] 一个 MinimalProject 会产出几个可执行文件？它们共享代码吗？
- [ ] 为什么 `Editor` 只有 21 KB，编辑器逻辑在哪？
- [ ] "Headless 不等于无渲染"这句话的实际后果是什么？
- [ ] 你的需求应该做成 Gem 还是改引擎？判断依据是什么？

## 1.12 相关章节

| 想更深入 | 去哪 |
|---|---|
| 目录逐个剖析（体积、行数、找代码路线） | [第二十四部分](#第二十四部分--引擎目录结构剖析) |
| 底层设计原则（九条）与架构债务 | [第二部分](#第二部分--整体设计架构) |
| 手上这个 MinimalProject 到底是什么 | [第五部分](#第五部分--项目全景解剖-minimalproject) |
| 名词的完整概念地图 | [第十七部分](#第十七部分--概念地图从资产讲起) |
| 编译它 | [第三部分](#第三部分--编译步骤与原理) |

# 第二部分 · 整体设计架构

> **🎓 L3 · 懂架构 ★核心** ｜ 前置：L2（**必须先写过 Gem**） ｜ 读完能做什么：解释 9 条底层设计决策，并用编译选项/符号表自证 ｜ 下一站 → **第四部分（L3）**

> 本章是整份文档的核心。所有结论都来自 `Code/Framework/AzCore` 的实际源码（**873 个头文件 / 602 个 cpp / 约 42 万行**），
> 以及本机 `build.ninja` / `nm` / `grep` 的实测输出。
> 目的不是讲"怎么用"，而是讲**为什么这样设计**——那些你在写业务代码时感受不到、但决定了整个引擎形态的底层决策。

## 2.1 九条核心设计原则

先给出结论，后面逐条展开证据。

| # | 原则 | 代码证据 | 解决什么问题 |
|---|---|---|---|
| 1 | **跨二进制稳定的类型标识** | `using TypeId = AZ::Uuid;` | 类型信息要能存盘、跨 DLL、给脚本用 |
| 2 | **类型擦除后再查询** | `IRttiHelper` 抽象接口 | 序列化时不知道具体类型，仍要能操作 |
| 3 | **编译期多态优先于运行时** | `EBusTraits` 8 个 constexpr 策略 | 零开销抽象 |
| 4 | **分配器可组合** | `ChildAllocatorSchema<Base>` | 每子系统独立统计/追踪/策略 |
| 5 | **显式状态机 + 结构冻结** | `Entity::State` 8 态 | 消除重入与中间态 bug |
| 6 | **依赖倒置** | 生命周期事件经 Settings Registry 广播 | 核心不依赖上层 |
| 7 | **渐进式演进而非推翻重来** | Job（旧）+ TaskGraph（新）并存 | 十年级代码库的现实约束 |
| 8 | **异常关闭，错误即返回值** | 全树 `-fno-exceptions`（2 049 处）+ `AZ::Outcome`（1 733 处） | 确定性、跨模块安全 |
| 9 | **反射是唯一的数据模型** | 4 651 个 `Reflect()`；`EditContext` 挂在 `SerializeContext` 上 | 运行时不必依赖编辑器 |

> **读法建议**：原则 1–7 是"引擎怎么组织自己"，原则 8–9 是"引擎怎么和 C++ 语言/工具链打交道"。
> 如果你时间有限，先读 1、3、9——这三条决定了你写代码时的全部日常体验。

## 2.2 原则 1：用 UUID 而不是 `typeid`

### 事实

`Code/Framework/AzCore/AzCore/RTTI/TypeInfoSimple.h:20`：

```cpp
/**
* Used to reference unique types by their unique id.
*/
using TypeId = AZ::Uuid;
```

类型 ID 是 **UUID**，而且**硬编码在源码里**：

```cpp
#define AZ_TYPE_INFO_SPECIALIZE(_ClassType, _ClassUuid) \
    AZ_TYPE_INFO_INTERNAL_SPECIALIZE_WITH_NAME(_ClassType, #_ClassType, _ClassUuid)

// 展开后
_Inline AZ::TypeId GetO3deTypeId(AZ::Adl, AZStd::type_identity<_ClassName>) \
{ \
    constexpr AZ::TypeId typeId{ _ClassUuid }; \    // ← 字面量，不是算出来的
    return typeId; \
}
```

你项目的 `MyProjectTypeIds.h` 就是这个机制的产物：

```cpp
inline constexpr const char* MyProjectSystemComponentTypeId = "{C429B730-364B-435A-AF7C-E5D78B3D2EAC}";
```

### 为什么不用 `typeid` / `std::type_index`

这是**根本性决策**。C++ 标准 RTTI 有三个致命问题：

| 问题 | 后果 |
|---|---|
| **不稳定**：`typeid(T).name()` 是实现定义（GCC 是 mangled name，MSVC 是 `class X`） | 换编译器/换版本 → 类型名全变 |
| **不可序列化**：`type_info` 只有运行时地址，无法写进文件 | 关卡存盘无法记录"这个组件的类型" |
| **不跨 DLL/DSO**：`type_info` 的相等性在跨动态库时依赖实现 | 插件系统直接失效 |

**O3DE 的插件式架构（第四部分）能成立，前提就是类型 ID 稳定。** 没有稳定 ID 就没有：

- 关卡文件里的组件类型引用（`{C429B730-...}` 存进 `.prefab`）
- 跨 `.so` 的类型查找（`libMyProject.so` 用 UUID 请求 `libAzCore.so` 的类型）
- 脚本绑定（Lua 里按名字/UUID 找类型）
- 网络同步（`NetEntityId` + 组件 UUID）

### 代价与配套设计

**代价：必须人工分配 GUID。** 这就解释了为什么 O3DE 到处是 `{XXXXXXXX-XXXX-...}`，以及为什么新组件的第一个坑就是"生成唯一 GUID"。

**配套：`AzTypeInfo` 还支持组合式 ID**（`TypeInfoSimple.h:527`）：

```cpp
constexpr AZ::TypeId prefixUuid{ "{2FCDBAB3-45E0-4159-A91D-FD1D37056C0F}" };
constexpr AZ::TypeId postfixUuid{};
```

以及指针类型 ID 的推导（`:55`）：

```cpp
// Represents an identifier that can modify an existing typeid "T" to form a new "T*" typeid
inline constexpr AZ::TypeId PointerId_v{ "{35C8A027-FE00-4769-AE36-6997CFFAF8AE}" };
```

**`T*` 的类型 ID = `T` 的 ID 与一个固定修饰 UUID 的组合。** 这意味着类型系统支持**派生类型 ID**，而不需要为每个指针类型单独分配 GUID。

### 一个巧妙的 ADL 技巧

`TypeInfoSimple.h:69-84`：

```cpp
// Tag Type inside the AZ Namespace, which is added supplied as the first
// argument to function calls of GetO3deTypeName, GetO3deTypeId, GetO3deClassTemplateId
// This allow Argument Dependent Lookup(ADL) to find overloads of these functions
// in the AZ namespace
// Therefore allowing for existing overloads for types not declared in the AZ
// namespace to be picked up
struct Adl {};

_Inline AZ::TypeId GetO3deTypeId(AZ::Adl, AZStd::type_identity<_ClassName>)
```

**问题**：想给第三方类型（如 `AZStd::allocator`，在 `AZStd` 命名空间）添加类型信息，但不能侵入它的命名空间。

**解法**：函数第一个参数是 `AZ::Adl` tag，ADL 就会去 `AZ` 命名空间找重载，于是宏可以写在任意位置。

**这是"非侵入式扩展"的经典手法**，和 `std::hash` 特化是一个思路，但更灵活（不受命名空间限制）。

## 2.3 原则 2：类型擦除后仍可查询

### 问题

序列化系统遍历一个对象时，手里只有 `void*` 和"某个类型 ID"。它需要：

- 知道这个类型有多大
- 把 `void*` 安全地转换成某个基类的指针
- 判断它是不是某个类型
- 枚举它的继承层次

但此时**模板参数 `T` 已经不在了**。

### 解法：`IRttiHelper` 抽象接口

`RTTI.h:31-50`：

```cpp
class IRttiHelper
{
public:
    virtual AZ::TypeId   GetActualUuid(const void* instance) const = 0;
    virtual const void*  Cast(const void* instance, const AZ::TypeId& asType) const = 0;
    virtual void*        Cast(void* instance, const AZ::TypeId& asType) const = 0;
    virtual AZ::TypeId   GetTypeId() const = 0;
    virtual AZ::TypeId   GetGenericTypeId() const = 0;
    virtual bool         IsTypeOf(const AZ::TypeId& id) const = 0;
    virtual bool         IsAbstract() const = 0;
    virtual bool         ProvidesFullRtti() const = 0;
    virtual void         EnumHierarchy(RTTI_EnumCallback callback, void* userData) const = 0;
    virtual TypeTraits   GetTypeTraits() const = 0;
    virtual size_t       GetTypeSize() const = 0;
};
```

**所有方法只操作 `void*` 和 `TypeId`，不出现任何模板参数。** 这就是类型擦除。

而官方注释点明了用途（`RTTI.h:76-84`）：

> Call `GetRttiHelper<T>()` to retrieve an `IRttiHelper` interface for AZRtti-enabled types **while type info is still available**, so it **can be used for queries after type info is lost**.

**"在类型信息还在时获取 helper，之后类型信息丢失了仍能用它查询。"**

### 双轨实现（重要的性能设计）

`RTTI.h` 里有两个实现：

| 实现 | 条件 | `ProvidesFullRtti()` | `Cast` 能力 |
|---|---|---|---|
| `RttiHelper<T>` | 类型有 `AZ_RTTI` | `true` | 完整运行时转换（`RTTI_AddressOf`） |
| `TypeInfoOnlyRttiHelper<T>` | 类型只有 `AZ_TYPE_INFO` | **`false`** | 只支持同类型（`asType == GetTypeId()`） |

```cpp
// TypeInfoOnlyRttiHelper 的 Cast
const void* Cast(const void* instance, const AZ::TypeId& asType) const override
{
    return asType == GetTypeId() ? instance : nullptr;   // ← 不支持继承转换
}
```

**为什么分两轨**：

- 只有 `AZ_TYPE_INFO` 的简单类型（`int`、`float`、POD struct）**不付虚函数表代价**
- 需要多态的类型才付完整 RTTI 开销

`ProvidesFullRtti()` 让调用方能提前判断"这个类型的 Cast 是否可信"。

### 编译期优化：DECL/IMPL 分离

`TypeInfoSimple.h:98-112`：

```cpp
// Helper Macros which provides declaration of TypeInfo methods
// Useful for reducing build times by moving implementation to a translation unit
#define AZ_TYPE_INFO_INTERNAL_SPECIALIZE_WITH_NAME_DECL(_ClassName) \
    AZ::TypeNameString GetO3deTypeName(AZ::Adl, AZStd::type_identity<_ClassName>); \
    AZ::TypeId GetO3deTypeId(AZ::Adl, AZStd::type_identity<_ClassName>);
```

**注释直说："Useful for reducing build times by moving implementation to a translation unit"**

这解释了 `libAzCore.so` 为什么是 25 MB：**大量模板实例化被集中到一个 .cpp 里产出一次**，而不是在每个包含它的 TU 里重复实例化。

**这是大型 C++ 项目的标准降编译时间手法**，O3DE 把它做成了系统化的宏对（`_DECL` / `_IMPL` / `_IMPL_INLINE`）。

## 2.4 原则 3：Policy-Based Design —— EBus 的 8 个编译期维度

### `EBusTraits` 的完整策略面

`EBus/EBus.h:80-175`（原文注释摘要）：

```cpp
template<class InterfaceType, class Traits = EBusTraits>
struct EBusTraits
{
    // ① 分配器
    using AllocatorType = AZ::Internal::EBusEnvironmentAllocator;

    // ② handler 数量与顺序
    static constexpr EBusHandlerPolicy HandlerPolicy = EBusHandlerPolicy::Multiple;

    // ③ 地址策略
    static constexpr EBusAddressPolicy AddressPolicy = AZ::EBusAddressPolicy::Single;

    // ④ 地址 ID 类型（仅 ById 时用）
    using BusIdType = NullBusId;

    // ⑤ 地址排序
    using BusIdOrderCompare = NullBusIdCompare;

    // ⑥ handler 排序
    using BusHandlerOrderCompare = BusHandlerCompareDefault;

    // ⑦ 锁策略
    using MutexType = NullMutex;

    // ⑧ 事件队列
    static constexpr bool EnableEventQueue = false;
    static constexpr bool EventQueueingActiveByDefault = true;
    static constexpr bool HasSlots = false;
    // ...
};
```

### 为什么这是"零开销"的关键

全部是 `constexpr` 常量或类型别名，**没有任何运行时分支**。`EBus<Interface, Traits>` 用这些参数特化出完全不同的实现：

| 策略组合 | 生成的数据结构 | 运行时开销 |
|---|---|---|
| `Single` + `Single` | 一个函数指针 | ≈ 直接调用 |
| `ById` + `Multiple` | 哈希表 + 每槽 vector | 哈希查找 + 遍历 |
| `Single` + `Multiple` | 一个 vector | 遍历 |
| `ByIdAndOrdered` + `MultipleAndOrdered` | 有序容器 | 插入排序 + 遍历 |

### `MutexType = NullMutex` 是精髓

默认值是**空锁**——单线程场景下连接/派发**完全没有锁开销**。

需要多线程时，显式改成 `AZStd::mutex` 或 `AZStd::recursive_mutex`。注释还给了选择指南：

> - 简单多线程：`AZStd::mutex`
> - 事件处理器**在处理事件时又发事件/连接/断开同一总线**：`AZStd::recursive_mutex`
> - 需要"事件可并行执行，但不能与 connect/disconnect 并行"：自定义 mutex + 自定义 LockGuard policy

**这是"默认零成本，按需付费"的典范。** 也解释了为什么 `libAzCore.so` 有 2194 个 EBus 导出符号但性能仍可接受。

### 对照：为什么不用虚函数做多态

如果用虚函数实现总线策略：

```cpp
// ✗ 假想的糟糕设计
class IEBus {
    virtual void Dispatch(...) = 0;   // 每次派发一次虚调用
};
```

每次派发都有间接跳转 + 无法内联。而 **policy-based design 把选择移到编译期**，编译器能看到完整实现并内联。

**代价：需要为每种策略组合生成一份代码（代码膨胀）。** 这就是 `libAzCore.so` 25 MB 的另一半原因。

## 2.5 原则 4：分配器可组合链

### 事实

`Memory/ChildAllocatorSchema.h:22-45`：

```cpp
//! Helper macro to define a child allocator with a custom name for the allocator
//! It provides the following types
//! "<_ALLOCATOR_CLASS>" for use with the AZ::AllocatorInstance template and the AZ_CLASS_ALLOCATOR macro
//! "<_ALLOCATOR_CLASS>_for_std_t" for use with AZStd container types
//! Ex. AZ_CHILD_ALLOCATOR_WITH_NAME(FooAllocator, "Foo", "{...}", AZ::SystemAllocator)
#define AZ_CHILD_ALLOCATOR_WITH_NAME(_ALLOCATOR_CLASS, _ALLOCATOR_NAME, _ALLOCATOR_UUID, _ALLOCATOR_BASE) \
    class _ALLOCATOR_CLASS \
        : public AZ::ChildAllocatorSchema<_ALLOCATOR_BASE> \
    { \
        ...
        AZ_RTTI_NO_TYPE_INFO_DECL(); \
    };
```

### 结构

```mermaid
graph TD
  A["OSAllocator<br/>malloc/mmap"] --> B["SystemAllocator<br/>HPHA 池化堆"]
  B --> C["FooAllocator<br/>ChildAllocatorSchema&lt;SystemAllocator&gt;"]
  B --> D["BarAllocator"]
  C --> E["BazAllocator<br/>ChildAllocatorSchema&lt;FooAllocator&gt;<br/>（多层嵌套）"]
```

每个分配器都实现 `IAllocator`（`Memory/IAllocator.h`）：

```cpp
virtual pointer   allocate(size_type byteSize, align_type alignment = 1) = 0;
virtual size_type deallocate(pointer ptr, size_type byteSize = 0, align_type alignment = 0) = 0;
virtual size_type max_size() const;
virtual size_type get_allocated_size(pointer ptr, align_type alignment = 1) const = 0;
virtual void      GarbageCollect();
virtual size_type NumAllocatedBytes() const;       // ← 独立统计
virtual void      SetRecords(Debug::AllocationRecords* records);
virtual void      SetProfilingActive(bool active);
```

### 设计价值

| 能力 | 实现方式 |
|---|---|
| **每子系统独立内存统计** | `NumAllocatedBytes()` 逐层累加 |
| **独立泄漏追踪** | `SetRecords()` 只在关心的子系统开启 |
| **独立分配策略** | 子分配器可以是池/栈/双缓冲 |
| **内存预算控制** | 可以给某个子系统设上限 |
| **分配器也参与 RTTI** | `AZ_RTTI_NO_TYPE_INFO_DECL()` → 运行时能问"这块内存属于谁" |

**这解释了为什么崩溃日志里能看到 `AZ::HphaSchemaBase<false>::HpAllocator::tree_free`** ——分配器不是透明的 `malloc` 包装，而是有可观测的内部状态。

### `AZ_CLASS_ALLOCATOR` 如何接入

```cpp
class MyComponent
{
    AZ_CLASS_ALLOCATOR(MyComponent, MyProjectAllocator);   // 指定用哪个分配器
};
```

宏展开后重载 `operator new/delete`，把分配重定向到指定分配器。**这是"类级别的分配策略"**，不侵入业务代码。

## 2.6 原则 5：显式状态机 + 结构冻结

### `Entity::State` 的 8 个状态（`Component/Entity.h:53-63`）

```cpp
enum class State : u8
{
    Constructed,    ///< 构造完成，未初始化
    Initializing,   ///< 过渡：Constructed → Init
    Init,           ///< 已初始化，**可增删组件**
    Activating,     ///< 过渡：Init → Active
    Active,         ///< 完全激活，**不可增删组件**（除非先 Deactivate）
    Deactivating,   ///< 过渡：Active → Init
    Destroying,     ///< 过渡：Init → Destroyed
    Destroyed       ///< 已销毁
};
```

### 两个关键设计

**① 过渡状态是显式的**

`Initializing` / `Activating` / `Deactivating` / `Destroying` 都是独立状态。这允许：

- 检测重入（"你正在激活，不能再激活一次"）
- 正确的错误处理（激活失败 → 回滚到 Init）
- 状态变化事件（`EntityStateEvent = Event<State, State>`，新旧状态都传）

**② 结构冻结不变式**

注释明确：

> You **cannot** add or remove components from the entity unless you first deactivate the entity.

**为什么**：如果激活后还能增删组件，就会遇到：

- 新组件的依赖还没激活，但 Entity 已是 Active
- 遍历组件列表时列表被修改
- 已缓存的组件索引失效

**解法：把"修改结构"限制在 `Init` 状态。** 这是用**状态机把并发/重入问题转成状态合法性检查**。

### 依赖排序

```cpp
//! Represents whether an entity can be activated.
//! An entity cannot be activated unless all component dependency requirements are met, and
//! components are sorted so that each can be activated before the components that depend on it.
enum class DependencySortResult
```

**引擎自动做拓扑排序**：你只声明 `GetRequiredServices` / `GetProvidedServices`，激活顺序不用管。

## 2.7 原则 6：依赖倒置 —— 生命周期事件用 Registry 作信使

### 完整的事件清单（`Registry/application_lifecycle_events.setreg`）

```json
{
    "O3DE": {
        "Application": {
            "LifecycleEvents": {
                "SystemComponentsActivated": {},
                "SystemComponentsDeactivated": {},
                "ReflectionManagerAvailable": {},
                "ReflectionManagerUnavailable": {},
                "SystemAllocatorCreated": {},
                "SystemAllocatorPendingDestruction": {},
                "SettingsRegistryAvailable": {},
                "SettingsRegistryUnavailable": {},
                "ConsoleAvailable": {},
                "ConsoleUnavailable": {},
                "GemsLoaded": {},
                "GemsUnloaded": {},
                "FileIOAvailable": {},
                "FileIOUnavailable": {},
                "LegacySystemInterfaceCreated": {},
                "CriticalAssetsCompiled": {},
                "LegacyCommandLineProcessed": {}
            }
        }
    }
}
```

### 三个设计要点

**① 成对设计（Available / Unavailable）**

不是单向事件，而是**生命周期区间**。这让订阅者能安全地做资源管理：

```cpp
// 假想的订阅逻辑
OnFileIOAvailable  → 打开配置文件
OnFileIOUnavailable → 关闭所有文件句柄
```

**这是 RAII 思路在跨模块通信上的应用。**

**② 用 Settings Registry 作为广播中介**

`ComponentApplicationLifecycle.h:17-24`：

```cpp
inline constexpr AZStd::string_view ApplicationLifecycleEventRegistrationKey =
    "/O3DE/Application/LifecycleEvents";
inline constexpr AZStd::string_view ApplicationLifecycleEventSignalKey =
    "/O3DE/Runtime/Application/LifecycleEvents";
```

`SignalEvent()` 的实现本质是**往 Settings Registry 里写一个 key**，注册在同一个 key 上的回调被触发。

**为什么这样设计**：

| 方案 | 问题 |
|---|---|
| 直接调用各子系统的初始化函数 | `ComponentApplication` 强依赖所有子系统 → 无法裁剪 |
| 定义一堆 C++ 接口 | 每个子系统要继承/实现，耦合在编译期 |
| **写 Registry key** | **完全解耦**：核心不知道谁在监听 |

**这是依赖倒置**：核心定义"会发生什么"（事件名），上层决定"谁来响应"。

**③ 事件名用字符串而非枚举**

`SignalEvent(settingsRegistry, "FileIOUnavailable", ...)` 里的 `"FileIOUnavailable"` 是字符串。

**代价**：拼写错误只能运行时发现（你之前遇到的 `Cannot signal event FileIOUnavailable because it is not a field of object` 就是这个）。

**收益**：Gem 可以定义**自己的**生命周期事件，不需要改核心枚举。这又是插件式架构的支撑。

## 2.8 原则 7：并发抽象的双轨演进

### 两套并存

```
AzCore/Jobs/     Job.h · JobManager.h · JobCompletion.h · JobContext.h ...   13 个
AzCore/Task/     TaskDescriptor.h · TaskGraph.h · TaskExecutor.h ...          4 个
```

`Scene.cpp` 里能看到**运行时切换**（第六部分提过）：

```cpp
auto taskGraphActiveInterface = AZ::Interface<AZ::TaskGraphActiveInterface>::Get();
m_taskGraphActive = taskGraphActiveInterface && taskGraphActiveInterface->IsTaskGraphActive();

if (m_taskGraphActive) SimulateTaskGraph();    // 新式
else                   SimulateJobs();         // 旧式
```

### 两代对比

| | `AZ::Job`（旧） | `AZ::TaskGraph`（新） |
|---|---|---|
| 粒度 | 一个 Job 对象 | 任务图（DAG） |
| 依赖表达 | `SetDependent()` | 图结构 |
| 生命周期 | 需手动 `JobCompletion` | 图整体提交/等待 |
| 调度信息 | 少 | `TaskDescriptor` 4 维度 |
| 抽象层级 | 低（像线程池任务） | 高（像 DAG 引擎） |

### `TaskDescriptor` 的 4 个维度（`Task/TaskDescriptor.h`）

```cpp
struct TaskDescriptor
{
    const char* taskName = nullptr;      // 唯一任务名（必须提供）
    const char* taskGroup = nullptr;     // 任务组，用于预算追踪（如 "graphics"）
    TaskPriority priority = TaskPriority::MEDIUM;
    // EXPERTS ONLY. 限制只能跑在特定核心上
};
```

优先级 4 级：

```cpp
enum class TaskPriority : uint8_t
{
    CRITICAL = 0,
    HIGH = 1,
    MEDIUM = 2,   // 默认
    LOW = 3,
};
```

**注释里有两句很重要的话**：

> Task priorities MAY be used judiciously to fine tune runtime execution, **with the understanding that profiling is needed to understand what the critical path per frame is**. Modifying task priorities is an **EXPERT setting that should succeed a healthy dose of measurement**.

**"改优先级是专家设置，必须先测量。"**

这是**设计哲学的表达**：提供旋钮，但明确警告不要瞎调。默认值经过调优，改它需要数据支撑。

### 为什么保留两代

| 原因 | 说明 |
|---|---|
| 代码库体量 | 42 万行核心 + 600+ Gem，一次性迁移不现实 |
| 二进制兼容 | 第三方 Gem 可能依赖 Job API |
| 渐进验证 | 可以按子系统逐个切换（Scene 已经是开关式） |
| 风险控制 | 新系统出问题可以切回旧系统 |

**这是十年期 C++ 项目的现实**：不是"设计最优"，而是"如何安全演进"。

<!--BLOCK:A-->
## 2.9 原则 8：异常关闭——错误是返回值

### 事实

```bash
# 本机实测：整个引擎以 -fno-exceptions 编译
$ grep -c -- "-fno-exceptions" /workspaces/o3de-build/build.ninja
2049          # = 编译单元数

# 源码里 throw / try 的实际使用
$ grep -rn "\bthrow \|\btry *{" Code/Framework/AzCore/AzCore --include=*.h --include=*.cpp
# 共 9 行：全部是注释，或 AzCore/std/exceptions.h 里被
# #ifdef AZSTD_HAS_EXEPTIONS 包住的宏 —— 该宏在整个仓库里从未被 #define，那段是死代码
```

**推论**：`catch` 永远不会执行。任何"用异常做控制流"的第三方代码在 O3DE 的编译单元里行为不可预期；
跨 `.so` 抛异常在 C++ 里本来就不可移植（不同的 libstdc++/libc++ 之间尤其如此）。

### 错误用什么表达

| 机制 | 定位 | 使用量（`Code/` + `Gems/`） |
|---|---|---|
| `AZ::Outcome<T, E>` | 可失败的返回值（值 + 错误码/错误串） | **1 733** 处 |
| `AZStd::expected<T, E>` | 同上，C++23 风格，**新代码首选** | 43 处 |
| `AZ_Error(window, cond, fmt, ...)` | 记录错误后继续 | **4 042** 处（仅 `.cpp`） |
| `AZ_Assert` | 开发期断言（违反即 bug） | 大量 |
| `AZ_Warning` / `AZ_Info` / `AZ_Trace` | 分级日志 | 大量 |

`AZ::Outcome` 的形状（`Code/Framework/AzCore/AzCore/Outcome/Outcome.h:84`）：

```cpp
class Outcome
{
    using SuccessType = AZStd::conditional_t<!AZStd::is_void_v<ValueType>, ValueType, AZStd::in_place_t>;
    using FailureType = AZStd::unexpected<ErrorType>;
    ...
    AZ_FORCE_INLINE bool IsSuccess() const;
```

典型用法：

```cpp
AZ::Outcome<AZStd::string, AZStd::string> ReadFile(const char* path);

auto result = ReadFile(path);
if (!result.IsSuccess())
{
    AZ_Error("MyProject", false, "读取失败：%s", result.GetError().c_str());
    return false;
}
Use(result.GetValue());
```

### 代价 1：`AZ_Assert` 里的表达式可能**根本不执行**

`Debug/Trace.h` 用 `AZ_ENABLE_TRACING` 做整体开关：

```cpp
#else // !AZ_ENABLE_TRACING
    #define AZ_Assert(...)                 // ← 展开为空，表达式不求值
    #define AZ_Error(...)                  // ← 同上
    ...
    #define AZ_Verify(expression, ...)  AZ_UNUSED(expression)   // ← 只有这个保证求值
```

本机 Profile 构建里 `-DAZ_ENABLE_TRACING` 出现 **1556 次**（开启），所以你调试时能看到断言。
但**永远不要把有副作用的调用写进 `AZ_Assert`**：

```cpp
AZ_Assert(Initialize(), "init failed");   // ❌ 某天 tracing 关掉，Initialize 就不跑了
bool ok = Initialize();                   // ✅
AZ_Assert(ok, "init failed");
```

### 代价 2：错误必须逐层手工传递

没有异常，就没有"跳过中间层"的捷径，于是每一层都得写：

```cpp
auto outcome = DoInner();
if (!outcome.IsSuccess())
{
    return AZ::Failure(outcome.GetError());   // 一行都不能少
}
```

这就是 O3DE 代码里满是 `if (!x) { AZ_Error(...); return false; }` 的原因——
**不是风格偏好，是语言机制决定的**。

### 收益：为什么值得

| 收益 | 具体表现 |
|---|---|
| **确定性** | 没有栈展开，不存在"走到一半开始析构"的中间态 |
| **性能** | 二进制里没有 unwind table；热路径不必为"可能抛"付代价 |
| **跨模块安全** | 异常跨 `.so` 边界在 C++ 里不可移植 → 干脆禁掉 |
| **崩溃现场干净** | 断言触发即停在错误点，栈没被展开 |
| **平台覆盖** | 部分主机 / 嵌入式的工具链对异常支持很差 |

### 一条实用规则：函数签名就是错误契约

| 签名 | 含义 |
|---|---|
| `AZ::Outcome<T, E>` / `AZStd::expected<T, E>` | 可能失败，**必须检查** |
| `bool` | 可能失败，原因看 `AZ_Error` 的日志（第一个参数是窗口名） |
| `void` / 裸 `T` | 不会失败，或失败也无能为力 |

---

## 2.10 原则 9：反射是唯一的数据模型

### 一个函数，三种用途

每个可序列化的类型都实现同一个签名：

```cpp
static void Reflect(AZ::ReflectContext* context);
```

实测这个函数在 `Code/` + `Gems/` 里出现 **4 651 次**。标准写法：

```cpp
void PerformanceMonitorComponent::Reflect(AZ::ReflectContext* context)
{
    if (AZ::SerializeContext* serialize = azrtti_cast<AZ::SerializeContext*>(context))
    {
        serialize->Class<PerformanceMonitorComponent, AZ::Component>()
            ->Version(0);
    }
}
```

`azrtti_cast<AZ::SerializeContext*>` 出现 **2 123 次**，`azrtti_cast<AZ::BehaviorContext*>` 出现 **548 次**。

### 类层次：注意 `EditContext` 不在其中

```mermaid
graph TD
  R["AZ::ReflectContext<br/>RTTI/ReflectContext.h:105"]
  R --> S["AZ::SerializeContext<br/>序列化 + 编辑器数据模型"]
  R --> B["AZ::BehaviorContext<br/>脚本 / 行为绑定"]
  R --> J["AZ::JsonRegistrationContext<br/>JSON 读写"]

  S --> E["AZ::EditContext<br/>❌ 不是 ReflectContext<br/>挂在 SerializeContext 上的属性层"]
```

`EditContext` 的构造函数说明了一切（`Serialization/EditContext.h:204`）：

```cpp
/**
 * EditContext uses serialize context to interact with data, so serialize context is
 * required.
 */
EditContext(SerializeContext& serializeContext);
```

**这个设计非常关键**：

| 层 | 住在哪 | 谁在用 | 结果 |
|---|---|---|---|
| `SerializeContext` | `AzCore` | **所有人（含运行时）** | 运行时能序列化，但完全不知道"属性面板"存在 |
| `EditContext` | 也在 `AzCore`，仅编辑器侧使用 | Editor / Tools | 编辑器把 UI 元数据**附加**到同一份 ClassData 上 |
| `BehaviorContext` | `AzCore` | 需要脚本绑定的模块 | 脚本看到的 API 与 C++ 反射声明同源 |

**没有第二份"编辑器专用数据模型"。** 属性面板显示什么、存盘写什么、脚本能调什么，
全部来自同一份 `Reflect` 声明。

### 为什么这样设计

| 如果分成两套（运行模型 + 编辑器模型） | O3DE 的选择 |
|---|---|
| 要维护两份字段清单 | **一份** |
| 改字段要同步两处，容易漏 | 注册时立刻暴露不一致 |
| 运行时被迫链接编辑器依赖 | 运行时产物里没有 Qt、没有 `AzToolsFramework` |
| 脚本绑定要重新描述一遍 | `BehaviorContext` 复用同一批类型信息 |

这也解释了 2.12 的依赖规则：**`AzCore` 不含 Qt，却包含 `EditContext`**——
因为 `EditContext` 只是"属性容器"，不含任何 UI 代码。

### 代价：反射是运行期契约，忘了就静默失败

| 你忘了什么 | 现象 |
|---|---|
| 没有 `AZ_TYPE_INFO` / `AZ_RTTI` | 编译期报错（还算友好） |
| `Reflect()` 里没注册字段 | **编译通过、运行通过，但编辑器里该字段不显示 / 不存盘** |
| `EditContext` 里少写 `->DataElement(...)` | 能存盘，但属性面板是空的 |
| `BehaviorContext` 里少写 | 脚本调不到，运行期才报"方法不存在" |

**这是 O3DE 最常见的"静默失败"来源**（与 3.11.1 的 `*_files.cmake` 漏登记同类）。
排查方法：在 `Reflect` 里打断点，确认它**真的被调用过**——
模块没加载时，整个 `Reflect` 都不会执行。

## 2.11 自研 STL：AzStd 的取舍

### 规模

```
AzCore/AzCore/std/    263 个头文件/inl
├── containers/       array deque list map set vector string ...
├── string/           basic_string fixed_string string_view ...
├── smart_ptr/        shared_ptr unique_ptr intrusive_ptr ...
├── function/         function bind reference_wrapper ...
├── chrono/ concepts/ iterator/ metaprogramming/ ranges/ typetraits/
├── parallel/         （并行算法）
├── delegate/
└── utility/
```

**这是一套几乎完整的 STL 替代实现。**

### 为什么不用 `std::`

| 理由 | 证据 |
|---|---|
| **分配器控制** | 需要 `AZ_CLASS_ALLOCATOR` 与 `ChildAllocatorSchema` 联动，`std::allocator` 无法对接 |
| **固定容量容器** | `fixed_vector` / `fixed_list` / `fixed_unordered_map` —— **STL 没有**，游戏常用（避免运行时分配） |
| **侵入式容器** | `intrusive_list` / `intrusive_set` —— 节点内嵌于对象，零额外分配 |
| **调试与追踪** | 分配要能记录到 `AllocationRecords` |
| **跨平台一致性** | 不同标准库 ABI/行为差异（尤其 MSVC vs libstdc++） |
| **内存布局控制** | 游戏需要可预测的内存布局（缓存友好） |

### 代价

| 代价 | 表现 |
|---|---|
| 学习成本 | 新人要学 `AZStd::string` 而非 `std::string` |
| 生态隔离 | 不能直接用为 STL 写的第三方库（需转换） |
| 维护负担 | 263 个头文件要自己维护 |
| 编译时间 | 大量模板实例化 |

**但这也是 `libAzCore.so` 25 MB 的原因之一，以及项目构建要 3 小时的原因之一。**

## 2.12 架构全景：依赖方向

```mermaid
graph TD
  subgraph L4["④ 产品层"]
    P1["Editor"]
    P2["AssetProcessor"]
    P3["GameLauncher / ServerLauncher"]
  end

  subgraph L3["③ 工具框架层"]
    T1["AzToolsFramework<br/>24 万行 · 578 头"]
    T2["AzQtComponents<br/>6 万行 · 170 头"]
  end

  subgraph L2["② 框架层"]
    F1["AzFramework<br/>12 万行 · 377 头"]
    F2["AzGameFramework<br/>360 行 · 3 头"]
    F3["AzNetworking<br/>1.6 万行 · 82 头"]
  end

  subgraph L1["① 核心层 AzCore · 42 万行 · 873 头"]
    C1["RTTI / TypeInfo<br/>UUID 类型系统"]
    C2["Memory<br/>分配器链"]
    C3["EBus / Interface<br/>通信"]
    C4["Component / Entity<br/>状态机"]
    C5["Serialization<br/>反射"]
    C6["Jobs / Task<br/>并发"]
    C7["Module<br/>插件加载"]
    C8["Settings<br/>配置"]
    C9["AzStd<br/>STL 替代"]
  end

  P1 --> T1
  P1 --> T2
  P2 --> T1
  P3 --> F2
  P3 --> F1
  T1 --> F1
  T2 --> F1
  F2 --> F1
  F1 --> L1
  F3 --> L1
  T1 --> L1
```

### 依赖规则（架构约束）

| 规则 | 含义 |
|---|---|
| **只向下依赖** | `AzCore` 不知道 `AzFramework` 存在 |
| **工具侧与运行时侧分离** | `AzToolsFramework` 只在 Editor 里链接；`AzGameFramework` 只在 Launcher 里 |
| **核心无 UI 依赖** | `AzCore` 不含 Qt（`AzQtComponents` 才含） |
| **运行时无编辑器代码** | GameLauncher 的 `cmake_dependencies` 里没有 `MyProject.Tools` |

**第三条和第四条就是第四部分讲的"变体裁剪"的架构基础。**

### 一个实证：`AzGameFramework` 只有 360 行

它包含 3 个头文件、2 个 cpp、**360 行代码**。对比 `AzFramework` 12 万行。

**为什么这么小**：它只做一件事——**提供运行时专用的主循环与引导序列**（`GameApplication`）。

**这个极端的对比说明架构分层的"纯度"**：如果分层是假的，这一层会膨胀成几千行；只有 360 行说明**职责边界被严格遵守**。

## 2.13 把编译选项当架构读

架构文档会骗人，**编译选项不会**。本机 Linux / Profile 构建里，每个编译单元的 FLAGS 是：

```bash
$ grep -m1 "FLAGS = " /workspaces/o3de-build/build.ninja
# （下方为便于阅读人工折行，实际是一行）
  FLAGS = -fno-exceptions -fvisibility=hidden -fvisibility-inlines-hidden -Wall -Werror \
    -Wno-inconsistent-missing-override -Wrange-loop-analysis \
    -Wno-dllexport-explicit-instantiation-decl -Wno-parentheses -Wno-reorder -Wno-switch \
    -Wno-undefined-var-template -Wno-unknown-warning-option \
    -msse4.1 -fno-fast-math -O2 -g -fstack-protector-all -fstack-check -std=c++20 -fPIC
```

逐个翻译成"你写代码时会撞到什么"：

| 选项 | 架构含义 | 你的后果 |
|---|---|---|
| `-fno-exceptions` | **不用异常**（2.9） | 没有 try/catch；错误用 `Outcome` / 返回值 |
| `-fvisibility=hidden`<br/>`-fvisibility-inlines-hidden` | 默认**不导出**任何符号 | 新增公开 API 必须加导出宏（`AZCORE_API` / `AZ_MODULE_API`…），否则别的 `.so` 链接不到 |
| `-Wall -Werror` | **零警告政策** | 任何新警告 = 编译失败（模板代码尤其容易踩） |
| `-msse4.1` | 最低 CPU 基线 **SSE4.1**（2008 年后的 x86） | 不能无条件用 AVX/AVX2，需运行期检测 |
| `-fno-fast-math` | **浮点必须可复现** | 不能依赖近似数学；网络同步 / 回放要靠它 |
| `-O2 -g` | Profile = 优化 + 完整调试信息 | 能下断点、能看变量，但代码被内联过（见第十部分） |
| `-fstack-protector-all`<br/>`-fstack-check` | 栈保护全开 | 栈溢出/越界更容易当场被抓到，代价是少量性能 |
| `-std=c++20` | 语言基线 **C++20** | 可用 concepts / `std::span`，但**不能用 C++23 库特性** |
| `-fPIC` | 位置无关代码 | 所有产物都能进共享库 |

### 再补一条：unity build 默认是开着的

```bash
$ grep "LY_UNITY_BUILD" /workspaces/o3de-build/CMakeCache.txt
LY_UNITY_BUILD:BOOL=ON

$ find /workspaces/o3de-build -name "unity_*_cxx.cxx" | wc -l
1086        # 其中 368 个来自引擎自身代码，718 个来自 External/（ImGui 等第三方）
```

后果（详见 3.9 与第十部分）：

- 多个 `.cpp` 被 `#include` 进同一个 `unity_0_cxx.cxx` 一起编译 → **编译快 2–5 倍**
- 但**改一个 `.cpp` 要重编整批**
- clangd 看到的是 unity 文件，**跳转/补全可能错位** → 必须另生成 `compile_commands.json`

> **自查三连**：任何"这项目到底怎么编的"问题，先看这三条——
> `grep -m1 "FLAGS = " build.ninja`、`grep UNITY build/CMakeCache.txt`、
> `grep -c fno-exceptions build.ninja`。

## 2.14 与主流引擎的设计对比

| 维度 | O3DE | Unreal Engine | Unity |
|---|---|---|---|
| 类型 ID | **UUID（硬编码）** | UClass 反射系统 + 名字 | 无（C# 反射） |
| 通信 | **EBus（policy-based）+ AZ::Interface** | 委托/事件 + 硬引用 | C# event / SendMessage |
| 对象模型 | Entity + Component（**组合**） | Actor + Component（组合） | GameObject + Component（组合） |
| 模块化 | **Gem（连渲染/物理都是 Gem）** | Plugin / Module | Package |
| 内存 | **分配器链 + 自研 STL** | 分配器 + 自研容器 | C# GC（Burst 除外） |
| 序列化 | ReflectContext（Serialize/Edit/Behavior 三上下文） | UPROPERTY 反射 | SerializeField |
| 脚本 | **Script Canvas / Lua / Python** | Blueprint / Python | C# |
| 并发 | Job（旧）+ TaskGraph（新）双轨 | Task Graph | Job System / Burst |

### O3DE 最独特的三点

**① 连渲染器都是 Gem**

`Gems/Atom/` 是一个 Gem。理论上你可以：

```json
"gem_names": ["MyProject", "MyCustomRenderer"]
```

——**整个渲染器被替换掉**。这在商业引擎里几乎不存在（Unreal 的渲染器不可换）。

**② 类型系统用人工 GUID**

这是"重工业"式的严谨，代价是开发体验（要手动生成 GUID）。好处是：
- 关卡文件可以在任何引擎版本间互通
- 插件可以跨编译器二进制兼容
- 类型可以被脚本、网络、编辑器一致引用

**③ 两代并发系统并存**

不追求"架构纯洁性"，而是承认演进现实。`Scene` 里那个 `m_taskGraphActive` 开关就是明证。

## 2.15 设计权衡总结表

| 决策 | 收益 | 代价 | 值不值得 |
|---|---|---|---|
| UUID 类型 ID | 稳定、可序列化、跨 DLL | 手动管 GUID | ✅ 插件式架构的前提 |
| 自研 STL | 分配器控制、固定容量容器 | 生态隔离、学习成本 | ✅ 游戏需要内存可预测 |
| Policy-based EBus | 零开销抽象 | 代码膨胀（25 MB .so） | ✅ 热路径收益大 |
| 编译期策略 | 可内联、无分支 | 模板实例化时间 | ✅ 运行时优先 |
| 分配器链 | 独立统计与策略 | 增加间接层 | ✅ 内存问题可定位 |
| 显式状态机 | 消除重入 bug | 状态多、代码长 | ✅ 崩溃成本远高于代码量 |
| 事件用字符串 | Gem 可扩展事件 | 拼写错误运行时才发现 | ⚠️ 权衡 |
| unity build | 编译快 2-5 倍 | 改一个文件重编整批；clangd 失效 | ⚠️ 见第十部分 |
| 两代并发并存 | 安全演进 | 维护两套 | ✅ 十年项目的现实 |
| 项目中心构建重编引擎 | 项目自包含 | 3 小时首次构建 | ⚠️ 可用 `LY_PROJECTS` 优化 |
| 关闭异常（2.9） | 确定性、无 unwind、跨模块安全 | 错误逐层传递，代码冗长 | ✅ 游戏/主机场景必需 |
| 反射即数据模型（2.10） | 一份声明三处复用，运行时不依赖编辑器 | 漏注册即静默失败；注册有运行期开销 | ✅ 代价可控，收益极大 |
| 零警告（`-Wall -Werror`） | 问题在编译期暴露 | 新代码必须自己消警告 | ⚠️ 严格但有效 |

## 2.16 已知的架构债务清单

一份**诚实**的清单。债务不等于缺陷——它是"这个项目活了十年、还要继续活"的证据。

| # | 债务 | 可验证的迹象 | 对你的影响 | 规避方式 |
|---|---|---|---|---|
| 1 | **两代并发系统并存** | `Job`（旧）+ `TaskGraph`（新）；`Scene` 里有 `m_taskGraphActive` 开关 | 不知道新代码该用哪套 | 新代码用 TaskGraph（2.8） |
| 2 | **AZStd 与 std 并存** | `AZStd::string` 30 156 处 vs `std::string` 409 处（≈ 98.7% : 1.3%） | 两者不隐式互转，混用要显式构造 | 模块边界统一 AZStd，第三方 API 处才转 |
| 3 | **模板膨胀** | `libAzCore.so` 25 MB / **11 296** 个导出符号；`nm -D … \| grep -c EBus` = 2 194 | 编译慢、二进制大 | 接受它；别在公共头里加模板重载 |
| 4 | **unity build 破坏单文件语义** | 1 086 个 `unity_*_cxx.cxx` | 改一个文件重编整批；clangd 需额外 compdb | 第十部分 |
| 5 | **反射靠人工登记** | 4 651 个 `Reflect()`；漏写即静默失败 | 字段不显示 / 不存盘，但**不报错** | 2.10 末尾的排查法 |
| 6 | **`.setreg` 用字符串键** | `Registry/*.setreg` 全是路径字符串 | 拼错只在运行期暴露 | 用常量 + 单测覆盖 |
| 7 | **无异常 → 错误传播冗长** | 2 049 个编译单元全 `-fno-exceptions` | 每层都要写 `if (!x) return …` | 用 `AZ::Outcome` 明确契约（2.9） |
| 8 | **GUID 手工分配** | 新组件第一件事是生成 UUID | 忘了 = 类型冲突，且很隐蔽 | 用 `ClassCreationWizard` / CLI 生成 |
| 9 | **Editor 单体** | `Editor` 21 KB + `libEditorLib.so` **32 MB** | 插件边界模糊，改一处要重链大库 | 优先做 Gem，而不是改 Editor |
| 10 | **构建时间** | configure 140 s + 全量编译数小时 | 迭代慢 | 分批 + 增量（3.5 / 3.8） |
| 11 | **文档与代码不同步** | 部分注释里的类名 / 路径已过期 | 照旧文档做会失败 | **以 `AutomatedTesting/` 和源码为准** |

### 怎么读这份清单

> 债务 = **用"现在的麻烦"换"过去的进度"**。
> 每一条都对应一个当时合理的选择：两代并发是为了不打断在用代码；
> AZStd 是为了内存可控；unity build 是为了把 4 小时的编译压到 1 小时。
>
> **判断一个项目是否成熟的标志，不是"有没有债务"，而是"债务有没有被显式记录"。**
> 这份清单里每一条都能在源码里找到痕迹（开关、宏、注释、测试），
> 而不是只能靠口口相传——这才是可以放心用的项目。

## 2.17 给架构学习者的五条建议

**① 看"约束"比看"功能"更有价值**

O3DE 的每个设计决策背后都是约束：

- 要跨 DLL → 必须 UUID
- 要内存可预测 → 必须自研容器
- 要热路径零开销 → 必须编译期多态

**学架构就是学"在什么约束下做什么取舍"。**

**② 用"如果去掉会怎样"来验证设计必要性**

| 如果去掉 | 后果 |
|---|---|
| UUID，改用 `typeid` | 关卡无法存盘、插件失效 |
| `ChildAllocatorSchema` | 内存泄漏无法定位到子系统 |
| Entity 状态机 | 组件增删竞态、崩溃 |
| `ProvidesFullRtti()` | 简单类型白付虚表开销 |
| `MutexType = NullMutex` 默认 | 单线程场景白付锁开销 |
| 关闭异常（`-fno-exceptions`） | 跨 `.so` 抛异常不可靠；但错误传播会变短 |
| `EditContext` 独立于 `SerializeContext` | 运行时要链 Qt；或维护两份字段清单 |

**③ 注意"并存"与"弃用"的痕迹**

- `Job` + `TaskGraph` 并存 → 架构在演进
- `ApplyRenderPipelineChange` 标注 `O3DE_DEPRECATION_NOTICE(GHI-12687)` → 用 `AddRenderPasses` 代替
- `m_lastCompletedStep` 幂等设计 → 为将来热加载留口子

**这些"历史层积"比教科书式的纯净架构更有信息量**——它们告诉你这个项目真实经历过什么。

**④ 用数据验证直觉，而不是用直觉接受结论**

本章的每个数字你都可以自己复核。三把工具就够了：

| 你想知道 | 命令 | 本章用到的结果 |
|---|---|---|
| 某个 API 用得多不多 | `grep -rn "AZ::Outcome<" Code Gems --include=*.cpp \| wc -l` | 1 733 |
| 某个符号真的导出了没 | `nm -D --defined-only libAzCore.so \| grep -c EBus` | 2 194 |
| 这个目标依赖了谁 | `ninja -C build -t query bin/profile/Editor` | 52 个直接输入 |
| 编译选项是什么 | `grep -m1 "FLAGS = " build.ninja` | 见 2.13 |

> **反例警示**："这个引擎太臃肿了"是印象；"1 086 个 unity 文件、11 296 个导出符号、25 MB 核心库"是可核对的判断。

**⑤ 先读测试，再读实现**

`AutomatedTesting/` 和各个 Gem 的 `Tests/` 目录里，是**唯一保证与当前代码同步的"文档"**：

| 你的问题 | 去哪找答案 |
|---|---|
| 这个 API 应该怎么调？ | 对应模块的 `Tests/*.cpp` |
| 边角情况怎么处理？ | 单元测试的用例名往往就是需求描述 |
| 这个行为是有意还是 bug？ | `git log -S"函数名"` 看提交信息 |

**读实现告诉你"怎么做的"，读测试告诉你"合同是什么"**——而后者才是你真正要遵守的东西。

---

# 第三部分 · 编译步骤与原理

> **🎓 L1 · 跑起来 ★核心** ｜ 前置：L0 ｜ 读完能做什么：从零源码编出 Editor ｜ 下一站 → **第五部分（L2 · 能改）** ｜ ⚠️ 边做边查 [第十四部分 坑 1–3](#坑-1-3-dev-包和运行时包是两回事)

> 这一部分是本文档的重点。不仅给命令，还解释**每一步为什么这样做**。

### 本章导航：你可能会带着这些问题来

| 你的疑问 | 去哪节 |
|---|---|
| **开始之前我该先想清楚什么？磁盘够不够？** | 3.12 先做三个决定 ／ 3.13 磁盘与内存预算 |
| 每步到底在干什么？产生了什么？漏了会怎样？ | 3.1（「每步的产物与作用」表） |
| 环境里 Qt 版本乱怎么办？ | 3.4 末尾「环境陷阱」 |
| 为什么要按 `AzCore → AzFramework → Qt/Tools → Editor` 的顺序？能不能直接编 `Editor`？ | 3.5.1 为什么要先建子目标 |
| 编完怎么确认真的成功了？ | 3.6 产物验证 ／ 3.7 末尾冒烟测试 |
| 为什么项目要重编一遍引擎？能不能复用？ | 3.8 |
| 编译为什么这么慢？ | 3.9（unity build） |
| **我要加 / 删一个组件，要改哪几个文件？** | 3.11 如何添加或移除组件与 Gem |
| 产物长什么样、都在哪？ | 3.10 |
| 全流程要多少时间 / 多少磁盘？ | 3.14 一张总表 |
| **编坏了想全部推倒重来** | 3.15 完全重来：干净的重置流程 |

## 3.1 完整编译流程（六步）

```mermaid
flowchart TD
  S0["① 环境准备<br/>系统依赖 + 工具链"] --> S1["② 获取源码<br/>跳过 LFS"]
  S1 --> S2["③ 首次 configure<br/>下载三方包 + 生成构建图"]
  S2 --> S3["④ 分批编译<br/>核心框架 → 工具 → 编辑器"]
  S3 --> S4["⑤ 产物验证<br/>ldd / nm"]
  S4 --> S5["⑥ 建项目<br/>create-project"]
  S5 --> S6["⑦ 项目单独 configure+build"]
```

### 每步的产物与作用（关键：知道每步在"造"什么）

很多人编完一圈还是不知道自己在干什么，是因为**不知道每一步的产物是什么**。
下面这张表是本章的总纲——后面每一节都在展开其中一行。

| 步 | 动作 | **产物**（能看到的实物） | **作用**（不做的后果） | 失败特征 | 耗时 |
|---|---|---|---|---|---|
| ① | 装系统依赖 + clang | `/usr/bin/clang++-18`、`/usr/local/bin/clang-scan-deps` | 给后面所有步骤提供**编译器与探测工具**。缺了 → configure 或编译直接报错 | `Could NOT find LibUnwind` / `CLANG_SCAN_DEPS-NOTFOUND` | 3–5 min |
| ② | 克隆源码 | `o3de/`（448 MB，30103 文件） | 拿到**构建的输入**（源码 + `cmake/` 规则 + `Gems/`） | 目录不存在 | 1–2 min |
| ③ | configure | **`build.ninja`** + `CMakeCache.txt` + `o3de-packages/`（4.2 GB） | 把「源码树 + 依赖」**翻译成一张 12780 个目标的依赖图**。这是唯一会**下载**东西的步骤 | 没有 `build.ninja` | ~25 min |
| ④ | `ninja <target>` | **`.a` 静态库 → `.so` 动态库 → 可执行文件** | 按依赖图**真正编译并链接**。前 3 步都只是准备，这一步才产出可运行的东西 | `FAILED:` + 具体命令 | ~90 min |
| ⑤ | 验证 | 三组数字（`ninja -n` 干净 / `ldd` 无缺失 / `nm` 有符号） | 证明**产物是完整可用的**，而不是"编完了但一跑就崩" | 有 `not found` 或符号数为 0 | 1 min |
| ⑥ | `create-project` | `MyProject/`（~5 MB，19 个顶层项） | 从模板**实例化**一个项目（改 GUID、写 manifest）。此时**没有编译产物** | 目录为空 / `project.json` 缺失 | 几秒 |
| ⑦ | 项目 configure + build | `MyProject/build/linux/bin/profile/*` | 因为**项目是独立的构建树**（3.8），要在项目自己的目录里再走一遍 ③④ | 同 ③④ | 2 min + 数小时 |

**三条读表要点**：

1. **③ 和 ⑦ 是同一件事做了两遍**——一遍给引擎，一遍给项目。这就是"为什么要等两轮长编译"的根源（3.8 解释机制）。
2. **只有 ④ 和 ⑦ 是"编译"**，其余都是准备或校验。所以你看到 `ninja` 输出 `[1/789]` 才是真正在干活。
3. **⑤ 的验证不是形式主义**：`ldd` 的 `not found` 和 `nm` 的符号数，是区分"编完了"和"能用了"的唯一客观标准。

### 六步之间的依赖关系（为什么不能跳步）

```mermaid
flowchart LR
    A["① 环境"] -->|"没有编译器<br/>configure 直接失败"| C["③ configure"]
    B["② 源码"] -->|"没有 CMakeLists<br/>无输入"| C
    C -->|"没有 build.ninja<br/>ninja 报 unknown target"| D["④ 编译"]
    D -->|"没有 .so<br/>无法验证"| E["⑤ 验证"]
    E -->|"未确认引擎可用<br/>项目编译失败时无法归因"| F["⑥⑦ 项目"]

    style C fill:#ffe6cc
    style D fill:#d5e8d4
```

> 💡 **唯一可以从中间开始的情况**：如果别人的机器上已经有 `o3de-build`（且路径一致），
> 你可以跳过 ①②③ 直接 ④。但**路径必须完全一致**——构建树里存的是绝对路径（3.8 讲过）。

> 📖 **想直接动手？** 本章讲"为什么"；**照着做的分步版在
> [第三部分 · 编译步骤与原理](#第三部分--编译步骤与原理)**——
> 那里每一步都有**验证门**、时间/磁盘预算和失败处置。

## 3.2 步骤 ①：环境准备

### 命令

```bash
sudo apt-get update -y
sudo apt-get install -y \
  build-essential ninja-build pkg-config \
  libunwind-dev libzstd-dev libssl-dev \
  libx11-dev libxext-dev libxrender-dev libxrandr-dev libxinerama-dev \
  libxcursor-dev libxi-dev libxfixes-dev libxss-dev libxtst-dev \
  libxcb1-dev libxcb-xkb-dev libxcb-xinerama0-dev libxcb-xinput-dev \
  libxcb-xfixes0-dev libxcb-icccm4-dev libxcb-keysyms1-dev \
  libxcb-shape0-dev libxcb-randr0-dev libxcb-util-dev \
  libxcb-image0-dev libxcb-render-util0-dev libxcb-sync-dev \
  libxcb-glx0-dev libxcb-shm0-dev libxcb-dri2-0-dev libxcb-dri3-dev \
  libxcb-present-dev libxcb-cursor0 \
  libfontconfig1-dev libpulse-dev \
  libxkbcommon-dev libxkbcommon-x11-dev \
  libglu1-mesa-dev libxt-dev \
  clang-18 clang-tools-18

# clang-scan-deps 必须能被 CMake 以无版本名探测到
sudo ln -sf /usr/bin/clang-scan-deps-18 /usr/local/bin/clang-scan-deps
```

### 为什么必须一次装全

O3DE 的依赖检查**分散在不同位置**，而且是**逐个暴露**的：

| 缺失项 | 报错位置 | 报错时机 |
|---|---|---|
| `libunwind-dev` | `cmake/Platform/Linux/libunwind_linux.cmake:15` | configure 第 5 行 |
| `libxcb-xkb-dev` | `cmake/3rdParty/FindX11.cmake` ← `AzFramework/CMakeLists.txt:163` | configure 中段 |
| `libxkbcommon-x11-dev` | 同上 ← `CMakeLists.txt:179` | configure 后段 |
| `clang-scan-deps` | `.ddi` 规则 | **编译到第 227 个目标** |

没有一处集中的依赖声明文件。所以每缺一个都要重跑一次 configure，而 configure 前面可能已经下载了几 GB 包。

### 为什么必须用 clang 而不是 GCC 13

`cmake/Platform/Linux/CompilerSettings_linux.cmake` 在没设 `CC`/`CXX` 时**自动选最高版本 clang**：

```cmake
list(TRANSFORM path_search APPEND "/clang-[0-9]*" OUTPUT_VARIABLE path_with_version_search)
file(GLOB clang_versions ${path_with_version_search})
if(clang_versions)
    list(SORT clang_versions COMPARE NATURAL ORDER DESCENDING)   # 降序，取最高
    list(GET clang_versions 0 clang_higher_version_path)
```

实测对比（同机、同版本 O3DE）：

| 问题 | GCC 13 | clang 18 |
|---|---|---|
| `-Werror` 让新警告变致命 | ❌ 中断 | ✅ 通过 |
| `-fvisibility=hidden` 使 EBus 模板符号变 local → 522 个 undefined reference | ❌ 链接失败 | ✅ 通过（2194 个 EBus 导出符号） |
| `extern template basic_fixed_string<char,1024>` 缺单参数构造 | ❌ 链接失败 | ✅ 通过 |
| GCC 13 concepts 求值 bug（`AzToolsFramework` 6 个 unity 目标） | ❌ 失败 | ✅ 通过 |

**注意**：`-Werror`、`-fvisibility=hidden` 这些"雷"在 clang 下**依然存在**，只是不触发。所以这不是"关掉了检查"，而是编译器行为差异。

### 为什么 `clang-tools-18` 也要装

Ubuntu 的 `clang-18` 包**不含** `clang-scan-deps`（在独立的 `clang-tools-18` 里）。

而 Atom 通过 FetchContent 引入的 `meshoptimizer` 启用了 **C++20 模块依赖扫描**，CMake 会生成 `.ddi` 规则调用它。缺了会报：

```
FAILED: _deps/meshoptimizer-build/CMakeFiles/meshoptimizer.dir/src/allocator.cpp.o.ddi
"CMAKE_CXX_COMPILER_CLANG_SCAN_DEPS-NOTFOUND" -format=p1689 -- /usr/bin/clang++-18 ...
```

⚠️ **这个错误延迟到编译期才暴露**，configure 阶段完全正常。

### ✅ 验证门 1（环境）

```bash
cmake --version | head -1          # ≥ 3.24
ninja --version                    # 任意
clang++-18 --version | head -1     # 18.x
which clang-scan-deps              # /usr/local/bin/clang-scan-deps
clang-scan-deps --help > /dev/null && echo "scan-deps OK"
```

**全绿才继续。** 缺一项都会在后面付出一小时代价。

## 3.3 步骤 ②：获取源码

```bash
cd /workspaces
GIT_LFS_SKIP_SMUDGE=1 git clone --depth=1 --single-branch \
  --branch 2605.0 https://github.com/o3de/o3de.git o3de
```

### 为什么 `GIT_LFS_SKIP_SMUDGE=1`

仓库 `.gitattributes` 有 **123 条** `filter=lfs` 规则，但实测：

```bash
git ls-files "*.a" "*.lib" "*.so" "*.DLL" | wc -l
# → 0
```

**LFS 里全是资产（PNG/FBX），没有编译必需的二进制。** 不跳过的话会尝试下载 2906 个 LFS 对象，实测速度降到 32 KB/s。

结果：**448 MB / 30033 文件，秒级完成**。

### 为什么用 `--depth=1 --single-branch`

只要一个版本，不需要历史。省掉 90% 下载量。

### ✅ 验证门 2（源码）

```bash
cd /workspaces/o3de
cat engine.json | python3 -c "import json,sys;print(json.load(sys.stdin)['version'])"
# 期望：2.6.0（对应 2605.0 发行版）

du -sh .            # 约 448 MB
ls CMakeLists.txt   # 必须存在
```

## 3.4 步骤 ③：首次 configure

```bash
cmake -B /workspaces/o3de-build -S /workspaces/o3de -G Ninja \
  -DCMAKE_BUILD_TYPE=Profile \
  -DLY_3RDPARTY_PATH=/workspaces/o3de-packages
```

### 每个参数的作用

| 参数 | 作用 | 不写的后果 |
|---|---|---|
| `-B` | 构建目录 | 污染源码树 |
| `-S` | 源码目录（含 CMakeLists.txt） | |
| `-G Ninja` | 用 Ninja 生成器 | 默认 Make，慢 2-3 倍 |
| `CMAKE_BUILD_TYPE=Profile` | 优化 + 部分符号 | 见下表 |
| `LY_3RDPARTY_PATH` | 三方包位置 | **重新下载 4.2 GB** |

### 为什么用 Profile 而不是 Debug / Release

| 类型 | 优化 | 符号 | 用途 |
|---|---|---|---|
| `Debug` | 无 | 完整 | 断点调试（但慢 10 倍） |
| **`Profile`** | O2 | 部分 | **开发首选**（O3DE 特色） |
| `Release` | O2+ | 无 | 发布 |

`Profile` 是 O3DE 独有的构建类型：性能接近 Release，但保留足够符号做性能分析。日常开发用它。

### configure 阶段实际做了什么（耗时 25 分钟）

```mermaid
flowchart TD
  A["读取 CMakeLists.txt 顶层"] --> B["PAL 平台抽象层检测<br/>确定 Linux/x86_64"]
  B --> C["系统依赖检查<br/>libunwind / libzstd / X11 / xkb"]
  C --> D["下载三方包<br/>packman → 压缩包 4.8 GB<br/>解压后 4.2 GB"]
  D --> E["FetchContent 拉取<br/>googletest / meshoptimizer / miniaudio<br/>ogg / openmesh / recastnavigation / vorbis"]
  E --> F["遍历 engine.json 的<br/>80+ external_subdirectories"]
  F --> G["每个 Gem 的 CMakeLists.txt<br/>生成 target"]
  G --> H["生成 build.ninja<br/>12780 个目标"]
```

**耗时主要在 D 阶段**（下载）。实测 packman 速度 150~725 KB/s，4.8 GB 需要 20 多分钟且会超时中断。

### 三方包缓存机制（为什么可以重跑）

`cmake/3rdPartyPackages.cmake:512-545`：包里已有 + **sha256 匹配** → 直接复用，不重下。

所以 configure 失败后重跑不会重新下载已完成的包。

#### ⚠️ 环境陷阱：`QT_ROOT` / `CMAKE_PREFIX_PATH` 可能指向错误的 Qt

如果机器上装过 Qt（或装过 Qt Creator），环境里很可能有：

```bash
$ env | grep -i qt
QT_ROOT=/home/hwg/Qt/6.8.3/gcc_64
QT_DIR=/home/hwg/Qt/6.8.3/gcc_64
CMAKE_PREFIX_PATH=/home/hwg/Qt/6.8.3/gcc_64     # ← 这个最危险
```

而 **O3DE 用的是 `o3de-packages` 里的 Qt 5.15.2**。configure 时会告警：

```
CMake Warning (dev) at cmake/LYWrappers.cmake:620 (find_package):
  Policy CMP0144 is not set: find_package uses upper-case <PACKAGENAME>_ROOT variables.
  Environment variable QT_ROOT is set to:
    /home/hwg/Qt/6.8.3/gcc_64
```

**本机实测：只是一个 warning，编译正常完成**——因为 `ly_parse_third_party_dependencies`
把包解析限制在 `LY_3RDPARTY_PATH` 下。但为排除隐患，建议清掉再配：

```bash
unset QT_ROOT QT_DIR CMAKE_PREFIX_PATH
cmake -B /workspaces/o3de-build -S /workspaces/o3de -G Ninja \
  -DCMAKE_BUILD_TYPE=Profile -DLY_3RDPARTY_PATH=/workspaces/o3de-packages
```

> **为什么值得警惕**：`CMAKE_PREFIX_PATH` 是**全局**的 `find_package` 搜索根。
> 某个依赖不指定版本时，CMake 可能先找到 Qt 6 而不是 5.15 → 链接到错的 Qt
> → 运行时 `undefined symbol` 或 ABI 崩溃。**O3DE 能忍它，不代表你的其他项目也能。**

### ✅ 验证门 3（configure）

```bash
ls /workspaces/o3de-build/build.ninja                          # 必须存在
grep "^CMAKE_BUILD_TYPE" /workspaces/o3de-build/CMakeCache.txt # Profile
grep "CLANG_SCAN_DEPS" /workspaces/o3de-build/CMakeCache.txt   # 必须不是 -NOTFOUND
du -sh /workspaces/o3de-packages                               # 约 4.2 GB
```

**`build.ninja` 存在 = configure 成功。** 后面所有问题都是编译期问题。

## 3.5 步骤 ④：分批编译（**关键技巧**）

### 第一次编时，不要直接编 `Editor`

```bash
# ⚠️ 第一次编 / 排查环境问题时，不要这样
ninja -C /workspaces/o3de-build -j4 Editor
```

原因：`Editor` 展开后是 789 个目标，中间任何一个失败你都不知道是哪一层的问题。

> 💡 **澄清**：这条命令**技术上能编成功**（`ninja` 会自己按依赖图先建子目标），
> 问题在**人因**——70 分钟里挂掉时你无法快速定位。下面 3.5.1 会详细讲这个区别。
> 构建树已确认健康后，直接 `ninja Editor` 反而是更省心的做法。

### 正确做法：按依赖层次分批

```bash
# 第一层：核心（41 个目标，约 3 分钟）
ninja -C /workspaces/o3de-build -j4 AzCore

# 第二层：框架（46 个目标，约 2 分钟）
ninja -C /workspaces/o3de-build -j4 AzFramework AzGameFramework

# 第三层：工具框架（137 个目标，约 15 分钟）
ninja -C /workspaces/o3de-build -j4 AzQtComponents AzToolsFramework

# 第四层：编辑器（789 个目标，约 70 分钟）
ninja -C /workspaces/o3de-build -j4 Editor
```

**每批编完立刻验证产物**（这比"编完了"重要得多，漏了会一直卡在后面）：

| 层 | 验证命令 | 期望 |
|---|---|---|
| ① 核心 | `ls -lh bin/profile/libAzCore.so` | ~25 MB |
| ② 框架 | `ls bin/profile/libAzFramework.so libAzGameFramework.so` | 都存在 |
| ③ 工具框架 | `ls bin/profile/libAzToolsFramework.so libAzQtComponents.so` | 都存在 |
| ④ 编辑器 | `ls -lh bin/profile/Editor bin/profile/libEditorLib.so` | Editor 21 KB（loader）、libEditorLib.so 32 MB |

任何一条不满足，**就是当前这一层没编完**，不要往下走。

### 为什么必须先建子目标（依赖 DAG 的真相）

这是本节的核心问题：**为什么 `Editor` 必须等 `AzCore` / `AzFramework` / `AzToolsFramework` 都编完？**

答案不是"框架规定"，而是**链接器的硬约束**：`Editor` 这个可执行文件要链接一堆 `.so` 和 `.a`，
**这些文件不存在，链接命令根本无法执行**。

#### 实测证据：`Editor` 的链接输入清单

```bash
ninja -C /workspaces/o3de-build -t query bin/profile/Editor | sed -n '/^  input:/,$p'
```

输出（节选，共 **52 条输入**）：

```
bin/profile/Editor:
  input: CXX_EXECUTABLE_LINKER__Editor_Profile
    Code/Editor/CMakeFiles/Editor.dir/Unity/unity_0_cxx.cxx.o
    | lib/profile/libCryCommon.a          ← 必须已存在
    | bin/profile/libAzFramework.so       ← 必须已存在
    | lib/profile/libAzNetworking.a       ← 必须已存在
    | bin/profile/libAzCore.so            ← 必须已存在
    ...
    || bin/profile/AssetProcessor                              ← order-only
    || bin/profile/EditorPlugins/libComponentEntityEditorPlugin.so
    || bin/profile/EditorPlugins/libEditorAssetImporter.so
    ...
```

| 数字 | 含义 |
|---|---|
| **52** | `Editor` 的直接输入条目总数 |
| **34** | 其中 `\|\|` 标记的 **order-only 依赖**（要先建好，但不参与链接） |
| — | 剩下的 `\|` 条目是**必须存在且会被链接进来**的库 |

再看 `Editor` 真正干活的那个库：`Editor` 只链 `Legacy::EditorLib`（即 `libEditorLib.so`，32 MB），
而 **`EditorLib` 自己有 84 个输入依赖**，其中就包括 `AZ::AzToolsFramework`、`AZ::AzCore`、
`Gem::Atom_RPI.Public` 等。

**链条完整展开**：

```mermaid
graph BT
    AZCORE["libAzCore.so<br/>25 MB"]
    AZFW["libAzFramework.so<br/>36 MB"]
    AZNET["libAzNetworking.a"]
    QTC["libAzQtComponents.so<br/>3.2 MB"]
    AZTOOLS["libAzToolsFramework.so<br/>47 MB"]
    ATOMRPI["libAtom_RPI.Public.so"]
    EDITORLIB["libEditorLib.so<br/>32 MB<br/>84 个输入依赖"]
    EDITOR["Editor<br/>21 KB<br/>52 个输入依赖"]
    PLUGINS["EditorPlugins/*.so<br/>（34 个 order-only）"]

    AZCORE --> AZFW --> AZTOOLS
    AZCORE --> QTC --> AZTOOLS
    AZCORE --> ATOMRPI
    AZTOOLS --> EDITORLIB
    ATOMRPI --> EDITORLIB
    EDITORLIB --> EDITOR
    PLUGINS -.->|order-only| EDITOR

    style AZCORE fill:#ffe6cc
    style EDITOR fill:#d5e8d4
```

#### 三层原因，从浅到深

| 层次 | 原因 | 具体表现 |
|---|---|---|
| **链接层**（最直接） | 链接器需要**所有输入文件已存在** | 缺 `libAzCore.so` → `ld: cannot find -lAzCore` |
| **符号层** | 上层用下层的符号。`Editor` 调用 `AzToolsFramework` 的函数，那些函数的**定义在 `.so` 里** | 顺序反了 → `undefined reference` |
| **架构层**（根本原因） | **依赖方向决定了构建方向**。`AzCore` 不依赖任何 O3DE 模块（24.3 验证过），所以它能最先编完；`Editor` 依赖一切，所以只能最后 | 这不是工期安排，是**分层设计的直接后果** |

> 💡 **关键洞察**：**构建顺序是架构的镜像**。
> 你在 [24.3 依赖图](#codeframework--分层最清晰的地方) 里看到的箭头方向，就是 `ninja` 的执行顺序。
> 所以理解"为什么这个先编"，等于理解"为什么架构这样分层"。

#### ⚠️ 一个重要澄清：分批编译是"给人看的"，不是"必须的"

很多人误以为"必须手动分批，否则编不出来"。**事实不是这样**：

```bash
# 这样也能编成功 —— ninja 自己会解析依赖图，自动先建子目标
ninja -C /workspaces/o3de-build -j4 Editor
```

`ninja` 拿着 `build.ninja` 里的 DAG，**天然知道**要先建 `libAzCore.so` 才能链接 `Editor`。
你手动分批，收益是**人因工程**上的：

| 手动分批的收益 | 不分批的代价 |
|---|---|
| **失败可定位**：第 2 层挂了 → 问题在 `AzFramework` | 编 70 分钟挂在第 500 个目标，你得翻日志找 |
| **进度可感知**：每层几分钟就有产物，知道在推进 | 一小时看不到任何 `.so`，容易以为卡死 |
| **可中断恢复**：编完 3 层后中断，下次从第 4 层继续 | 同样可以恢复（ninja 增量），但心理上没底 |
| **可选择性放弃**：只要无头服务器 → 编完第 2 层就够 | 必须等全部 |

**结论**：

- **第一次编、或排查环境问题** → 分批（能快速定位到层）
- **构建树已健康、只是等产物** → 直接 `ninja Editor`（更省心）
- **只要跑服务器** → `ninja AzCore AzFramework AzGameFramework` 就停（**不编 Qt/Tools/Editor**，省 85 分钟）

#### 每层"漏了会怎样"—— 反向验证

| 你只编到 | 能做什么 | 不能做什么 |
|---|---|---|
| 第 1 层（`AzCore`） | 写纯逻辑单元测试 | 任何需要组件/资产的东西 |
| 第 2 层（+ `AzFramework`） | **可以跑无头服务器**（组件、资产、Spawnable 都在 AzFramework） | 没有编辑器、没有渲染 UI |
| 第 3 层（+ Qt/Tools） | 可以跑 `AssetProcessor`、`ProjectManager` | 没有 `Editor` |
| 第 4 层（+ `Editor`） | 完整编辑器 | — |

**这就是"为什么要先建子目标"的实用答案**：分层让你可以**在任意层停下来**，
用最小代价换到你真正需要的能力。

### 为什么要分成这四层

这是 O3DE 的**真实依赖倒置链**（不是人为划分）：

```mermaid
graph TD
  E["Editor<br/>789 目标"] --> T["AzToolsFramework + AzQtComponents<br/>仅工具侧"]
  E --> G["AzGameFramework<br/>仅运行时侧"]
  T --> F["AzFramework"]
  G --> F
  F --> C["AzCore<br/>数学/内存/序列化/EBus/RTTI"]
```

后面再加 GraphCanvas、EMotionFX、Atom RHI/RPI 等 Gem 层。

### 遇到失败怎么办：用 `-k 0`

```bash
ninja -C /workspaces/o3de-build -j4 -k 0
```

`-k 0` = 不限制失败次数，继续编其他目标。这样一次就能看到**所有**失败点，而不是修一个跑一次。

```bash
# 汇总所有失败目标
grep '^FAILED' build.log | sort -u
```

### 并行度怎么选

| 内存 | 建议 | 原因 |
|---|---|---|
| ≥ 16 GB | `-j4` 或更高 | |
| 8~16 GB | `-j4` | 单个编译进程峰值 1.3 GB |
| **4~8 GB** | **`-j3`** | 本机档位 |
| < 4 GB | `-j2` | |

实测：

| 并行度 | 吞吐 | swap |
|---|---|---|
| `-j4` | 7.7 目标/分钟 | 吃 1.5 GB |
| `-j3` | 约 3 目标/分钟 | 轻微 |
| `-j2` | 2.2 目标/分钟 | 无 |

反直觉结论：**`-j4` + swap 比 `-j2` 快**（4 核机器上 2 个进程用不满 CPU）。

### 长任务必须 `setsid`

```bash
cd /workspaces && setsid nohup ./build.sh < /dev/null > /dev/null 2>&1 & disown
```

三要素缺一不可：

| 要素 | 作用 |
|---|---|
| `setsid` | 脱离进程组，不被父进程信号波及 |
| `< /dev/null` | 防止 stdin 关闭异常 |
| `disown` | 从 shell 作业表移除 |

**`nohup ... &` 不够**。否则会看到假的"用户中断"：

```
ninja: build stopped: interrupted by user.
```

## 3.6 步骤 ⑤：产物验证

```bash
# 1. 构建树是否干净
ninja -C /workspaces/o3de-build -n Editor
# 期望：ninja: no work to do.

# 2. 依赖是否完整
ldd /workspaces/o3de-build/bin/profile/Editor | grep -c "not found"
# 期望：0

# 3. 符号是否正确导出（验证 -fvisibility 没坏事）
nm -D --defined-only /workspaces/o3de-build/bin/profile/libAzCore.so | grep -c EBus
# 期望：2000 以上（实测 2194）

# 4. 产物清单
ls -lh /workspaces/o3de-build/bin/profile/{Editor,libEditorLib.so,libAzCore.so}
```

### 为什么这三条能证明构建健康

| 检查 | 能发现什么 |
|---|---|
| `ninja -n` | 构建图是否一致（增量有效） |
| `ldd` | 链接期缺失的库 |
| `nm` 符号数 | 编译期 `-fvisibility=hidden` 是否误伤模板实例化 |

## 3.7 步骤 ⑥⑦：创建并构建项目

```bash
# 创建（几秒，只是模板实例化）
cd /workspaces/o3de
./scripts/o3de.sh create-project \
  -pp /workspaces/MyProject -pn MyProject -tn MinimalProject

# 项目单独 configure（2 分 42 秒）
cmake -B /workspaces/MyProject/build/linux -S /workspaces/MyProject -G Ninja \
  -DCMAKE_BUILD_TYPE=Profile -DLY_3RDPARTY_PATH=/workspaces/o3de-packages

# 编译（⚠️ 实测 3 小时以上）
ninja -C /workspaces/MyProject/build/linux -j3 MyProject.GameLauncher Editor
```

### ✅ 验证门 6（项目产物）

```bash
cd /workspaces/MyProject
ls -lh build/linux/bin/profile/libMyProject.so                 # 你的 Gem（实测 302 KB）
ls -lh build/linux/bin/profile/MyProject.HeadlessServerLauncher
ls -la Cache/linux/assetcatalog.xml                            # 资产已处理（约 1.7 MB）
ninja -C build/linux -n MyProject | tail -1                    # no work to do
```

四条全过才到冒烟测试——否则你分不清是"代码错"还是"没编完"。

### 冒烟测试：编完立刻跑一次

```bash
cd /workspaces/MyProject
timeout 30 ./build/linux/bin/profile/MyProject.HeadlessServerLauncher \
  --project-path /workspaces/MyProject 2>&1 | tail -25
```

**期望看到**：AssetProcessor 连接成功、资产数量（实测 3042）、`SystemComponent activated`。
看不到就查 [第十四部分](#第十四部分--踩坑与排错)。

> ⚠️ 本机无 GPU 时会在 RHI 阶段卡住（[坑 19](#坑-19headlessserver-并不是无渲染无-gpu-时会卡死)），
> 但 `component activated` 仍会出现——**能区分"我的代码错"和"环境不支持"**。

## 3.8 ⭐ 为什么项目要重编引擎（核心原理）

这是最容易让人困惑的一点。

### 实测证据

```
$ ninja -C /workspaces/MyProject/build/linux -j3 MyProject.GameLauncher Editor
[1/1025] Building CXX object o3de/Code/Framework/AtomCore/CMakeFiles/AtomCore.dir/Unity/unity_0_cxx.cxx.o
[2/1025] Building CXX object o3de/Code/Framework/AzCore/CMakeFiles/AzCore.dir/Unity/unity_34_cxx.cxx.o
         ↑ 注意前缀 o3de/ —— 它在项目构建目录下重建了引擎
```

```bash
$ ls /workspaces/MyProject/build/linux/o3de/Code/
CMakeFiles  Editor  Framework  LauncherUnified
                    ↑ 引擎的 Framework 完整镜像
```

### 机制链条

```mermaid
flowchart TD
  A["MyProject/CMakeLists.txt"] --> B["find_package(o3de REQUIRED)"]
  B --> C["Findo3de.cmake:64<br/>set(LY_PROJECTS ${CMAKE_CURRENT_LIST_DIR})"]
  C --> D["o3de/CMakeLists.txt:144<br/>add_subdirectory_on_external_subdirs()"]
  D --> E["Subdirectories.cmake:470<br/>遍历 engine.json + project.json 的<br/>external_subdirectories"]
  E --> F["你的 Gem/ 被 add_subdirectory"]
  F --> G["但引擎的所有 target 也一起注册了"]
  G --> H["build.ninja 里包含引擎全部目标<br/>→ 从零开始编"]
```

**关键一行**（`o3de/cmake/Findo3de.cmake:64`）：

```cmake
set(LY_PROJECTS ${CMAKE_CURRENT_LIST_DIR})
```

项目中心模式下，`Findo3de.cmake` 自动把"当前项目目录"塞进 `LY_PROJECTS`，于是引擎的 `CMakeLists.txt` 在处理 `add_subdirectory_on_external_subdirs()` 时会把你的 Gem 一起纳入。

**代价**：两个构建树的对象文件**互不共享**。同一个 `AzCore` 源码被编了两遍，产出两份不同的 `.o` 和 `.so`。

### 为什么这样设计

| 优点 | 说明 |
|---|---|
| 项目自包含 | 项目构建树里只有它需要的东西，不含无关 Gem |
| 多项目隔离 | 不同项目可以启用不同 Gem 版本，互不干扰 |
| 分发简单 | 别人只需 `find_package(o3de)` 找到引擎，不用完整引擎树 |

| 代价 | 说明 |
|---|---|
| 首次构建慢 | 3 小时+ |
| 磁盘翻倍 | 引擎 8 GB + 项目 4~6 GB |

### 加速方案：`LY_PROJECTS` 复用引擎构建树

`LY_PROJECTS` 是个 **CACHE 变量**（`o3de/cmake/Projects.cmake:17`），所以可以在**引擎构建树**里直接指定项目：

```bash
cmake -B /workspaces/o3de-build -S /workspaces/o3de \
  -DLY_PROJECTS="/workspaces/MyProject"
```

这样引擎的 12780 个目标都在，项目 target 额外加上。改一个 cpp 只需重编那一个 unity + 链接（**约 1 分钟**）。

⚠️ **当前被 googletest 阻塞**：重新 configure 会触发 `FetchContent_MakeAvailable(googletest)` 联网。解法：

```bash
cmake -B /workspaces/o3de-build -S /workspaces/o3de \
  -DLY_PROJECTS="/workspaces/MyProject" \
  -DFETCHCONTENT_FULLY_DISCONNECTED=ON \
  -DFETCHCONTENT_SOURCE_DIR_GOOGLETEST=/workspaces/o3de-build/_deps/googletest-src \
  -DFETCHCONTENT_SOURCE_DIR_MESHOPTIMIZER=/workspaces/o3de-build/_deps/meshoptimizer-src \
  -DFETCHCONTENT_SOURCE_DIR_MINI_AUDIO=/workspaces/o3de-build/_deps/miniaudio-src \
  -DFETCHCONTENT_SOURCE_DIR_OGG=/workspaces/o3de-build/_deps/ogg-src \
  -DFETCHCONTENT_SOURCE_DIR_OPENMESH=/workspaces/o3de-build/_deps/openmesh-src \
  -DFETCHCONTENT_SOURCE_DIR_RECASTNAVIGATION=/workspaces/o3de-build/_deps/recastnavigation-src \
  -DFETCHCONTENT_SOURCE_DIR_VORBIS=/workspaces/o3de-build/_deps/vorbis-src
```

> `_deps` 下已有这 7 个源码目录，`FETCHCONTENT_FULLY_DISCONNECTED=ON` 会跳过所有下载。

## 3.9 为什么 O3DE 编译这么慢：unity build

### 什么是 unity build

O3DE 默认 `LY_UNITY_BUILD=ON`。CMake 不直接编译 `.cpp`，而是生成聚合文件：

```cpp
// Code/Framework/AzCore/CMakeFiles/AzCore.dir/Unity/unity_34_cxx.cxx
/* generated by CMake */
#include "/workspaces/o3de/Code/Framework/AzCore/Platform/Common/UnixLike/AzCore/IO/SystemFile_UnixLike.cpp"
#include "/workspaces/o3de/Code/Framework/AzCore/Platform/Common/UnixLike/AzCore/IO/Internal/SystemFileUtils_UnixLike.cpp"
#include "..."
```

一个 unity 文件包含 **8~40 个** `.cpp`。

### 为什么这样做

| 收益 | 说明 |
|---|---|
| **编译快** | 头文件只解析一次，而不是每个 `.cpp` 各一次。实测提升 2-5 倍 |
| 链接快 | 更少的对象文件 |
| 内联优化更好 | 同一 TU 内的函数可以直接内联 |

### 代价

| 问题 | 说明 |
|---|---|
| 改一个文件要重编整个 unity | 实测：改 `Vector3.cpp` 触发 1 个 unity 重编，**1 分 09 秒** |
| 符号冲突 | 静态函数/宏重名会报重复定义 |
| **clangd 失效** | `compile_commands.json` 里只有 unity 文件，没有单个 `.cpp` → 智能提示退化（见第十部分） |

### unity 批次不可调

`LyUnityBuild.cmake` 里没有 `LY_UNITY_BUILD_BATCH_SIZE` 之类变量。批次由 CMake 的 `UNITY_BUILD_BATCH_SIZE` 属性控制，O3DE 没暴露它。

想完全关掉：

```bash
cmake -B <build> -S <src> -DLY_UNITY_BUILD=OFF
```

**代价**：编译时间可能翻 2-3 倍。不推荐，除非要排查符号冲突。

## 3.10 编译产物结构

```
/workspaces/o3de-build/
├── bin/profile/               ← 可执行程序（16 个）+ 运行时 .so（81 个）
│   ├── Editor                 21 KB（外壳）
│   ├── libEditorLib.so        32 MB（真实现）
│   ├── o3de                   ProjectManager
│   ├── AssetProcessor
│   ├── libAzCore.so           25 MB
│   ├── libAzFramework.so      36 MB
│   ├── libAzToolsFramework.so 47 MB
│   ├── libAzQtComponents.so   3.2 MB
│   ├── platforms/             Qt 平台插件（minimal / xcb）
│   ├── Qt5*.so                Qt 5.15.1
│   └── Registry/              ← **生成的插件清单**（见第四部分）
├── lib/profile/               ← 静态库（58 个 .a）
│   ├── libAzGameFramework.a   857 KB
│   └── libAzNetworking.a      9.2 MB
├── External/                  ← FetchContent 拉的三方源码构建
├── _deps/                     ← FetchContent 源码 + 构建
├── Code/ External/ lib/       ← 各 target 的中间对象
├── build.ninja                12 MB（8260 处绝对路径）
├── .ninja_deps                3.8 MB（头文件依赖）
├── .ninja_log                 172 KB（构建历史）
└── CMakeCache.txt             92 KB
```

### `Editor` 只有 21 KB 的原因

它是启动器外壳，真实现全在动态库里：

| 文件 | 体积 |
|---|---|
| `Editor` | 21 KB |
| `libEditorLib.so` | 32 MB |

**为什么这样设计**：静态库/动态库分离让多个 Gem 能共享代码、又能被独立替换。见第四部分。

## 3.11 如何添加或移除组件与 Gem

这是 L2 最常做的事，也是最容易卡住的地方——因为**要改的文件不止一个**，
而且**漏改的后果各不相同**（有的静默失败，有的链接报错）。

### 3.11.1 添加一个组件：三处必改 + 一处可选

以本项目新增 `HeartbeatComponent` 为例（已在 [第十九部分](#第十九部分--端到端实战从零做一个能跑的功能) 实战验证）。

| # | 改哪里 | 改什么 | **漏改的后果** | 何时发现 |
|---|---|---|---|---|
| **1** | `Gem/<name>_files.cmake` | 把 `.cpp` / `.h` 加进 `set(FILES ...)` | ⚠️ **静默失败**：文件完全不参与编译，没有任何报错 | 运行时"组件不存在"，你会以为代码没生效 |
| **2** | `Gem/Source/<Name>Module.cpp` | `m_descriptors.insert(..., { XxxComponent::CreateDescriptor() })` | ⚠️ **静默失败**：符号在 `.so` 里但没注册 → 反射找不到、`CreateComponent<T>()` 返回 `nullptr` | 运行时 |
| **3** | 组件头/源文件 | GUID（`XxxComponentTypeId`）+ `AZ_COMPONENT_DECL` / `AZ_COMPONENT_IMPL` | **链接失败**：`undefined reference to vtable for Xxx` | 编译期，明确报错 |
| 4（可选） | `Gem/Tests/test_files.cmake` | 加了测试的话 | 测试不跑，但不影响主程序 | — |

**最小 diff 示例**（1 和 2 是必须的）：

```cmake
# ① Gem/myproject_files.cmake
set(FILES
    Include/MyProject/MyProjectBus.h
    Include/MyProject/MyProjectTypeIds.h
    Source/HeartbeatComponent.cpp      # ← 新增
    Source/HeartbeatComponent.h        # ← 新增
    Source/MyProjectSystemComponent.cpp
    Source/MyProjectSystemComponent.h
)
```

```cpp
// ② Gem/Source/MyProjectModule.cpp
#include "HeartbeatComponent.h"        // ← 新增

MyProjectModule::MyProjectModule() : AZ::Module()
{
    m_descriptors.insert(m_descriptors.end(), {
        MyProjectSystemComponent::CreateDescriptor(),
        HeartbeatComponent::CreateDescriptor(),   // ← 新增
    });
}
```

### 3.11.2 为什么"漏改第 1 处"是静默的（源码级原因）

O3DE 用 **unity build**（3.9）：每个模块把多个 `.cpp` 用 `#include` 汇进一个
`unity_0_cxx.cxx`，再编译这一个文件。

```bash
# 看它到底编了哪个文件
cat /workspaces/MyProject/build/linux/External/Gem-1fce54cf/CMakeFiles/MyProject.Private.Object.dir/Unity/unity_0_cxx.cxx
```

真实输出（本机，含 CMake 自动生成的注释）：

```cpp
/* generated by CMake */

/* NOLINTNEXTLINE(bugprone-suspicious-include) */
#include "/workspaces/MyProject/Gem/Source/HeartbeatComponent.cpp"

/* NOLINTNEXTLINE(bugprone-suspicious-include) */
#include "/workspaces/MyProject/Gem/Source/MyProjectSystemComponent.cpp"
```

**关键**：这个 unity 文件由 CMake **根据 `set(FILES ...)` 自动生成**。
你的文件不在 `FILES` 里 → 它不会被 `#include` → **编译器根本看不到它** →
如果没人引用它，编译和链接都会"成功"，运行时才发现组件不存在。

> 💡 **看到 `bugprone-suspicious-include` 这个 NOLINT 就明白了**：连 clang-tidy 都知道
> "在 .cxx 里 include .cpp" 是不寻常的写法，O3DE 是刻意为之（为了编译速度，见 3.9）。

> 💡 这也解释了另一个常见困惑："我明明改了代码，为什么 `ninja` 说 `no work to do`？"
> 因为那个文件根本没进构建图，`ninja` 认为没有输入变化。

### 3.11.3 移除一个组件：实测三阶段失败

**移除比添加更容易出错**，因为别处可能还在引用它。本机实测了完整过程：

```bash
# 只从 files.cmake 删掉 HeartbeatComponent 两行，别的都不动
sed -i '/HeartbeatComponent/d' Gem/myproject_files.cmake
ninja MyProject.Private.Object      # 阶段 A
ninja MyProject                     # 阶段 B
```

| 阶段 | 结果 | 为什么 |
|---|---|---|
| **A：编静态库** | ✅ **成功**（`EXIT=0`） | `.a` 只是把 `.o` 打包，**不解析符号**。未定义符号可以合法存在 |
| **B：链动态库** | ❌ **失败** | `libMyProject.so` 链接时带 `-Wl,--no-undefined`，**不允许任何未定义符号** |

阶段 B 的真实错误（三条，全部指向还没清理的引用点）：

```
/usr/bin/ld: MyProjectModule.cpp.o: in function `MyProjectModule::MyProjectModule()':
  MyProjectModule.cpp:25: undefined reference to `MyProject::HeartbeatComponent::CreateDescriptor()'

/usr/bin/ld: libMyProject.Private.Object.a(unity_0_cxx.cxx.o): in function
  `MyProjectSystemComponent::Activate()':
  Entity.h:479: undefined reference to `MyProject::HeartbeatComponent::operator new(unsigned long)'

/usr/bin/ld: ... in function `MyProjectSystemComponent::Activate()':
  HeartbeatComponent.h:25: undefined reference to `vtable for MyProject::HeartbeatComponent'
```

| 错误 | 来自 | 说明 |
|---|---|---|
| `CreateDescriptor()` | `MyProjectModule.cpp:25` | 模块还在注册这个组件 |
| `operator new` | `MyProjectSystemComponent::Activate()` | 系统组件还在 `CreateComponent<HeartbeatComponent>()` |
| `vtable for ...` | `HeartbeatComponent.h:25` | 头文件里的虚函数表需要 `.cpp` 提供 |

**这三条错误正好构成一张"清理清单"**——把这三个引用点删掉，就删干净了。

### 3.11.4 移除组件的正确顺序（五步）

```mermaid
flowchart TD
    A["① 全项目搜引用<br/>grep 类名"]
    B["② 删掉所有引用点<br/>CreateComponent / CreateDescriptor / include"]
    C["③ 从 *_files.cmake 移除<br/>.cpp 与 .h"]
    D["④ 重新编译<br/>ninja MyProject"]
    E["⑤ 验证符号已消失"]

    A --> B --> C --> D --> E

    style A fill:#ffe6cc
    style E fill:#d5e8d4
```

```bash
# ① 全项目搜引用（这一步能一次找全，别靠猜）
cd /workspaces/MyProject
grep -rn "HeartbeatComponent" Gem/ --include=*.cpp --include=*.h   | grep -v "^Gem/Source/HeartbeatComponent"

# ② 编辑上面查到的每个文件，删掉引用
# ③ 编辑 files.cmake 移除两行，然后删物理文件
# ④ 重新编译
ninja -C build/linux -j3 MyProject

# ⑤ 验证
nm --defined-only build/linux/lib/profile/libMyProject.Private.Object.a | grep -c Heartbeat
# 期望：0
ls -lh build/linux/bin/profile/libMyProject.so   # 期望：仍然链接成功
```

> ⚠️ **为什么建议"先清引用，再删文件"**：文件还在磁盘上时，`#include` 仍能成功，
> 你**只会看到链接错误**（明确的 `undefined reference`）；一旦先删了文件，报错会变成
> `fatal error: 'HeartbeatComponent.h' file not found`（编译期），
> 两类错误混在一起反而难定位。**先清引用 → 再删文件**，错误类型单一。

### 3.11.5 添加 / 移除 Gem（比组件简单，但有缓存陷阱）

Gem 是**整个功能包**级别的开关，操作对象是 `project.json` 的 `gem_names`。

```bash
# 添加（自动改 project.json）
cd /workspaces/o3de
./scripts/o3de.sh enable-gem -gn PhysX -pp /workspaces/MyProject

# 移除
./scripts/o3de.sh disable-gem -gn PhysX -pp /workspaces/MyProject
```

**加 Gem 之后的完整生效链条**：

```mermaid
flowchart LR
    A["gem_names 变化"] --> B["重新 configure<br/>生成新的目标图"]
    B --> C["重新编译<br/>新 Gem 的 .so 被构建"]
    C --> D["运行时<br/>模块被加载"]
    D --> E["Registry/*.setreg<br/>被合并"]

    style B fill:#ffe6cc
```

| 步骤 | 命令 | 漏了会怎样 |
|---|---|---|
| 改 `gem_names` | `enable-gem` | — |
| **重新 configure** | `cmake -B build/linux -S .`（或让 `ninja` 自动触发） | `ninja` 报 `unknown target Gem::PhysX` |
| 编译 | `ninja -C build/linux -j3` | 运行时 `Attempting to load module` 失败 |
| 运行 | — | — |

**四个 Gem 相关的坑**（都验证过）：

| 坑 | 现象 | 原因 |
|---|---|---|
| **只改 `gem_names` 不重配** | `ninja` 找不到新目标 | 目标图在 configure 时生成（3.4） |
| **启用但没编** | 运行时加载模块失败 | "启用 ≠ 已编译"（18.5） |
| **资产没重建** | 材质/贴图找不到 | 新 Gem 的 `Assets/` 需要 AP 重新扫描 |
| **`.setreg` 冲突** | 配置值不是你以为的 | 合并顺序见 9.2 |

### 3.11.6 一张速查表：我要改什么，要重编多少

| 你的改动 | 需要做什么 | 耗时（本机实测） |
|---|---|---|
| 改 `Gem/Source/*.cpp` 的**内容** | `ninja MyProject` | 约 1 分钟 |
| **加/删** `Gem/Source/*.cpp`（改 `*_files.cmake`） | `ninja MyProject`（**自动触发 re-configure**） | 约 3 分钟（configure 本身 140 秒） |
| 改 `Gem/CMakeLists.txt` | 同上 | 约 3 分钟 |
| 改 `project.json` 的 `gem_names` | 重新 configure + `ninja` | 分钟级 |
| 加/删 `Assets/**` | 等 AssetProcessor（不用编译） | 秒级 |
| 改 `Registry/*.setreg` | 重启程序（不用编译） | 秒级 |
| 改**引擎**源码（`Code/Framework/**`） | 重编引擎 + 重编项目 | 小时级（3.8） |

> 💡 **注意第 2 行**：改 `*_files.cmake` 会让 CMake **重新 configure**（本机实测 140.5 秒），
> 而重新 configure 会**重新生成 unity 文件**——所以哪怕只加一个文件，
> 那一整个 unity 批次（可能几十个 `.cpp`）都要重编。**这是 unity build 的隐性代价**（3.9）。

### 3.11.7 自检

- [ ] 加组件要改哪两处"必须"的地方？各自漏了会怎样（哪个静默、哪个报错）？
- [ ] 为什么从 `*_files.cmake` 移除文件后，**静态库能编成功**但**动态库链接失败**？
- [ ] 移除组件时，为什么建议"先清引用，再删文件"？
- [ ] `enable-gem` 之后漏了重新 configure，会看到什么错误？
- [ ] 改 `*_files.cmake` 为什么比改 `.cpp` 内容慢那么多？

---

## 3.12 先做三个决定

动手之前先回答三个问题。**答错了后面全白费。**

```mermaid
flowchart TD
    Q1{"① 在哪编？"}
    Q1 -->|"有 40 GB 磁盘 + 8 GB 内存"| LOCAL["本机直接编<br/>✅ 最快（增量方便）<br/>✅ 不用传文件"]
    Q1 -->|"磁盘/内存不够"| CLOUD["Codespace / 云主机<br/>⚠️ 32 GB 磁盘是硬瓶颈<br/>⚠️ 编完要传回来"]

    Q2{"② 编什么？"}
    Q2 -->|"只要引擎 + 自己的项目"| STD["标准流程（本章）"]
    Q2 -->|"只要跑服务器/无头"| HEADLESS["同上，但跳过 Editor<br/>省约 1 小时"]

    Q3{"③ 用哪个版本？"}
    Q3 -->|"学习/跟进最新"| TAG["--branch 2605.0（本文实测）"]
    Q3 -->|"要长期稳定"| LTS["用官方 LTS 分支"]
```

### 决定 ①：在哪编

| 环境 | 优点 | 缺点 | 本机实测 |
|---|---|---|---|
| **本机 Linux** | 增量编译快、传文件零成本、clangd 直接可用 | 需要磁盘内存 | ✅ 推荐 |
| **Codespace** | 免配置、配置高（15 GB 内存） | **32 GB 磁盘是硬瓶颈**、编完要传 12 GB 回来、隧道会断 | ⚠️ 应急可用 |
| **Docker** | 环境可复现 | 拉镜像需要网络；本机实测 Docker Hub 不可达 | ❌ 本机不可行 |

### 决定 ②：编什么

| 目标组 | 时间（4 核） | 你什么时候需要 |
|---|---|---|
| `AzCore` + `AzFramework` | 约 5 分钟 | 只想跑无头服务器 |
| 上面 + `AzQtComponents` + `AzToolsFramework` | 约 20 分钟 | 需要编辑器框架 |
| 上面 + `Editor` | **再加约 70 分钟** | 需要图形编辑器 |
| 全部 12780 个目标 | 数小时 | 需要所有 Gem 和工具 |

**本指南默认走完整流程**，同时在需要处标注"如果只要无头可以跳过"。

## 3.13 磁盘与内存预算（先算，别中途炸）

### 磁盘（本机实测）

| 阶段 | 新增占用 | 累计 |
|---|---|---|
| 源码（`GIT_LFS_SKIP_SMUDGE=1`） | 448 MB | 0.45 GB |
| 第三方包（configure 时下载解压） | **4.2 GB** | 4.7 GB |
| 构建树（编完，含 `.dbg`） | **12 GB** | **16.7 GB** |
| 项目构建树 | 1.2 GB（未编完）/ 4–6 GB（完整） | 约 22 GB |
| 资产缓存（`Cache/`） | 111 MB | 约 22 GB |

> ⚠️ **按 40 GB 规划，不是 17 GB。** 只留 20 GB 会在链接阶段失败（坑 5 就是这么踩的）。

### 内存与并行度

实测：编译一个引擎里的较大文件（`Entity.cpp`，含大量头文件）：

```
耗时      23.4 秒
峰值内存  551 MB
```

考虑后端代码生成，**按每个编译进程 1 GB 估算**：

| 可用内存 | 建议 `-j` | 说明 |
|---|---|---|
| 3–4 GB | **`-j2`** 或 `-j3` | 本机实测 `-j3` 可用但会碰 swap |
| 8 GB | `-j4` | 舒适 |
| 13 GB+ | `-j4`（受核数限制） | 4 核机器再高也没用 |

**公式**：`j = min(CPU 核数, 可用内存GB ÷ 1)`，再减 1 留余量。

### 工具链版本要求

| 项 | 要求 | 本机实测 |
|---|---|---|
| CMake | **≥ 3.24**（`cmake_minimum_required`） | 3.28.3 |
| Ninja | 任意近期版本 | 1.11.1 |
| 编译器 | **clang 18**（推荐；O3DE 会自动挑最高版本） | 18.1.3 |
| Python | 3.10（O3DE 自带 venv 用它） | 3.10.13 |
| OS | Ubuntu 22.04 / 24.04 | 24.04.5 |

> 💡 **为什么推荐 clang 而不是 GCC**：O3DE 的 `cmake/Platform/Linux/CompilerSettings_linux.cmake`
> 在没有 `CC`/`CXX` 时会**自动挑 `/usr/bin/clang-[0-9]*` 里版本最高的**。
> 用 GCC 13 编会遇到一批已知问题；clang-18 实测全程干净。

## 3.14 一张总表：每阶段的时间 / 磁盘 / 验证

| 阶段 | 耗时（4 核） | 新增磁盘 | 验证命令 | 过了说明 |
|---|---|---|---|---|
| 1 依赖 | 3–5 min | ~1 GB | `which clang-scan-deps` | 工具链齐了 |
| 2 源码 | 1–2 min | 448 MB | `du -sh .` | 源码完整 |
| 3 configure | **~25 min** | 4.2 GB | `ls build.ninja` | 构建图生成 |
| 4 编译 | **~90 min** | 12 GB | `ninja -n Editor` → no work | 引擎编好 |
| 5 验证 | 1 min | 0 | `ldd \| grep -c "not found"` → 0 | 产物可用 |
| 6 项目 | **~2 min configure + 数小时编译** | 4–6 GB | `libMyProject.so` 存在 | 项目能用 |
| 7 clangd | 5 min | 0 | `clangd --check` → 0 errors | 能读代码 |
| **合计** | **约 2 小时（引擎）+ 数小时（项目）** | **约 22 GB** | | |

## 3.15 完全重来：干净的重置流程

搞乱了想从头来？**分清删什么**：

```bash
# ① 只重置构建（保留源码和三方包，最快）
rm -rf /workspaces/o3de-build
# 重新 configure 即可，源码与包都不用重下

# ② 重置三方包（怀疑包损坏）
rm -rf /workspaces/o3de-packages
# configure 会重新下载 4.2 GB

# ③ 彻底重来
rm -rf /workspaces/o3de /workspaces/o3de-build /workspaces/o3de-packages

# ④ 项目重置（保留项目源码，只重置构建）
rm -rf /workspaces/MyProject/build /workspaces/MyProject/Cache
```

### ⚠️ 三个"删了会后悔"的东西

| 路径 | 为什么不能随便删 |
|---|---|
| `~/.o3de/` | 引擎/项目/Gem 的注册清单 + Python venv。删了要重新 `register` |
| `/workspaces/MyProject/Assets/` | **源资产**，不可再生 |
| `/workspaces/MyProject/Registry/*.setreg` | 你的项目配置 |

**可以放心删的**：`build/`、`Cache/`、`log/`、`user/`。

# 第四部分 · 插件式架构

> **🎓 L3 · 懂架构 ★核心** ｜ 前置：L2（写过 Gem 才看得懂） ｜ 读完能做什么：画出插件从磁盘到内存的装配链路 ｜ 下一站 → **第六部分（L3）**

> 这部分基于 `ModuleManager.cpp`、`ComponentApplication.cpp`、`SettingsRegistry.cmake` 的实际源码。

## 4.1 三个概念要分清

| 概念 | 是什么 | 粒度 | 例子 |
|---|---|---|---|
| **Gem** | 打包单元：代码 + 资产 + 工具 + 编辑器扩展 | 一组功能 | `Atom`、`PhysX`、`MyProject` |
| **Target** | CMake 构建目标 | 一个二进制 | `MyProject`、`MyProject.Builders`、`MyProject.Tools` |
| **Module** | 运行时加载单元 = 一个 `.so` | 一个动态库 | `libMyProject.so` |

关系：

```mermaid
graph LR
  A["Gem: Atom<br/>（打包单元）"] --> B["Target: Atom<br/>Target: Atom.Builders<br/>Target: Atom.Editor"]
  B --> C["Module: libAtom.so<br/>libAtom.Builders.so<br/>libAtom.Editor.so"]
```

**一个 Gem 可以产出多个 Module，用于不同场景（运行时/构建/编辑器）。**

## 4.2 ⭐ 核心机制：CMake 生成插件清单

这是整个插件架构的**装配关键**，也是最少人知道的一点。

### 生成的清单文件

编译后在 `bin/profile/Registry/` 下会看到：

```
cmake_dependencies.assetbuilder.setreg
cmake_dependencies.assetprocessor.setreg
cmake_dependencies.editor.setreg
cmake_dependencies.materialeditor.setreg
cmake_dependencies.myproject.setreg
cmake_dependencies.myproject.editor.setreg
cmake_dependencies.myproject.myproject_gamelauncher.setreg
cmake_dependencies.myproject.myproject_serverlauncher.setreg
cmake_dependencies.myproject_headlessserverlauncher.setreg
...
```

**每个可执行目标一个文件。**

### 文件内容（实测）

`cmake_dependencies.myproject.setreg`：

```json
{
    "O3DE": {
        "Gems": {
            "MyProject": {
                "Targets": {
                    "MyProject": {
                        "Modules": ["libMyProject.so"]        ← 关键
                    },
                    "MyProject.Builders": {
                    }
                }
            },
            "AtomFont": {
                "Targets": {
                    "AtomFont": {
                        "Modules": ["libAtomFont.so"]
                    }
                }
            },
            "AtomImGuiTools": {
                "Targets": {
                    "AtomImGuiTools": {
                        "Modules": ["libAtomImGuiTools.so"]
                    }
                }
            },
            ...
        }
    }
}
```

**这就是"Gem 名 → 目标名 → `.so` 文件"的完整映射表。**

### 谁生成的

`cmake/SettingsRegistry.cmake:235` 的 `ly_delayed_generate_settings_registry()`：

```cmake
function(ly_delayed_generate_settings_registry)
    if(LY_MONOLITHIC_GAME)   # 单体构建不需要生成
        return()
    endif()

    foreach(prefix_target_variant ${ly_delayed_load_targets})
        # 取出 prefix / target / variant
        # 查询该 (项目, 目标) 组合的 Gem 依赖
        o3de_get_gem_load_dependencies(...)
        # 生成 json 片段
        ly_populate_gem_objects(gem_load_dependencies_json "${all_gem_dependencies}")
        ...
    endforeach()
endfunction()
```

### ⭐ 为什么按目标生成不同清单（实测数据）

同样一个项目，不同可执行目标拿到的 Gem 清单**完全不同**：

| 清单文件 | Gem 数量 | 含 `MyProject` |
|---|---|---|
| `cmake_dependencies.editor.setreg`（引擎编辑器） | **39** | ❌ |
| `cmake_dependencies.myproject.editor.setreg`（项目编辑器） | **36** | ✅ |
| `cmake_dependencies.myproject.myproject_gamelauncher.setreg` | **22** | ✅ |
| `cmake_dependencies.myproject.myproject_serverlauncher.setreg` | **22** | ✅ |
| `cmake_dependencies.myproject_headlessserverlauncher.setreg` | **24** | — |

**这就是插件式的核心价值：**

```mermaid
graph TD
  G["同一套 Gem 源码"] --> A["Editor 变体<br/>libAtom.Editor.so<br/>39 Gem"]
  G --> B["GameLauncher 变体<br/>libAtom.so<br/>22 Gem"]
  G --> C["ServerLauncher 变体<br/>22 Gem"]
  A --> A1["含编辑器 UI / Gizmo / 属性面板"]
  B --> B1["只含运行时渲染，无编辑器代码"]
  C --> C1["跳过渲染相关 Gem"]
```

**同一个 Gem，按变体编出不同的 `.so`，加载进不同程序。**

具体到你的 `MyProject`：

```json
"MyProject": {
    "Targets": {
        "MyProject":          { "Modules": ["libMyProject.so"] },        ← 运行时
        "MyProject.Builders": { }                                          ← 无模块（assets-only）
    }
}
```

`MyProject.Tools` 在编辑器清单里出现，在 GameLauncher 里不出现 → **工具代码不进游戏包**。

## 4.3 变体系统：5 种应用类型

`Gem/CMakeLists.txt:67-71` 定义了 5 个变体别名：

```cmake
ly_create_alias(NAME ${gem_name}.Builders NAMESPACE Gem TARGETS Gem::${gem_name})
ly_create_alias(NAME ${gem_name}.Tools    NAMESPACE Gem TARGETS Gem::${gem_name})
ly_create_alias(NAME ${gem_name}.Clients  NAMESPACE Gem TARGETS Gem::${gem_name})
ly_create_alias(NAME ${gem_name}.Servers  NAMESPACE Gem TARGETS Gem::${gem_name})
ly_create_alias(NAME ${gem_name}.Unified  NAMESPACE Gem TARGETS Gem::${gem_name})
```

| 变体 | 用途 | 特点 |
|---|---|---|
| **Builders** | AssetProcessor / AssetBuilder | 资产构建，无渲染 |
| **Tools** | Editor / MaterialEditor | 含完整编辑器 UI |
| **Clients** | GameLauncher | 玩家运行时 |
| **Servers** | ServerLauncher | 专用服务器，无渲染/音频 |
| **Unified** | 统一启动器 | 客户端+服务端合一 |

`o3de_add_variant_dependencies_for_gem_dependencies()` 会根据 `gem.json` 里声明的依赖，自动把每个变体连到对应变体的依赖 Gem 上。

**实用意义**：如果一个 Gem 声明只支持 `Clients`，那它不会出现在 Editor 里，反之亦然。

## 4.4 运行时加载：5 个阶段

`ModuleManager.cpp:344` 的 `LoadDynamicModule()` 定义了精确的 5 个阶段：

```cpp
AZStd::vector<AZStd::pair<ModuleInitializationSteps, AZStd::function<PhaseOutcome()>>> phases = {
    { ModuleInitializationSteps::None,                     ... },   // 占位
    { ModuleInitializationSteps::Load,                     ... },   // dlopen
    { ModuleInitializationSteps::CreateClass,              ... },   // new Module
    { ModuleInitializationSteps::RegisterComponentDescriptors, ... }, // 注册组件
    { ModuleInitializationSteps::ActivateEntity,           ... },   // 激活
};
```

### 阶段 1：`Load` —— dlopen

```cpp
m_preModuleLoadEvent.Signal(preprocessedModulePath);
moduleDataPtr->m_dynamicHandle = DynamicModuleHandle::Create(preprocessedModulePath.c_str());
if (!moduleDataPtr->m_dynamicHandle->Load(AZ::DynamicModuleHandle::LoadFlags::InitFuncRequired))
{
    return AZ::Failure("Failed to load dynamic library at path ...");
}
```

做的事情：

1. 信号 `PreModuleLoadEvent`（其他系统可以在这时准备）
2. 创建 `DynamicModuleHandle`（Linux 上是 `dlopen`）
3. 加载并**要求存在初始化函数**（`InitFuncRequired`）
4. 调用库里的 `InitializeDynamicModule()` → 把 DLL 挂到全局 `AZ::Environment`

### 阶段 2：`CreateClass` —— 找符号、造对象

```cpp
auto createModuleFunction = moduleDataPtr->m_dynamicHandle->GetFunction<CreateModuleClassFunction>(
    CreateModuleClassFunctionName);
if (!createModuleFunction)
{
    return AZ::Failure("'%s' entry point in module \"%s\" failed to create AZ::Module.");
}
moduleDataPtr->m_module = createModuleFunction();
```

**符号名约定**是 `CreateModuleClass_<ModuleName>`。这就是 `MyProjectModule.cpp` 结尾那段宏的作用：

```cpp
#if defined(O3DE_GEM_NAME)
AZ_DECLARE_MODULE_CLASS(AZ_JOIN(Gem_, O3DE_GEM_NAME), MyProject::MyProjectModule)
#else
AZ_DECLARE_MODULE_CLASS(Gem_MyProject, MyProject::MyProjectModule)
#endif
```

`AZ_DECLARE_MODULE_CLASS` 生成：

```cpp
extern "C" AZ_DLL_EXPORT AZ::Module* CreateModuleClass_Gem_MyProject()
{
    return aznew MyProject::MyProjectModule();
}
```

而 `O3DE_GEM_NAME` 这个宏从哪来？`Gem/CMakeLists.txt:58-64`：

```cmake
ly_add_source_properties(
SOURCES Source/MyProjectModule.cpp
PROPERTY COMPILE_DEFINITIONS
    VALUES
        O3DE_GEM_NAME=${gem_name}          # ← 注入 "MyProject"
        O3DE_GEM_VERSION=${gem_version})
```

**这是整个插件机制最脆弱的一环**：改 Gem 名字时，`gem_name` 变了 → 宏变了 → 符号名变了 → 但 `AZ_DECLARE_MODULE_CLASS` 也跟着变，所以一致。但如果手动硬编码符号名就会断。

### 阶段 3：`RegisterComponentDescriptors` —— 注册组件

```cpp
moduleDataPtr->m_module->RegisterComponentDescriptors();
```

`AZ::Module::RegisterComponentDescriptors()` 会遍历构造函数里塞进 `m_descriptors` 的每个 `ComponentDescriptor`：

```cpp
MyProjectModule()
    : AZ::Module()
{
    m_descriptors.insert(m_descriptors.end(), {
        MyProjectSystemComponent::CreateDescriptor(),   // ← 在这里被注册
        MyRotatorComponent::CreateDescriptor(),          // ← 你加的
    });
}
```

**注册后**：序列化系统才知道"存在这个组件类型、怎么创建它、怎么读写字段"。

### 阶段 4：`ActivateEntity` —— 激活

```cpp
Entity* systemEntity = nullptr;
ComponentApplicationBus::BroadcastResult(systemEntity,
    &ComponentApplicationBus::Events::FindEntity, SystemEntityId);

if (systemEntity && systemEntity->GetState() == Entity::State::Active)
{
    AZStd::vector<AZStd::shared_ptr<ModuleDataImpl>> modulesToInit = { moduleDataPtr };
    ActivateEntities(modulesToInit);
}
```

把模块声明的 SystemComponent 挂到 SystemEntity 上并激活。

## 4.5 ⭐ 三趟横向扫描（不是纵向）

这是 O3DE 插件加载最巧妙的设计。

`ComponentApplication.cpp:1607`：

```cpp
for (ModuleInitializationSteps lastStepToPerform : {
        ModuleInitializationSteps::Load,
        ModuleInitializationSteps::CreateClass,
        ModuleInitializationSteps::RegisterComponentDescriptors })
{
    AZ::ModuleManagerRequests::LoadModulesResult loadModuleOutcomes;
    ModuleManagerRequestBus::BroadcastResult(
        loadModuleOutcomes, &ModuleManagerRequests::LoadDynamicModules,
        gemModules, lastStepToPerform, true);
}
```

**不是**对每个模块依次走完 4 个阶段，而是：

```mermaid
flowchart TD
  subgraph P1["第 1 趟：Load"]
    A1["libAzCore.so"] --> A2["libAtom.so"] --> A3["libMyProject.so"]
  end
  subgraph P2["第 2 趟：CreateClass"]
    B1["libAzCore.so"] --> B2["libAtom.so"] --> B3["libMyProject.so"]
  end
  subgraph P3["第 3 趟：RegisterComponentDescriptors"]
    C1["libAzCore.so"] --> C2["libAtom.so"] --> C3["libMyProject.so"]
  end
  P1 --> P2 --> P3
```

### 为什么必须这样

因为**模块之间可能互相引用**：

- `libMyProject.so` 的组件可能继承 `libAzCore.so` 里的基类
- 序列化时需要解析 `libAtom.so` 的类型

如果纵向走（A 走完再 B），加载 B 时 A 的类型可能还没注册 → 崩溃。

横向走保证：**所有库都加载完 → 所有 Module 对象都造好 → 所有组件描述符都注册完 → 再激活**。

### 阶段可以"部分完成"

`LoadDynamicModule` 有幂等设计：

```cpp
// If the module is already "loaded enough," just return it
if (moduleDataPtr->m_lastCompletedStep >= lastStepToPerform)
{
    return AZ::Success(...);
}
```

每个模块记录 `m_lastCompletedStep`。所以第二趟调 `LoadDynamicModule(..., CreateClass)` 时，已完成的 `Load` 会跳过。

**实用意义**：可以在运行时增量加载一个 Gem（只做 `Load` + `CreateClass`，不 `RegisterComponentDescriptors`），这就是某些插件系统的热加载基础。

## 4.6 完整装配链路图

```mermaid
flowchart TD
  subgraph BUILD["编译期（CMake）"]
    A1["project.json<br/>gem_names: [MyProject, Atom, ...]"] --> A2["CMake 解析依赖图<br/>递归 gem.json 的 dependencies"]
    A2 --> A3["按 (项目, 目标, 变体) 组合<br/>生成 cmake_dependencies.*.setreg"]
    A3 --> A4["每个 Gem 编出变体对应的 .so<br/>libMyProject.so / libMyProject.Tools.so"]
  end

  subgraph RUNTIME["运行期（开始加载）"]
    B1["启动 bin/profile/Editor"] --> B2["读 Registry/*.setreg<br/>合并所有 cmake_dependencies.*.setreg"]
    B2 --> B3["SettingsRegistry 里得到<br/>O3DE.Gems.&lt;Name&gt;.Targets.&lt;Target&gt;.Modules"]
    B3 --> B4["筛选 autoLoad=true 的 Gem"]
    B4 --> B5["第 1 趟：dlopen 全部 .so"]
    B5 --> B6["第 2 趟：dlsym CreateModuleClass_*<br/>new AZ::Module()"]
    B6 --> B7["第 3 趟：RegisterComponentDescriptors()"]
    B7 --> B8["创建 SystemEntity<br/>加入 GetRequiredSystemComponents()"]
    B8 --> B9["SystemEntity 激活<br/>所有系统组件按依赖排序 Activate()"]
  end

  A4 -.-> B5
```

## 4.7 插件隔离的三个层次

O3DE 的"插件式"不只是"动态库"，而是三层隔离：

### 第一层：编译隔离

你的 Gem 只依赖内核的**公开头文件**。想改引擎行为？只能通过：

- 继承接口（`AZ::Component`、`AZ::TickBus::Handler`）
- 实现 EBus handler
- 注册 `AZ::Interface`

**不能**直接改 `AzCore` 的内部状态。

### 第二层：符号隔离

`-fvisibility=hidden -fvisibility-inlines-hidden` 让 `.so` 只导出显式标记的符号。

实测：

```bash
nm -D --defined-only /workspaces/o3de-build/bin/profile/libAzCore.so | grep -c EBus
# → 2194    （显式导出）
```

而 `AZ::EBus<ComponentDescriptor, ...>::GetContext` 这类**没有导出宏**的模板实例是 **local 符号**（`t`），其他 `.so` 看不到。

> 这正是 GCC 13 下报 522 个 undefined reference 的根因——clang 处理 `-fvisibility` 与 `extern template` 的方式不同，恰好正确。

### 第三层：进程内服务隔离

通过 `GetProvidedServices` / `GetRequiredServices` 声明依赖，引擎**自动按依赖排序激活**：

```cpp
void GetProvidedServices(DependencyArrayType& provided)
{
    provided.push_back(AZ_CRC_CE("MyProjectRotationService"));
}
void GetRequiredServices(DependencyArrayType& required)
{
    required.push_back(AZ_CRC_CE("TransformService"));
}
```

**你不需要管激活顺序。** 引擎会算出拓扑序。

## 4.8 为什么这样设计：对比其他引擎

| 方案 | 例子 | 优点 | 缺点 |
|---|---|---|---|
| 改引擎源码 | 很多自研引擎 | 完全自由 | 无法升级，多人冲突 |
| 单体内核 + 条件编译 | 部分商业引擎 | 性能最好 | 包体大，无法裁剪 |
| **插件/模块系统** | **O3DE / UE 的 Plugin** | 隔离好，可按需裁剪 | 抽象开销，加载复杂 |
| 微服务 | 后端 | 完全隔离 | 游戏需要极低延迟 |

O3DE 选了第三条，并且做得比较彻底：

- **连渲染器都是 Gem**（`Atom`），可以整个换掉
- **连网络栈都是 Gem**（`Multiplayer`）
- **连物理都是 Gem**（`PhysX`）

这意味着你可以做一个不用 Atom 的 O3DE 应用（比如纯服务器）。

## 4.9 验证插件机制的三条命令

```bash
# 1. 看某个目标会加载哪些 Gem
python3 -c "
import json
d = json.load(open('/workspaces/MyProject/build/linux/bin/profile/Registry/cmake_dependencies.myproject.myproject_gamelauncher.setreg'))
for name, info in d['O3DE']['Gems'].items():
    for tgt, ti in info.get('Targets', {}).items():
        mods = ti.get('Modules', [])
        if mods: print(f'{name:35s} {mods}')
"

# 2. 看你的 Gem 是否被列入
grep -l '"MyProject"' /workspaces/MyProject/build/linux/bin/profile/Registry/*.setreg

# 3. 看运行时会加载哪些 .so（从启动日志）
grep "Attempting to load module" /tmp/ed.log | sed 's|.*/||'
```

---

# 第五部分 · 项目全景：解剖 MinimalProject

> **🎓 L0 / L1 · 认识与跑起来** ｜ 前置：无 ｜ 读完能做什么：**说清 `myproject-src` 里每个文件的作用、"最小"具体小在哪、它是怎么被创建和编译出来的**
>
> 本章对象就是工作区里的 `myproject-src`（软链接 → `/workspaces/MyProject`）。
> 所有数字都在本机实测。原先分散在「第五部分 项目全景」与「原第二十七部分 解剖 MinimalProject」的
> 内容已合并到这一章。

## 5.1 先回答"为什么叫最小"

官方的定义就一句话（`Templates/MinimalProject/template.json` 的 `summary` 字段，原文）：

> **"Use this project template to create project that is the absolute minimum needed to get started in O3DE."**

即：**"起步所需的最小集合"**。注意它说的是"起步所需"，不是"能做出游戏"。这个区分很重要。

### "最小"的四个量化维度

| 维度 | MinimalProject | DefaultProject | 倍数 |
|---|---|---|---|
| **声明的 Gem 数** | **4** | 23 | 1 : 5.75 |
| **项目源码体积**（排除 `build`/`Cache`/`user`） | **564 KB** | — | — |
| **项目自己的 C++ 文件** | **7 个**（模板原本只有 **5 个**） | 更多（含 Editor 变体） | — |
| **`Assets/` 里的资产** | **0 个文件** | 有示例资产 | ∞ |

### 4 个 Gem 是哪些，各自为什么"非它不可"

```json
"gem_names": [
    "MyProject",          // ← 你的 Gem，必须有（哪怕空的）
    "Atom",               // ← 渲染器。去掉它，引擎没有 RHI，连窗口都开不了
    "CameraFramework",    // ← 相机。没有相机就没有"看"的角度
    "ImGui"               // ← 调试面板（可选，但 MinimalProject 保留了）
]
```

| Gem | 能不能去掉 | 去掉会怎样 |
|---|---|---|
| `MyProject` | ❌ 不能 | 项目没有自己的代码载体，`external_subdirectories` 里的 `Gem` 没人引用 |
| `Atom` | ⚠️ 理论上能（换 Null RHI） | 没有渲染管线，`Atom_RPI`/`RHI` 都不加载（但 [坑 19](#坑-19headlessserver-并不是无渲染无-gpu-时会卡死) 说明连 Headless 都要它） |
| `CameraFramework` | ✅ 能（但没用） | 没有相机组件，看不到东西 |
| `ImGui` | ✅ 能 | 少一个调试 UI，其他照常 |

**所以"4 个"不是硬性下限，而是"官方认为再少就没意义了"的实用下限。**

## 5.2 564 KB 里到底有什么（逐文件）

`du -sh --exclude=build --exclude=Cache --exclude=user .` → **564 KB**。

**注意三个要排除的目录**，它们不是项目源码：

| 目录 | 体积 | 是什么 | 进版本控制吗 |
|---|---|---|---|
| `build/` | **1.6 GB** | 项目构建树 | ❌ |
| `Cache/` | **165 MB** | AP 生成的产品资产 | ❌ |
| `user/` | **89 MB** | 日志 / Metrics / `AssetProcessorTemp` / 会话状态 | ❌ |
| 剩下的 | **564 KB** | **真正的项目源码** | ✅ |

> 🔍 **564 KB vs 1.6 GB = 源码只占构建树的 0.035%**（约 1/2900）。
> 这个比例解释了一个常见误解："项目才 500 KB，为什么编译要几小时？"——
> 因为 99.96% 的编译产物来自**引擎**，不是你的代码（[3.8](#38--为什么项目要重编引擎核心原理)）。

### 逐文件说明（15 个关键文件）

```
/workspaces/MyProject/                     564 KB
├── project.json                    ← ★ 项目身份证（CMake 和运行时都读它）
├── CMakeLists.txt                  ← ★ 项目构建入口（找引擎 + o3de_initialize）
├── CMakePresets.json               ← IDE / 命令行预设
├── gem.json?                       ← 没有！项目本身不是 Gem（见 27.5）
├── cmake/
│   └── EngineFinder.cmake          ← ★ 怎么找到引擎（读 ~/.o3de/o3de_manifest.json）
├── Gem/                    152 KB  ← ★ 你的代码（唯一需要长期维护的地方）
│   ├── gem.json                    ← Gem 清单（gem_name: MyProject）
│   ├── CMakeLists.txt              ← 两个目标：Private.Object（静态）+ MyProject（.so）
│   ├── myproject_files.cmake       ← 6 个条目（含我加的 Heartbeat）
│   ├── myproject_shared_files.cmake← 1 个条目（Module.cpp）
│   ├── Include/MyProject/          ← 公开头文件（Bus + TypeIds）
│   └── Source/                     ← 实现（Module / SystemComponent / Heartbeat）
├── Registry/                16 KB  ← .setreg 配置（AP 扫描、Assimp、启动关卡）
├── Levels/                  32 KB  ← DefaultLevel.prefab（唯一的"场景"）
├── Assets/                 4.0 KB  ← ⚠️ **空目录（0 个文件）**
├── ShaderLib/               16 KB  ← 全局 shader 资源组（.srgi）
├── Shaders/                8.0 KB  ← 你自己的 shader 放这
├── Config/                 8.0 KB  ← shader_global_build_options.json
├── Platform/                64 KB  ← 平台配置（Linux/Windows…）
├── Resources/              188 KB  ← 图标等资源
├── game.cfg / autoexec.cfg         ← CVar 配置（8 行都不到）
└── export.sh / export.bat          ← 发布脚本（缺 ExportScripts/，见 22.2）
```

### 三个"反直觉"的点

| 现象 | 实际情况 |
|---|---|
| `Assets/` 是**空目录**（0 文件） | 因为 MinimalProject 不含任何示例资产。你的场景只有一个 `DefaultLevel.prefab`（在 `Levels/` 里） |
| 项目根**没有** `gem.json` | 只有 `Gem/gem.json`。**项目 ≠ Gem**（27.5 详解） |
| `Gem/` 里只有 **5 个源文件**（模板原本） | 因为 MinimalProject 的 Gem 是"能编译通过的空壳"：一个 Module + 一个 SystemComponent |

## 5.3 "最小"意味着缺少什么（对照 DefaultProject）

DefaultProject 有 23 个 Gem，MinimalProject 缺了 **20 个**。按能力分类：

| 缺失能力 | 对应 Gem | 后果 |
|---|---|---|
| **物理** | `PhysX5` | 没有碰撞、刚体、角色控制器 |
| **动画** | `EMotionFX` | 没有骨骼动画、动画图 |
| **音频** | `AudioSystem` / `MiniAudio` | **完全没有声音** |
| **UI** | `LyShine` | 没有游戏内 UI（按钮/文本/血条） |
| **输入映射** | `StartingPointInput` | 没有"按键 → 动作"映射层（要自己连原始输入） |
| **存档** | `SaveData` | 没有跨平台存档 API |
| **可视化脚本** | `ScriptCanvasPhysics` / `ScriptEvents` | 没有节点式脚本 |
| **调试绘制** | `DebugDraw` | 不能在场景里画线/画球 |
| **地形/植被** | `LandscapeCanvas` | 没地形系统 |
| **关卡编辑辅助** | `WhiteBox` | 没有白盒快速建模 |
| **GI** | `DiffuseProbeGrid` | 没有漫反射全局光照 |
| **Python 绑定** | `EditorPythonBindings` | Editor 里不能跑 Python 脚本 |
| **远程工具** | `RemoteTools` | 没有 Editor ↔ 运行时 远程连接 |
| **基础几何体** | `PrimitiveAssets` | 没有现成的 cube/sphere 资产 |
| **Prefab 构建** | `PrefabBuilder` | — |
| **纹理图集** | `TextureAtlas` | — |

**所以"最小项目能做什么"的诚实答案是**：

| 能做 | 不能做 |
|---|---|
| ✅ 编译出 4 种 Launcher（Game / Server / HeadlessServer / Unified） | ❌ 没有物理 |
| ✅ 加载你的 Gem 与组件 | ❌ 没有声音 |
| ✅ 跑起渲染管线（有 GPU 时） | ❌ 没有 UI |
| ✅ 加载一个 Level（`DefaultLevel.prefab`） | ❌ 没有输入映射 |
| ✅ 作为你加功能的**干净起点** | ❌ 没有动画 |

> 💡 **这恰恰是它存在的意义**：一个**没有干扰的起点**。
> 你不会在排查"我的组件为什么不工作"时，被 20 个不相干的 Gem 干扰。

## 5.4 `Gem/` 深挖：最核心的目录与两个 `.cmake` 清单

```
Gem/
├── gem.json                     ★ Gem 身份证
├── CMakeLists.txt               ★ 定义 2 个构建目标（90 行）
├── myproject_files.cmake        ★ 静态库文件清单（4 项）
├── myproject_shared_files.cmake ★ 动态模块文件清单（1 项）
├── Include/MyProject/
│   ├── MyProjectTypeIds.h          ★ 3 个 UUID
│   └── MyProjectBus.h              对外接口（目前空的）
├── Source/
│   ├── MyProjectModule.cpp         ★ 模块入口
│   ├── MyProjectSystemComponent.h  ★ 全局服务声明
│   └── MyProjectSystemComponent.cpp★ 全局服务实现
└── Platform/
    ├── Linux/PAL_linux.cmake
    ├── Linux/myproject_linux_files.cmake
    ├── Linux/myproject_shared_linux_files.cmake
    └── ...（Mac / Windows / Android / iOS 同理）
```

### ⭐ 两个 `.cmake` 清单的区别（新手第一大坑）

一个 Gem 会被编成**两个**产物：

| 文件 | 登记内容 | 编成什么 | 谁用 |
|---|---|---|---|
| `myproject_files.cmake` | `MyProjectBus.h`、`MyProjectTypeIds.h`、`MyProjectSystemComponent.cpp/.h` | **静态库** `Gem::MyProject.Private.Object` | 其他 Gem 编译时链接 |
| `myproject_shared_files.cmake` | `MyProjectModule.cpp` | **动态模块** `libMyProject.so` | 引擎运行时 `dlopen` |

**为什么分开**：

- `libMyProject.so` 运行时加载，符号不对外暴露
- 但别的 Gem 想在编译期链接你的组件类，需要一个静态库
- 所以"会被外部引用"的放静态库，只把"入口"放动态模块

**实际影响：新增 `.cpp` 必须手动加进其中一个清单。漏了 CMake 不报错、不编译。**

判断规则：

| 新增文件 | 加到哪 |
|---|---|
| 新的组件类 `XxxComponent.cpp/.h` | `myproject_files.cmake`（90% 情况） |
| 新的公开头文件 `XxxBus.h` | `myproject_files.cmake` |
| 改 `MyProjectModule.cpp` | 已在 `shared` 里，不用动 |

### `Gem/CMakeLists.txt` 逐段解读

```cmake
o3de_gem_setup("MyProject")
```
设置 `gem_name`、`gem_path`、`gem_version`、`pal_dir`。

```cmake
include(${pal_dir}/PAL_${PAL_PLATFORM_NAME_LOWERCASE}.cmake)
if(NOT PAL_TRAIT_MYPROJECT_SUPPORTED)
    return()
endif()
```
平台抽象层。`Gem/Platform/Linux/PAL_linux.cmake` 内容就一行 `set(PAL_TRAIT_MYPROJECT_SUPPORTED TRUE)`。不支持的平台直接跳过。

```cmake
ly_add_target(
    NAME ${gem_name}.Private.Object STATIC        # ← 静态库
    NAMESPACE Gem
    FILES_CMAKE
        myproject_files.cmake
        ${pal_dir}/myproject_${PAL_PLATFORM_NAME_LOWERCASE}_files.cmake
    INCLUDE_DIRECTORIES
        PUBLIC Include
    BUILD_DEPENDENCIES
        PRIVATE
            AZ::AzGameFramework
            Gem::Atom_AtomBridge.Static
)
```

```cmake
ly_add_target(
    NAME ${gem_name} ${PAL_TRAIT_MONOLITHIC_DRIVEN_MODULE_TYPE}   # ← 动态模块
    NAMESPACE Gem
    FILES_CMAKE
        myproject_shared_files.cmake
        ${pal_dir}/myproject_shared_${PAL_PLATFORM_NAME_LOWERCASE}_files.cmake
    INCLUDE_DIRECTORIES
        PUBLIC Include
    BUILD_DEPENDENCIES
        PRIVATE
            Gem::${gem_name}.Private.Object     # ← 链接上面的静态库
            AZ::AzCore
)
```

```cmake
ly_add_source_properties(
SOURCES Source/MyProjectModule.cpp
PROPERTY COMPILE_DEFINITIONS
    VALUES
        O3DE_GEM_NAME=${gem_name}               # → "MyProject"
        O3DE_GEM_VERSION=${gem_version})
```
注入宏，拼出 `CreateModuleClass_Gem_MyProject()` 供 `dlsym`。

## 5.5 `project.json` 逐字段

```json
{
    "project_name": "MyProject",
    "version": "1.0.0",
    "project_id": "{9C02BE0C-840E-494D-9F5F-2090F1BC5067}",
    "engine": "o3de",
    "engine_version": "2.6.0",
    "external_subdirectories": [ "Gem" ],
    "gem_names": [ "MyProject", "Atom", "CameraFramework", "ImGui" ]
}
```

| 字段 | 作用 | 改了会怎样 |
|---|---|---|
| `engine` | 引擎注册名 | 找不到同名引擎 → configure 失败 |
| `external_subdirectories` | 额外的 Gem 目录 | **新建 Gem 必须加**，否则不参与构建 |
| `gem_names` | 启用列表 | 去掉 Atom → 没渲染；去掉 MyProject → 你的代码不加载 |
| `project_id` | 唯一 GUID | 用于资产标识，**不要改** |

对比：`DefaultProject` 的 `gem_names` 有 **23 个**，Minimal 只有 **4 个**。

### 为什么改 `project.json` 后 `ninja` 会自动重跑 cmake

`cmake/EngineFinder.cmake:17`：

```cmake
set_property(DIRECTORY APPEND PROPERTY CMAKE_CONFIGURE_DEPENDS ${CMAKE_CURRENT_SOURCE_DIR}/project.json)
```

注册成了配置依赖，所以不用手动重配。

## 5.6 它是怎么被创建出来的

### 一条命令（两步：找模板 → 实例化）

```bash
cd /workspaces/o3de
./scripts/o3de.sh create-project \
  -pp /workspaces/MyProject \
  -pn MyProject \
  -tn MinimalProject
```

| 参数 | 含义 |
|---|---|
| `-pp` | project path（创建到哪） |
| `-pn` | project name（项目名，会替换模板里的 `${Name}`） |
| `-tn` | **template name**（用哪个模板） |

### 实例化过程做了什么（第五部分 5.1 讲过，这里补关键细节）

```
1. 复制 Templates/MinimalProject/Template/ 的 19 项
   → 含 .gitignore / .command_settings 两个隐藏项
2. 把 ${Name} 全部替换成 MyProject
   → 文件名、文件内容、CMake 变量名都替换
3. 生成新的 GUID 写进 project.json 的 project_id
   → 每个项目必须有唯一 ID（{9C02BE0C-840E-494D-9F5F-2090F1BC5067}）
4. 记下 engine_version: "2.6.0"
5. 把路径写进 ~/.o3de/o3de_manifest.json 的 projects 数组
   → 这一步让引擎"知道"这个项目存在
```

**验证第 5 步**：

```bash
python3 -c "import json;d=json.load(open('$HOME/.o3de/o3de_manifest.json'));print(d.get('projects'))"
```

### 此时还没有任何编译产物

```bash
ninja -C /workspaces/MyProject/build -n 2>/dev/null
# 可能是 unknown target —— 因为还没 configure
```

`create-project` **只复制文件**，不编译、不 configure。这是最常见的误解。

## 5.7 它是怎么被编译出来的

**关键认知：项目不是"引擎的一部分"，而是一棵独立的构建树。**

### 三个层次

```mermaid
flowchart TD
    A["引擎构建树<br/>/workspaces/o3de-build<br/>12 GB<br/>12780 个目标"] -->|"已被编译，可复用"| C
    B["项目构建树<br/>/workspaces/MyProject/build/linux<br/>1.6 GB<br/>12759 个目标"] --> C
    C["你的产物<br/>libMyProject.so 302 KB<br/>4 种 Launcher"]

    style A fill:#ffe6cc
    style B fill:#d5e8d4
    style C fill:#c0ddec
```

**注意 12780 vs 12759**：项目构建树和引擎构建树的目标数**几乎一样多**。
这就是"项目为什么要重编引擎"的量化表现（[3.8](#38--为什么项目要重编引擎核心原理)）。

### 前置条件：五项必须全绿

编译项目前，**引擎必须已经编好**。这不是可选步骤——项目构建树要链接引擎的库。

```bash
# ① 引擎已注册（create-project 的前提）
python3 -c "import json,os;d=json.load(open(os.path.expanduser('~/.o3de/o3de_manifest.json')));print('engines:',d.get('engines'))"
# 期望：['/workspaces/o3de']

# ② 引擎构建树可用（项目要链它的 .so / .a）
ls /workspaces/o3de-build/build.ninja && ninja -C /workspaces/o3de-build -n Editor | tail -1
# 期望：ninja: no work to do.

# ③ 三方包在位（4.2 GB）
du -sh /workspaces/o3de-packages
# 期望：4.2G

# ④ 编译工具链
which clang++-18 clang-scan-deps cmake ninja

# ⑤ 磁盘余量（项目构建树 1.6 GB 起，完整 4–6 GB）
df -h /workspaces | tail -1
```

| 前置 | 缺了会怎样 | 怎么办 |
|---|---|---|
| 引擎未注册 | `create-project` 报 `Could not find engine` | `./scripts/o3de.sh register --engines /workspaces/o3de` |
| 引擎没编 | configure 能找到引擎，但链接时缺 `libAzCore.so` | 先做[第三部分](#第三部分--编译步骤与原理) |
| 三方包缺失 | configure 尝试下载（很慢/可能超时） | 传 `-DLY_3RDPARTY_PATH=` 指向正确位置 |
| 缺 `clang-scan-deps` | 编译期 `CLANG_SCAN_DEPS-NOTFOUND`（[坑 4](#坑-4clang_scan_deps-notfound错误延迟暴露)） | 补软链 |
| 磁盘不足 | 链接阶段 `No space left on device`（[坑 5](#坑-5磁盘耗尽)） | 清 `.dbg` / `.tar.xz` |

### 从零到能跑：八个步骤

```mermaid
flowchart TD
    S0["⓿ 确认引擎已编<br/>ninja -n Editor → no work"] --> S1["① create-project<br/>几秒<br/>→ 564 KB 源码"]
    S1 --> S2["② 检查实例化<br/>GUID 已替换<br/>→ 可 configure"]
    S2 --> S3["③ configure<br/>140 秒<br/>→ build.ninja (12759 目标)"]
    S3 --> S4["④ 编 Gem<br/>1–3 分钟<br/>→ libMyProject.so 302 KB"]
    S4 --> S5["⑤ 编 Launcher<br/>209 个边<br/>→ 可执行 + 24 个 .so"]
    S5 --> S6["⑥ 验证产物<br/>ldd / nm"]
    S6 --> S7["⑦ 运行<br/>→ 日志出现你的组件"]

    style S3 fill:#ffe6cc
    style S4 fill:#d5e8d4
    style S5 fill:#e1d5e7
```

#### ① 创建项目（几秒）

```bash
cd /workspaces/o3de
./scripts/o3de.sh create-project \
  -pp /workspaces/MyProject \
  -pn MyProject \
  -tn MinimalProject
```

**产物**：19 个顶层项、564 KB、**零编译产物**。

#### ② 检查实例化是否成功（30 秒）

**不要跳过这一步**——实例化有 10 个占位符要替换，任何一个没换成都不会立刻报错。

```bash
cd /workspaces/MyProject

# ① GUID 必须已替换（不是 ${SysCompClassId}）
grep -E "TypeId\s*=" Gem/Include/MyProject/MyProjectTypeIds.h
# 期望：三个不同的真实 UUID，形如 "{C429B730-364B-435A-AF7C-E5D78B3D2EAC}"

# ② project_id 必须已生成
python3 -c "import json;print(json.load(open('project.json'))['project_id'])"
# 期望：{9C02BE0C-840E-494D-9F5F-2090F1BC5067}（你的会不同）

# ③ 文件/目录名不能残留占位符
find . -name "*\${*" -not -path "./build/*" | head -3
# 期望：空

# ④ license 块应已被剥离（文件开头是空行，不是 # {BEGIN_LICENSE}）
head -2 Gem/CMakeLists.txt
```

| 检查失败 | 原因 | 解法 |
|---|---|---|
| GUID 还是 `${SysCompClassId}` | 模板实例化中断 | 删掉重来 |
| 三个 GUID 相同 | 手改过 | 重新生成（[3.11](#311-如何添加或移除组件与-gem)） |
| 残留 `${Name}` | 文件名没替换 | 删掉重来（别手改，见 27.7） |

#### ③ configure（实测 **140 秒**）

```bash
cd /workspaces/MyProject
cmake -B build/linux -S . -G Ninja \
  -DCMAKE_BUILD_TYPE=Profile \
  -DLY_3RDPARTY_PATH=/workspaces/o3de-packages
```

**产物**：`build/linux/build.ninja`（**12 759 个目标**）。

**这一步在做什么**（见下一节逐行分析）：读 `project.json` → 找引擎 → `find_package(o3de)` →
`o3de_initialize()` 遍历 `gem_names` 为每个 Gem 建目标。

**验证**：

```bash
ls build/linux/build.ninja
grep "^CMAKE_BUILD_TYPE" build/linux/CMakeCache.txt     # Profile
ninja -C build/linux -t targets all | wc -l             # 约 12759
```

> ⚠️ **`bin/profile` 目录此时是空的**——configure 只生成规则，不编译。

#### ④ 先编 Gem（实测 1–3 分钟）· **最快的健康检查**

```bash
cd /workspaces/MyProject
ninja -C build/linux -j3 MyProject
```

**产物**（本机实测）：

| 文件 | 体积 | 内容 |
|---|---|---|
| `build/linux/lib/profile/libMyProject.Private.Object.a` | **2.1 MB** | 全部实现（含 225 个 Heartbeat 符号） |
| `build/linux/bin/profile/libMyProject.so` | **302 KB** | 可加载的模块（导出 `CreateModuleClass` 等 4 个入口） |

**为什么先编这个**：它**不依赖引擎的可执行**，只依赖引擎的库。
1–3 分钟就能知道"我的代码有没有语法/链接问题"，不用等 200 个边。

**验证**：

```bash
cd build/linux

# ① 符号编出来了（查 .a，不要查 .so！见下）
nm --defined-only lib/profile/libMyProject.Private.Object.a | grep -ci 你的类名

# ② .so 是合法的可加载模块
nm -D --defined-only bin/profile/libMyProject.so | grep -E "CreateModuleClass|InitializeDynamicModule"
# 期望 4 个 T 符号

# ③ 依赖隔离：runtime 不能拖进 Qt
ldd bin/profile/libMyProject.so | grep -ci qt
# 期望 0
```

> ⚠️ **不要在 `.so` 里 grep 你的类名**：`-fvisibility=hidden` 会把组件符号变成
> **local**，`nm -D` 一定返回 0 条。这是很多人误判"代码没编进去"的原因（[3.11.3](#3113-移除一个组件实测三阶段失败)）。

#### ⑤ 编 Launcher（实测 **209 个边**）· 最慢的一步

```bash
cd /workspaces/MyProject
ninja -C build/linux -j3 MyProject.HeadlessServerLauncher
```

**这 209 个边在做什么**（这才是"为什么这么慢"的答案）：

本机实测中途采样（前 61 条边）的真实构成：

```
Building CXX : 40 条   （其中 30 条在 External/ = 传递依赖 Gem）
Linking      : 21 条
其他（生成/拷贝）: 0 条（在最后才出现）
```

按比例推算 193 个边：

| 阶段 | 占比 | 边数（推算） | 干什么 |
|---|---|---|---|
| **编译**（`Building CXX`） | ~65% | ~125 | 其中约 **3/4 在 `External/`**——`LmbrCentral` / `Camera` / `EMotionFX` / `GradientSignal` 等传递依赖 Gem |
| **链接**（`Linking`） | ~35% | ~68 | ⚠️ 比想象中多：**每个 Gem 都要链出 `.a` + `.so` 两份**（`Camera` → `libCamera.Static.a` + `libCamera.so`） |
| `runtime_dependencies` 收尾 | — | 1 | **把 24 个 `.so` 拷到 `bin/profile/` 并生成清单** |
| 生成 `Registry/*.setreg` | — | 2 | 插件清单（运行时据此加载模块） |

**关键洞察**：链接占了 35%，因为 O3DE 的每个 Gem 同时产出**静态库**（给 Launcher 链）
和**动态库**（给运行时加载）。这是"插件式架构"的直接成本。

**这解释了"我的 Gem 才 302 KB，为什么要等这么久"**：209 个边里只有 2 个是你的
（`MyProject.Private.Object` + `MyProject`），其余全是引擎侧依赖。

**验证**：

```bash
cd build/linux
ls -lh bin/profile/MyProject.HeadlessServerLauncher    # 期望约 21–25 KB
ldd bin/profile/MyProject.HeadlessServerLauncher | grep -c "not found"   # 期望 0
```

> 💡 **`MyProject.HeadlessServerLauncher` 只有 21–25 KB** 不是错误。
> 它只是"配置壳"——`Game.cpp` 全文只有 **30 行**，返回日志文件名、是否专用服务器等常量。
> 真正的 `main()` 在 `libLauncher.Headless.Static.a` 里（`Launcher.cpp`，654 行）。
> 详见 [3.10](#310-编译产物结构)。

#### ⑥ 验证产物（1 分钟）

```bash
cd /workspaces/MyProject/build/linux

# ① 构建树干净（没有半途而废的目标）
ninja -n MyProject.HeadlessServerLauncher | tail -1      # ninja: no work to do.

# ② 依赖完整
ldd bin/profile/MyProject.HeadlessServerLauncher | grep -c "not found"   # 0

# ③ 运行时依赖清单已生成（24 个模块）
python3 - <<'EOF'
import re
t = open('runtime_dependencies/Profile/MyProject.HeadlessServerLauncher.cmake').read()
for k in ('target_target_files','target_link_files'):
    m = re.search(k + r'\s+"([^"]*)"', t)
    print(k, len([x for x in m.group(1).split(';') if x.strip()]) if m else '?')
EOF
# 期望：target_target_files 24 / target_link_files 8

# ④ 插件清单
ls bin/profile/Registry/cmake_dependencies.*.setreg | wc -l    # 若干（每个目标一份）
```

#### ⑦ 运行（本机的真实结果）

```bash
cd /workspaces/MyProject
timeout 70 ./build/linux/bin/profile/MyProject.HeadlessServerLauncher \
  --project-path /workspaces/MyProject > /tmp/run.log 2>&1

grep -E "Attempting to load module.*MyProject|Heartbeat|Enumerated physical" /tmp/run.log
```

**本机实测输出**：

```
Module: Attempting to load module:/workspaces/MyProject/build/linux/bin/profile/libMyProject.so
MyProject: [Heartbeat] component activated, interval=2.00s
MyProject: [MyProject] SystemComponent activated
RHISystem: Initializing RHI...
RHISystem:      Enumerated physical device:       ← 空（本机无 Vulkan 设备）
```

| 看到什么 | 说明 |
|---|---|
| `Attempting to load module:...libMyProject.so` | ✅ **你的 Gem 被加载了** |
| `[Heartbeat] component activated` | ✅ **组件跑起来了**（反射、EBus、注册全对） |
| `Enumerated physical device:` 为空 | ⚠️ 本机无 GPU → 进不了 tick 循环（[坑 19](#坑-19headlessserver-并不是无渲染无-gpu-时会卡死)） |
| `count=N` 出现 | ✅ 有 GPU 时才出现 |

### 四个 Launcher 的区别（项目一次能产出四种可执行）

```bash
ninja -C build/linux -t targets all | grep -oE "bin/profile/MyProject\.[A-Za-z]+" | sort -u
```

实测四个目标：

| 目标 | 产物 | 用途 | 定义它的宏 |
|---|---|---|---|
| `MyProject.GameLauncher` | `bin/profile/MyProject.GameLauncher` | 玩家客户端（有渲染 + 输入） | `O3DE_GAME` |
| `MyProject.ServerLauncher` | 同上 | 专用服务器（无渲染，但要 RHI 初始化） | — |
| `MyProject.HeadlessServerLauncher` | 同上 | 无头服务器（最轻） | `O3DE_HEADLESS_SERVER=1` |
| `MyProject.UnifiedLauncher` | 同上 | 客户端+服务端合一 | — |

**四个 Launcher 共用同一套源码**，区别只在编译宏和链接的变体库：

```bash
# 实测：Headless 变体多了一个宏
ninja -t commands MyProject.HeadlessServerLauncher | grep -o "O3DE_HEADLESS_SERVER=1" | head -1
# → O3DE_HEADLESS_SERVER=1
```

**所以加载的模块也不同**（[4.3 变体](#43-变体系统5-种应用类型)）：

| Launcher | 加载的 Atom 变体 |
|---|---|
| Game / Server | `libAtom_Feature_Common.Public.so` |
| **Headless** | `libAtom_Feature_Common.**Headless**.so` |

### 一键全编 vs 分步编

```bash
# 一键全编（推荐：构建树健康时）
ninja -C build/linux -j3

# 分步（第一次编 / 排查问题时，能定位到层）
ninja -C build/linux -j3 MyProject                  # ① Gem，最快
ninja -C build/linux -j3 MyProject.HeadlessServerLauncher  # ② 无头服务器
ninja -C build/linux -j3 MyProject.GameLauncher     # ③ 客户端（需要更多 Atom 模块）
```

### 时间与空间总账（本机实测，4 核 / 3.7 GB 可用内存）

| 步骤 | 时间 | 新增磁盘 | 备注 |
|---|---|---|---|
| ① create-project | 几秒 | 564 KB | |
| ② 检查实例化 | 30 秒 | 0 | 别跳过 |
| ③ configure | **140 秒** | ~2 MB（build.ninja） | 主要耗时在读 Gem 依赖图 |
| ④ 编 Gem | 1–3 分钟 | ~2.4 MB（.a + .so） | 最快健康检查 |
| ⑤ 编 Launcher | 见下 | ~30 MB（+ 24 个 .so） | 209 个边 |
| ⑥ 验证 | 1 分钟 | 0 | |
| ⑦ 运行 | 秒级 | 日志 | |
| **项目构建树总计** | | **1.6 GB**（含引擎库的副本） | |

**内存**：实测单个 `clang++` 进程 **568–700 MB**。
按 **1 GB/进程** 规划并行度：`j = min(核数, 可用内存GB) - 1`。

### 失败排查（按步骤定位）

| 步骤 | 症状 | 原因 | 解法 |
|---|---|---|---|
| ① | `Could not find engine` | 引擎未注册 | `./scripts/o3de.sh register --engines /workspaces/o3de` |
| ① | `Invalid template name` | `-tn` 写错 | `ls /workspaces/o3de/Templates` |
| ② | GUID 还是占位符 | 实例化中断 | 删掉重来 |
| ③ | `Could NOT find LibUnwind` | 缺系统包 | [坑 1–3](#坑-1-3-dev-包和运行时包是两回事) |
| ③ | `unknown target Gem::Xxx` | `gem_names` 里有但引擎没编 | 先编引擎，或去掉该 Gem |
| ③ | `Could not find a compatible engine` | manifest 路径失效 | `register` 重新注册 |
| ④ | `undefined reference to vtable` | 组件没实现 | 检查 `AZ_COMPONENT_IMPL` |
| ④ | 文件不编译（静默） | 没进 `*_files.cmake` | [3.11.1](#3111-添加一个组件三处必改--一处可选) |
| ⑤ | `No space left on device` | 磁盘不足 | [坑 5](#坑-5磁盘耗尽) |
| ⑤ | `Killed` | 内存不足 | `-j` 降到 2 |
| ⑥ | `ldd` 有 `not found` | 缺 `.so` | 重跑 ⑤（收尾步骤会拷） |
| ⑦ | `Failed to load module` | `.so` 不在 `bin/profile` | 同样重跑 ⑤ |

### `cmake` 那一步到底在做什么（`CMakeLists.txt` 逐行）

项目的 `CMakeLists.txt` 只有 40 行，核心是四件事：

```cmake
if(NOT PROJECT_NAME)                                  # ① 防止重复初始化
    cmake_minimum_required(VERSION 3.24)
    ...
    get_engine_finder_cmake_path(".../user/project.json" ...)   # ② 找 EngineFinder
    get_engine_finder_cmake_path(".../project.json" ...)
    if(NOT engine_finder_cmake_path)
        set(engine_finder_cmake_path cmake/EngineFinder.cmake)  # 默认路径
    endif()

    include(${engine_finder_cmake_path} OPTIONAL)     # ③ 执行引擎查找
    find_package(o3de REQUIRED)                       # ★ 找到引擎（关键一步）
    project(MyProject LANGUAGES C CXX VERSION 1.0.0.0)
    o3de_initialize()                                 # ④ 加载 Gem / 生成目标
endif()
```

| 步 | 做什么 | 失败会怎样 |
|---|---|---|
| ② | 读 `project.json` 的可选字段 `engine_finder_cmake_path` | 用默认的 `cmake/EngineFinder.cmake` |
| ③ | `EngineFinder.cmake` 读 `~/.o3de/o3de_manifest.json`，挑**版本最兼容**的引擎 | `Could not find a compatible engine` |
| **`find_package(o3de REQUIRED)`** | **把引擎的 CMake 规则装进来**（`o3deConfig.cmake`） | 整个 configure 失败 |
| ④ | `o3de_initialize()` 遍历 `gem_names`，为每个 Gem 生成目标 | 目标缺失 → `unknown target` |

**`EngineFinder.cmake` 的查找优先级**（源码实证，`cmake/EngineFinder.cmake`）：

```cmake
# Option 1/2: 环境变量 O3DE_ENGINE_PATH / 项目内 engine 目录
# Option 3: 找 ~/.o3de/o3de_manifest.json 里注册的引擎（本机走这条）
set(manifest_path $ENV{HOME}/.o3de/o3de_manifest.json)
...
# 然后在多个引擎里挑版本最兼容的（O3DE_MOST_COMPATIBLE_ENGINE_VERSION）
```

> 💡 **这就是为什么"移动引擎目录后项目编不了"**：manifest 里存的是**绝对路径**。
> 引擎一挪，路径失效，`find_package(o3de)` 找不到。

### 4 个 Gem 如何变成 25 个运行时模块

这是最值得理解的一步。**声明的 Gem 只是"直接依赖"，运行时要加载的是传递闭包。**

实测启动日志（`Attempting to load module`，共 **25 条**）：

```
libMyProject.so                       ← 你的 Gem（直接）
libAtom_Bootstrap.so                  ← Atom（直接）
libAtom_RPI.Private.so                ← Atom 的私有部分
libAtom_RHI.Private.so                ← Atom 的私有部分
libAtom_RHI_Null.Private.so           ← 4 个 RHI 后端都编了，运行时按平台选
libAtom_Feature_Common.Headless.so    ← Atom 的 Feature 库（Headless 变体！）
libAtom_AtomBridge.Headless.so        ← Atom 桥接（Headless 变体）
libAtomFont.so / libImguiAtom.so / libAtomImGuiTools.so
libCamera.so                          ← CameraFramework（直接）
libCameraFramework.so                 ← CameraFramework
libLmbrCentral.so                     ← 传递依赖（很多 Gem 的基础）
libGradientSignal.so                  ← 传递依赖
libSurfaceData.so                     ← 传递依赖
libMaestro.so                         ← 传递依赖（过场动画）
libEMotionFX.so / libEMotionFX_Atom.so← 传递依赖（动画！你没显式启，但被依赖带入）
libCommonFeaturesAtom.so / libCrySystem.so / libAtomViewportDisplayInfo.so / ...
```

**三个重要发现**：

| 发现 | 说明 |
|---|---|
| **`Headless` 变体** | `libAtom_Feature_Common.Headless.so` —— 因为你跑的是 `HeadlessServerLauncher`，加载的是 Headless 变体的模块（4.3 的变体机制） |
| **`EMotionFX` 被带进来了** | 你没在 `gem_names` 里写它，但某个直接 Gem 依赖它 → **传递依赖自动带入** |
| **4 个 RHI 后端都编了** | `libAtom_RHI_Null.Private.so` 也在（这就是 [坑 19](#坑-19headlessserver-并不是无渲染无-gpu-时会卡死) 里能选 Null 的道理） |

### 机器可读的证据：生成的插件清单

```bash
cat build/linux/bin/profile/Registry/cmake_dependencies.*.setreg
```

```json
{
    "O3DE": {
        "Gems": {
            "AtomShader": {
                "Targets": {
                    "AtomShader.Builders": { "Modules":["libAtomShader.Builders.so"] }
                }
            },
            ...
        }
    }
}
```

**这是"Gem → Target → Module"的三级映射**（[4.2](#42--核心机制cmake-生成插件清单) 讲的就是它的生成过程）。
运行时读这个文件，才知道"该加载哪些 `.so`"。

## 5.8 工作区里的 `myproject-src` 是什么

```bash
$ ls -la /home/hwg/tmp/ai/tmp/myproject-src
myproject-src -> /workspaces/MyProject
```

**它是符号链接，不是副本。** 用途：

| 场景 | 为什么需要它 |
|---|---|
| VS Code 资源管理器 | 工作区根在 `~/tmp/ai/tmp`，源码在 `/workspaces` **之外**，看不到 |
| clangd 后台索引 | 同上，索引器只扫工作区内的文件 |
| 读代码 | 从 `myproject-src/Gem/Source/` 进去，比记绝对路径方便 |

**不是"架子"，也不是编译产物**——它直接指向 564 KB 的真实源码（含 1.6 GB 的 `build/` 和 165 MB 的 `Cache/`）。

> ⚠️ **不要经符号链接跑构建**：`build/linux/CMakeCache.txt` 里存的是 `/workspaces/MyProject` 绝对路径。
> 用链接路径 configure 会得到路径不一致的新构建树 → 全量重编。
> **读走链接，构建走真实路径**（10.9 详述）。

## 5.9 我对这个项目做过什么（当前状态）

你现在看到的 `MyProject` **已经不完全是 MinimalProject 了**：

| 项 | 模板原样 | 现在 |
|---|---|---|
| `Gem/Source/` 文件数 | 3（Module / SystemComponent.h / SystemComponent.cpp） | **5**（+ `HeartbeatComponent.h/.cpp`） |
| `Gem/Include/` | 2（Bus / TypeIds） | 2（内容扩展了：加了 Heartbeat 总线 + 2 个 GUID） |
| `myproject_files.cmake` 条目 | 4 | **6** |
| `libMyProject.so` | 未编译 | **302 KB**（已编） |
| `libMyProject.Private.Object.a` | 无 | **2.1 MB**，含 **225 个 Heartbeat 符号** |
| 4 种 Launcher | 未编译 | 仍未编译（只到 Gem 层） |

**改动清单**（都在 [第十九部分](#第十九部分--端到端实战从零做一个能跑的功能) 里有完整代码）：

```diff
  # 1. Include/MyProject/MyProjectTypeIds.h
+ HeartbeatComponentTypeId / HeartbeatNotificationsTypeId

  # 2. Include/MyProject/MyProjectBus.h
+ MyProjectRequests 加了两个纯虚方法
+ 新增 HeartbeatNotifications（Multiple handler）+ 其 Traits

  # 3. Source/HeartbeatComponent.{h,cpp}       ← 全新文件
+ 继承 AZ::Component + AZ::TickBus::Handler

  # 4. Source/MyProjectSystemComponent.{h,cpp}
+ 实现两个请求方法 + OnHeartbeat
+ Activate 时程序化创建一个带 HeartbeatComponent 的 Entity

  # 5. Source/MyProjectModule.cpp
+ #include "HeartbeatComponent.h"
+ HeartbeatComponent::CreateDescriptor()

  # 6. myproject_files.cmake
+ Source/HeartbeatComponent.cpp
+ Source/HeartbeatComponent.h
```

**如果你想回到"纯净的最小项目"**：

> ⚠️ **不要试图手动复制模板目录**。本机实测（`grep -ohE '\$\{[A-Za-z_]+\}'` 去重后
> 排除 CMake 内置变量）发现 MinimalProject 模板里有 **10 个占位符**：
>
> | 类别 | 占位符 | 被替换成 |
> |---|---|---|
> | 命名 | `${Name}` / `${NameLower}` / `${NameUpper}` / `${SanitizedCppName}` | `MyProject` / `myproject` / `MYPROJECT` / `MyProject` |
> | 元信息 | `${Version}` / `${Platforms}` / `${ProjectId}` | `1.0.0` / 平台列表 / 生成的 UUID |
> | UUID | `${Random_Uuid}` / `${ModuleClassId}` / `${SysCompClassId}` | 各不相同的新 UUID |
>
> 而且它们**出现在文件名和目录名里**（如 `Source/${Name}Module.cpp`、`Include/${Name}/`、
> `${NameLower}_files.cmake`）。`sed` 只能改内容，改不了文件名——**手抄必然漏**。

```bash
# ✅ 方案 A：整个项目重新实例化（最干净，推荐）
cd /workspaces
mv MyProject MyProject.bak            # 先留备份
cd /workspaces/o3de
./scripts/o3de.sh create-project \
  -pp /workspaces/MyProject -pn MyProject -tn MinimalProject
# 然后重新 configure + 编译（build/ 是新的，要重来）

# ✅ 方案 B：只想还原 Gem（保留 project.json / Registry 等配置）
cd /workspaces/MyProject
mv Gem Gem.bak
cd /workspaces/o3de
./scripts/o3de.sh create-gem \
  -gp /workspaces/MyProject/Gem -gn MyProject -tg DefaultGem
# ⚠️ 注意：这会用 DefaultGem 模板（比 MinimalProject 的 Gem 多 Tests/ 和 Tools/）
#    想完全对齐，还是用方案 A
```

### 为什么不建议"手动改回去"

`create-project` 实例化时做了 **5 类**事（源码实证 `scripts/o3de/o3de/engine_template.py`）：

| # | 动作 | 代码位置 | 手动做的难度 |
|---|---|---|---|
| 1 | 替换 5 个命名占位符（`${Name}` 系列） | `engine_template.py:1475-1479` | 中（还要改文件名/目录名） |
| 2 | `${Version}` → `1.0.0` | `:1800` | 易 |
| 3 | `${Random_Uuid}` → 随机 UUID，**每次出现一个新值** | `:190-191` | 中 |
| 4 | `${ModuleClassId}` / `${SysCompClassId}` → **从模板里已有的 UUID 提取**，保证同一项目内一致 | `:752-765` | **难**（要读懂提取逻辑） |
| 5 | **剥离 `{BEGIN_LICENSE}` / `{END_LICENSE}` 之间的块** | `:113-122` | 易但容易忘 |

**第 5 条解释了一个现象**：真实项目里的 `CMakeLists.txt` **开头有一个空行**、没有 license 注释——
因为那段被剥离了，只留下空行。你在模板里看到的 license 块不会出现在你的项目里。

**第 3、4 条的坑**：三个 TypeId 必须是**三个不同的 UUID**，且 Module 与 SystemComponent 的
UUID 在 `.h` 和 `.cpp` 里必须**一致**。手改很容易写成同一个值 → 运行时"类型冲突"或"组件未注册"。

## 5.10 用 MinimalProject 当起点的推荐姿势

既然它是"干净起点"，正确用法是**增量长出来**，而不是先塞满 Gem：

| 阶段 | 加什么 | 为什么这时候加 |
|---|---|---|
| **起步（当前）** | 什么都不加 | 先把"组件 → EBus → 编译 → 验证"跑通（19 部） |
| **要物理** | `enable-gem -gn PhysX5` | 这时你需要碰撞检测了 |
| **要输入** | `+ StartingPointInput` | 需要"按键 → 动作" |
| **要 UI** | `+ LyShine` | 需要血条/菜单 |
| **要声音** | `+ MiniAudio`（轻量）或 `AudioSystem`（完整） | 需要音效 |
| **要动画** | `+ EMotionFX`（可能已被传递依赖带入） | 需要骨骼动画 |
| **要调试绘制** | `+ DebugDraw` | 需要画线看碰撞体 |

**每次只加一个，加完立刻验证**（26.3 的四环节）：
改 `gem_names` → **重新 configure** → 编译 → 看日志 `Attempting to load module` → 用它的组件。

> ⚠️ **反模式**：一次性把 DefaultProject 的 23 个 Gem 全抄过来。
> 你会立刻遇到：编译时间翻倍、配置冲突、资产处理变慢，而且**分不清哪个 Gem 带来的问题**。

## 5.11 自检

- [ ] 官方对"Minimal"的定义是什么？（提示：`template.json` 的 `summary`）
- [ ] 项目源码 564 KB，构建树 1.6 GB —— 这个比例说明了什么？
- [ ] `Assets/` 里有几个文件？（答案：0）
- [ ] 项目根的 `CMakeLists.txt` 里哪一行是"找到引擎"的关键？
- [ ] 4 个 Gem 为什么会在运行时加载 25 个模块？
- [ ] 为什么 `EMotionFX` 被加载了，而你没声明它？
- [ ] 为什么项目构建树的目标数（12759）几乎等于引擎（12780）？
- [ ] `myproject-src` 是什么？为什么不能经它跑构建？
- [ ] 想回到纯净状态，改哪几个文件就够？

## 5.12 相关章节

| 想深入 | 去哪 |
|---|---|
| 项目目录每个细节 | [5.2 564 KB 里到底有什么](#52-564-kb-里到底有什么逐文件) |
| 为什么项目要重编引擎 | [3.8](#38--为什么项目要重编引擎核心原理) |
| Gem 如何变成插件清单 | [4.2](#42--核心机制cmake-生成插件清单) |
| 变体系统（Headless/Client/Server） | [4.3](#43-变体系统5-种应用类型) |
| 在它上面写第一个功能 | [19 端到端实战](#第十九部分--端到端实战从零做一个能跑的功能) |
| 加/删组件与 Gem | [3.11](#311-如何添加或移除组件与-gem) |
| 加 Gem 的四个环节 | [25.3](#253-加-gem从想要一个能力到它真的在跑) |
| 想改造它的路线图 | [25 改造路线](#第二十五部分--自顶向下的改造路线) |

---

# 第六部分 · 运行时链路

> **🎓 L3 · 懂架构** ｜ 前置：第二部分 + 第四部分 ｜ 读完能做什么：从 `main()` 追到第一帧 ｜ 下一站 → **第十六部分（L4 · 读源码）**

## 6.1 全景（15 步）

```mermaid
flowchart TD
  EXE["① Editor 可执行（21 KB）"] --> APP["② AzFramework::Application 初始化<br/>传：描述符路径 + CreateStaticModules 函数指针"]
  APP --> BOOT["③ 最小自举<br/>只够读描述符"]
  BOOT --> D1["④ 读描述符①：<br/>内存分配器设置 + 动态库列表"]
  D1 --> RS["⑤ 关掉已引导的系统<br/>按新分配器配置重启"]
  RS --> DL["⑥ dlopen 每个动态库"]
  DL --> INIT["⑦ InitializeDynamicModule()<br/>挂到 AZ::Environment"]
  INIT --> MOD["⑧ 创建 AZ::Module 实例<br/>dlsym CreateModuleClass_*"]
  MOD --> REG["⑨ RegisterComponentDescriptors()"]
  REG --> D2["⑩ 读描述符②：<br/>SystemEntity 及组件配置"]
  D2 --> REQ["⑪ GetRequiredSystemComponents()<br/>补齐缺失的系统组件"]
  REQ --> ACT["⑫ SystemEntity 激活"]
  ACT --> GEM["⑬ 加载项目 Gem<br/>libMyProject.so"]
  GEM --> YOUR["⑭ 你的 MyProjectSystemComponent::Activate()"]
  YOUR --> TICK["⑮ 每帧 OnTick()"]
```

## 6.2 为什么要读两次描述符

| 次序 | 目的 | 为什么不能一次读完 |
|---|---|---|
| ① | 内存分配器设置 + 要加载哪些库 | 分配器决定后续所有分配行为，必须先定 |
| ② | SystemEntity 及组件配置 | 组件类型必须先注册（第 ⑨ 步）才能反序列化 |

**副作用**：第一次读完会**关掉再重启**已引导的系统（分配器配置变了）。这解释了启动日志里的重复初始化信息。

### 内存分配器为什么值得折腾

O3DE 用 **HPHA（Hierarchical Pooled Heap Allocator）**：

- 按大小分桶的内存池，分配 O(1)
- 多线程（每线程独立池）
- **可以整体追踪每个分配**

> 这也解释了 Editor 崩溃：`HphaAllocator.cpp:2079` 的 `HPPA_ASSERT(bl->used())` 是**双重释放检测**。软件 Vulkan 驱动释放了不属于它的块，被断言抓住。

## 6.3 实测模块加载日志

```
Module: Attempting to load module:/workspaces/o3de-build/bin/profile/libEditorLib.so
Module: Success!
Module: Attempting to load module:/workspaces/o3de-build/bin/profile/libAtomViewportDisplayInfo.so
Module: Success!
Module: Attempting to load module:/workspaces/o3de-build/bin/profile/libCamera.Editor.so
Module: Success!
Module: Attempting to load module:/workspaces/o3de-build/bin/profile/libCommonFeaturesAtom.Editor.so
Module: Success!
Module: Attempting to load module:/workspaces/o3de-build/bin/profile/libLmbrCentral.Editor.so
Module: Success!
...
```

### 命名规律

| 后缀 | 含义 | 谁加载 |
|---|---|---|
| 无后缀 `libAtomFont.so` | 运行时通用 | 所有变体 |
| `.Editor` | 仅编辑器 | Editor |
| `.Builders` | 仅资产构建 | AssetProcessor |
| `.Tests` | 仅测试 | 测试运行器 |

## 6.4 系统组件与普通组件的区别

| | SystemComponent | 普通 Component |
|---|---|---|
| 实例数 | 全局 1 个 | 每个 Entity 各一个 |
| 谁创建 | 引擎自动（`GetRequiredSystemComponents`） | 你手动 Add / `CreateComponent` |
| 生命周期 | 与进程同生共死 | 跟 Entity 走 |
| 典型用途 | 全局服务、管理器 | 单个对象的行为 |

**判断口诀**：这件事是"整个游戏只有一份"还是"每个对象各有一份"？

## 6.5 组件生命周期

| 函数 | 何时 | 该做什么 | 不该做什么 |
|---|---|---|---|
| 构造函数 | 反序列化时 | 只做无副作用初始化 | 访问其他组件、读文件 |
| `Init()` | Activate 前 | 不依赖其他组件的初始化 | 连总线 |
| `Activate()` | 组件启用 | **连总线**、申请资源 | 阻塞操作 |
| `Deactivate()` | 组件停用 | **断总线**、释放资源 | 假设别人还活着 |
| 析构 | 销毁 | 兜底清理 | 复杂逻辑 |

⚠️ **必须成对**：`Activate` 里 `BusConnect()`，`Deactivate` 里必须 `BusDisconnect()`。忘断会导致悬空指针崩溃。

## 6.6 常见"代码没生效"排查表

| 现象 | 检查什么 |
|---|---|
| 编译通过但日志没输出 | 文件是否加进 `myproject_files.cmake` |
| 组件在 Editor 列表找不到 | `CreateDescriptor()` 是否加进 `m_descriptors` |
| `libMyProject.so` 没生成 | `myproject_shared_files.cmake` 是否有 `MyProjectModule.cpp` |
| Gem 完全没加载 | `project.json` 的 `gem_names` 是否含 `MyProject` |
| 改了代码没重编 | 改过 `.cmake` 需重新 configure |
| 接口调用崩溃 | `AZ::Interface::Register` 是否执行（组件是否 Activate） |

---

# 第七部分 · 组件开发手册

> **🎓 L2 · 能改 ★核心** ｜ 前置：L1 ｜ 读完能做什么：写出能被编辑器识别的组件 ｜ 下一站 → **第八部分（L2）**

## 7.1 完整示例：`MyRotatorComponent`

### 文件 1：`Gem/Include/MyProject/MyRotatorComponent.h`

```cpp
#pragma once

#include <AzCore/Component/Component.h>

namespace MyProject
{
    class MyRotatorConfig final
    {
    public:
        AZ_RTTI(MyRotatorConfig, "{A1B2C3D4-0001-4000-8000-000000000001}");
        AZ_CLASS_ALLOCATOR(MyRotatorConfig, AZ::SystemAllocator);

        static void Reflect(AZ::ReflectContext* context);

        float m_degreesPerSecond = 90.0f;
    };

    class MyRotatorComponent final
        : public AZ::Component
        , public AZ::TickBus::Handler
    {
    public:
        AZ_COMPONENT_DECL(MyRotatorComponent);

        static void Reflect(AZ::ReflectContext* context);
        static void GetProvidedServices(AZ::ComponentDescriptor::DependencyArrayType& provided);
        static void GetIncompatibleServices(AZ::ComponentDescriptor::DependencyArrayType& incompatible);
        static void GetRequiredServices(AZ::ComponentDescriptor::DependencyArrayType& required);
        static void GetDependentServices(AZ::ComponentDescriptor::DependencyArrayType& dependent);

        MyRotatorComponent() = default;
        explicit MyRotatorComponent(const MyRotatorConfig& config);
        ~MyRotatorComponent() override = default;

    protected:
        void Init() override;
        void Activate() override;
        void Deactivate() override;
        void OnTick(float deltaTime, AZ::ScriptTimePoint time) override;

    private:
        MyRotatorConfig m_config;
    };
}
```

### 文件 2：`Gem/Source/MyRotatorComponent.cpp`

```cpp
#include "MyRotatorComponent.h"

#include <AzCore/Serialization/EditContext.h>
#include <AzCore/Serialization/SerializeContext.h>
#include <AzCore/Component/TransformBus.h>

namespace MyProject
{
    void MyRotatorConfig::Reflect(AZ::ReflectContext* context)
    {
        if (auto* sc = azrtti_cast<AZ::SerializeContext*>(context))
        {
            sc->Class<MyRotatorConfig>()
                ->Version(1)
                ->Field("DegreesPerSecond", &MyRotatorConfig::m_degreesPerSecond);

            if (AZ::EditContext* ec = sc->GetEditContext())
            {
                ec->Class<MyRotatorConfig>("Rotator Config", "让实体匀速旋转")
                    ->ClassElement(AZ::Edit::ClassElements::EditorData, "")
                        ->Attribute(AZ::Edit::Attributes::AutoExpand, true)
                    ->DataElement(AZ::Edit::UIHandlers::Default,
                        &MyRotatorConfig::m_degreesPerSecond, "转速 (度/秒)", "负数反向")
                        ->Attribute(AZ::Edit::Attributes::Min, -3600.0f)
                        ->Attribute(AZ::Edit::Attributes::Max, 3600.0f);
            }
        }
    }

    AZ_COMPONENT_IMPL(MyRotatorComponent, "MyRotatorComponent",
        "{A1B2C3D4-0002-4000-8000-000000000002}");

    void MyRotatorComponent::Reflect(AZ::ReflectContext* context)
    {
        MyRotatorConfig::Reflect(context);

        if (auto* sc = azrtti_cast<AZ::SerializeContext*>(context))
        {
            sc->Class<MyRotatorComponent, AZ::Component>()
                ->Version(1)
                ->Field("Config", &MyRotatorComponent::m_config);

            if (AZ::EditContext* ec = sc->GetEditContext())
            {
                ec->Class<MyRotatorComponent>("My Rotator", "让实体匀速旋转")
                    ->ClassElement(AZ::Edit::ClassElements::EditorData, "")
                        ->Attribute(AZ::Edit::Attributes::Category, "MyProject")
                        ->Attribute(AZ::Edit::Attributes::AppearsInAddComponentMenu, AZ_CRC_CE("Game"))
                    ->DataElement(AZ::Edit::UIHandlers::Default,
                        &MyRotatorComponent::m_config, "旋转设置", "");
            }
        }

        if (auto* bc = azrtti_cast<AZ::BehaviorContext*>(context))
        {
            bc->Class<MyRotatorComponent>("MyRotator")
                ->Attribute(AZ::Script::Attributes::Category, "MyProject");
        }
    }

    void MyRotatorComponent::GetProvidedServices(AZ::ComponentDescriptor::DependencyArrayType& provided)
    {
        provided.push_back(AZ_CRC_CE("MyProjectRotationService"));
    }
    void MyRotatorComponent::GetIncompatibleServices(AZ::ComponentDescriptor::DependencyArrayType& incompatible)
    {
        incompatible.push_back(AZ_CRC_CE("MyProjectRotationService"));
    }
    void MyRotatorComponent::GetRequiredServices(AZ::ComponentDescriptor::DependencyArrayType& required)
    {
        required.push_back(AZ_CRC_CE("TransformService"));
    }
    void MyRotatorComponent::GetDependentServices(AZ::ComponentDescriptor::DependencyArrayType& dependent)
    {
        AZ_UNUSED(dependent);
    }

    MyRotatorComponent::MyRotatorComponent(const MyRotatorConfig& config)
        : m_config(config)
    {
    }

    void MyRotatorComponent::Init() {}

    void MyRotatorComponent::Activate()
    {
        AZ::TickBus::Handler::BusConnect();
    }

    void MyRotatorComponent::Deactivate()
    {
        AZ::TickBus::Handler::BusDisconnect();
    }

    void MyRotatorComponent::OnTick(float deltaTime, AZ::ScriptTimePoint)
    {
        const float deltaAngle = m_config.m_degreesPerSecond * deltaTime;
        AZ::TransformBus::Event(GetEntityId(),
            &AZ::TransformBus::Events::RotateLocalY, deltaAngle);
    }
}
```

### 文件 3：登记到 `Gem/myproject_files.cmake` ⚠️ **必做**

```cmake
set(FILES
    Include/MyProject/MyProjectBus.h
    Include/MyProject/MyProjectTypeIds.h
    Include/MyProject/MyRotatorComponent.h       # ← 加
    Source/MyProjectSystemComponent.cpp
    Source/MyProjectSystemComponent.h
    Source/MyRotatorComponent.cpp                 # ← 加
)
```

### 文件 4：注册到 `Gem/Source/MyProjectModule.cpp` ⚠️ **必做**

```cpp
#include "MyProjectSystemComponent.h"
#include "MyRotatorComponent.h"        // ← 加

// ...
            m_descriptors.insert(m_descriptors.end(), {
                MyProjectSystemComponent::CreateDescriptor(),
                MyRotatorComponent::CreateDescriptor(),      // ← 加
            });
```

### 两个必须自己编的 GUID

```bash
python3 -c "import uuid; print('{%s}' % str(uuid.uuid4()).upper())"
```

⚠️ 同一个类在 `.h` 的 `AZ_RTTI` 和 `.cpp` 的 `AZ_COMPONENT_IMPL` 里**必须是同一个 GUID**。

## 7.2 检查清单

```
□ Gem/Include/MyProject/MyRotatorComponent.h     新建
□ Gem/Source/MyRotatorComponent.cpp              新建
□ Gem/myproject_files.cmake                      加 2 行 ⚠️
□ Gem/Source/MyProjectModule.cpp                 加 #include + CreateDescriptor() ⚠️
□ 两个 GUID 已生成且 .h/.cpp 一致
```

**只有后两项最容易漏，且都不会报错。**

## 7.3 编译与验证

```bash
# 改了 .cmake 必须重新 configure
cmake -B /workspaces/MyProject/build/linux -S /workspaces/MyProject -G Ninja \
  -DCMAKE_BUILD_TYPE=Profile -DLY_3RDPARTY_PATH=/workspaces/o3de-packages

# 只编你的 Gem（快，能验证语法）
ninja -C /workspaces/MyProject/build/linux -j3 Gem::MyProject

# 确认符号
nm -D --defined-only .../libMyProject.so | grep -i rotator
```

## 7.4 常用服务名

| 服务名 | 提供者 |
|---|---|
| `TransformService` | 每个 Entity 都有 |
| `PhysicsService` | PhysX Gem |
| `CameraService` | Camera Gem |
| `MeshService` | Atom |
| `ScriptCanvasService` | ScriptCanvas Gem |

## 7.5 四种组件模式

### 模式 A：只在激活时做一次事

```cpp
void MySpawnerComponent::Activate()
{
    // 生成一些东西
}
void MySpawnerComponent::Deactivate() {}
```

### 模式 B：监听其他实体变换

```cpp
class MyFollowerComponent
    : public AZ::Component
    , public AZ::TransformNotificationBus::Handler
{
    void Activate() override
    {
        AZ::TransformNotificationBus::Handler::BusConnect(GetEntityId());
    }
    void Deactivate() override
    {
        AZ::TransformNotificationBus::Handler::BusDisconnect();
    }
    void OnTransformChanged(const AZ::Transform& local, const AZ::Transform& world) override
    {
        // 世界变换变了
    }
};
```

### 模式 C：延迟初始化

```cpp
void MyLateInitComponent::OnTick(float, AZ::ScriptTimePoint) override
{
    if (m_initialized) return;
    m_initialized = true;
    AZ::TickBus::Handler::BusDisconnect();   // 做完就断，省开销
    // 这里所有其他组件都已激活
}
```

### 模式 D：定时器代替手写计时

```cpp
m_timer = AZ::TickBus::QueueFunction([this]() {
    AZ_Printf("MyProject", "1 秒后执行");
}, 1.0f);
// Deactivate 里：AZ::TickBus::RemoveFunction(m_timer);
```

## 7.6 Tick 顺序控制

```cpp
AZ::TickBus::Handler::BusConnect(/*order=*/ -100);   // 数字越小越早
```

| 优先级 | 谁 |
|---|---|
| -1000 ~ -100 | 输入、摄像机 |
| 0 | 大多数游戏逻辑（默认） |
| 100 ~ 1000 | 物理后处理、渲染准备 |

## 7.7 在代码里给实体加组件

```cpp
AZ::Entity* entity = aznew AZ::Entity("MyEntity");
entity->CreateComponent<AzFramework::TransformComponent>();
entity->CreateComponent<MyRotatorComponent>();
entity->Init();
entity->Activate();

// 用完
entity->Deactivate();
delete entity;
```

**`CreateComponent` 之后必须 `Init()` + `Activate()`。**

---

# 第八部分 · 通信机制

> **🎓 L2 · 能改 ★核心** ｜ 前置：第七部分 ｜ 读完能做什么：暴露 EBus 接口给别人调用 ｜ 下一站 → **第九部分（L2）** ｜ 想懂底层实现 → [第十六部分](#第十六部分--深挖策略驱动的零成本抽象)

## 8.1 四种机制一览

| 机制 | 解决什么 | 方向 | 何时用 |
|---|---|---|---|
| **`AZ::Interface<T>`** | 全局单例同步调用 | 调用方 → 唯一实现 | 99% 场景首选 |
| **`EBus`** | 多播/寻址消息分发 | 调用方 → 多个处理器 | 需要"一对多" |
| **`SerializeContext`** | 对象 ↔ 磁盘/编辑器 | 持久化 | 写组件必须 |
| **`BehaviorContext`** | C++ ↔ 脚本 | 双向 | 想让脚本调用 |

## 8.2 `MyProjectBus.h` 的两套包装

```cpp
class MyProjectRequests                  // 纯虚函数接口
{
public:
    AZ_RTTI(MyProjectRequests, MyProjectRequestsTypeId);
    virtual ~MyProjectRequests() = default;
    // Put your public methods here
};

class MyProjectBusTraits : public AZ::EBusTraits
{
public:
    static constexpr AZ::EBusHandlerPolicy HandlerPolicy = AZ::EBusHandlerPolicy::Single;
    static constexpr AZ::EBusAddressPolicy AddressPolicy = AZ::EBusAddressPolicy::Single;
};

using MyProjectRequestBus = AZ::EBus<MyProjectRequests, MyProjectBusTraits>;
using MyProjectInterface  = AZ::Interface<MyProjectRequests>;
```

```mermaid
graph TD
  I["MyProjectRequests<br/>（纯虚接口）"]
  I --> EB["AZ::EBus&lt;I, Traits&gt;"]
  I --> IF["AZ::Interface&lt;I&gt;"]
  EB --> EBU["多 handler / 地址 / 多播<br/>有总线开销"]
  IF --> IFU["全局唯一指针<br/>零开销"]
```

**官方建议**：单例场景直接用 `AZ::Interface`，别绕 EBus。

## 8.3 `AZ::Interface` 用法

**实现方**（SystemComponent）：

```cpp
MyProjectSystemComponent::MyProjectSystemComponent()
{
    if (MyProjectInterface::Get() == nullptr)
        MyProjectInterface::Register(this);
}
MyProjectSystemComponent::~MyProjectSystemComponent()
{
    if (MyProjectInterface::Get() == this)
        MyProjectInterface::Unregister(this);
}
```

注意 `if (... == this)`：只在"当前登记的是自己"时才注销。

**调用方**：

```cpp
if (auto* iface = MyProject::MyProjectInterface::Get())
{
    iface->DoSomething();
}
```

**必须判空**：组件还没 Activate 时返回 `nullptr`。

## 8.4 EBus 四种组合

| `AddressPolicy` | `HandlerPolicy` | 用途 | 代码特征 |
|---|---|---|---|
| `Single` | `Single` | 全局单例接口 | `BusConnect()` |
| `ById` + `BusIdType=EntityId` | `Multiple` | 组件级服务 | `BusConnect(GetEntityId())` |
| `Single` | `Multiple` | 全局事件广播 | `BusConnect()`，多监听者 |
| `ById` | `Single` | 每实体唯一实现 | 少见 |

### 组件级 EBus 完整例子

**接口**：

```cpp
class MyHealthRequests
{
public:
    AZ_RTTI(MyHealthRequests, "{B1B2C3D4-0001-4000-8000-000000000001}");
    virtual float GetHealth() const = 0;
    virtual void ApplyDamage(float amount) = 0;
protected:
    ~MyHealthRequests() = default;
};

class MyHealthBusTraits : public AZ::EBusTraits
{
public:
    static constexpr AZ::EBusAddressPolicy AddressPolicy = AZ::EBusAddressPolicy::ById;
    using BusIdType = AZ::EntityId;
    static constexpr AZ::EBusHandlerPolicy HandlerPolicy = AZ::EBusHandlerPolicy::Single;
};
using MyHealthRequestBus = AZ::EBus<MyHealthRequests, MyHealthBusTraits>;
```

**实现方**：

```cpp
class MyHealthComponent
    : public AZ::Component
    , protected MyHealthRequestBus::Handler
{
protected:
    void Activate() override   { MyHealthRequestBus::Handler::BusConnect(GetEntityId()); }
    void Deactivate() override { MyHealthRequestBus::Handler::BusDisconnect(); }

    float GetHealth() const override { return m_health; }

    void ApplyDamage(float amount) override
    {
        const float old = m_health;
        m_health = AZStd::max(0.0f, m_health - amount);
        MyHealthNotificationBus::Event(GetEntityId(),
            &MyHealthNotifications::OnHealthChanged, old, m_health);
    }
private:
    float m_health = 100.0f;
};
```

**调用方**：

```cpp
float hp = 0.0f;
MyHealthRequestBus::EventResult(hp, targetEntityId, &MyHealthRequests::GetHealth);
MyHealthRequestBus::Event(targetEntityId, &MyHealthRequests::ApplyDamage, 25.0f);
```

## 8.5 EBus 调用语法速查

```cpp
// 无返回值，Single 地址
MyBus::Broadcast(&MyBus::Events::DoSomething, arg1);

// 有返回值，ById
float result = 0.0f;
MyBus::EventResult(result, entityId, &MyBus::Events::GetValue);

// 有返回值，Single
MyBus::BroadcastResult(result, &MyBus::Events::GetValue);

// 无返回值，ById
MyBus::Event(entityId, &MyBus::Events::SetValue, 42);

// 队列化（跨线程安全）
MyBus::QueueBroadcast(&MyBus::Events::DoSomething, arg);
MyBus::QueueEvent(entityId, &MyBus::Events::DoSomething, arg);
```

## 8.6 反射三要素

```cpp
void MyComponent::Reflect(AZ::ReflectContext* context)
{
    if (auto* sc = azrtti_cast<AZ::SerializeContext*>(context))
    {
        sc->Class<MyComponent, AZ::Component>()     // ① 声明继承
            ->Version(1)                            // ② 版本号
            ->Field("Speed", &MyComponent::m_speed) // ③ 字段绑定
            ->Field("Target", &MyComponent::m_target);
    }
}
```

| Context | 作用 | 不写的后果 |
|---|---|---|
| `SerializeContext` | 存盘/读盘 | 字段不保存，重开关卡回默认 |
| `EditContext` | 属性面板外观 | 面板看不到字段 |
| `BehaviorContext` | Script Canvas / Lua | 脚本调不到 |

### 版本升级的正确做法

改了字段结构后：

```cpp
sc->Class<MyComponent, AZ::Component>()
    ->Version(2, &MyComponent::VersionConverter)
    ->Field("Speed", &MyComponent::m_speed);

bool MyComponent::VersionConverter(AZ::SerializeContext& context,
    AZ::SerializeContext::DataElementNode& classElement)
{
    if (classElement.GetVersion() < 2)
    {
        int idx = classElement.FindElement(AZ_CRC_CE("Velocity"));
        if (idx >= 0) classElement.GetSubElement(idx).SetName("Speed");
    }
    return true;
}
```

**不改版本号就改字段，老关卡读取时会崩溃或错位。**

## 8.7 常用 UIHandler 与 Attribute

| UIHandler | 用于 |
|---|---|
| `Default` | 数字/字符串/布尔 |
| `ComboBox` | 枚举（配 `EnumAttribute`） |
| `Color` | 颜色 |
| `Slider` | 数值（配 Min/Max） |
| `EntityId` | 实体引用选择器 |
| `AssetPicker` | 资产选择器 |

| Attribute | 作用 |
|---|---|
| `Min` / `Max` | 硬限制 |
| `SoftMin` / `SoftMax` | 软限制 |
| `Step` | 步进 |
| `ReadOnly` | 只读 |
| `Visibility` | 条件显示 |
| `Category` | Add Component 菜单分类 |
| `AppearsInAddComponentMenu` | 出现在哪些菜单 |

## 8.8 选择流程图

```mermaid
flowchart TD
  A["我要实现通信"] --> B{"需要存盘或在编辑器配置？"}
  B -->|是| C["SerializeContext + Field()"]
  B -->|否| D{"需要被脚本调用？"}
  D -->|是| E["BehaviorContext"]
  D -->|否| F{"只有一个实现？"}
  F -->|是| G["✅ AZ::Interface::Get()"]
  F -->|否| H{"需要广播给多个监听者？"}
  H -->|是| I["EBus + Multiple<br/>（Notification Bus）"]
  H -->|否| J{"需要按实体寻址？"}
  J -->|是| K["EBus + ById"]
  J -->|否| G
```

## 8.9 性能对比

| 机制 | 相对开销 | 说明 |
|---|---|---|
| `AZ::Interface::Get()` | 1× | 一次指针读 |
| EBus `Single`+`Single` | 2-3× | 需查表找 handler |
| EBus `ById`+`Multiple` | 5-10× | 哈希查找 + 遍历 |
| EBus `QueueBroadcast` | 更高 | 分配 + 跨线程同步 |

**在 `OnTick`（60 次/秒）里优先用 `AZ::Interface`。** EBus 适合低频事件。

---

# 第九部分 · 资产与配置

> **🎓 L2 · 能改** ｜ 前置：L2 前几章 ｜ 读完能做什么：注册资产、改配置 ｜ 下一站 → **第十部分（L2）**

## 9.1 四种配置文件

| 文件 | 格式 | 谁读 | 何时生效 | 改动后 |
|---|---|---|---|---|
| `project.json` | JSON | CMake + 运行时 | configure + 启动 | 自动重配 |
| `gem.json` | JSON | CMake + 运行时 | configure + 启动 | 重新 configure |
| `Registry/*.setreg` | JSON | Settings Registry | 启动时合并 | 重启 |
| `game.cfg` / `autoexec.cfg` | 纯文本 CVar | 控制台系统 | 启动时 | 重启 |

## 9.2 `.setreg` 合并顺序

```mermaid
flowchart LR
  A["引擎 Registry/"] --> B["各 Gem 的 Registry/"]
  B --> C["项目 Registry/"]
  C --> D["~/.o3de/Registry/"]
  D --> E["命令行 --regset 覆盖"]
  E --> F["最终合并结果"]
```

**后者覆盖前者。** 所以能在项目里覆盖引擎默认值，不用改引擎文件。

## 9.3 你项目的三个 `.setreg`

### `assetprocessor_settings.setreg`

```json
{
    "Amazon": { "AssetProcessor": { "Settings": {
        "ScanFolder Project/ShaderLib": { "watch": "@PROJECTROOT@/ShaderLib", "recursive": 1, "order": 1 },
        "ScanFolder Project/Shaders":   { "watch": "@PROJECTROOT@/Shaders",   "recursive": 1, "order": 2 },
        "ScanFolder Project/Registry":  { "watch": "@PROJECTROOT@/Registry",  "recursive": 1, "order": 3 },
        "Exclude export scripts": { "pattern": ".*\\\\/ExportScripts\\\\/.*" },
        "ProjectRelativeGemsScanFolderPriority": "higher"
    }}}
}
```

| 键 | 含义 |
|---|---|
| `watch` | 监控目录，`@PROJECTROOT@` 运行时替换 |
| `recursive: 1` | 递归子目录 |
| `order` | 处理优先级，小的先 |

**`Assets/` 不在这里配** —— 它是内建默认扫描目录。

### `assimp_settings.setreg`

```json
{ "O3DE": { "Preferences": { "SceneAPI": { "AssImpReadRootTransform": true } } } }
```

控制 AssImp（FBX/glTF 导入）是否保留根节点变换。

**常见问题**：FBX 导入后"位置偏了/缩小 100 倍"，先来这里试另一个值。

### `load_level.setreg`

```json
{ "O3DE": { "Autoexec": { "ConsoleCommands": { "LoadLevel": "defaultlevel" } } } }
```

启动时自动执行 `LoadLevel defaultlevel`。

⚠️ 项目还没有 `defaultlevel`，会报错。想从空场景开始就删掉这个文件。

## 9.4 资产管线实测

```mermaid
flowchart LR
  S["源资产<br/>Assets/**.fbx .png .font"] --> AP["AssetProcessor<br/>（后台进程）"]
  AP --> R["产品资产<br/>Cache/&lt;platform&gt;/**.azmodel .streamingimage .xml"]
  R --> RT["运行时只读这里"]
  AP --> CAT["assetcatalog.xml<br/>资产索引"]
```

### 实测数字

| 项 | 数值 |
|---|---|
| 处理资产总数 | **3042** |
| 缓存体积 | **111 MB** |
| 位置 | `/workspaces/MyProject/Cache/linux/` |
| 首次耗时 | 约 1 分钟 |
| AP 连接耗时 | 2.008 秒 |
| 连接后 ping | 1.24 ms |

### 一个真实转换例子

| 源 | 产品 | 变化 |
|---|---|---|
| `o3de/Assets/Engine/Fonts/default.font` | `Cache/linux/fonts/default.xml` | 目录小写、扩展名 `.font`→`.xml` |

⚠️ **不要用源文件名拼运行时路径。** 大小写和扩展名都会变。

> 📖 **想看"为什么必须处理成另一种格式"的完整推理**（以及 `AssetId` / `subId` / `fingerprint` / 产品命名规则）
> → [第十七部分 · 概念地图](#第十七部分--概念地图从资产讲起) 的 17.2–17.6。

## 9.5 `Assets/` vs `Cache/`

| | `Assets/` | `Cache/` |
|---|---|---|
| 内容 | **源资产** | **产品资产** |
| 谁生成 | 你 | AssetProcessor |
| 进版本控制 | ✅ 必须 | ❌ 不要 |
| 运行时读哪个 | ❌ 从不 | ✅ 只读这个 |
| 能手动改吗 | ✅ | ❌ 会被覆盖 |

## 9.6 为什么日志里满是 Terrain 警告

```
AssetProcessor: '/workspaces/o3de/Gems/Terrain/Assets/Shaders/Terrain/SceneSrg.azsli'
does not appear to be in any input folder.
```

**原因**：项目没启用 `Terrain` Gem，AssetProcessor 不把 `Gems/Terrain/Assets` 当输入目录。但某些清单引用了它。

**这是无害噪音**，不是错误。

## 9.7 加 Gem

```bash
cd /workspaces/o3de
./scripts/o3de.sh enable-gem -gn PhysX -pp /workspaces/MyProject
```

自动改 `project.json` 的 `gem_names`。

| 需求 | Gem |
|---|---|
| 物理 | `PhysX` |
| 可视化脚本 | `ScriptCanvas` |
| Lua | `Lua` |
| 地形 | `Terrain` |
| 植被 | `Vegetation` |
| 音频 | `AudioSystem` |
| 寻路 | `RecastNavigation` |
| 动画 | `EMotionFX` |
| UI | `LyShine` |

## 9.8 CVar

```cpp
#include <AzCore/Console/IConsole.h>

AZ_CVAR(bool, my_debug_draw, false, nullptr, AZ::ConsoleFunctorFlags::Null,
    "是否绘制调试线");
AZ_CVAR(float, my_gamespeed, 1.0f, nullptr, AZ::ConsoleFunctorFlags::Null,
    "游戏速度倍率");

// 读
float speed = my_gamespeed;
```

运行时改：`my_gamespeed 2.0`（控制台）或 `my_gamespeed = 2.0f;`（代码）。

## 9.9 配置改动生效对照

| 改了 | 需要做什么 | 耗时 |
|---|---|---|
| `Gem/Source/*.cpp` | `ninja Gem::MyProject` | 秒~分钟 |
| `Gem/myproject_files.cmake` | `ninja`（自动重配） | 秒 |
| `Gem/CMakeLists.txt` | `cmake` + `ninja` | 分钟 |
| `project.json` 的 `gem_names` | `cmake` + `ninja` | 分钟 |
| `Registry/*.setreg` | 重启 | 秒 |
| `game.cfg` | 重启 | 秒 |
| 新增 `Assets/**` | 等 AssetProcessor | 秒 |
| 引擎源码 | 重编引擎 | 小时 |

---

# 第十部分 · clangd 智能提示

> **🎓 L2 · 能改** ｜ 前置：L1（必须已有构建树） ｜ 读完能做什么：clangd 能跳转、有补全 ｜ 下一站 → **第十一部分（L4）**

## 10.1 核心难点：unity build 会废掉 clangd

O3DE 默认 `LY_UNITY_BUILD=ON`，编译的是：

```
Code/Framework/AzCore/CMakeFiles/AzCore.dir/Unity/unity_34_cxx.cxx
```

内容只有 `#include` 列表。所以 `compile_commands.json` 里**只有 unity 文件条目，没有单个 `.cpp`** → clangd 找不到参数，智能提示严重退化。

### 实测对比

| 阶段 | 覆盖源文件 |
|---|---|
| 直接 `ninja -t compdb` | **1454**（全是 unity 文件） |
| 展开 unity 后 | **7977** |

**提升 5.5 倍。**

## 10.2 解决方案：不重配 CMake

```bash
ninja -C /workspaces/o3de-build -t compdb    # 2 秒，从现成 build.ninja 导出
```

**为什么不加 `-DCMAKE_EXPORT_COMPILE_COMMANDS=ON` 重配**：

- 会撞 googletest FetchContent 问题
- 配置一次 18 秒到 3 分钟
- 有破坏已有构建树的风险

### 展开算法

```mermaid
flowchart TD
  A["ninja -C build -t compdb"] --> B["8268 条原始条目"]
  B --> C["过滤 command 为空的<br/>（CUSTOM_COMMAND/phony）"]
  C --> D["3605 条有效"]
  D --> E["识别 unity_N_cxx.cxx"]
  E --> F["正则提取 #include &quot;绝对路径&quot;"]
  F --> G["为每个 .cpp 复制 unity 的 command"]
  G --> H["8081 条"]
```

## 10.3 已完成的配置

| 位置 | 内容 |
|---|---|
| `/workspaces/o3de-build/compile_commands.json` | 8081 条 → 7977 文件 |
| `/workspaces/MyProject/build/linux/compile_commands.json` | 8055 条 → 7951 文件 |
| `/workspaces/o3de/compile_commands.json` | → 符号链接 |
| `/workspaces/MyProject/compile_commands.json` | → 符号链接 |
| `/workspaces/o3de/.clangd` | 参数修正 + 诊断抑制 + 索引策略 |
| `/workspaces/MyProject/.clangd` | 同上 |
| `.vscode/settings.json` | `clangd.arguments` |
| `o3de-src` / `myproject-src` | 工作区符号链接入口 |
| `tools/gen-compdb.py` / `refresh-compdb.sh` | 生成与刷新 |

## 10.4 `.clangd` 关键配置

```yaml
CompileFlags:
  Compiler: /usr/bin/clang++-18
  Remove:
    - -MD
    - -MT
    - -MF
    - -o
    - -fstack-check
    - -g
  Add:
    - -fno-modules
    - -Wno-error
    - -Wno-unused-parameter
    - -Wno-unused-variable
    - -Wno-unused-private-field

Diagnostics:
  Suppress:
    - undeclared_var_use
    - unknown_typename
    - deprecated_declarations

Index:
  Background: Skip      # 本机 7.7 GB 内存，全量索引吃 1-2 GB

InlayHints:
  ParameterNames: Yes
  DeducedTypes: No
```

⚠️ **clangd 18 不支持 `Completion.ArgumentLists`**（更新版本的键），写了会报 `Unknown Completion key`。

## 10.5 VS Code 设置

```json
"clangd.arguments": [
    "--header-insertion=iwyu",
    "--query-driver=/usr/bin/clang++-18,/usr/bin/clang-18",
    "--background-index=false",
    "--all-scopes-completion",
    "--suggest-missing-includes",
    "--clang-tidy=false"
],
"C_Cpp.intelliSenseEngine": "disabled"
```

`--query-driver` 让 clangd 能查询编译器拿系统头文件路径。路径必须与 `compile_commands.json` 里记录的一致。

`C_Cpp.intelliSenseEngine: disabled` 因为 cpptools 会和 clangd 抢 IntelliSense。

## 10.6 验证

```bash
clangd --check=/workspaces/o3de/Code/Framework/AzCore/AzCore/Math/Vector3.cpp
```

期望两行：

```
I[...] Loaded compilation database from /workspaces/o3de/compile_commands.json
I[...] Compile command from CDB is: [/workspaces/o3de-build] /usr/lib/llvm-18/bin/clang++-18 ...
```

⚠️ 结尾的 `All checks completed, 28 errors` **不是代码错误**，是 clangd 在跑自己的重构自检（`tweak: ExtractFunction` / `AddUsing`）。真实诊断会带诊断码（如 `[undeclared_var_use]`）。

## 10.7 何时重新生成

| 改了什么 | 需要重跑 |
|---|---|
| `.cpp` / `.h` | ❌ 不需要 |
| `CMakeLists.txt` / `*.cmake` / `project.json` | ✅ |
| 重新 configure 过 | ✅ |

```bash
/home/hwg/tmp/ai/tmp/O3DE-学习文档/tools/refresh-compdb.sh
```

## 10.8 内存权衡

| `Index.Background` | 内存 | 跨文件跳转 | 建议 |
|---|---|---|---|
| **`Skip`**（当前） | 低 | ❌ | 内存紧张 |
| `Build` | +1~2 GB | ✅ | 内存充裕 |

改 `.clangd` 的 `Background: Build`，同时删 `settings.json` 里的 `--background-index=false`，然后 `clangd: Restart language server`。

---

## 10.9 工作区里的 `o3de-src` / `myproject-src` 是什么

工作区根 `/home/hwg/tmp/ai/tmp` 下有两个符号链接：

```bash
$ ls -la /home/hwg/tmp/ai/tmp/o3de-src /home/hwg/tmp/ai/tmp/myproject-src
myproject-src -> /workspaces/MyProject
o3de-src      -> /workspaces/o3de
```

**它们不是"架子"，是两个真实目录的只读入口。** 为什么需要它们：workspace 根在
`/home/hwg/tmp/ai/tmp`，而源码在 `/workspaces/`——**在 workspace 之外**，
VS Code 的资源管理器和 clangd 的后台索引都看不到。加两个链接就能看到。

### 关键区分：源码在这，产物不在这

| | 路径 | 内容 | 本机实测体积 |
|---|---|---|---|
| **源码** | `o3de-src` → `/workspaces/o3de` | 只读代码，**零产物** | 448 MB（含 `.git` 58 MB） |
| **引擎构建树** | `/workspaces/o3de-build` | `bin/profile/` 的 11 个可执行 + `.so` | **12 GB** |
| **项目源码** | `myproject-src` → `/workspaces/MyProject` | 项目配置 + `Gem/` 源码 | < 5 MB |
| **项目构建树** | `/workspaces/MyProject/build/linux` | 项目自己的 `bin/profile/` | 1.2 GB |
| **资产缓存** | `/workspaces/MyProject/Cache` | AP 生成的产品资产 | 111 MB |

验证"源码树里确实没有产物"：

```bash
find /workspaces/o3de -maxdepth 2 -name "*.so" -o -maxdepth 2 -name "bin" | head
# → 只有 /workspaces/o3de/scripts/build（那是个脚本目录，不是构建树）
```

### 经符号链接打开，clangd 依然命中

clangd 会把路径**规范化**（跟随符号链接）后再去 compdb 里找。实测（`clangd --check`）：

| 打开方式 | 结果 |
|---|---|
| `o3de-src/Code/Framework/AtomCore/.../InstanceId.cpp` | `Loaded compilation database from /workspaces/o3de/compile_commands.json` → **0 errors** |
| `myproject-src/Gem/Source/MyProjectSystemComponent.cpp` | 命中项目 compdb → **0 errors** |
| `myproject-src/Gem/Source/MyProjectModule.cpp` | 命中项目 compdb → **0 errors** |
| `myproject-src/Gem/Source/HeartbeatComponent.cpp` | ⚠️ **Compile command inferred from MyProjectModule.cpp** → 0 errors |

**最后一行是个真实陷阱**：`HeartbeatComponent.cpp` 是后来新增的文件，而
`compile_commands.json` 是新增之前生成的——**compdb 里没有它**。clangd 只好
"照着同目录的邻居推断"，靠猜。

> **经验**：新增 `.cpp` 之后，重新跑一次 `ninja`（或 `./tools/refresh-compdb.sh`）
> 让 compdb 收录它。推断虽然大多能歪打正着，但一旦参数不同（比如该文件用了
> 别的编译选项），你会看到假的报错或假的正常。

本机两个 compdb 的实测规模：

| compdb | 条目 | 其中引擎源码 | 其中构建树生成物 | 其中项目源码 |
|---|---|---|---|---|
| `/workspaces/o3de/compile_commands.json` | **8081** | 6755 | 1326 | 0 |
| `/workspaces/MyProject/compile_commands.json` | **8055** | 6755 | 1298 | **2** |

**注意项目 compdb 已经包含引擎源码条目**，所以读引擎代码时用哪一个都行。

### ⚠️ 不要经符号链接去构建

链接是给**读**用的，不是给**构建**用的。原因：CMake 会把源码路径
`realpath` 解析后写进构建树，而现有构建树里记录的、以及 compdb 的 `directory`
字段，全是真实路径（如 `/workspaces/o3de-build`）。用链接路径去 configure 会得到一套
路径不一致的新构建树，轻则全部重编，重则和现有产物互相干扰。

**规律**：读代码 → 经链接（方便）；跑 `ninja` / `cmake` / `o3de.sh` → 用真实路径。

---

# 第十一部分 · 实测数据

> **🎓 L4 · 读源码** ｜ 前置：L3 ｜ 读完能做什么：用实测数字校准性能直觉 ｜ 下一站 → **第十二部分（L4）**

## 11.1 环境规格

| | Codespace（编引擎） | 本机 WSL |
|---|---|---|
| CPU | 4 核 | 4 核 |
| 内存 | 15 GB（可用 13） | 7.7 GB（可用 **3.7**） |
| Swap | 无 | 2 GB |
| 磁盘 | 32 GB 总量 | 1007 GB（可用 746） |
| clang | 18.1.3 | 18.1.3 |
| CMake | 3.28.3 | 3.28.3 |
| Ninja | 1.11.1 | 1.11.1 |

**结论：磁盘是优势，内存是劣势。并行度必须降到 `-j2`/`-j3`。**

## 11.2 磁盘占用

### 引擎

| 项 | 体积 |
|---|---|
| 源码 | 448 MB |
| 三方包 | 4.2 GB |
| 构建树（删 `.dbg`） | 8.0 GB |
| **合计** | **约 12.6 GB** |

`.dbg`（分离调试符号）占 **3.7 GB**，删了不影响运行和编译。

> 🔄 **实测更新（2026-11-08）**：删掉 `.dbg` 后只要再做一次增量编译（哪怕只改一行），
> `.dbg` 会**立刻重新生成**——当前实测 `du -sh /workspaces/o3de-build` 已是 **12 GB**。
> 所以"删 `.dbg` 省 3.7 GB"只是**暂时**的，适合"编完就归档"的场景；
> 只要还在开发，它一定会回来。**规划磁盘时按 12 GB 算，别按 8 GB 算。**

### 项目

| 项 | 体积 |
|---|---|
| 源码 | < 5 MB |
| 资产缓存 | 111 MB |
| 构建树（预估完整） | 4~6 GB |

## 11.3 构建目标数

### 引擎构建树

| 目标 | 边数 | 耗时 |
|---|---|---|
| 全部 | **12780** | — |
| `AzCore` | 41 | 约 3 分钟 |
| `AzFramework` + `AzGameFramework` | 46 | 约 2 分钟 |
| `AzQtComponents` + `AzToolsFramework` | 137 | 约 15 分钟 |
| **`Editor`** | **789** | 约 70 分钟 |

### 项目构建树

| 项 | 数量 |
|---|---|
| 全部目标（`ninja -t targets all`） | 8960 |
| `Editor` + `GameLauncher` 边数 | **1025** |

## 11.4 耗时实测

### 引擎完整编译（Codespace，`-j4`）

| 阶段 | 耗时 |
|---|---|
| 装依赖 + 克隆 | 约 3 分钟 |
| CMake configure（下载 4.8 GB 压缩包 → 解压 4.2 GB） | **约 25 分钟** |
| 编译 AzCore → Editor | **约 85 分钟** |
| **合计** | **约 2 小时** |

### 项目构建（本机，`-j3`）

| 阶段 | 实测 |
|---|---|
| CMake configure | **2 分 42 秒** |
| 7 分钟后进度 | **22 / 1025** |
| **外推完整** | **3 小时以上** |

### 增量编译（本机，引擎构建树）

| 改动 | 触发目标 | 耗时 |
|---|---|---|
| 改 1 个 `.cpp` | 2（1 unity + 1 链接） | **1 分 09 秒** |
| 动了 `libAzCore.so` | **87**（下游重链） | **2 分 54 秒** |
| 什么都不改 | 0 | `no work to do` |

**提速 100 倍以上。**

## 11.5 产物清单

### 核心框架

| 文件 | 体积 | `.dbg` |
|---|---|---|
| `libAzCore.so` | 25 MB | +117 MB |
| `libAzFramework.so` | 36 MB | +157 MB |
| `libAzFramework.NativeUI.so` | 451 KB | +2.3 MB |
| `libAzQtComponents.so` | 3.2 MB | +11 MB |
| `libAzToolsFramework.so` | 47 MB | +250 MB |
| `libEditorLib.so` | 32 MB | — |
| `Editor` | **21 KB** | — |

### 统计

| 类别 | 数量 | 怎么数 |
|---|---|---|
| **可执行程序** | **16** | `bin/profile/` 顶层无扩展名且有执行权限的文件 |
| `bin/profile/*.so` | **81** | O3DE 自己的共享库 |
| `lib/profile/*.a` | **58** | 静态库 |
| 全部 `.so`（含子目录） | 132 | `find . -name '*.so'`，多出来的是插件与第三方拷贝 |

> ⚠️ **别把"有执行权限的文件"当可执行程序数**：`bin/profile` 下有 x 权限的文件共 **189** 个，
> 但其中 75 个是 `.so`（共享库通常带 x 位）。真正的可执行程序是 **16** 个。

### 符号抽查

| 检查 | 结果 |
|---|---|
| `libAzCore.so` EBus 导出符号 | **2194** |
| `libAzToolsFramework.so` 导出符号 | **22610** |
| `ldd` 未解析依赖 | **0** |

## 11.6 传输速率（`gh codespace ssh` 隧道）

| 方式 | 速率 | 12.6 GB 预估 |
|---|---|---|
| `tar` 直传 | 2.9 MB/s | 75 分钟 |
| `rsync -a --partial` | **1.5 MB/s** | 145 分钟 |
| **`tar \| zstd -1 -T4`** | **4~5 MB/s** | **45 分钟** |

## 11.7 内存与并行度

| 场景 | 峰值 |
|---|---|
| 单个 `cc1plus` | **1.3 GB** |
| `-j4` 时可用内存 | 4.2 GB → 400 MB，吃 1.5 GB swap |

| 并行度 | 吞吐 | swap |
|---|---|---|
| `-j4` | 7.7 目标/分钟 | 是 |
| `-j3` | 约 3 目标/分钟 | 轻微 |
| `-j2` | 2.2 目标/分钟 | 否 |

## 11.8 Python venv

| 项 | 值 |
|---|---|
| 位置 | `~/.o3de/Python/venv/<8位哈希>` |
| 单个体积 | **341 MB** |
| 包数 | 110 |
| Python | 3.10.13 |
| 哈希算法 | `SHA1(engineRoot 小写 + 尾斜杠)` 前 32 位 |

| engineRoot | 哈希 |
|---|---|
| `/workspaces/o3de/` | `8dcc7d4d` |
| `/workspaces/o3de-build/bin/profile/` | **`3295a26a`** |
| `/home/hwg/o3de/` | `04a8dd57` |

---

# 第十二部分 · Atom 渲染管线代码走读

> **🎓 L4 · 读源码 ★核心** ｜ 前置：L3 ｜ 读完能做什么：看懂 RHI 抽象与 Pass 系统 ｜ 下一站 → **第十三部分（L4）**

> 基于 `Gems/Atom/` 实际源码。RHI 共 **171 个头文件**，4 个后端（Vulkan / DX12 / Metal / Null）。

## 12.1 四层架构

```mermaid
flowchart TD
  A["你的代码 / Gem<br/>Component · Script Canvas"] --> B["Feature Processor<br/>Mesh / Light / Decal / PostProcess<br/>28 个实现"]
  B --> C["RPI<br/>Scene · RenderPipeline · Pass · View"]
  C --> D["RHI<br/>Device · Buffer · Image · CommandList · PipelineState"]
  D --> E1["Vulkan"]
  D --> E2["DX12"]
  D --> E3["Metal"]
  D --> E4["Null<br/>（无渲染，跑逻辑用）"]
```

| 层 | 目录 | 职责 | 可替换性 |
|---|---|---|---|
| **Feature** | `Gems/Atom/Feature/` | 具体功能：网格、光照、贴花、后处理 | 完全可换（连渲染器都能整个换掉） |
| **RPI**（Render Pipeline Interface） | `Gems/Atom/RPI/` | 场景、渲染管线、Pass、材质、Shader | 可换管线（多个 `.azasset` 管线描述） |
| **RHI**（Render Hardware Interface） | `Gems/Atom/RHI/` | 缓冲、纹理、命令列表、管线状态 | 4 个后端任选 |
| **后端** | `RHI/Vulkan` 等 | 具体图形 API | — |

**关键设计：RHI 把"图形 API 差异"隔离在 171 个头文件之后。** 上层写一次，四个后端都能跑。

## 12.2 ⭐ FeatureProcessor：渲染的插件扩展点

### 接口定义（`RPI.Public/FeatureProcessor.h`）

```cpp
class ATOM_RPI_PUBLIC_API FeatureProcessor
    : public SceneNotificationBus::Handler
{
public:
    AZ_RTTI(FeatureProcessor, "{B8027170-C65C-4237-964D-B557FC9D7575}");
    AZ_CLASS_ALLOCATOR(FeatureProcessor, AZ::SystemAllocator);

    // 生命周期
    virtual void Activate() {}
    virtual void Deactivate() {}

    // 每帧（三阶段）
    virtual void PrepareViews(const PrepareViewsPacket&, AZStd::vector<AZStd::pair<PipelineViewTag, ViewPtr>>& outViews) {}
    virtual void Simulate(const SimulatePacket&) {}
    virtual void Render(const RenderPacket&) {}
    virtual void OnEndCulling(const RenderPacket&) {}
    virtual void OnRenderEnd() {}

    // 管线构建时
    virtual void AddRenderPasses(RenderPipeline* pipeline) {}
};
```

### 官方注释里的关键设计说明（原文摘录）

> `Simulate()` is called from the simulation graph preparing and publishing data for use by the asynchronous rendering execution graph.
> `Render()` is called from the render graph, converting state data to GPU/rendering state and submitting to the pipeline coordinator.
> **Feature processors will contain or derive from listeners with a data buffers as needed to minimize contention.**

**翻译**：`Simulate` 在**模拟线程**准备数据，`Render` 在**渲染线程**消费数据。两者之间用**双缓冲/多缓冲**隔离，避免锁竞争。

### 三阶段调用时机

| 阶段 | 线程 | 频率 | 典型工作 |
|---|---|---|---|
| `PrepareViews` | 主线程 | 每帧 | 声明需要哪些额外 View（阴影图、反射探针） |
| `Simulate` | **并行 Job** | 每帧（可能跳过） | 更新 CPU 侧数据（粒子状态、动画） |
| `Render` | 并行 Job | 每帧 | 提交 DrawPacket 到 DrawList |
| `OnEndCulling` | — | 每帧 | 使用 VisibilityList（若不走默认剔除） |
| `OnRenderEnd` | — | 每帧 | 清理 |

### 28 个实际实现

以下列表由 `ls Gems/Atom/Feature/Common/Code/Source/*/*FeatureProcessor.h` 实测得出（**28 个**）：

```
MeshFeatureProcessor                    网格渲染
SkinnedMeshFeatureProcessor             蒙皮网格
TransformServiceFeatureProcessor        变换服务
AuxGeomFeatureProcessor                 调试几何体
SilhouetteFeatureProcessor              描边/剪影
DirectionalLightFeatureProcessor        平行光
PointLightFeatureProcessor              点光源
DiskLightFeatureProcessor               圆盘光
CapsuleLightFeatureProcessor            胶囊光
QuadLightFeatureProcessor               面光源
PolygonLightFeatureProcessor            多边形光
SimplePointLightFeatureProcessor        简化点光
SimpleSpotLightFeatureProcessor         简化聚光
ProjectedShadowFeatureProcessor         投影阴影
ImageBasedLightFeatureProcessor         IBL
ReflectionProbeFeatureProcessor         反射探针
DecalTextureArrayFeatureProcessor       贴花（纹理数组）
CubeMapCaptureFeatureProcessor          立方体捕获
SkyBoxFeatureProcessor                  天空盒
OcclusionCullingPlaneFeatureProcessor   遮挡剔除
PostProcessFeatureProcessor             后处理
SpecularReflectionsFeatureProcessor     镜面反射
SMAAFeatureProcessor                    抗锯齿
RayTracingFeatureProcessor              光追
RayTracingDebugFeatureProcessor         光追调试
DeferredMaterialFeatureProcessor        延迟材质
RenderDebugFeatureProcessor             调试渲染
SplashScreenFeatureProcessor            启动画面
```

> ⚠️ **注意没有 `DecalFeatureProcessor`**：真实类名是 `DecalTextureArrayFeatureProcessor`。
> 也没有 `DisplayMapperFeatureProcessor`——DisplayMapper 是 `Code/Source/DisplayMapper/`
> 下的独立模块，不是 FeatureProcessor。**类名靠猜会错，`ls` 一下最省事。**

**这就是渲染侧的插件式**：想加一个新特效，写一个 `FeatureProcessor` 子类，注册到 Scene 即可，不用改 RPI 核心。

## 12.3 走读案例：TransformServiceFeatureProcessor

选它是因为**简单且典型**（只有变换数据，没有复杂着色逻辑）。

### 头文件（`Feature/Common/Code/Source/TransformService/TransformServiceFeatureProcessor.h`）

```cpp
class TransformServiceFeatureProcessor final
    : public TransformServiceFeatureProcessorInterface
{
public:
    AZ_CLASS_ALLOCATOR(TransformServiceFeatureProcessor, AZ::SystemAllocator);
    AZ_RTTI(AZ::Render::TransformServiceFeatureProcessor,
        "{D8A2C353-2850-42F8-AA21-3979CBECBF80}",
        AZ::Render::TransformServiceFeatureProcessorInterface);

    // FeatureProcessor overrides
    void Activate() override;      // 创建 GPU 缓冲
    void Deactivate() override;    // 释放 GPU 资源

    // SceneNotificationBus overrides
    void OnBeginPrepareRender() override;
    void OnEndPrepareRender() override;

    // 业务接口
    ObjectId ReserveObjectId();
    void ReleaseObjectId(ObjectId& id);
    void SetTransformForId(ObjectId id, const AZ::Transform& transform, ...);
    AZ::Transform GetTransformForId(ObjectId id) const;
};
```

### 三个值得学的设计

#### ① 用 `union` 复用内存（空闲链表）

```cpp
// Holds both regular 4x3 transforms and 3x3 normal transforms
union Float4x3
{
    float m_transform[12] = { 0.0f };
    uint32_t m_nextFreeSlot;      // ← 同一个 12 字节：要么存变换，要么存空闲链表指针
};
```

**为什么**：一块 GPU 缓冲，用过的 slot 存矩阵，空闲的 slot 存"下一个空闲索引"，形成**链表**。这样：
- 分配 O(1)
- 不需要额外的空闲列表结构
- 缓冲可以静态大小

原文注释：

> Used slots have float12(matrix3x4) values, empty slots have a uint32_t that points to the next empty slot like a linked list. This allows mesh object SRGs to be compiled once with an index to their transform, and updates to the transform just update the buffer, not individual mesh SRGs.

**关键收益**：**SRG（ShaderResourceGroup）可以只编译一次**。更新变换只改缓冲区内容，不重编 SRG。

#### ② 用 SRG 名字索引而不是硬编码槽位

```cpp
RHI::ShaderInputNameIndex m_objectToWorldBufferIndex = "m_objectToWorldBuffer";
RHI::ShaderInputNameIndex m_objectToWorldInverseTransposeBufferIndex = "m_objectToWorldInverseTransposeBuffer";
RHI::ShaderInputNameIndex m_objectToWorldHistoryBufferIndex = "m_objectToWorldHistoryBuffer";
```

**为什么**：Shader 的 SRG 布局由 `.azsl` 反射生成，槽位号在不同材质/管线间会变。用**名字**查索引，布局变了不用改 C++。

`m_objectToWorldHistoryBuffer` 是**上一帧的变换**——用于运动模糊和 TAA。

#### ③ 通过 SceneNotificationBus 而不是 Tick

```cpp
void OnBeginPrepareRender() override;
void OnEndPrepareRender() override;
```

它**没有**用 `AZ::TickBus`，而是挂了 `SceneNotificationBus`。因为渲染数据必须在**正确的渲染阶段**上传，而不是任意 Tick 时刻。

**这是渲染相关组件的通用原则：跟渲染挂钩用 Scene/RPI 的总线，不要用 TickBus。**

## 12.4 Scene：每帧的调度中心

### `Scene::Simulate()`（`RPI.Public/Scene.cpp:484`）

```cpp
void Scene::Simulate(RHI::JobPolicy jobPolicy, float simulationTime)
{
    if (!m_activated) return;

    m_prevSimulationTime = m_simulationTime;
    m_simulationTime = simulationTime;

    // 上一帧的模拟可能还在跑 —— 等它
    if (m_taskGraphActive) WaitAndCleanTGEvent();
    else                   WaitAndCleanCompletionJob(m_simulationCompletion);

    // 选择并行策略
    if (jobPolicy == RHI::JobPolicy::Serial)
    {
        for (auto& fp : m_featureProcessors)
            fp->Simulate(m_simulatePacket);
    }
    else
    {
        if (m_taskGraphActive) SimulateTaskGraph();   // 新式：AZ::TaskGraph
        else                   SimulateJobs();        // 旧式：AZ::Job
    }
}
```

### 两种并行方案（`Scene.cpp:440` / `:462`）

```cpp
void Scene::SimulateTaskGraph()
{
    static const AZ::TaskDescriptor simulationTGDesc{"RPI::Scene::Simulate", "Graphics"};
    AZ::TaskGraph simulationTG{ "RPI::Scene::Simulate" };

    for (FeatureProcessorPtr& fp : m_featureProcessors)
    {
        FeatureProcessor* featureProcessor = fp.get();
        simulationTG.AddTask(simulationTGDesc, [this, featureProcessor]()
        {
            FeatureProcessor::SimulatePacket jobPacket = m_simulatePacket;
            jobPacket.m_parentJob = nullptr;
            featureProcessor->Simulate(jobPacket);
        });
    }
    simulationTG.Submit(m_simulationFinishedTGEvent.get());
}
```

**注意**：每个 FeatureProcessor 一个**独立 Task**，彼此无依赖 → 可以全并行。

**所以 FeatureProcessor 的 `Simulate` 必须线程安全**（只碰自己的数据）。这也是为什么接口注释强调"维护 N 缓冲的数据"。

### `Scene::PrepareRender()`（`:710`）

```cpp
void Scene::PrepareRender(RHI::JobPolicy jobPolicy, float simulationTime)
{
    if (!m_activated) return;

    // 等模拟完成
    if (m_taskGraphActive) WaitAndCleanTGEvent();
    else                   WaitAndCleanCompletionJob(m_simulationCompletion);

    // 通知所有 FP：开始准备渲染
    SceneNotificationBus::Event(GetId(), &SceneNotification::OnBeginPrepareRender);

    // 收集需要渲染的管线
    AZStd::vector<RenderPipelinePtr> activePipelines;
    for (auto& pipeline : m_pipelines)
    {
        if (pipeline->NeedsRender())
        {
            activePipelines.push_back(pipeline);
            pipeline->OnStartFrame(simulationTime);
        }
    }
    // ...
}
```

**这就是"模拟图"和"渲染图"的同步点**：等 `Simulate` 全部完成，才进 `PrepareRender`。

## 12.5 完整帧流程

```mermaid
sequenceDiagram
    participant App as 应用主循环
    participant Scene
    participant FP as FeatureProcessor ×28
    participant RP as RenderPipeline
    participant RHI
    participant GPU

    App->>Scene: Simulate(jobPolicy, time)
    par 并行（TaskGraph）
        Scene->>FP: Simulate(packet) ×28
    end
    Note over FP: 准备 CPU 侧数据<br/>写入 N 缓冲

    App->>Scene: PrepareRender(jobPolicy, time)
    Scene->>FP: OnBeginPrepareRender() ×28
    Scene->>RP: OnStartFrame()
    Scene->>FP: PrepareViews() → 额外 View
    Scene->>FP: Render(packet) ×28
    Note over FP: 生成 DrawPacket<br/>提交到 DrawList
    Scene->>FP: OnEndCulling()
    Scene->>FP: OnRenderEnd()

    Scene->>RP: Render()
    RP->>RHI: 提交 CommandList
    RHI->>GPU: vkQueueSubmit / ExecuteCommandLists
```

## 12.6 写一个自定义 FeatureProcessor

### 骨架

```cpp
// MyEffectFeatureProcessor.h
#pragma once
#include <Atom/RPI.Public/FeatureProcessor.h>

namespace MyProject
{
    class MyEffectFeatureProcessor final : public AZ::RPI::FeatureProcessor
    {
    public:
        AZ_RTTI(MyEffectFeatureProcessor, "{换成一个新UUID}",
            AZ::RPI::FeatureProcessor);
        AZ_CLASS_ALLOCATOR(MyEffectFeatureProcessor, AZ::SystemAllocator);

        static void Reflect(AZ::ReflectContext* context);

        // FeatureProcessor overrides
        void Activate() override;
        void Deactivate() override;
        void Simulate(const SimulatePacket& packet) override;
        void Render(const RenderPacket& packet) override;
    };
}
```

### 注册到 Scene

```cpp
// 在自己的组件或 SystemComponent 里
#include <Atom/RPI.Public/Scene.h>
#include <Atom/RPI.Public/FeatureProcessorFactory.h>

AZ::RPI::Scene* scene = AZ::RPI::RPISystemInterface::Get()->GetDefaultScene().get();
auto fp = AZ::RPI::FeatureProcessorFactory::Get()->CreateFeatureProcessor(
    azrtti_typeid<MyEffectFeatureProcessor>());
scene->AddFeatureProcessor(AZStd::move(fp));
```

### 还必须编译期注册类型

```cpp
// 在 Reflect 里
if (auto* behaviorContext = azrtti_cast<AZ::BehaviorContext*>(context))
{
    // ...
}

// 在模块初始化时（或在 SystemComponent::Activate 里）
AZ::RPI::FeatureProcessorFactory::Get()->RegisterFeatureProcessor<MyEffectFeatureProcessor>();
```

### 线程安全要点

| 阶段 | 线程 | 能做什么 |
|---|---|---|
| `Simulate` | 并行 Job（可能同时有多个 FP 在跑） | 只碰**自己**的成员；写数据缓冲 |
| `Render` | 并行 Job | 只读自己的 CPU 数据；生成 DrawPacket |
| `Activate`/`Deactivate` | 主线程 | 创建/释放 RHI 资源 |

**绝对不能**在 `Simulate`/`Render` 里做全局状态修改（如 `AZ::Interface::Get()->SetXxx()`）。

## 12.7 本机为什么渲染跑不起来

实测崩溃堆栈：

```
#4  AZ::Debug::Trace::Assert    HphaAllocator.cpp:2079
#5  AZ::HphaSchemaBase<false>::HpAllocator::tree_free
#6  libvulkan_lvp.so            ← Mesa lavapipe（软件 Vulkan）
#10 AZ::Vulkan::AsyncUploadQueue::EmmitPrologueMemoryBarrier
```

`HPPA_ASSERT(bl->used())` 是**双重释放检测**。软件 Vulkan 驱动释放了不属于它的块。

### 一个有用的发现：RHI 有 Null 后端

```
Gems/Atom/RHI/Null/
```

理论上可以用 `-DLY_RHI_BACKEND=Null` 之类的配置切到空后端（只跑逻辑不渲染）。但：

- 需要重新 configure + 编译（3 小时）
- Null 后端不产出可显示画面，只能验证逻辑

**实用替代**：直接用 `O3DE.HeadlessServerLauncher`（已验证可用），它根本不初始化 RHI。

## 12.8 渲染层的关键接口索引

| 想了解 | 位置 |
|---|---|
| FeatureProcessor 接口 | `Gems/Atom/RPI/Code/Include/Atom/RPI.Public/FeatureProcessor.h` |
| FeatureProcessor 工厂 | `.../RPI.Public/FeatureProcessorFactory.h` |
| Scene 调度 | `Gems/Atom/RPI/Code/Source/RPI.Public/Scene.cpp` |
| RenderPipeline | `.../RPI.Public/RenderPipeline.cpp` |
| RHI 抽象（171 个头） | `Gems/Atom/RHI/Code/Include/Atom/RHI/` |
| Vulkan 后端 | `Gems/Atom/RHI/Vulkan/` |
| Null 后端 | `Gems/Atom/RHI/Null/` |
| 材质系统 | `Gems/Atom/RPI/Code/Include/Atom/RPI.Public/Material/` |
| 28 个 FP 实现 | `Gems/Atom/Feature/Common/Code/Source/` |

---

# 第十三部分 · 多人网络架构

> **🎓 L4 · 读源码 ★核心** ｜ 前置：L3 ｜ 读完能做什么：看懂快照+增量同步 ｜ 下一站 → **第十六部分（L4）**

> 基于 `Gems/Multiplayer/` 与 `Code/Framework/AzNetworking/` 实际源码。

## 13.1 三层结构

```mermaid
flowchart TD
  A["你的网络组件<br/>*.AutoComponent.xml → 生成的 C++"] --> B["Multiplayer Gem<br/>NetworkEntityManager · Replicator<br/>Predictor · ReplicationWindow"]
  B --> C["AzNetworking<br/>Connection · Packet · Transport"]
  C --> D1["UDP"]
  C --> D2["TCP"]
  C --> D3["TCP/TLS"]
```

| 层 | 目录 | 职责 |
|---|---|---|
| **你的组件** | `Gems/*/Code/Source/AutoGen/*.AutoComponent.xml` | 声明"哪些属性要同步" |
| **Multiplayer Gem** | `Gems/Multiplayer/` | 实体复制、预测回滚、带宽控制、会话管理 |
| **AzNetworking** | `Code/Framework/AzNetworking/` | 连接抽象、打包、传输层 |

## 13.2 ⭐ 声明式网络同步：AutoComponent

这是 O3DE 网络最独特的设计——**你写 XML，代码自动生成**。

### 一个完整的例子（`Gems/Multiplayer/Code/Source/AutoGen/NetworkTransformComponent.AutoComponent.xml`）

```xml
<Component
    Name="NetworkTransformComponent"
    Namespace="Multiplayer"
    OverrideComponent="true"
    OverrideController="true"
    OverrideInclude="Multiplayer/Components/NetworkTransformComponent.h">

    <ComponentRelation Constraint="Weak" HasController="false"
        Name="TransformComponent" Namespace="AzFramework" />

    <NetworkProperty Type="AZ::Quaternion" Name="rotation"
        Init="AZ::Quaternion::CreateIdentity()"
        ReplicateFrom="Authority" ReplicateTo="Client"
        IsRewindable="true" IsPredictable="true"
        IsPublic="true" Container="Object" GenerateEventBindings="true" />

    <NetworkProperty Type="AZ::Vector3" Name="translation"
        Init="AZ::Vector3::CreateZero()"
        ReplicateFrom="Authority" ReplicateTo="Client"
        IsRewindable="true" IsPredictable="true"
        IsPublic="true" Container="Object" GenerateEventBindings="true" />

    <NetworkProperty Type="float" Name="scale" Init="1.0f"
        ReplicateFrom="Authority" ReplicateTo="Client"
        IsRewindable="true" IsPredictable="true"
        IsPublic="true" Container="Object" />

    <NetworkProperty Type="uint8_t" Name="resetCount" Init="0"
        ReplicateFrom="Authority" ReplicateTo="Client"
        IsRewindable="false" IsPredictable="true"
        IsPublic="true" Container="Object" />

    <NetworkProperty Type="NetEntityId" Name="parentEntityId"
        Init="InvalidNetEntityId"
        ReplicateFrom="Authority" ReplicateTo="Client"
        IsRewindable="true" IsPredictable="true"
        IsPublic="true" Container="Object" />

    <RemoteProcedure Name="MultiplayerTeleport"
        InvokeFrom="Server" HandleOn="Authority"
        IsPublic="true" IsReliable="true" GenerateEventBindings="true"
        Description="Teleports to a position while incrementing reset count to avoid interpolation">
        <Param Type="AZ::Vector3" Name="TeleportToPosition" />
    </RemoteProcedure>
</Component>
```

### 属性标志逐项解释

| 属性 | 值 | 含义 |
|---|---|---|
| `ReplicateFrom` | `Authority` | 只有权威端（服务器）能改这个值 |
| `ReplicateTo` | `Client` | 同步给客户端 |
| `IsRewindable` | `true` | **支持回滚**（服务器可回溯到过去的状态做判定） |
| `IsPredictable` | `true` | **客户端可预测**（本地先算，服务器确认后校正） |
| `IsPublic` | `true` | 其他组件可读 |
| `Container` | `Object` | 存放在组件对象上（另一个值是 `Array`） |
| `GenerateEventBindings` | `true` | 生成 `OnXxxChanged` 事件供别人监听 |

**`IsRewindable` + `IsPredictable` 这两个标志是射击游戏低延迟的核心**：

- 客户端预测：本地立刻移动，不等服务器
- 服务器回滚：收到玩家的开火请求时，把其他玩家回溯到"他开火那一刻"的位置做命中判定

### 生成的产物（`AUTOGEN_RULES`，`Gems/Multiplayer/Code/CMakeLists.txt:88-91`）

```cmake
AUTOGEN_RULES
    *.AutoComponent.xml,AutoComponent_Header.jinja,$path/$fileprefix.AutoComponent.h
    *.AutoComponent.xml,AutoComponent_Source.jinja,$path/$fileprefix.AutoComponent.cpp
    *.AutoComponent.xml,AutoComponentTypes_Header.jinja,$path/AutoComponentTypes.h
    *.AutoComponent.xml,AutoComponentTypes_Source.jinja,$path/AutoComponentTypes.cpp
```

> 注：源码里逗号后**没有空格**（`*.xml,AutoComponent_Header.jinja`）。
> 这不是排版偏好——`cmake/AzAutoGen.py:291` 是 `expansionRule.split(",")`，
> **不做 `strip()`**，随后用 `if expansionRuleSet[1] in fullPathTemplate` 做子串匹配。
> 一旦写成 `, AutoComponent_Header.jinja`，带前导空格的模板名就匹配不到真实路径，
> 会报 `No matching template file found for  AutoComponent_Header.jinja`。
> **复制这类规则时别顺手加空格。**

**一个 XML → 4 个文件**：

| 生成文件 | 内容 |
|---|---|
| `<Name>.AutoComponent.h` | 组件类声明 + 属性访问器 + RPC 声明 |
| `<Name>.AutoComponent.cpp` | 序列化、复制、RPC 分发实现 |
| `AutoComponentTypes.h/.cpp` | 所有网络组件的统一类型注册表 |

### 模板文件位置

```
Gems/Multiplayer/Code/Include/Multiplayer/AutoGen/
├── AutoComponent_Header.jinja
├── AutoComponent_Source.jinja
├── AutoComponentTypes_Header.jinja
├── AutoComponentTypes_Source.jinja
└── AutoComponent_Common.jinja
```

**这就是 AzAutoGen**：Jinja2 模板 + XML 数据 → 生成 C++。

### 10 个内置网络组件

```
NetworkTransformComponent            变换同步
NetworkCharacterComponent            角色移动
NetworkRigidBodyComponent            刚体同步
NetworkHitVolumesComponent           判定体积
NetworkHierarchyRootComponent        层级根
NetworkHierarchyChildComponent       层级子
LocalPredictionPlayerInputComponent  本地预测输入
NetworkDebugPlayerIdComponent        调试
```

## 13.3 实体复制机制

### 核心类

| 类 | 位置 | 职责 |
|---|---|---|
| `NetworkEntityManager` | `Code/Source/NetworkEntity/` | 全局：管理所有网络实体的生命周期 |
| `NetworkEntityTracker` | 同上 | 追踪 EntityId ↔ NetEntityId 映射 |
| `NetworkEntityAuthorityTracker` | 同上 | 追踪"哪个连接对哪个实体有权威" |
| `EntityReplicator` | `NetworkEntity/EntityReplication/` | 单个实体：何时发、发什么 |
| `PropertyPublisher` | 同上 | 权威侧：收集脏属性 |
| `PropertySubscriber` | 同上 | 客户端：应用收到的属性 |
| `ReplicationRecord` | 同上 | 记录历史（供回滚） |

### 复制流程

```mermaid
flowchart TD
  A["权威侧属性改变<br/>SetTranslation(...)"] --> B["PropertyPublisher<br/>标记为 dirty"]
  B --> C["EntityReplicator<br/>每帧决定是否发"]
  C --> D{"在复制窗口内？<br/>优先级够高？"}
  D -->|否| E["跳过（下帧再看）"]
  D -->|是| F["打包 NetworkEntityUpdateMessage"]
  F --> G["AzNetworking 传输"]
  G --> H["客户端 PropertySubscriber"]
  H --> I["应用到本地实体<br/>触发 OnXxxChanged 事件"]
```

### 带宽控制：ReplicationWindow

`Code/Source/ReplicationWindows/ServerToClientReplicationWindow.h`：

```cpp
class ServerToClientReplicationWindow
{
    struct PrioritizedReplicationCandidate
    {
        PrioritizedReplicationCandidate(const ConstNetworkEntityHandle& entityHandle, float priority);
        bool operator <(const PrioritizedReplicationCandidate& rhs) const;
        bool operator >(const PrioritizedReplicationCandidate& rhs) const;
        float m_priority;
    };

    bool IsInWindow(const ConstNetworkEntityHandle& entityPtr, NetEntityRole& outNetworkRole) const override;
    void AddEntity(AZ::Entity* entity) override;
    void RemoveEntity(AZ::Entity* entity) override;
    void UpdateWindow() override;

private:
    void EvaluateConnection();
    void AddEntityToReplicationSet(ConstNetworkEntityHandle& entityHandle,
        float priority, float distanceSquared);
};
```

**机制**：按 `priority` 排序，只同步"窗口内"的实体。

- `distanceSquared` 参与优先级计算 → **离玩家越近越优先**
- 超出窗口的实体不同步（省带宽）
- 这就是 MMO / 大世界游戏的标准做法

## 13.4 预测与回滚

### 涉及的模块

```
Code/Source/NetworkInput/
├── NetworkInput.cpp              一次输入
├── NetworkInputArray.cpp         输入数组（一个帧的多个输入）
├── NetworkInputHistory.cpp       ★ 输入历史（回滚用）
├── NetworkInputChild.cpp
└── NetworkInputMigrationVector.cpp

Code/Source/NetworkTime/
└── NetworkTime.h                 ★ 时钟同步
```

### `NetworkTime` 的关键接口

```cpp
class NetworkTime
{
    AzNetworking::ConnectionId GetRewindingConnectionId() const override;
    void SyncEntitiesToRewindState(const AZ::Aabb& rewindVolume) override;

private:
    AZ::TimeMs m_hostTimeMs = AZ::Time::ZeroTimeMs;   // 主机时间
};
```

**`SyncEntitiesToRewindState(AZ::Aabb rewindVolume)`** —— 这个签名信息量很大：

- 只回滚**指定包围盒内**的实体（不是整个世界）
- 说明回滚是**按需、局部**的，不是全场景快照

### 预测回滚的四步

```mermaid
sequenceDiagram
    participant C as 客户端
    participant S as 服务器
    participant H as NetworkInputHistory

    Note over C: t=0 按下前进
    C->>C: 本地立即预测（向前移动）
    C->>H: 记录 (frame=100, input=前进)
    C->>S: 发送 input(frame=100)

    Note over S: t=1 收到（延迟 1 帧）
    S->>S: 用权威状态计算
    S->>S: 存进 ReplicationRecord
    S->>C: 回发权威状态(frame=100)

    Note over C: t=2 收到权威状态
    C->>H: 取出 frame=100 之后的输入
    C->>C: 回滚到 frame=100 的权威状态
    C->>C: 重放 frame=101, 102... 的输入
    Note over C: 结果：无橡皮筋的流畅体验
```

**关键**：`NetworkInputHistory` 保存最近 N 帧的输入，用于"服务器确认后重放"。

## 13.5 权威模型

### 三种角色

| 角色 | `NetEntityRole` | 说明 |
|---|---|---|
| **Authority** | 服务器 / 主机 | 唯一能改 `ReplicateFrom="Authority"` 的属性 |
| **Autonomous** | 客户端自己的角色 | 可预测，但不能最终决定 |
| **Simulated** | 其他玩家的角色 | 只接收同步，插值平滑 |

### 权限检查

```cpp
// 属性 setter 里通常会有（自动生成的代码）
if (!IsAuthority())
{
    AZ_Warning("Multiplayer", false, "Only authority can set %s", "translation");
    return;
}
```

**这是声明式的**：`ReplicateFrom="Authority"` 让生成器自动插入这个检查，你不需要手写。

### 会话管理

```
Code/Source/Session/
```

管理：
- 谁连上了
- 谁离开了
- 主机迁移（host migration）

## 13.6 RPC：远程过程调用

### XML 声明

```xml
<RemoteProcedure Name="MultiplayerTeleport"
    InvokeFrom="Server"           ← 谁可以调用
    HandleOn="Authority"          ← 谁执行
    IsPublic="true"
    IsReliable="true"             ← 可靠传输（TCP 语义）
    GenerateEventBindings="true"
    Description="Teleports to a position while incrementing reset count to avoid interpolation">
    <Param Type="AZ::Vector3" Name="TeleportToPosition" />
</RemoteProcedure>
```

### 生成的接口

```cpp
// 调用方
NetworkTransformComponent::MultiplayerTeleport(position);

// 被调方（自动生成的 handler）
void NetworkTransformComponent::HandleMultiplayerTeleport(AzNetworking::IConnection* invoker,
    const AZ::Vector3& teleportToPosition);
```

### `IsReliable` 的取舍

| 值 | 传输 | 适用 |
|---|---|---|
| `true` | 可靠（重传直到送达） | 传送、购买、开箱 |
| `false` | 不可靠（丢了就丢） | 高频小幅更新（位置、朝向） |

**原则**：能用不可靠就别用可靠，可靠传输会阻塞后续包（队头阻塞）。

## 13.7 网络层关键接口索引

| 想了解 | 位置 |
|---|---|
| AutoComponent 例子 | `Gems/Multiplayer/Code/Source/AutoGen/*.AutoComponent.xml` |
| 代码生成规则 | `Gems/Multiplayer/Code/CMakeLists.txt:88-91` |
| Jinja2 模板 | `Gems/Multiplayer/Code/Include/Multiplayer/AutoGen/` |
| 实体复制 | `Gems/Multiplayer/Code/Source/NetworkEntity/EntityReplication/` |
| 复制窗口 | `Gems/Multiplayer/Code/Source/ReplicationWindows/` |
| 输入历史 | `Gems/Multiplayer/Code/Source/NetworkInput/NetworkInputHistory.cpp` |
| 时钟同步 | `Gems/Multiplayer/Code/Source/NetworkTime/NetworkTime.h` |
| 实体域 | `Gems/Multiplayer/Code/Source/EntityDomains/` |
| 底层网络 | `Code/Framework/AzNetworking/AzNetworking/` |
| 连接层 | `AzNetworking/ConnectionLayer/` |
| 打包层 | `AzNetworking/PacketLayer/` |
| 传输层 | `AzNetworking/UdpTransport/`、`TcpTransport/` |

## 13.8 两种"插件式"的对比

学完渲染和网络后，能看到 O3DE 插件式的**两种不同实现风格**：

| | Atom FeatureProcessor | Multiplayer AutoComponent |
|---|---|---|
| 扩展方式 | C++ 继承 `FeatureProcessor` | **XML 声明** + 代码生成 |
| 注册方式 | 运行时 `AddFeatureProcessor()` | 编译期 `AUTOGEN_RULES` |
| 生成物 | 无（纯手写） | 4 个 C++ 文件（Jinja2 生成） |
| 适合场景 | 逻辑复杂、需要精细控制 GPU | 模式固定、样板代码多 |
| 学习曲线 | 需要懂渲染管线 | 需要懂 XML 语义 |
| 样板代码量 | 多 | **极少** |

**这是同一种设计哲学（"声明你想要什么，框架负责实现"）的两种落地**：

- 渲染的"想要什么"太复杂，无法用 XML 表达 → 手写 C++
- 网络同步的"想要什么"高度模式化（属性 + RPC）→ 可以用 XML 表达 → 生成

---

# 第十四部分 · 踩坑与排错

> **🎓 L1 / L5 通用 · 随时查** ｜ 前置：无 ｜ 用法：**遇到问题先来这里搜关键词**，**19 个**坑按「编译期 / 运行期 / 逻辑」分类 ｜ 快速定位看 [14.1 快速索引](#141-快速索引)，系统化排查看 [14.3 诊断工具箱](#143-系统化诊断工具箱)

## 14.1 快速索引

| # | 症状 | 类别 |
|---|---|---|
| 1–3 | `libunwind` / `xcb_xkb` / `xkbcommon_X11` 找不到 | 依赖 |
| 4 | `CLANG_SCAN_DEPS-NOTFOUND` | 依赖 |
| 5 | 磁盘满导致链接失败 | 资源 |
| 6 | `gh` 全线 EOF（fake-ip） | 网络 |
| 7 | 终端卡住不动（引号嵌套） | 操作 |
| 8 | 长任务被"用户中断" | 操作 |
| 9 | `tar: Cannot open` | 迁移 |
| 10 | 增量判断全失效 | 迁移 |
| 11 | `[0/1] Re-running CMake...` 反复触发 | 迁移 |
| 12 | `CMake step for googletest failed: 1` | 迁移 |
| 13 | 迁移后缺系统 `-dev` 软链接 | 迁移 |
| 14 | 卡在 `Running get_python script...` | 运行时 |
| 15 | Editor 段错误（含 `Could not load font` 干扰项） | 运行时 |
| 16 | `pkill -f` 杀不掉进程 | 操作 |
| 17 | `ninja -n` 显示 1295 待办（误判） | 误判 |
| 18 | 改了代码没生效（不报错） | 开发 |
| 19 | `HeadlessServer` 无 GPU 时卡死 | 运行时 |

> ⚠️ **编号说明**：**坑 1–3 合并在一节**（同一个根因：`-dev` 包 vs 运行时包），
> 所以正文有 17 个 `### 坑` 标题，但覆盖 **19 条坑**。
> 坑 15 里的 `Could not load font` 不是独立问题，是 Editor 段错误的**干扰项**
> （详见该节），所以它也合并在 15 里。

## 14.2 详细记录

### 坑 1-3：`-dev` 包和运行时包是两回事

```
Could NOT find X11 (missing: xcb_xkb)
  → cmake/3rdParty/FindX11.cmake:29 ← AzFramework/CMakeLists.txt:163

Could NOT find X11 (missing: xkbcommon_X11)
  → cmake/LYWrappers.cmake:569 ← CMakeLists.txt:179
```

**根因**：装了 `libxkbcommon-x11-0`（**运行时**），CMake 需要 `libxkbcommon-x11-dev`（**开发**，含头文件和 `.pc`）。

**通用规律**：

| 你需要 | 装哪个 |
|---|---|
| 运行时 | `libfoo0` / `libfoo8` |
| **编译/链接** | **`libfoo-dev`** |

**诊断**：

```bash
ls /usr/lib/x86_64-linux-gnu/libxkbcommon.so       # 有没有（链接需要）
ls /usr/lib/x86_64-linux-gnu/libxkbcommon.so.0     # 有没有（运行需要）
```

只有 `.so.0` 没有 `.so` → 缺 dev 包。

**修复**：

```bash
sudo apt-get install -y libunwind-dev \
  libxcb-xfixes0-dev libxcb-xinerama0-dev libxcb-xinput-dev \
  libxcb-icccm4-dev libxcb-keysyms1-dev libxcb-shape0-dev \
  libxcb-randr0-dev libxcb-util-dev libpulse-dev \
  libxkbcommon-x11-dev libxkbcommon-dev libxcb-xkb-dev
```

### 坑 4：`CLANG_SCAN_DEPS-NOTFOUND`（错误延迟暴露）

**现象**：configure 成功，编译到第 227 个目标才失败：

```
FAILED: _deps/meshoptimizer-build/CMakeFiles/meshoptimizer.dir/src/allocator.cpp.o.ddi
"CMAKE_CXX_COMPILER_CLANG_SCAN_DEPS-NOTFOUND" -format=p1689 -- /usr/bin/clang++-18 ...
```

**根因链条**：

1. meshoptimizer 启用 C++20 模块依赖扫描（生成 `.ddi`）
2. CMake 用 `clang-scan-deps`，路径在**配置阶段**写入缓存
3. Ubuntu 的 `clang-18` **不含**它（在 `clang-tools-18` 里）
4. CMake 记为 `...-NOTFOUND`，生成 `rules.ninja` 时当命令 → **编译期才炸**

**修复（两步）**：

```bash
sudo apt-get install -y clang-tools-18
sudo ln -sf /usr/bin/clang-scan-deps-18 /usr/local/bin/clang-scan-deps
```

**关键技巧：直接改缓存，别重配**

```bash
cp CMakeCache.txt CMakeCache.txt.bak
sed -i 's|^CMAKE_CXX_COMPILER_CLANG_SCAN_DEPS:FILEPATH=.*|CMAKE_CXX_COMPILER_CLANG_SCAN_DEPS:FILEPATH=/usr/local/bin/clang-scan-deps|' CMakeCache.txt
sed -i 's|^CMAKE_C_COMPILER_CLANG_SCAN_DEPS:FILEPATH=.*|CMAKE_C_COMPILER_CLANG_SCAN_DEPS:FILEPATH=/usr/local/bin/clang-scan-deps|' CMakeCache.txt
cmake -B <build> -S <src> ...      # 只重生成 build.ninja，不重编
```

**收益**：保住已编的 227 个目标，省 20 分钟。

**验证**：

```bash
grep -o '[^ ]*clang-scan-deps[^ ]*' CMakeFiles/rules.ninja | head -1
# 期望 "/usr/local/bin/clang-scan-deps"（不是 ...-NOTFOUND）
```

### 坑 5：磁盘耗尽

**实测账目**：

| 项 | 占用 |
|---|---|
| 源码 | 448 MB |
| 三方包 | 4.2 GB |
| build（含 `.dbg`） | **12 GB** |
| build（删 `.dbg`） | 8 GB |
| **合计** | **17 GB / 12.6 GB** |

**救急**：

```bash
find /workspaces/o3de-packages/downloaded_packages -name "*.tar.xz" -delete   # 631 MB
find /workspaces/o3de-build -name "*.dbg" -delete                             # 3.7 GB
```

**安全性**：configure 靠 **sha256 校验 `packages/`** 而非压缩包。只要不再 configure，删压缩包无影响。

### 坑 6：`api.github.com` 被 fake-ip 劫持

**现象**：

```
$ gh api user/codespaces
Get "https://api.github.com/user/codespaces": EOF
```

**诊断序列**：

```bash
getent hosts api.github.com
# → 198.18.0.108     ← Clash fake-ip，RFC2544 保留段

curl --noproxy '*' -o /dev/null -w "%{http_code}\n" https://github.com        # → 200 ✓
curl --noproxy '*' -o /dev/null -w "%{http_code}\n" https://api.github.com    # → SSL_ERROR_SYSCALL

curl -sS 'https://dns.alidns.com/resolve?name=api.github.com&type=A'          # → 20.205.243.168
curl --resolve api.github.com:443:20.205.243.168 ... https://api.github.com/  # → 403 ✓
```

**结论：DNS 污染，不是代理故障。**

- `github.com` 未污染 → SSH 主连接正常
- 但 `gh codespace` 每条命令先调 API → 整个工具失效
- 本地 7897 端口走 HTTP/SOCKS **都失败**（代理自己也用污染 DNS）
- `sudo` 需密码 → 无法改 `/etc/hosts`

**修复：自建 CONNECT 代理做域名→IP 覆盖**

```python
# o3de-codespace/_gh_proxy.py
OVERRIDE = {"api.github.com": "20.205.243.168"}
```

```bash
setsid nohup python3 _gh_proxy.py 18080 > /tmp/gh_proxy.log 2>&1 < /dev/null & disown
export HTTPS_PROXY=http://127.0.0.1:18080 HTTP_PROXY=http://127.0.0.1:18080
gh api user/codespaces      # ✓
```

### 坑 7：远端命令引号嵌套挂死终端

```bash
# ✗ 单引号内又用双引号，被换行截断 → PS2 续行，终端卡住
gh codespace ssh -c X -- 'cd /workspaces/o3de && sed -n "725,760p" file.cmake
```

**修复：本地脚本 + stdin**

```bash
gh codespace ssh -c X -- 'bash -s' < local_script.sh
```

**收益**：彻底规避引号地狱、可版本管理、多行不会被截断。

### 坑 8：长任务被"用户中断"

```
ninja: build stopped: interrupted by user.
```

看起来像 Ctrl+C，实际是 SSH 会话结束**向进程组发信号**。

**修复**：

```bash
setsid nohup ./build.sh < /dev/null > /dev/null 2>&1 & disown
```

| 要素 | 作用 |
|---|---|
| `setsid` | 脱离进程组 |
| `< /dev/null` | 防 stdin 关闭异常 |
| `disown` | 从作业表移除 |

**`nohup ... &` 不够。**

### 坑 9：`tar: Cannot open` 重试 20 次全失败

```
tar: /workspaces/o3de-build: Cannot open: No such file or directory
```

**根因**：`tar -C <dir>` 要求**目标目录已存在**。脚本没 `mkdir -p`，重试机制形同虚设，**白等 20 分钟**。

### 坑 10：增量判断全失效

`du -sh *` 看不到以点开头的文件，漏掉：

| 文件 | 体积 | 作用 |
|---|---|---|
| `.ninja_deps` | 3.8 MB | 头文件依赖数据库 |
| `.ninja_log` | 172 KB | 构建历史 |

**修复**：必须带隐藏文件

```bash
cd /workspaces/o3de-build && tar -cf - --exclude='./bin' ... . | zstd -1 -T4 -c
#                                                 ↑ 这个 "." 包含隐藏文件
```

**另一个必要条件**：mtime 必须保留（`tar -p` / `rsync -a`）。

### 坑 11：`[0/1] Re-running CMake...` 反复触发

```bash
$ ninja -n Editor
[0/1] Re-running CMake...
```

**诊断**：

```bash
ninja -d explain -n
# 直接告诉你哪个输入 dirty
```

实测输出：

```
ninja explain: output /home/codespace/.o3de/Python/packages/python-3.10.13-rev2-linux/FindPython.cmake
                of phony edge with no inputs doesn't exist
ninja explain: /usr/share/cmake-3.28/Modules/AddFileDependencies.cmake is dirty
```

**两个根因**：

1. 绝对路径 `/home/codespace/.o3de/Python/...` 不存在（468 处）
2. `/usr/share/cmake-3.28/Modules/*.cmake` 的 mtime 比 `build.ninja` 新

**修复**：

```bash
touch build.ninja
```

**为什么安全**：`build.ninja` 不是编译规则的输入，只是输出。`restat = 1` 让 ninja 认为配置已最新。

⚠️ **千万不要让 CMake 真的跑起来**，会撞坑 12。

### 坑 12：`CMake step for googletest failed: 1`

```
CMake Error at FetchContent.cmake:1667:
  CMake step for googletest failed: 1
Call Stack:
  Code/Framework/AzTest/3rdParty/Findgoogletest.cmake:75 (FetchContent_MakeAvailable)
```

**根因**：重新配置时 `FetchContent_MakeAvailable(googletest)` 要**重新联网 clone**。

**一个反直觉的好消息**：**失败后 `build.ninja` 未被破坏。**

```bash
diff -q /tmp/build.ninja.bak build.ninja     # → 完全一致
```

CMake 失败时不写新文件。

**修复思路**：

```bash
cmake ... \
  -DFETCHCONTENT_FULLY_DISCONNECTED=ON \
  -DFETCHCONTENT_SOURCE_DIR_GOOGLETEST=/workspaces/o3de-build/_deps/googletest-src \
  -DFETCHCONTENT_SOURCE_DIR_MESHOPTIMIZER=... \
  ...（共 7 个）
```

`_deps` 下已有：`googletest-src` `meshoptimizer-src` `miniaudio-src` `ogg-src` `openmesh-src` `recastnavigation-src` `vorbis-src`。

### 坑 13：迁移后缺系统 `-dev` 软链接

```bash
$ ninja -n Editor
ninja: error: '/usr/lib/x86_64-linux-gnu/libunwind.so', needed by 'bin/profile/libAzCore.so',
             missing and no known rule to make it
```

补完后：

```bash
ninja: error: '/usr/lib/x86_64-linux-gnu/libxcb-xfixes.so', needed by '...'
```

**特点**：`ninja` **一次只报一个**，需要迭代。

**为什么不能改 `build.ninja` 指向别处**：

改路径 → 命令文本变化 → **ninja 判定命令变了 → 全量重编**。

**必须补到系统路径**（见坑 1-3 的 apt 命令）。

### 坑 14：卡在 `Running get_python script...`

**现象**：编辑器/项目管理器启动后弹框：

```
Running get_python script...
/workspaces/o3de-build/bin/profile/python/get_python.sh
```

进度条**永远不动**，Cancel 无响应。

**根因链条**：

```mermaid
flowchart TD
  A["ProjectManager 启动"] --> B["PythonBindings::StartPython()"]
  B --> C{"找到 venv 吗"}
  C -->|否| D["RunGetPythonScript(GetEngineRoot())"]
  D --> E["执行 &lt;engineRoot&gt;/python/get_python.sh"]
  E --> F["构建树里没有这个文件<br/>（只存在于 SDK 安装布局）"]
  F --> G["QProcess 启动失败<br/>模态框不终止 = 卡死"]
```

**为什么找不到 venv**：`PythonLoader::GetPythonVenvPath()` 用**引擎路径的 SHA1 前 32 位**当目录名。

日志证据：

```
python~~Missing python venv file at /home/hwg/.o3de/Python/venv/3295a26a/pyvenv.cfg.
```

| engineRoot | 哈希 |
|---|---|
| `/workspaces/o3de/` | `8dcc7d4d`（configure 时创建的） |
| `/workspaces/o3de-build/bin/profile/` | **`3295a26a`**（ProjectManager 要的） |

**关键**：在构建树里跑 ProjectManager 时 `GetEngineRoot()` 解析成 `bin/profile/`（向上找不到 `engine.json`）。

**修复**：

```bash
cd ~/.o3de/Python/venv && ln -sfn 8dcc7d4d 3295a26a
```

**自己算哈希**：

```bash
python3 -c "import hashlib; print(hashlib.sha1('/workspaces/o3de/'.encode()).hexdigest()[:8])"
```

### 坑 15：Editor 段错误（本机硬限制）

```
Segmentation fault (core dumped)
```

**关键：先用 gdb 抓真实堆栈，别被日志误导**

```bash
gdb -batch -ex run -ex "bt 25" --args ./Editor --project-path=/workspaces/MyProject
```

实测堆栈：

```
#4  AZ::Debug::Trace::Assert
     /workspaces/o3de/Code/Framework/AzCore/AzCore/Memory/HphaAllocator.cpp:2079
#5  AZ::HphaSchemaBase<false>::HpAllocator::tree_free
#6  libvulkan_lvp.so                        ← Mesa lavapipe（软件 Vulkan）
#10 AZ::Vulkan::AsyncUploadQueue::EmmitPrologueMemoryBarrier
```

**根因**：`HphaAllocator.cpp:2079`：

```cpp
// This assert detects a double-free of ptr
HPPA_ASSERT(bl->used());
```

**双重释放检测**。软件 Vulkan 驱动与 O3DE 的 HPHA 全局分配器 hook 不兼容。

**环境事实**：

| 检查 | 结果 |
|---|---|
| `vulkaninfo --summary` | 只有 `llvmpipe` |
| Vulkan ICD | 只有 Mesa 各家，**无 `nvidia_icd.json`、无 `dzn`** |
| GPU 直通 | `/dev/dxg` 存在，Windows 侧 GTX 1650 |
| O3DE Linux 后端 | **只有 Vulkan**，无 null/GL，无 `--rhi` |

WSL 的 NVIDIA 直通只提供 `libcuda`（CUDA 可用），**Vulkan 走不到 NVIDIA**。

**出路**：HeadlessServer（可用）/ 换硬件 Vulkan 环境 / Windows 原生 O3DE。

### 坑 16：`pkill -f` 杀不掉进程

```bash
pkill -f "bin/profile/o3de"      # 没反应
```

**根因**：进程 argv[0] 是 `./o3de`，**不含** `bin/profile/` 前缀。

**修复**：

```bash
pkill -x o3de                         # 按精确进程名
pkill -f "^\./o3de$"                  # 或按 argv 精确匹配
pgrep -af "o3de|Editor" | grep -v grep  # 先看清楚
```

### 坑 17：`ninja -n` 显示 1295 待办（误判）

```bash
$ ninja -n
[1/1295] Building CXX object External/ScriptCanvasTesting-...
```

**实际**：不带目标时用**默认目标集合**，包含从未编过的测试类 Gem。

**正确**：

```bash
ninja -n Editor                  # → no work to do
ninja -n AzCore AzFramework      # → no work to do
```

### 坑 18：改了代码没生效（不报错）

| # | 原因 | 检查 |
|---|---|---|
| 1 | **文件没加进 `myproject_files.cmake`** | `grep 文件名 Gem/myproject_files.cmake` |
| 2 | 组件没加进 `m_descriptors` | 看 `MyProjectModule.cpp` 构造函数 |
| 3 | `gem_names` 没含 `MyProject` | `cat MyProject/project.json` |
| 4 | 改了 `.cmake` 没重配 | `ninja` 是否自动触发 |
| 5 | 用了另一个构建树 | `ls -l` 看二进制时间 |
| 6 | 组件没 `Activate`（没连总线） | `Activate()` 里有 `BusConnect` |

**通用排查**：

```bash
# ① 文件是否被 CMake 看到
grep -r "你的文件名" /workspaces/MyProject/Gem/*.cmake

# ② 符号有没有编出来（注意查 .a，不要查 .so）
#    -fvisibility=hidden 会让你的组件符号在 .so 里变成 local，nm -D 一定找不到
nm --defined-only <build>/lib/profile/libMyProject.Private.Object.a | grep -i 你的类名

# ③ 运行时有没有加载
ls -l /proc/$(pgrep -x Editor)/maps | grep MyProject

# ④ 日志里有没有输出
grep MyProject ~/.o3de/Logs/O3DE.log
```

### 坑 19：`HeadlessServer` 并不是"无渲染"，无 GPU 时会卡死

**现象**：明明用的是 `HeadlessServerLauncher`（名字里带 Headless），却启动后卡住不动，
最后被 `timeout` 杀掉（exit 124）。日志尾部是一堆重复的：

```
[Error] (Serialize) - Element 'NULL'(0x41405e39) with class ID '{...}'
found in 'AZStd::intrusive_ptr<ShaderStageFunction>' is not registered with the serializer!
... File shaders/auxgeom/auxgeomobject_vulkan_0.azshadervariant
```

**根因**：`Headless` 只表示**不开窗口**，不代表**不初始化 RHI**。实测日志：

```
RHISystem: Initializing RHI...
RHISystem:      Enumerated physical device:       ← 空
RHISystem:      Using physical device:            ← 空
```

设备名为空 → 后续所有 `_vulkan_` shader 变体反序列化失败 →
主循环（进而 `OnTick`）永远不启动。

**怎么判断是这个问题**：

```bash
grep -E "Enumerated physical device|Using physical device" /tmp/hb.log
# 两行后面都是空的 → 就是它
```

| 处置 | 说明 |
|---|---|
| 换有 GPU 的机器 | 最直接 |
| 用**不启用 `Atom`** 的项目 | 完全不进 RHI，但也就没有渲染 |
| 保留 `Atom` 但改 `Atom_RHI_Null` | `Atom_RHI` 依赖 DX12/Metal/Vulkan/Null 四个后端，需改平台配置 |
| **只想验证逻辑** | 看到 `component activated` 就可停手——说明组件/EBus/反射都对 |

> 💡 **这条坑的价值**：它教你区分"我的代码错"和"环境不支持"。
> 判据里先出现 `component activated`（你的代码），后出现 `count`（需要主循环），
> 两者分离设计，就能一眼定位责任方。

## 14.3 系统化诊断工具箱

```mermaid
flowchart TD
  A["出问题"] --> B{"哪一类"}
  B -->|configure 失败| C["看 CMake Error 的 Call Stack<br/>最后一行指向哪个 .cmake"]
  B -->|编译失败| D["看 FAILED: 后面的命令<br/>分辨编译还是链接"]
  B -->|链接失败| E["grep 'undefined reference'<br/>符号问题还是库缺失"]
  B -->|运行时崩溃| F["gdb -batch -ex run -ex bt 25"]
  B -->|行为不对| G["先确认代码真被加载<br/>nm / /proc/maps / 日志"]
  C --> H["按 missing 关键词装包"]
  D --> I[".ddi→scan-deps<br/>-Werror→换 clang<br/>undefined→查可见性"]
  F --> J["看栈里最后一个第三方库名"]
```

### 最有用的 6 条命令

```bash
# 1. ninja 解释为什么重编
ninja -C <build> -d explain -n

# 2. 找出缺失依赖（一次一个，需迭代）
ninja -n <target> 2>&1 | grep -oE "'/[^']*', needed"

# 3. 统计构建树的路径耦合
grep -c "/workspaces" build.ninja

# 4. 检查产物依赖完整性
ldd <binary> | grep -c "not found"

# 5. 检查符号
nm -D --defined-only <lib.so> | grep -c EBus

# 6. 抓崩溃现场
gdb -batch -ex run -ex "bt 30" --args <binary> <args>
```

## 14.4 迁移构建树检查清单

1. **工具链逐字节一致**：OS + clang 版本 + cmake + ninja
2. 复刻 `CMAKE_HOME_DIRECTORY` / `CMAKE_CACHEFILE_DIR`（`build.ninja` 里 `/workspaces` 出现 **8260** 次）
3. 复刻 `$HOME/.o3de/Python/...`（**468** 处）
4. 补齐所有 `-dev` 软链到**系统路径**
5. 保留 **mtime**
6. 带上 `.ninja_deps` / `.ninja_log`
7. `touch build.ninja` 规避 RERUN_CMAKE
8. 检查 venv 哈希目录是否存在

**验证**：

```bash
ninja -n Editor     # → ninja: no work to do.
```

---

# 第十五部分 · 动手实验

> **🎓 贯穿 L1–L4 · 动手实验** ｜ 每个实验都标注了所属级别与是否需要编译 ｜ 建议：**每读完一级，做掉对应级别的实验** ｜ 进度表在章末

## 实验 0：摸清现状（5 分钟，无需编译）

```bash
# ① 引擎工具是否就绪
ls -1 /workspaces/o3de-build/bin/profile/ | grep -E "^(Editor|o3de|AssetProcessor|O3DE\.)" | grep -v "\.dbg"

# ② 引擎构建树是否干净
ninja -C /workspaces/o3de-build -n Editor

# ③ 项目注册了吗
cat ~/.o3de/o3de_manifest.json

# ④ 项目里有编译产物吗
ls /workspaces/MyProject/build 2>/dev/null || echo "尚未构建项目"
```

**预期**：

```
Editor
o3de
AssetProcessor
O3DE.HeadlessServerLauncher
O3DE.ServerLauncher
ninja: no work to do.
{ "engines": ["/workspaces/o3de"], "projects": ["/workspaces/MyProject"], ... }
尚未构建项目
```

## 实验 1：不带 GUI 跑一次项目（10 分钟）

```bash
cd /workspaces/o3de-build/bin/profile
timeout 40 ./O3DE.ServerLauncher --project-path=/workspaces/MyProject 2>&1 | head -40
```

**预期关键行**：

```
AssetCatalog: Loaded registry containing 3042 assets.
Launcher: Launched Asset Processor and received connection in 2.007959 seconds
AssetSystem: Ping time to asset processor: 1.24 milliseconds
```

## 实验 2：读懂 5 个源文件（30 分钟，纯阅读）

```bash
cd /workspaces/MyProject/Gem
cat Source/MyProjectModule.cpp              # ① 入口
cat Include/MyProject/MyProjectBus.h        # ② 接口声明
cat Include/MyProject/MyProjectTypeIds.h    # ③ 类型 ID
cat Source/MyProjectSystemComponent.h       # ④ 声明
cat Source/MyProjectSystemComponent.cpp     # ⑤ 实现
cat myproject_files.cmake                   # ⑥ 文件登记
cat myproject_shared_files.cmake
```

**回答这些问题**：

1. `AZ_DECLARE_MODULE_CLASS` 生成了什么函数名？引擎怎么找到它？
2. `m_descriptors` 里装的是什么？不加会怎样？
3. `GetRequiredSystemComponents()` 返回后，引擎做了什么？
4. `MyProjectInterface::Register(this)` 为什么在构造函数里？
5. 两个 `.cmake` 清单的区别是什么？

**自检**：能不看文档答出第 1 和第 5 题，就理解了核心机制。

## 实验 3：验证插件清单（15 分钟，纯阅读）

```bash
cd /workspaces/MyProject/build/linux/bin/profile/Registry 2>/dev/null || \
cd /workspaces/o3de-build/bin/profile/Registry

# 看不同目标加载不同 Gem
for f in cmake_dependencies.editor.setreg \
         cmake_dependencies.myproject.myproject_gamelauncher.setreg \
         cmake_dependencies.myproject.myproject_serverlauncher.setreg; do
  [ -f "$f" ] && echo "$f: $(python3 -c "import json;print(len(json.load(open('$f'))['O3DE']['Gems']))") Gem"
done
```

**预期**（实测）：

```
cmake_dependencies.editor.setreg: 39 Gem
cmake_dependencies.myproject.myproject_gamelauncher.setreg: 22 Gem
cmake_dependencies.myproject.myproject_serverlauncher.setreg: 22 Gem
```

**思考**：为什么 Editor 的 Gem 比 GameLauncher 多？

## 实验 4：加一个最小组件（**第一次编译**，含 3 小时等待）

### 步骤 1：头文件 `Gem/Include/MyProject/HelloComponent.h`

```cpp
#pragma once
#include <AzCore/Component/Component.h>

namespace MyProject
{
    class HelloComponent final : public AZ::Component
    {
    public:
        AZ_COMPONENT_DECL(HelloComponent);
        static void Reflect(AZ::ReflectContext* context);
        static void GetProvidedServices(AZ::ComponentDescriptor::DependencyArrayType&);
        static void GetIncompatibleServices(AZ::ComponentDescriptor::DependencyArrayType&);
        static void GetRequiredServices(AZ::ComponentDescriptor::DependencyArrayType&);
        static void GetDependentServices(AZ::ComponentDescriptor::DependencyArrayType&);
        HelloComponent() = default;
        ~HelloComponent() override = default;
    protected:
        void Activate() override;
        void Deactivate() override;
    };
}
```

### 步骤 2：实现 `Gem/Source/HelloComponent.cpp`

```cpp
#include "HelloComponent.h"
#include <AzCore/Serialization/SerializeContext.h>
#include <AzCore/Serialization/EditContext.h>

namespace MyProject
{
    AZ_COMPONENT_IMPL(HelloComponent, "HelloComponent",
        "{C0FFEE00-0001-4000-8000-000000000001}");

    void HelloComponent::Reflect(AZ::ReflectContext* context)
    {
        if (auto* sc = azrtti_cast<AZ::SerializeContext*>(context))
        {
            sc->Class<HelloComponent, AZ::Component>()->Version(1);
            if (AZ::EditContext* ec = sc->GetEditContext())
            {
                ec->Class<HelloComponent>("Hello", "打印一句问候")
                    ->ClassElement(AZ::Edit::ClassElements::EditorData, "")
                        ->Attribute(AZ::Edit::Attributes::Category, "MyProject")
                        ->Attribute(AZ::Edit::Attributes::AppearsInAddComponentMenu, AZ_CRC_CE("Game"));
            }
        }
    }

    void HelloComponent::GetProvidedServices(AZ::ComponentDescriptor::DependencyArrayType& p)     { AZ_UNUSED(p); }
    void HelloComponent::GetIncompatibleServices(AZ::ComponentDescriptor::DependencyArrayType& i) { AZ_UNUSED(i); }
    void HelloComponent::GetRequiredServices(AZ::ComponentDescriptor::DependencyArrayType& r)     { AZ_UNUSED(r); }
    void HelloComponent::GetDependentServices(AZ::ComponentDescriptor::DependencyArrayType& d)    { AZ_UNUSED(d); }

    void HelloComponent::Activate()
    {
        AZ_Printf("MyProject", "HelloComponent activated on entity %s",
            GetEntityId().ToString().c_str());
    }
    void HelloComponent::Deactivate()
    {
        AZ_Printf("MyProject", "HelloComponent deactivated");
    }
}
```

### 步骤 3：登记（⚠️ 必做）

`Gem/myproject_files.cmake`：

```cmake
set(FILES
    Include/MyProject/MyProjectBus.h
    Include/MyProject/MyProjectTypeIds.h
    Include/MyProject/HelloComponent.h          # ← 加
    Source/MyProjectSystemComponent.cpp
    Source/MyProjectSystemComponent.h
    Source/HelloComponent.cpp                   # ← 加
)
```

### 步骤 4：注册（⚠️ 必做）

`Gem/Source/MyProjectModule.cpp`：

```cpp
#include "HelloComponent.h"                      // ← 加
// ...
            m_descriptors.insert(m_descriptors.end(), {
                MyProjectSystemComponent::CreateDescriptor(),
                HelloComponent::CreateDescriptor(),      // ← 加
            });
```

### 步骤 5：编译

```bash
cmake -B /workspaces/MyProject/build/linux -S /workspaces/MyProject -G Ninja \
  -DCMAKE_BUILD_TYPE=Profile -DLY_3RDPARTY_PATH=/workspaces/o3de-packages

# 先只编你的 Gem —— 最快的验证方式
ninja -C /workspaces/MyProject/build/linux -j3 Gem::MyProject
```

**验证**：

```bash
nm -D --defined-only .../libMyProject.so | grep -iE "Hello|CreateModuleClass"
```

## 实验 5：用 `AZ::Interface` 打通一次调用

### 步骤 1：`MyProjectBus.h` 加方法

```cpp
class MyProjectRequests
{
public:
    AZ_RTTI(MyProjectRequests, MyProjectRequestsTypeId);
    virtual ~MyProjectRequests() = default;
    virtual void PrintHello(const char* who) = 0;      // ← 加
};
```

### 步骤 2：`MyProjectSystemComponent.h` 加声明

```cpp
    protected:
        void PrintHello(const char* who) override;
```

### 步骤 3：`MyProjectSystemComponent.cpp` 加实现

```cpp
void MyProjectSystemComponent::PrintHello(const char* who)
{
    AZ_Printf("MyProject", "Hello, %s!", who);
}
```

### 步骤 4：在 Activate 里调用（闭环验证）

```cpp
void MyProjectSystemComponent::Activate()
{
    MyProjectRequestBus::Handler::BusConnect();
    if (auto* iface = MyProjectInterface::Get())
        iface->PrintHello("via Interface");
    MyProjectRequestBus::Broadcast(&MyProjectRequests::PrintHello, "via EBus");
}
```

**预期输出**：

```
MyProject: Hello, via Interface!
MyProject: Hello, via EBus!
```

**思考**：两种方式调的是**同一个实现**。这就是为什么官方说"单例场景别用 EBus"。

## 实验 6：给组件加可编辑属性

```cpp
private:
    AZStd::string m_greeting = "Hello";
```

`Reflect` 里：

```cpp
sc->Class<HelloComponent, AZ::Component>()
    ->Version(1)
    ->Field("Greeting", &HelloComponent::m_greeting);   // ← 存盘

if (AZ::EditContext* ec = sc->GetEditContext())
{
    ec->Class<HelloComponent>("Hello", "...")
        ->DataElement(AZ::Edit::UIHandlers::Default,
            &HelloComponent::m_greeting, "问候语", "...");   // ← 面板
}
```

### 验证分工

| 删掉哪部分 | 后果 |
|---|---|
| `->Field(...)` | 面板能改，但存盘丢失 |
| `EditContext` 整段 | 能存盘，但面板看不到 |
| 两者都删 | 字段完全不存在于反射系统 |

## 实验 7：读构建产物（20 分钟）

```bash
cd /workspaces/o3de-build/bin/profile

# 核心框架体积排序
ls -lhS libAz*.so libEditor*.so 2>/dev/null | head

# 你的 Gem 依赖
ldd /workspaces/MyProject/build/linux/bin/profile/libMyProject.so 2>/dev/null | head -20

# 模块加载清单
grep "Attempting to load module" /tmp/ed.log 2>/dev/null | sed 's|.*/||' | sort | head -30
```

**预期**：

| 项 | 值 |
|---|---|
| `libAzToolsFramework.so` | 47 MB（最大） |
| `libAzFramework.so` | 36 MB |
| `libAzCore.so` | 25 MB |
| `libAzQtComponents.so` | 3.2 MB |

**思考**：为什么 `Editor` 只有 21 KB，而 `libEditorLib.so` 有 32 MB？

## 实验 8：改一行引擎代码，观察增量

```bash
# ① 确认干净
ninja -C /workspaces/o3de-build -n Editor          # → no work to do

# ② 改一行注释
F=/workspaces/o3de/Code/Framework/AzCore/AzCore/Math/Vector3.cpp
cp $F /tmp/Vector3.bak
echo "// test" >> $F

# ③ 看影响范围
ninja -C /workspaces/o3de-build -n AzCore | grep -c "^\["     # → 2

# ④ 实际编译
time ninja -C /workspaces/o3de-build -j3 AzCore               # → 约 1 分 09 秒

# ⑤ 看下游影响
ninja -C /workspaces/o3de-build -n Editor | wc -l             # → 87

# ⑥ 还原
cp /tmp/Vector3.bak $F
ninja -C /workspaces/o3de-build -j3 Editor                    # → 约 2 分 54 秒
```

**记录这三组数字，它们决定你的迭代节奏。**

## 实验 9（L4）：把 EBus 的模板特化表挖出来

**目标**：不读文章，自己从源码里找出"4 种 policy 组合 → 4 种数据结构"的对应关系。

```bash
AZCORE=/workspaces/o3de/Code/Framework/AzCore/AzCore

# ① 入口：BusImpl 怎么把 Traits 变成容器类型？
grep -n "BusesContainer" $AZCORE/EBus/BusImpl.h
#   → 157: using BusesContainer = AZ::Internal::EBusContainer<Interface, Traits>;

# ② 顺着找到所有特化
grep -n "^        struct EBusContainer<" $AZCORE/EBus/Internal/BusContainer.h
#   → 766 / 1308 / 1504   （加上 85 行的主模板，共 4 个）

# ③ 存储策略另在一个文件
grep -n "struct AddressStoragePolicy<\|struct HandlerStoragePolicy<" \
     $AZCORE/EBus/Internal/StoragePolicies.h
#   → 33 / 96 / 152 / 168
```

**要交出的答案**（自己填，别先看第十六部分的表）：

| AddressPolicy | HandlerPolicy | 地址容器 | handler 容器 |
|---|---|---|---|
| `Single` | `Single` | ? | ? |
| `Single` | `Multiple` | ? | ? |
| `ById` | `Single` | ? | ? |
| `ById` | `Multiple` | ? | ? |

**验证方法**：在 `BusContainer.h` 里搜 `// No need for` 和 `HandlerNode =`。

```bash
grep -n "// No need for\|using HandlerNode\s*=" $AZCORE/EBus/Internal/BusContainer.h
```

**思考**：如果 `Single + Single` 的 `HandlerNode` 只是一个裸指针，那么从 `Connect()` 到实际调用，一共发生了几次内存分配？（答案：**0 次**，第十六部分 16.4 有推导）

## 实验 10（L4）：用编译器证明"零成本"

**目标**：不看文档，让编译器告诉你模板特化后到底生成了什么。

```bash
cat > /tmp/ebus_probe.cpp <<'EOF'
#include <AzCore/EBus/EBus.h>

// 最省的一种：单地址 + 单 handler
class ProbeRequests : public AZ::EBusTraits {
public:
    static constexpr AZ::EBusAddressPolicy AddressPolicy = AZ::EBusAddressPolicy::Single;
    static constexpr AZ::EBusHandlerPolicy HandlerPolicy = AZ::EBusHandlerPolicy::Single;
    virtual void Ping() = 0;
    virtual ~ProbeRequests() = default;
};
using ProbeBus = AZ::EBus<ProbeRequests>;

// 最贵的一种：按 id 寻址 + 多 handler
class Probe2Requests : public AZ::EBusTraits {
public:
    static constexpr AZ::EBusAddressPolicy AddressPolicy = AZ::EBusAddressPolicy::ById;
    static constexpr AZ::EBusHandlerPolicy HandlerPolicy = AZ::EBusHandlerPolicy::Multiple;
    using BusIdType = unsigned int;
    virtual void Ping() = 0;
    virtual ~Probe2Requests() = default;
};
using Probe2Bus = AZ::EBus<Probe2Requests>;

// 把两种 Context 的大小打印成编译期常量
static_assert(sizeof(ProbeBus::Context) > 0, "");
template<int N> struct Show;
Show<sizeof(ProbeBus::Context)>  show_single;      // 让编译器在报错里报出数字
Show<sizeof(Probe2Bus::Context)> show_multi;
EOF

clang++-18 -std=c++17 -fsyntax-only \
  -I/workspaces/o3de/Code/Framework/AzCore \
  -I/workspaces/o3de/Code/Framework/AzCore/Platform/Linux \
  /tmp/ebus_probe.cpp 2>&1 | grep -E "Show<|incomplete"
```

**这个技巧叫 "template error printing"** —— 没有运行时代码，纯靠类型系统把数字逼出来。编译器会报类似：

```
error: implicit instantiation of undefined template 'Show<112>'
error: implicit instantiation of undefined template 'Show<192>'
```

**比较两个数字**，思考差在哪（提示：`hash_table` 有 `min_buckets = 7`）。

> 如果编译报找不到 `AzCore/base.h` 之类，说明 include 路径不全。改用项目的 compdb 更省事：
> 从 `compile_commands.json` 里抄一条 `command`，把末尾的 `-c xxx.cpp` 换成你的探针文件。

## 练习进度表

| # | 实验 | 耗时 | 需编译 | 所属级别 | 完成 |
|---|---|---|---|---|---|
| 0 | 摸清现状 | 5 min | ❌ | L0 | ☐ |
| 1 | 无 GUI 跑项目 | 10 min | ❌ | L1 | ☐ |
| 2 | 读 5 个源文件 | 30 min | ❌ | L0 | ☐ |
| 3 | 验证插件清单 | 15 min | ❌ | L1 | ☐ |
| 4 | 加最小组件 | **3 h** | ✅ | L2 | ☐ |
| 5 | Interface 调用 | 20 min | ✅ | L2 | ☐ |
| 6 | 可编辑属性 | 20 min | ✅ | L2 | ☐ |
| 7 | 读构建产物 | 20 min | ❌ | L1 | ☐ |
| 8 | 增量编译体验 | 10 min | ❌ | L2 | ☐ |
| 9 | 挖 EBus 特化表 | 40 min | ❌ | **L4** | ☐ |
| 10 | 证明零成本 | 30 min | ❌ | **L4** | ☐ |

**不编译也能完成 0/1/2/3/7/8/9/10 —— 先做完这 8 个，再决定要不要投入 3 小时。**

---

# 第十六部分 · 深挖：策略驱动的零成本抽象

> **🎓 L4 · 读源码 ★核心（本章为 L4 的入口）** ｜ 前置：第二部分 + 第八部分 + **写过能跑的 Gem** ｜ 读完能做什么：独立走读任意引擎模块 ｜ 下一站 → 第十二 / 十三部分

> **本章属于 L4。** 前置：读完第二部分（九条原则）、第八部分（EBus 用法），并且**写过至少一个能跑的 Gem**。
>
> 这一章要回答一个具体问题：**O3DE 说它的 EBus 是"零成本抽象"，凭什么？**
> 不是靠"我们优化过"，而是靠**编译期把用不到的东西全部删掉**。
> 读完你应该能在不看文档的情况下，说出任意一组 policy 会生成什么数据结构。

## 16.1 先讲方法：O3DE 源码该怎么读

大多数人读引擎源码失败，是因为**从第一个文件开始读**。O3DE 的 `AzCore` 有 873 个头文件，这样读三个月也读不完。

正确的读法是**带着一个能验证的假设，顺着类型定义往下钻**。本章就是完整示范：

```mermaid
graph LR
    Q["问题：<br/>一个 Connect() 到底<br/>操作了什么容器？"]
    S1["① grep 定位<br/>BusImpl.h 的<br/>BusesContainer"]
    Q --> S1
    S1 --> S2["② 顺到模板特化<br/>BusContainer.h<br/>4 个特化"]
    S2 --> S3["③ 看存储策略<br/>StoragePolicies.h<br/>4 个特化"]
    S3 --> S4["④ 找到实体类型<br/>intrusive_list /<br/>hash_table / 裸指针"]
    S4 --> A["答案：<br/>policy 组合决定<br/>数据结构"]

    style Q fill:#ffe6cc
    style A fill:#d5e8d4
```

**四条实用技巧：**

| 技巧 | 用法 | 为什么有效 |
|---|---|---|
| **从 `using` 入手** | `grep -n "using .*Container"` | O3DE 大量用别名把实现藏起来，别名就是入口 |
| **数特化** | `grep -n "struct X<"` 找 `<` 后带参数的 | 主模板 + N 个特化 = N+1 种行为，一眼看全 |
| **看注释里的 "No need"** | `grep -n "// No need for"` | O3DE 作者会标注"这里为什么不需要某物"，这是设计意图的直接证据 |
| **靠 `static_assert` 逼数字** | 实验 10 的模板报错技巧 | 模板参数会出现在错误信息里，等于免费的类型级 `printf` |

**反模式**（新手最常犯）：

- ❌ 从 `AzCore/base.h` 开始往下读 —— 那是工具头文件，不含设计
- ❌ 读 `.cpp` 而不读 `.h` —— O3DE 的设计几乎全在头文件里的模板
- ❌ 试图理解每个宏 —— `AZ_CLASS_ALLOCATOR` / `AZ_RTTI` 展开后几百行，先当黑盒
- ❌ 在 IDE 里 `Go to Definition` 跳到 `azstd/` 深处 —— 那是自研 STL，和设计无关

## 16.2 EBus 的 8 个编译期维度

第二部分 2.4 列过 EBus 的 8 个 policy 维度。先回顾一下它们各自影响什么：

| # | policy | 取值 | 影响 |
|---|---|---|---|
| 1 | `AddressPolicy` | `Single` / `ById` / `ByIdAndOrdered` | **有几个地址** → 要不要地址容器 |
| 2 | `HandlerPolicy` | `Single` / `Multiple` / `MultipleAndOrdered` | **每个地址挂几个 handler** → 用什么容器 |
| 3 | `BusIdType` | 任意可哈希类型 | 地址容器的 key 类型 |
| 4 | `ConnectionPolicy` | `Direct` / `Custom` | `Connect()` 返回什么 |
| 5 | `MutationPolicy` | `Eventual` / `Custom` | 遍历中增删 handler 的行为 |
| 6 | `StoragePolicy` | `ThreadLocal` / `Global` | Context 存在哪 |
| 7 | `EventQueuePolicy` | `Queue` / `QueueAndNotify` | 能否 `QueueEvent` |
| 8 | `EventProcessingPolicy` | `Call` / `Custom` | 最终怎么调用 handler |

关键洞察：**只有前两个维度会改变数据结构**。3–8 改变的是"行为"（加不加锁、能不能排队、调用时遍历还是直调），而不是"布局"。

所以模板特化的数量不是 $3 \times 3 = 9$，而是 **4 个**——因为有些组合在 `EBusTraits` 层面就被 `static_assert` 禁掉了（例如 `ByIdAndOrdered` + `Single` 毫无意义：一个地址只挂一个 handler，有序给谁看）。

## 16.3 四个特化，四种布局

`BusContainer.h`（1630 行）里只有 4 个 `EBusContainer` 定义：

```cpp
// ① 主模板（第 85 行）—— 默认实现，处理「多地址 + 多 handler」及大部分变体
template <typename Interface, typename Traits,
          EBusAddressPolicy addressPolicy = Traits::AddressPolicy,
          EBusHandlerPolicy handlerPolicy = Traits::HandlerPolicy>
struct EBusContainer { /* hash_table 或 ordered_map + intrusive_list */ };

// ② 第 766 行 —— 多地址 + 单 handler
struct EBusContainer<Interface, Traits, addressPolicy, EBusHandlerPolicy::Single>
{ ... };

// ③ 第 1308 行 —— 单地址 + 多 handler
struct EBusContainer<Interface, Traits, EBusAddressPolicy::Single, handlerPolicy>
{ ... };

// ④ 第 1504 行 —— 单地址 + 单 handler
struct EBusContainer<Interface, Traits, EBusAddressPolicy::Single, EBusHandlerPolicy::Single>
{ ... };
```

注意特化的写法：**②只固定 handlerPolicy，③只固定 addressPolicy**。这是 C++ 偏特化的技巧——比 full specialization 覆盖更多组合，又不需要写 4 个完整特化。编译器按"最特殊匹配"规则选：④ 比 ②③ 更特殊，所以 `Single+Single` 命中 ④。

### 布局对照表（源码实证）

| AddressPolicy | HandlerPolicy | 地址容器 | handler 容器 | `HandlerNode` 实体类型 |
|---|---|---|---|---|
| `Single` | `Single` | **无** | **无** | `Interface*`（裸指针） |
| `Single` | `Multiple` | **无** | `intrusive_list` | `HandlerNode<...>` |
| `ById` | `Single` | `hash_table` | **无** | `Interface*` |
| `ById` | `Multiple` | `hash_table` | `intrusive_list` | `HandlerNode<...>` |
| `ByIdAndOrdered` | `MultipleAndOrdered` | `ordered` 容器 | `intrusive_multiset` | 含 `intrusive_multiset_node` |

源码依据：

```cpp
// BusContainer.h:1322  ← ③ 单地址多 handler
// No need for AddressStorage, there's only 1

// BusContainer.h:1519  ← ④ 单地址单 handler
// Handlers can just be stored as raw pointer
// Needs to be public for ConnectionPolicy
using HandlerNode = Interface*;
// No need for AddressStorage, there's only 1
// No need for HandlerStorage, there's only 1
```

**「No need for …」这两行注释是整章的核心。** 它不是"我们省了点内存"，而是**这个成员变量在特化后根本不存在**——没有指针字段，没有条件分支，没有 `if (handlerPolicy == Single)` 的运行时判断。

## 16.4 推导：从 Connect() 到零分配

拿最省的 `Single + Single` 走一遍。这是 O3DE 里最常见的单例型接口（例如 `AZ::Interface<T>` 的底层近似形态）。

### 第一步：Connect() 做了什么

`BusImpl.h` 的 `Handler` / 连接逻辑里，`Single+Single` 特化下 `HandlerNode` 就是 `Interface*`，所以连接 = **往一个指针变量写地址**：

```cpp
// 简化示意（BusContainer.h:1504 特化内）
// m_handler 的类型就是 Interface*
m_handler = handlerPtr;      // ← 一次指针赋值，无分配
```

对比 `Multiple` 特化（`StoragePolicies.h:152`）：

```cpp
struct StorageType
    : public AZStd::intrusive_list<Handler, AZStd::list_base_hook<Handler>>
{
    void insert(Handler& elem) { base_type::push_front(elem); }
};
```

`intrusive_list` 的 `push_front` **不分配内存**——节点内存由 handler 对象自己携带（`Handler` 继承 `intrusive_list_node`）。所以 `Multiple` 也是零分配，只是多了一次链表指针改写。

**这就是 "intrusive" 的意义**：容器不拥有节点，节点内嵌在对象里。代价是"一个 handler 只能同时属于一个 intrusive 容器"。O3DE 敢这么做，是因为一个 handler 本来就只挂在一个 bus 上。

### 第二步：Broadcast() 做了什么

```cpp
// BusContainer.h:1536 附近，④ 特化的 Dispatcher::Broadcast
template <typename Function, typename... ArgsT>
static void Broadcast(Function&& func, ArgsT&&... args)
{
    if (auto* context = Bus::GetContext())
    {
        typename Bus::Context::DispatchLockGuard lock(context->m_contextMutex);
        EBUS_DO_ROUTING(*context, nullptr, false, false);

        auto handler = context->m_buses.m_handler;   // ← 一次指针读取
        if (handler)                                  // ← 一次判空
        {
            CallstackEntry entry(context, nullptr);
            Traits::EventProcessingPolicy::Call(AZStd::forward<Function>(func),
                                                handler,   // ← 直接传指针
                                                AZStd::forward<ArgsT>(args)...);
        }
    }
}
```

**没有循环。** 没有 `begin()/end()`。没有迭代器解引用。没有虚函数分派去找"下一个 handler"。

对比 `Multiple` 版本（第 1308 行特化）就必须：

```cpp
for (auto it = begin; it != end; ++it)     // ← 链表遍历
{
    ...Call(func, node.handler, args...);
}
```

而 `ById` 版本还要先 `m_addresses.find(busId)`（哈希查找）才能拿到 handler 集合。

### 第三步：调用本身

```cpp
Traits::EventProcessingPolicy::Call(...)
```

`EventProcessingPolicy` 默认是 `EBusEventProcessingPolicy`，它的 `Call` 就是 `func(handler, args...)`。`handler` 是 `Interface*`，`func` 通常是 lambda 里 `handler->OnFoo(...)`——**一次虚函数调用**。

所以完整链路：

```mermaid
graph LR
    A["Broadcast()"] --> B["读 m_handler<br/>(1 次 load)"]
    B --> C["判空<br/>(1 次 test)"]
    C --> D["Call()<br/>(inline)"]
    D --> E["handler->OnFoo()<br/>(1 次 vcall)"]

    style E fill:#d5e8d4
```

**开销 = 1 次间接调用。** 这就是"零成本"的实际含义——**和手写一个全局指针 + 虚函数调用完全等价**，抽象层没有额外代价。

### 隐形开销：调试期计数器

`CallstackEntry`（`Internal/CallstackEntry.h:61`）在构造时做两件事：

```cpp
m_threadId = AZStd::this_thread::get_id().m_id;
if (!this->m_prev || static_cast<CallstackEntry*>(this->m_prev)->m_threadId == m_threadId)
{
    m_context->s_callstack->m_prev = this;
    m_context->m_dispatches++;        // ← 统计分派次数
}
else
{
    AZ::Debug::Trace::Instance().Assert(...,
        "Bus %s has multiple threads in its callstack records. "
        "Configure MutexType on the bus, or don't send to it from multiple threads", ...);
}
```

这是 O3DE 的一个精巧设计：

- **成本**：一次 `this_thread::get_id()` + 一次比较 + 一次自增。release 下 `get_id()` 通常就是读 TLS 里的一个整数
- **收益**：能检测出"你没配 MutexType 却多线程用同一个 bus"，编译期查不出来的 bug
- **为什么用 `if` 而不是 `AZ_Assert`**：源码注释写得很清楚——

  > `We don't use the AZ_Assert macro here because it places the assert call (unlikely) before the actual work to do (likely) which results in inlining shenanigans and icache misses.`

  即：`AZ_Assert` 宏把"罕见分支"放在前面，会让编译器把热路径排到后面，破坏 i-cache 局部性。所以这里手写了 `if (likely) ... else Assert(...)`。

**这段注释本身就是教材**：性能优化到极致时，连"错误分支在代码里的物理位置"都要管。

## 16.5 反事实：如果不用 policy 会怎样

要理解"策略驱动"的价值，最好的方法是看**别的写法会付出什么**。

### 方案 A：虚函数 + 运行时枚举

```cpp
// 假想设计
class BusContext {
public:
    enum class AddressPolicy { Single, ById, ByIdAndOrdered };
    enum class HandlerPolicy { Single, Multiple, MultipleAndOrdered };

    void Broadcast() {
        if (m_addrPolicy == AddressPolicy::Single) {
            if (m_handlerPolicy == HandlerPolicy::Single) {
                if (m_handler) m_handler->Call();
            } else {
                for (auto* h : m_handlers) h->Call();
            }
        } else {
            // ... 再加两层 if
        }
    }

private:
    AddressPolicy m_addrPolicy;
    HandlerPolicy m_handlerPolicy;
    void* m_handler;                    // ← 永远占 8 字节
    std::vector<void*> m_handlers;      // ← 永远占 24 字节
    std::unordered_map<Id, std::vector<void*>> m_addresses;  // ← 永远占 56 字节
};
```

代价：

| 项 | 后果 |
|---|---|
| **内存** | `Single+Single` 的 bus 要 88+ 字节，其中 80 字节永远用不到 |
| **分支** | 每次 `Broadcast` 至少 2 次不可预测的条件跳转（几百 ns 的误预测惩罚） |
| **内联** | 编译器看不到具体调用，`Call()` 无法内联进 `Broadcast()` |
| **类型安全** | `void*` 全丢，取回来要 `static_cast`，写错了运行时炸 |

在 O3DE 这种"一次场景里几千个 bus、每帧几万次分派"的场景下，这 2 次分支的累积就是**每秒几百万次误预测**。

### 方案 B：模板 + `std::function`

```cpp
template<typename HandlerPolicy>
class BusContext {
    std::vector<std::function<void()>> m_handlers;   // Single 也用 vector
};
```

代价：

| 项 | 后果 |
|---|---|
| **`std::function` 的间接层** | 每个 handler 一次类型擦除调用，比裸虚函数多一跳 |
| **`std::vector` 堆分配** | 每个 bus 至少一次堆分配，即使只有 1 个 handler |
| **无法表达 intrusive** | 连接时还要 `new` 一个包装对象 |

### 方案 C：O3DE 的选择

| 手段 | 效果 |
|---|---|
| **policy 做模板参数** | 编译期确定，零运行时存储 |
| **偏特化而非 `if`** | 分支在编译期消失 |
| **`intrusive_list`** | 容器零分配，节点内嵌 |
| **`static constexpr bool HasId`** | 让 `BusIdType` 相关代码整体消失（见 16.6） |
| **`EBUS_DO_ROUTING` 宏** | 路由表为空时只做一次 `size()` 判断，且可被内联消除 |

结果就是 16.4 推导出的"1 次间接调用"。

## 16.6 `if constexpr`：让整个成员函数消失

另一种"零成本"手法：**用编译期条件让函数体为空**。

`BusImpl.h:189`：

```cpp
static constexpr bool HasId = Traits::AddressPolicy != EBusAddressPolicy::Single;
```

这个常量在 `BusImpl` 里被用来控制一批 API 的存在性（源码注释明确写了 `Used only when the address policy is AZ::EBusAddressPolicy::ById or ByIdAndOrdered`）。典型用法：

```cpp
// 假想的简化版（O3DE 里分散在多处）
template<typename Id>
static void Event(Id id) {
    if constexpr (HasId) {
        // 只有 ById 系列才会实例化这段代码
        Bus::GetContext()->m_buses.m_addresses.find(id) ...
    } else {
        // Single 系列：id 参数被完全忽略，这段代码编译后不存在
        Bus::Broadcast(...);
    }
}
```

关键点：**`if constexpr` 的分支如果条件为假，那个分支根本不会被实例化**。所以 `Single` 版本的 bus 不会有任何 `hash_table::find` 的代码，连符号都不会生成。

对比 `if`：

```cpp
if (HasId) { ... }   // 条件为假，但代码仍要编译、仍占 .text、仍被优化器挣扎
```

优化器通常能消掉，但**不保证**——只要 `find` 有明显的副作用（比如 `EBUS_ASSERT` 里的 `Trace::Assert`），优化器就必须保留。

**这是 `if constexpr` 比 `if` 强的地方：不是"优化成没有"，而是"从来不生成"。**

### 配合 `HasRegisterHandler`

`BusImpl.h` 还有 `HasRegisterHandler` 等一批 `static constexpr bool`，模式完全一致：把 policy 映射成布尔，再用 `if constexpr` 控制代码生成。

**记住这个模式**，你在 O3DE 里会反复看到它：

```mermaid
graph LR
    P["policy 枚举<br/>(编译期常量)"] --> B["static constexpr bool<br/>HasXxx"]
    B --> C["if constexpr<br/>控制代码生成"]
    C --> D["不同的实例化<br/>= 不同的二进制"]
    B --> E["模板偏特化<br/>控制数据结构"]
    E --> D

    style P fill:#ffe6cc
    style D fill:#d5e8d4
```

## 16.7 三套反射上下文：为什么不能合并

EBus 之外，O3DE 另一个大量使用"分层抽象"的地方是**反射系统**。`AzCore` 里有三个 `*Context`，新手最容易搞不清。

### 三者的关系（源码实证）

```cpp
// SerializeContext.h:125
class AZCORE_API SerializeContext : public ReflectContext { ... };

// BehaviorContext.h:1275
class AZCORE_API BehaviorContext : public ReflectContext { ... };

// EditContext.h:188  ← 注意：不继承 ReflectContext！
class AZCORE_API EditContext
{
public:
    /**
     * EditContext uses serialize context to interact with data, so serialize context is
     * required.
     */
    EditContext(SerializeContext& serializeContext);
    ...
};
```

**这三个的类型关系不对称**，这是理解全局的关键：

```mermaid
graph TD
    RC["ReflectContext<br/>(抽象基类)"]
    SC["SerializeContext<br/>序列化 / 持久化"]
    BC["BehaviorContext<br/>脚本绑定 / 反射调用"]
    EC["EditContext<br/>编辑器元数据<br/>⚠️ 不继承 ReflectContext"]
    RC --> SC
    RC --> BC
    SC -.->|"被包装<br/>(持有引用)"| EC

    style SC fill:#d4e9f2
    style BC fill:#d4e9f2
    style EC fill:#ffe6cc
```

### 各自解决什么问题

| Context | 解决什么 | 典型用法 | 数据形态 |
|---|---|---|---|
| **SerializeContext** | 对象**存盘 / 读盘 / 版本迁移** | `builder->Class<MyComp>()->Field("m_speed", &MyComp::m_speed);` | 字节流 / JSON |
| **EditContext** | 对象**在编辑器里怎么显示** | `->DataElement(...)->Attribute(AZ::Edit::Attributes::Min, &MinSpeed);` | UI 描述（不产生数据） |
| **BehaviorContext** | 对象**怎么被脚本 / 反射调用** | `->Method("GetSpeed", &MyComp::GetSpeed);` | 可调用的元信息 |

### 为什么 EditContext 不继承 ReflectContext

这是整章最值得琢磨的一处设计。看 `EditContext` 的构造函数签名：

```cpp
EditContext(SerializeContext& serializeContext);
```

**它必须拿着一个已存在的 `SerializeContext&` 才能构造。** 原因写在同一处注释里：

> `EditContext uses serialize context to interact with data, so serialize context is required.`

即：`EditContext` 本身**不存储类型信息**。你写 `->DataElement("Speed", &MyComp::m_speed, "速度")` 时，"`MyComp` 有个成员叫 `m_speed`、偏移多少"这件事已经由 `SerializeContext` 记着了；`EditContext` 只是**往那条记录上挂标签**（"最小值 0、最大值 100、显示名'速度'"）。

所以要理解成：

```mermaid
graph LR
    subgraph SC["SerializeContext（唯一的数据源）"]
        T["ClassData for MyComp<br/>─────────────<br/>m_speed @ offset 0x10<br/>m_name  @ offset 0x18"]
    end
    subgraph EC["EditContext（一堆标签）"]
        A1["m_speed: Min=0, Max=100"]
        A2["m_name: MaxLength=32"]
    end
    EC -.->|"按 (类型, 字段) 挂到"| T

    style SC fill:#d5e8d4
    style EC fill:#ffe6cc
```

**如果 `EditContext` 继承 `ReflectContext`**，它会倾向于自己保存一份类型信息 → 两份数据 → 必然不同步。O3DE 用"包装 + 强制引用"从**类型系统层面**禁止了这种可能。

### 与 `Reflect()` 的关系

现在回头看组件里那段每次都写但很多人没细想的代码：

```cpp
void MyComponent::Reflect(AZ::ReflectContext* context)
{
    if (auto* serializeContext = azrtti_cast<AZ::SerializeContext*>(context))
    {
        serializeContext->Class<MyComponent, AZ::Component>()
            ->Field("Speed", &MyComponent::m_speed);

        // 关键：在 SerializeContext 里面再建 EditContext
        if (auto* editContext = serializeContext->GetEditContext())
        {
            editContext->Class<MyComponent>("My Component", "说明")
                ->DataElement(AZ::Edit::UIHandlers::Default, &MyComponent::m_speed, "速度", "");
        }
    }
    else if (auto* behaviorContext = azrtti_cast<AZ::BehaviorContext*>(context))
    {
        behaviorContext->Class<MyComponent>("MyComponent")
            ->Method("GetSpeed", &MyComponent::GetSpeed);
    }
}
```

`serializeContext->GetEditContext()` 这个方法的存在，就是"EditContext 依附于 SerializeContext"的直接证据。

**注意 `azrtti_cast` 的三个分支不是互斥的**：同一个 `Reflect()` 会被调用三次，每次传不同的 context，每次只走一个分支。这就是为什么必须写 `if / else if` 而不是无条件执行——你在第四部分 4.4 看到的"反射阶段"就是这个。

### 三者对比：为什么不全塞进一个

| 如果合并成一个 Context | 会发生什么 |
|---|---|
| 序列化时能访问 UI 元数据 | 运行时不需要 UI 知识 → 白白把 `AzToolsFramework` 拖进 runtime 二进制 |
| 脚本绑定时能访问字段偏移 | 偏移是 ABI 相关的，脚本层需要稳定接口 → 混在一起会让 ABI 变化传导到脚本 |
| 编辑器里能访问脚本元信息 | 编辑器需要脚本信息（是的），但脚本层不需要编辑器信息 → **依赖方向单一化** |

第三条最重要：**分开的结果是依赖方向可以单向流动**（Edit → Serialize，Behavior 独立），而不是三者互相依赖。这直接对应第二部分 2.7 的"依赖倒置"原则。

## 16.8 本章的自检清单

读完这一章，你应该能回答：

- [ ] `Single + Single` 的 EBus，其 `HandlerNode` 类型是什么？为什么这样设计？
- [ ] `intrusive_list` 相比 `std::list` 省了什么？代价是什么？
- [ ] 为什么 `EBusContainer` 只有 4 个特化而不是 9 个？
- [ ] `if constexpr` 和 `if` 在"消除代码"这件事上的本质区别是什么？
- [ ] `EditContext` 为什么不继承 `ReflectContext`？它的构造函数为什么必须接收 `SerializeContext&`？
- [ ] `CallstackEntry` 在热路径上加了什么开销？作者为什么不用 `AZ_Assert`？
- [ ] `EBUS_DO_ROUTING` 宏在没有 router 时开销是多少？

**如果某一题答不上来**，回到对应小节，用 16.1 的四条技巧去源码里找答案。**不要背结论——结论会过时，方法不会。**

## 16.9 下一步往哪走

本章示范了"读一处实现"的完整方法。可以继续用同样的方法钻这些地方：

| 想深入 | 起点（文件:行） | 用哪条技巧 |
|---|---|---|
| 分配器链怎么组合 | `AzCore/Memory/AllocatorBase.h` + `IAllocator.h` | 看 `using` 别名链 |
| 类型擦除后怎么查回原类型 | `AzCore/RTTI/AzStdTypeInfo.h` | 数特化 |
| Settings Registry 的合并优先级 | `AzCore/Settings/SettingsRegistryImpl.cpp` | 找 `Merge` 的递归 |
| 组件怎么被自动发现 | `AzCore/Component/ComponentApplication.cpp` | 找 `static_assert` |
| Atom 的 RHI 怎么多后端 | `Atom/RHI/RHISystem.cpp` + `Atom/RHI/Factory.h` | 看工厂注册 |
| TaskGraph 的任务窃取 | `AzCore/Task/TaskExecutor.cpp` | 找 `while` 循环 |

**最后一句话**：O3DE 的源码量大但**结构极其规律**——policy → `constexpr bool` → `if constexpr` / 特化 → 具体类型。你在 16.2–16.6 学到的这个模式，会在后面每一处重复出现。认出模式，就不用读完全部 42 万行了。

---

# 第十七部分 · 概念地图：从「资产」讲起

> **🎓 L0–L2 · 随时查阅 ★核心** ｜ 前置：无 ｜ 用法：**L0 阶段先通读 17.1–17.7**（把"资产为什么必须处理"彻底搞懂），17.8 之后当字典查 ｜ 下一站 → 第二部分（L3）或第四部分（L3）

## 17.1 这一章解决什么问题

你问了两个问题，第二个其实更关键：

> "我只知道资产这个东西，里面肯定还有很多其他我不知道的概念，我是不知道的。"

这是学习任何大型引擎时最真实的状态——**不是"学不会"，是"不知道要学什么"**。所以本章不只是讲资产，而是给你一张**概念地图**：哪些名词属于哪一层、彼此怎么咬合、以及最重要的——**每个东西没有它时会发生什么**。

### 三栏读法：判断自己是否真懂一个概念

对每个名词只问三句：

| # | 问题 | 为什么问 |
|---|---|---|
| 1 | 它是什么？（一句话，不用术语） | 检验你是否只会复述名词 |
| 2 | **没有它会怎样？** | 这才是"真懂"的分界线 |
| 3 | 我在哪能亲眼看到它？ | 防止把传说当事实 |

第 2 条是本章的主线。它和第十六部分的"反事实对比"是同一个方法：

> 想理解一个设计，先想清楚**不用它时你会付出什么代价**。代价说不出来，说明你还没理解它存在的理由。

---

## 17.2 核心疑问：`.fbx` 为什么不能直接被引擎用？

这是你问题的原点。答案很短：**因为运行时需要的东西，`.fbx` 一样都不直接提供。**

### 差距清单

| 运行时真正需要 | `.fbx` 实际给的是 | 差距 |
|---|---|---|
| **定长顶点缓冲**：position / normal / tangent / uv 各占几个字节，stride 固定 | 带名字的节点树，属性可缺可多、可嵌套 | 必须重排、补齐、决定布局 |
| **索引缓冲 + submesh 区间**：第 0 个 submesh 是索引 0–1199 | 场景图，submesh 边界是隐式的 | 必须重建索引与区间 |
| **AABB / LOD / 骨骼绑定表** | 取决于导出器心情，不规范 | 必须计算或校验 |
| **GPU 纹理格式**：BC7 / ASTC / ETC2，按平台不同 | 贴图是独立 png/tga，未压缩 | 必须按平台压缩 |
| **稳定身份**：改个名字引用不断 | 文件名 + 节点名字符串 | 必须生成 Uuid |
| **已解析的依赖**：材质 → 贴图的 AssetId | 材质只是个名字字符串 | 必须在构建期解析 |

### 如果硬要运行时直接读 `.fbx`

| 后果 | 量级 |
|---|---|
| 加载从**毫秒**变**秒** | 解析 ASCII + 建场景图 + 转换 |
| 内存翻几倍 | 节点名、临时对象、重复属性 |
| 每个平台都要带 FBX SDK | 体积大、编译复杂、许可麻烦 |
| **无法流式/增量** | 不读完整文件不知道里面有什么 |
| 坏数据在**玩家机器上崩** | 而不是在美术机器上构建失败 |

### 关键类比：Asset Processor 就是"资产的编译器"

想通这一点，整个资产系统就通了：

| 编译 C++ | 处理资产 |
|---|---|
| `.cpp` 源文件 | `Assets/*.fbx`、`*.png`、`*.azsl` **源资产** |
| 编译器（clang） | **Asset Builder**（Scene Compiler / Image Compiler / Shader Compiler…） |
| `.o` 目标文件 | `Cache/<platform>/` 里的**产品资产** |
| 符号表 / 链接表 | `assetcatalog.xml` + `assetdb.sqlite` |
| `.a` / 可执行 | `*.pak` **资产包** |
| 增量编译（时间戳 + 依赖） | **fingerprint**（源哈希 + builder 版本 + 依赖） |
| 头文件依赖 | 资产依赖（材质 → 贴图） |
| `#include` 找不到 → 编译错误 | 材质引用缺失 → **AP 报错，带文件名** |

**所以"资产要处理成特定格式"不是 O3DE 的怪癖，而是和"源码要编译成机器码"完全同构的必然。** 你从来不会问"为什么 .cpp 不能直接被 CPU 执行"，资产也是同一个问题。

---

## 17.3 资产的四种形态

这是最容易混淆的地方。**同一个东西在管线里叫四个名字**：

| 形态 | 位置（本机实测） | 真实例子 | 谁生成 | 进版本控制 |
|---|---|---|---|---|
| **源资产** Source | `Assets/`、`Gems/*/Assets/` | `sphere.fbx`、`default.font`、`*.material`、`*.azsl` | 美术 / 你 | ✅ **必须** |
| **中间资产** Intermediate | `Cache/Intermediate Assets/` | shader 预处理结果、MaterialCanvas 产物 | Asset Processor | ❌ |
| **产品资产** Product | `Cache/<platform>/` | `*.azmodel`、`*.azshadervariant`、`fonts/*.xml` | Asset Builder | ❌ **绝不** |
| **资产包** Bundle | `*.pak` + `AssetBundling/SeedLists/*.seed` | `DefaultLevel.seed` → pak | AssetBundler | 视发布流程 |

本机实测的目录形态：

```
/workspaces/MyProject/
├── Assets/                       ← 源资产（你放东西的地方）
├── Levels/DefaultLevel/
│   └── DefaultLevel.prefab       ← Level 就是一个目录 + 同名 .prefab
├── AssetBundling/SeedLists/
│   └── DefaultLevel.seed         ← 打包种子清单（从哪个 Level 开始抓依赖）
└── Cache/                        ← 全部是生成物，别手改
    ├── Intermediate Assets/      ← ⚠️ 注意：中间资产在 Cache 里面
    │   ├── shaders/
    │   ├── materials/
    │   └── materialcanvas/
    ├── assetdb.sqlite            ← AP 的作业数据库（-shm/-wal 是 WAL 文件）
    └── linux/                    ← 产品资产，按平台分目录
        ├── assetcatalog.xml      ← 运行时索引（1.7 MB）
        ├── engineassets/ icons/ fonts/ materials/ passes/
        ├── shaders/ shaderlib/ textures/ translation/ schema/
        └── levelassets/ resources/ config/ ...
```

> ⚠️ **两个反直觉点**：
> 1. **中间资产在 `Cache/` 里，不在项目根**（很多人以为在 `Intermediate/`）
> 2. **`assetcatalog.xml` 虽然叫 .xml，内容是二进制**。实测 `file` 输出为 `data`，`head` 出来是乱码。
>    它由 `SerializeContext` 的二进制模式写出——**所以永远不要手改或用文本工具处理它**。

---

## 17.4 资产的三个身份

运行时**不用路径**找资产，用三个值：

```cpp
// AzCore/Asset/AssetCommon.h:43
typedef Uuid AssetType;        // 「它是什么类型」= 类型自己的 UUID

// AzCore/Asset/AssetCommon.h:86-87
struct AssetId
{
    Uuid m_guid;   // 「是哪一个资产」= 全局唯一 ID
    u32  m_subId;  // 「同一资产的第几部分」
};
```

`m_subId` 的官方注释直接给了用途：

> `To allow easier and more consistent asset guid, we can provide asset sub ID. (i.e. Guid is a cubemap texture, subId is the index of the side)`

**一个立方体贴图 = 1 个 guid + 6 个 subId。** 这一句就解释了"为什么一个源文件能出多个产品"。

| 身份 | 回答的问题 | 类比 |
|---|---|---|
| `AssetType` | 这是模型？贴图？材质？ | 文件类型 / MIME |
| `AssetId::m_guid` | 是哪一个？ | inode 号 |
| `AssetId::m_subId` | 是它的第几块？ | 文件里的第几个区段 |

### 为什么不能用路径

`AzToolsFramework/API/EditorAssetSystemAPI.h:154` 有一段官方吐槽，值得原文引用：

> `... for example, a passing in a product file name like "sphere.azmodel" when the actual source file is "shapes.fbx", there simply is not enough information in just that string to know what the source file is unless it has already been compiled and is in the catalog.`

翻译：**光看 `sphere.azmodel` 这个名字，你无法反推它的源文件是 `shapes.fbx`。** 名字里没有这个信息。

三条硬理由：

| 用路径当 ID 的问题 | 具体后果 |
|---|---|
| 路径会变 | 重命名 / 移目录 / 大小写规范化 → 所有引用断掉 |
| 路径在平台间不一致 | Linux 全小写，Windows 保留大小写（实测 `Fonts/` → `fonts/`） |
| 一个源出多个产品 | 路径无法表达"我要第 3 个 submesh" |

**所以：代码里永远持有 `AssetId`，只在编辑器工具/人类交互时才碰路径。**

---

## 17.5 管线六步：从磁盘文件到内存对象

```mermaid
flowchart TD
    S["① 扫描输入目录<br/>ScanFolder（来自 .setreg）"]
    FP["② 算 fingerprint<br/>源哈希 + builder 版本 + 依赖"]
    B["③ 按扩展名选 Builder<br/>.fbx→Scene / .png→Image / .azsl→Shader"]
    P["④ 写产品资产<br/>Cache/&lt;platform&gt;/..."]
    C["⑤ 更新索引<br/>assetcatalog.xml + assetdb.sqlite"]
    R["⑥ 运行时读取<br/>AssetManager → AZ::Data::Asset&lt;T&gt;"]

    S --> FP --> B --> P --> C --> R
    FP -.->|"没变就跳过"| SKIP["不重新编译"]
    P -.->|"多个产品"| P2["model.fbx.azmodel<br/>model.stl.azmodel"]

    style FP fill:#ffe6cc
    style C fill:#d5e8d4
```

### 逐步骤说明

| 步 | 做什么 | 你能在哪看到 | 关键点 |
|---|---|---|---|
| ① | 扫描输入目录 | `Registry/assetprocessor_settings.setreg` 的 `watch`（见 9.3） | `Assets/` 是内建默认，不用配 |
| ② | **fingerprint** | `assetdb.sqlite` | 变了才重跑；这是增量 |
| ③ | 选 Builder | `Code/Tools/SceneAPI`、`Gems/*/Atom/Asset` | 按**源扩展名**分发 |
| ④ | 写产品 | `Cache/linux/` | 命名规则见下 |
| ⑤ | 更新索引 | `assetcatalog.xml` | **二进制**，别手改 |
| ⑥ | 加载 | `AzCore/Asset/AssetManager.h` | 异步 + 状态机 |

### 产品命名规则（源码原文）

`Code/Tools/SceneAPI/SceneCore/Utilities/FileUtilities.cpp:27-36` 有一段极好的注释：

> `For example, 'model.fbx' and 'model.stl' would both have a groupName of 'model', and would then produce 'model.azmodel' ... By appending the original source extension here, we end up with the unique names of 'model.fbx.azmodel' and 'model.stl.azmodel'.`

**所以产品名形如 `<组名>.<源扩展名>.<产品扩展名>`。** 这就是为什么你在 cache 里会看到 `xx.fbx.azmodel` 这种"双扩展名"——不是拼错了，是为了避免两个不同源撞名。

### 加载状态机（8 态）

`AssetCommon.h:115-125` 定义了 `AssetStatus`：

| 状态 | 含义 |
|---|---|
| `NotLoaded` | 还没加载，也没排队 |
| `Queued` | 已建作业，未开始 |
| `StreamReady` | **流式加载器**读完（可开始反序列化） |
| `Loading` | 正在加载 |
| `LoadedPreReady` | 数据 + 预加载依赖就绪，即将回调 |
| `ReadyPreNotify` | 已可用，但 `OnAssetReady` 还没在主线程分发 |
| `Ready` | **完全可用** |
| `Error` | 它或某个强依赖失败 |

**看清这套状态机，你就明白为什么 `Asset<T>` 不能当普通指针用**——总共 **8 个状态**，只有 `NotLoaded` 与 `Ready` 是“稳定态”，其余 5 个是过渡态（`Queued` / `StreamReady` / `Loading` / `LoadedPreReady` / `ReadyPreNotify`），外加 `Error`。
这就是第八部分讲事件队列、第十二部分讲流式加载的共同基础。

---

## 17.6 六个"为什么非要这么麻烦"

| 疑问 | 不这么做的后果 | O3DE 的做法 |
|---|---|---|
| 为什么不能直接读 `.fbx` | 秒级加载、内存翻倍、要带 SDK、无法流式 | 构建期编成定长二进制 |
| 为什么产品要**按平台分目录** | 纹理压缩格式、shader 字节码与 GPU/RHI 绑定 | `Cache/<platform>/`（本机 = `Cache/linux/`） |
| 为什么要 **UUID** | 重命名/移目录后引用全断 | `AssetId = guid + subId` |
| 为什么一个 `.fbx` 出多个产品 | 只想加载一个 mesh 却要加载整包 | 每产品独立 `AssetId`，`subId` 区分 |
| 为什么要 **Intermediate** | 每个 builder 各自重解一遍 shader，极慢 | `Cache/Intermediate Assets/` 复用 |
| 为什么要 **catalog/bundle** | 运行时扫目录、上万小文件随机 IO | 一个索引文件 + `.pak` 打包 |

---

## 17.7 实测：你的项目里到底有什么

在 `/workspaces/MyProject/Cache/linux` 上按扩展名统计（去掉目录）：

| 扩展名 | 数量 | 是什么 |
|---|---|---|
| `json` | 1462 | 各类资产内部描述（shader options、pass 配置…） |
| `hlsl` | 284 | 中间着色器源码 |
| `azslin` | 284 | 着色器输入清单（shader input） |
| `azshadervariant` | 284 | **最终着色器变体**（可被 GPU 直接用） |
| `svg` | 227 | 图标 |
| `pass` | 170 | 渲染 Pass 资产 |
| `azshader` | 116 | 着色器资产 |
| `png` | 45 | 纹理 |
| `azasset` | 45 | 通用二进制资产容器（LUT 等） |
| `luac` | 36 | 编译后的 Lua |
| `cfg` | 35 | 配置 |
| `xml` | 11 | 字体等 |
| `setreg` | 9 | 设置注册表 |
| `pak` | 8 | **资产包** |
| `slice` | 2 | 旧 Slice 机制残留（`default.slice`、`defaultlevelsetup.slice`） |

**三条结论：**

1. **着色器占绝对多数**：`284×3 + 116 + 170 = 1138` 个文件，占全部产品的**三分之一以上**。资产管线里最重的部分是**着色器编译**，不是模型导入。
2. **`slice` 还在**——旧机制仍能加载，但新项目不要用（用 Prefab，见 17.8）。
3. **`json` 最多但体积小**，真正占空间的是纹理与 shader 变体。这解释了 9.4 里"3042 个资产 / 111 MB"的比例。

---

## 17.8 场景侧概念：Entity → Component → Prefab → Level → World

这一组是**最容易被混为一谈**的。先用包含关系看清结构：

```
Level          一个目录 + 同名 .prefab（可加载单元）
└── Prefab     可嵌套、可覆盖（Override）的场景片段
    └── Entity 只有 Id + 组件列表，自己不含任何逻辑
        └── Component  逻辑单元（编辑器版 + 运行时版，成对）
            └── Asset<T>  引用的模型/材质/贴图
```

| 概念 | 一句话 | 没有它会怎样 | 在哪看 |
|---|---|---|---|
| **Entity** | 一个带 `AZ::EntityId` 的**容器**，本身没有行为 | 所有逻辑挤在一个巨型对象里 | `AzCore/Component/Entity.h` |
| **Component** | 挂在 Entity 上的一块逻辑（移动、网格、碰撞…） | 无法组合复用，只能继承 | `AzCore/Component/Component.h` |
| **Prefab** | 可嵌套/可覆盖的场景片段 | 每改一处都要手工同步所有副本 | `AzToolsFramework/Prefab/` |
| **Level** | 一个**目录** + 同名 `.prefab` | 没有"可加载单元"这个概念 | `Levels/DefaultLevel/DefaultLevel.prefab`（实测） |
| **Spawnable** | 运行时可在**任意时刻实例化**的实体树资产 | 动态生成/网络同步没有载体 | `AzFramework/Spawnable/` |
| **World** | 运行时概念：已实例化的实体集合 + 渲染 Scene + 物理场景 | 无法同时存在多个"世界" | `AzFramework/Spawnable/RootSpawnableInterface.h` |
| **Scene** | **纯渲染层**概念（RPI），不是场景文件 | 渲染器不知道该画谁 | `Atom/RPI.Public/Scene.h` |
| **Slice** | 旧的分片机制，已被 Prefab 取代 | — | 产品里仍有 `.slice` 残留，别在新项目用 |

### Level 是怎么变成 World 的

```mermaid
flowchart LR
    L["Level<br/>（磁盘上的 .prefab）"] --> P["Prefab 处理<br/>展开嵌套 + 应用 Override"]
    P --> SP["Spawnable<br/>（运行时实体树）"]
    SP --> W["World<br/>实体集合（已实例化）"]
    W --> SC["Scene（RPI）<br/>渲染"]
    W --> PH["物理场景（PhysX）<br/>模拟"]

    style L fill:#e8f4f8
    style W fill:#d5e8d4
```

**关键区分：**

- **Level 是磁盘上的东西**，World 是内存里的东西，Scene 是 GPU 视角的东西
- 同一个 Level 可以实例化出多个 World（联机服务器一进程多房间就是这样做的）
- 编辑器里改的是 Prefab/Level，运行时只见到 Spawnable 和 World

---

## 17.9 构建侧概念

| 概念 | 一句话 | 没有它会怎样 | 详见 |
|---|---|---|---|
| **Gem** | 可插拔的功能包（代码 + 资产 + 工具） | 所有功能静态编进引擎，无法裁剪 | 第四部分 |
| **Module** | 一个 `libXxx.so` 动态库（Gem 的运行时形态） | 无法按需加载/隔离 | 4.4 |
| **Target** | CMake 构建目标（`.so` / `.a` / exe） | 无法并行/增量 | 第三部分 |
| **Variant** | 应用类型：Editor / Game / Server / Headless / Unified | 每种形态都要一份独立配置树 | 4.3 |
| **PAL** | Platform Abstraction Layer：`Platform/{Linux,Windows,…}` 下的实现分叉 | 平台差异散落各处 | 3.8 |
| **`gem.json` / `project.json` / `engine.json`** | 三层的清单文件 | 引擎不知道有哪些 Gem/项目 | 5.2 |
| **SystemComponent** | 每个 Gem 的"常驻单例"，随应用启动 | 无法在启动时注册服务 | 7.2 |
| **`*_files.cmake`** | 显式列出参与编译的文件 | ⚠️ 新文件不加进去就**静默不编译** | 坑 18 |

---

## 17.10 代码与数据侧概念

| 概念 | 一句话 | 没有它会怎样 | 详见 |
|---|---|---|---|
| **EBus** | 类型安全的多播/单播事件总线，policy 决定实现 | 模块间要硬编码指针 | 第八部分 / 第十六部分 |
| **`AZ::Interface<T>`** | 单例式接口（比 EBus 轻） | 到处 `GetGlobal()` | 8.6 |
| **`ReflectContext`** | 反射的抽象入口 | 无法统一描述"类型长什么样" | 16.7 |
| **SerializeContext** | 存盘/读盘/版本迁移 | 手写序列化代码 | 16.7 |
| **EditContext** | 编辑器里怎么显示（**依附**于 SerializeContext） | 编辑器 UI 与数据脱节 | 16.7 |
| **BehaviorContext** | 脚本/反射调用 | 脚本层无法访问 C++ | 16.7 |
| **Settings Registry** | 分层合并的配置系统（`.setreg`） | 改个默认值要改引擎源码 | 9.2 |
| **CVar** | 运行时开关（`AZ_CVAR`） | 调参要重编 | 9.8 |
| **`AZ::Name`** | 用 CRC32 表示的名字（比较 O(1)、不分配） | 字符串比较成为热点 | 2.11 |
| **`AZ::Uuid` / `AZ::Crc32`** | 身份与哈希的基础类型 | 用 `typeid().name()` 不可跨编译器 | 2.2 |
| **`AZStd`** | 自研 STL 子集（分配器可控） | 无法统一内存统计/追踪 | 2.11 |

---

## 17.11 运行侧概念

| 概念 | 一句话 | 没有它会怎样 | 详见 |
|---|---|---|---|
| **ComponentApplication** | 应用根对象：装载模块、建系统组件、跑主循环 | 没有统一生命周期 | 第六部分 |
| **Launcher** | 可执行入口（`Editor` / `GameLauncher` / `ServerLauncher` / `HeadlessServerLauncher`） | 一个 exe 塞所有形态 | 1.4 |
| **TickBus** | 每帧回调总线（`OnTick(deltaTime)`） | 组件无法参与帧循环 | 7.4 |
| **TaskGraph** | 依赖图式并行任务系统 | 手写线程池，依赖难管 | 2.8 |
| **Allocator** | 可组合的分配器链（System / Pool / Hpha…） | 内存失控、无法定位泄漏 | 2.5 |
| **RHI** | 渲染硬件接口（Vulkan / DX12 / Metal 统一抽象） | 渲染代码按后端分叉 | 第十二部分 |
| **FeatureProcessor** | 渲染功能的扩展点（27 个内置） | 加效果要改渲染器核心 | 12.4 |
| **DrawPacket / Pass / Material / Shader** | 渲染数据链：画什么 → 怎么画 → 用什么 → 跑哪段 GPU 代码 | 无法组织复杂管线 | 12.x |

---

## 17.12 十二个「你以为 vs 其实」

这一节专治"不知道自己不知道"：

| # | 你可能以为 | 其实是 |
|---|---|---|
| 1 | 资产就是一个文件 | 是 **`AssetId(Uuid+subId)` + 类型 + 一组产品文件**；文件只是载体 |
| 2 | 运行时读 `Assets/` | 运行时**只读 `Cache/<platform>/`**，源目录根本不进运行时 |
| 3 | 改了 `.fbx` 立刻生效 | 要等 Asset Processor 重编产品；编辑器里可能还要 reload |
| 4 | `Cache/` 可以随便删 | 删了要重跑 AP（几分钟）；但**删了是安全的**，因为它全是生成物 |
| 5 | `assetcatalog.xml` 是 XML，能编辑 | 是**二进制**，编辑即损坏 |
| 6 | Level 是一个 `.level` 文件 | 本版本是**一个目录 + 同名 `.prefab`**（`.level` 是旧格式） |
| 7 | Prefab 和 Slice 是一回事 | Slice 是**旧机制**，Prefab 是替代品，别在新项目用 Slice |
| 8 | Component 就是 Entity 的一部分代码 | Component 是**可拆卸单元**；Entity 本身只是 Id + 列表 |
| 9 | 一个 shader 源 = 一个 shader | 一份源会展开成**每平台 × 每 Pass × 每材质**的大量变体（实测 284 个） |
| 10 | Gem 只是 C++ 代码 | Gem = 代码 + 资产 + 工具 + 清单，是一个**完整功能包** |
| 11 | 编译完成就能跑 | 还要 AP 处理资产；缺 catalog 会报"资产找不到" |
| 12 | 引擎和项目是两棵独立的树 | 项目构建会**重编引擎目标**（3.8 讲了原因） |

---

## 17.13 自检：现在你能回答吗

- [ ] 用"没有它会怎样"的方式解释：为什么需要 `AssetId` 而不是路径？
- [ ] 源资产、中间资产、产品资产、资产包，各自的目录在哪？
- [ ] 为什么 `model.fbx` 和 `model.stl` 的产品名会是 `model.fbx.azmodel` / `model.stl.azmodel`？
- [ ] `assetcatalog.xml` 为什么不能手改？
- [ ] 一个 Level 和 World、Scene 的区别是什么？
- [ ] `Asset<T>` 为什么不能当裸指针用？（答：8 种状态）
- [ ] 产品里出现 `.slice` 说明什么？（答：旧机制残留）
- [ ] 为什么产品目录要按平台分？（纹理压缩 + shader 字节码）

**如果哪条答不上来**，回到对应小节，用 17.1 的三栏读法自己补。**别背名词——名词会变，问题不会。**

## 17.14 下一步

| 你现在想做的 | 去哪 |
|---|---|
| 动手验证资产管线 | 9.4（实测数字）、实验 7（读构建产物） |
| 深入插件装配 | 第二部分 → 第四部分 |
| 深入 EBus / 反射实现 | 第十六部分 |
| 深入渲染数据链 | 第十二部分 |
| 查某个名词在哪实现 | 附录 B |

**一句话收尾**：O3DE 里所有看起来"多余"的步骤，都可以用同一个问题检验——**"不做这一步，代价是什么？"** 答得出来，它就是必要的；答不出来，那才是真的多余。

---

# 第十八部分 · 子系统地图：79 个 Gem 都在干什么

> **🎓 L0–L2 ｜ 前置：第十七部分（至少懂"资产"和"Gem"是什么） ｜ 读完能做什么：看到一个需求，知道该开哪个 Gem ｜ 下一站 → 第十九部分（L2 ★实战）**

## 18.1 先看清规模

在 `/workspaces/o3de/Gems` 下数一遍（读每个 `gem.json` 的 `summary` 字段）：

```bash
cd /workspaces/o3de/Gems && ls -d */ | wc -l          # → 83 个目录
ls */gem.json | wc -l                                  # → 79 个有清单
```

**79 个 Gem + `Code/` 下的框架层**，这就是 O3DE 的全部能力面。

再看你自己的项目：

| 项 | 数量 | 说明 |
|---|---|---|
| `project.json` 里的 `gem_names` | **4 个** | `MyProject`（项目自带）、`Atom`、`CameraFramework`、`ImGui` |
| 引擎提供的 Gem | **79 个** | 其中只有 **3 个**被启用，其余 76 个**没编译、没加载、不占内存** |
| 产品资产里出现的 Gem 目录 | 视启用情况 | `Cache/linux/gem/` |

**这就是"插件式"的实际收益**：不是概念，是 76 个 Gem 的代码根本没进你的二进制。

## 18.2 按用途分类

下面按"你想干什么"组织，而不是按字母序。**描述取自各 Gem 的 `gem.json` 的 `summary` 字段**（不是我编的）。

### ① 渲染与图形（Atom 体系）

| Gem | 干什么 | 你的项目 |
|---|---|---|
| `Atom` | Atom 渲染器本体 + 工具 | ✅ 已启用 |
| `AtomContent` | Atom 的资产（材质类型、pass 等） | ✅（随 Atom） |
| `AtomLyIntegration` | Atom 与 O3DE 组件层的桥接 | ✅（随 Atom） |
| `AtomTressFX` | 毛发/皮毛模拟 | ❌ |
| `DiffuseProbeGrid` | 漫反射全局光照（DDGI） | ❌ |
| `Meshlets` | 纯 GPU 渲染网格的概念验证 | ❌ |
| `SkyAtmosphere` | 物理化天空大气 | ❌ |
| `Stars` | 基于物理的星空 | ❌ |
| `OpenParticleSystem` | 粒子系统（**preview，格式可能变**） | ❌ |
| `WhiteBox` | 白盒快速关卡设计 | ❌ |
| `DebugDraw` | 调试可视化（画线、画球） | ❌ |
| `PrimitiveAssets` | 基础几何体网格 + 物理 | ❌ |
| `GradientSignal` | 程序化梯度（地形/植被的基础） | ❌ |
| `SurfaceData` | 从表面发出信号或标签 | ❌ |
| `TextureAtlas` | 纹理图集 | ❌ |
| `AFR` | 交替帧渲染（VR 常用） | ❌ |

### ② 场景与环境

| Gem | 干什么 | 备注 |
|---|---|---|
| `Terrain` | 地形系统 | ⚠️ `gem.json` 自称 **experimental** |
| `Vegetation` | 植被散布 | 依赖 `GradientSignal` + `SurfaceData` |
| `LandscapeCanvas` | 地形/植被的节点式编辑 | 编辑器功能 |
| `SceneProcessing` | Scene Settings（导入默认值） | 影响资产管线 |
| `RecastNavigation` | 寻路（Recast/Detour） | 做 AI 必备 |
| `NvCloth` | NVIDIA 布料模拟 | ❌ |

### ③ 物理

| Gem | 干什么 |
|---|---|
| `PhysX` | 物理引擎（刚体、碰撞、角色控制器、车辆） |
| `NvCloth` | 布料 |
| `ScriptCanvasPhysics` | 给 ScriptCanvas 用的物理节点 |

### ④ 角色与动画

| Gem | 干什么 |
|---|---|
| `EMotionFX` | 动画系统（骨骼、蒙皮、动画图） |
| `MotionMatching` | 数据驱动的动作匹配（新一代动画技术） |
| `Maestro` | Track View 过场动画 |

### ⑤ 音频

| Gem | 干什么 |
|---|---|
| `AudioSystem` | 音频翻译层（ATL）+ 音频引擎接口 |
| `AudioEngineWwise` | Wwise 后端 |
| `MiniAudio` | 轻量播放（替代完整音频系统） |
| `Microphone` | 麦克风输入 |

### ⑥ UI

| Gem | 干什么 | 备注 |
|---|---|---|
| `LyShine` | 运行时 UI 系统 + 制作工具 | 游戏内 UI |
| `LyShineExamples` | LyShine 示例 | 学习用 |
| `UiBasics` | 基础 UI prefab（按钮等） | 配合 LyShine |
| `GraphCanvas` | 节点图框架 | 做编辑器工具用 |
| `GraphModel` | 节点图数据模型 | 配合 GraphCanvas |
| `MessagePopup` | 弹窗示例实现 | |
| `ImGui` | 即时模式 GUI | ✅ 已启用（调试面板） |

### ⑦ 脚本与可视化编程

| Gem | 干什么 |
|---|---|
| `ScriptCanvas` | 可视化脚本环境 |
| `ScriptCanvasDeveloper` | ScriptCanvas 开发工具 |
| `ScriptCanvasTesting` | ScriptCanvas 测试框架 |
| `ScriptEvents` | 事件资产框架（C++ ↔ 脚本） |
| `ScriptedEntityTweener` | 脚本驱动的补间动画 |
| `ExpressionEvaluation` | 表达式解析与执行 |
| `EditorPythonBindings` | 编辑器 Python 命令 |
| `PythonAssetBuilder` | **用 Python 写自定义资产 Builder** |
| `QtForPython` | PySide2 绑定 |
| `ScriptAutomation` | 自动化测试用的脚本绑定 |

### ⑧ 输入与相机

| Gem | 干什么 |
|---|---|
| `StartingPointInput` | 低层输入映射 |
| `StartingPointCamera` | 相机行为 |
| `StartingPointMovement` | 一系列 Lua 移动脚本 |
| `Camera` | 基础相机组件 |
| `CameraFramework` | 复杂相机框架 | ✅ 已启用 |
| `Gestures` | 手势识别 |
| `VirtualGamepad` | 虚拟手柄（触屏） |
| `BarrierInput` | 把 O3DE 变成 Barrier 客户端（多机同步输入） |

### ⑨ 游戏框架与服务

| Gem | 干什么 |
|---|---|
| `GameState` | 游戏状态机框架（菜单/游戏/暂停…） |
| `GameStateSamples` | 示例状态实现 |
| `SaveData` | **跨平台存档 API** |
| `Prefab` | Prefab 系统（框架级） |
| `LocalUser` | 本地用户 ID 映射 |
| `Presence` | 在线状态（平台无关接口） |
| `Achievements` | 成就系统（平台无关接口） |
| `InAppPurchases` | 内购 |
| `CertificateManager` | 认证文件访问 |

### ⑩ 联机

| Gem | 干什么 |
|---|---|
| `Multiplayer` | 多人功能公共 API（第十三部分详述） |
| `MultiplayerCompression` | 网络压缩器 |
| `RemoteTools` | 远程工具连接（编辑器 ↔ 运行时） |
| `AWSCore` | AWS SDK 集成 |

### ⑪ 工程与工具链

| Gem | 干什么 | 为什么重要 |
|---|---|---|
| `Profiler` | **性能数据采集工具集** | 第二十一部分 |
| `CrashReporting` | 外部崩溃上报 | 发布必备 |
| `Compression` | 压缩 API 注册（LZ4/ZStd…） | 存档/网络 |
| `Archive` | 归档文件读写 | |
| `Streamer` | `AZ::IO::Streamer` 的实现 | 流式加载 |
| `AssetValidation` | 资产校验命令 | 发布前检查 |
| `TestAssetBuilder` | 给 Asset Processor 做特性测试 | 学资产管线 |
| `CustomAssetExample` | **自定义资产 Builder 的示例代码** | 想扩展资产管线先看它 |
| `SceneLoggingExample` | 扩展 SceneAPI 的示例 | |
| `FastNoise` | FastNoise 噪声库 | 程序化生成 |
| `TickBusOrderViewer` | 用 CVar 显示 Tick 顺序 | 排查执行顺序 |
| `DevTextures` | 通用开发纹理 | |
| `MiniAudio` | 见音频 | |
| `LmbrCentral` | O3DE 核心必需代码与资产 | 很多 Gem 的依赖 |

## 18.3 启用决策：不同项目该开哪些

| 项目类型 | 建议启用 | 理由 |
|---|---|---|
| **最小可运行** | `Atom` + `CameraFramework` + 你的 Gem | 当前 `MyProject` 就是这样 |
| **单机 3D 小游戏** | 上面 + `PhysX` + `EMotionFX` + `AudioSystem` + `LyShine` + `StartingPoint*` | 物理/动画/音效/UI/输入全齐 |
| **联机游戏** | 上面 + `Multiplayer` + `MultiplayerCompression` | 见第十三部分 |
| **有地形的大世界** | 上面 + `Terrain` + `Vegetation` + `GradientSignal` + `SurfaceData` + `LandscapeCanvas` | ⚠️ Terrain 仍是 experimental |
| **移动端** | 精简：`Atom` + `MiniAudio` + `VirtualGamepad` + `Gestures` | 体积敏感 |
| **做编辑器工具** | + `GraphCanvas` + `GraphModel` + `EditorPythonBindings` | 节点式工具 |

**加 Gem 的命令**（会自动改 `project.json`）：

```bash
cd /workspaces/o3de
./scripts/o3de.sh enable-gem -gn PhysX -pp /workspaces/MyProject
```

⚠️ **加了 Gem 必须重新 configure + 编译**（9.9 的生效对照表）。

## 18.4 三条命令查清一个 Gem 到底提供什么

不要靠猜，也不要只信文档。**先认清一个坑**：Gem 的目录层级不总是"一层"。

```bash
# ⚠️ 先确认 gem.json 到底在哪一层（PhysX 就是深两层的）
find /workspaces/o3de/Gems/PhysX -maxdepth 3 -name gem.json
# /workspaces/o3de/Gems/PhysX/Core/PhysX5/gem.json
# /workspaces/o3de/Gems/PhysX/Core/PhysX4/gem.json
# /workspaces/o3de/Gems/PhysX/Common/gem.json
# /workspaces/o3de/Gems/PhysX/Debug/PhysX5/gem.json
# /workspaces/o3de/Gems/PhysX/Debug/PhysX4/gem.json
#   ↑ `Gems/PhysX/gem.json` 并不存在！PhysX 是把 4 个变体装在子目录里的"父目录"
```

搞清层级之后，三条命令才有意义（`grep -r` 本身是递归的，所以 ②③ 直接在父目录搜就行）：

```bash
GEM=/workspaces/o3de/Gems/PhysX            # 顶层用父目录

# ① 官方描述与依赖 —— 需要指向真正的 gem.json
python3 -c "import json; d=json.load(open('$GEM/Core/PhysX5/gem.json')); \
print('summary:', d.get('summary')); print('dependencies:', d.get('dependencies'))"
# → summary: The PhysX5 Gem provides physics simulation with NVIDIA PhysX including
#   static and dynamic rigid body simulation, force regions, ragdolls, articulations...

# ② 它有哪些组件（找 CreateDescriptor）
grep -rn "CreateDescriptor()" $GEM --include=*.cpp | head -3
# → Core/Code/Source/EditorComponentDescriptors.cpp:37: EditorBallJointComponent::CreateDescriptor(),
# → ...:38: EditorCharacterControllerComponent::CreateDescriptor(),
# → ...:39: EditorCharacterGameplayComponent::CreateDescriptor(),

# ③ 它暴露了哪些 EBus / Interface（能力边界）
grep -rn "using .*Bus = AZ::EBus<" $GEM --include=*.h | head -3
# → Core/Code/Include/PhysX/SystemComponentBus.h:90: using SystemRequestsBus = AZ::EBus<SystemRequests>;
# → Core/Code/Include/PhysX/EditorColliderComponentRequestBus.h:47: ...
```

**第 ③ 条最有用**：一个 Gem 的能力边界，基本等于它暴露的 EBus/Interface 集合。

> ⚠️ **注意 `PhysX/Common`、`PhysX/Core/PhysX5` 这类子目录里 ②③ 可能是空的**——
> 因为代码集中在 `PhysX/Core/Code/`，子目录只有 `gem.json` 与少量资源。
> 所以 **②③ 用父目录 `Gems/PhysX` 递归搜**，只有 ① 需要精确定位 `gem.json`。

### 排查顺序（一次能查对）

```bash
# 一步到位：不管层级多深，先找到所有 gem.json，再挑你要的那个
find /workspaces/o3de/Gems -maxdepth 4 -name gem.json | grep -i physx
```

**为什么 PhysX 要分这么多层**：它同时支持 PhysX 4 与 PhysX 5，还要区分 `Core`（运行时）
与 `Debug`（调试可视化），所以用"父目录 + 变体子目录"组织。**大部分 Gem 是单层的**，
遇到 `gem.json` 找不到时，`find` 一下即可。

## 18.5 三种"状态"，别搞混

| 状态 | 含义 | 怎么判断 |
|---|---|---|
| **存在** | 磁盘上有这个 Gem 目录 | `ls /workspaces/o3de/Gems` |
| **启用** | 写进了 `project.json` 的 `gem_names` | 读 `project.json` |
| **已编译** | 构建树里有它的目标 | `ninja -t targets all \| grep -i <gem>` |

**三个状态互相独立**。常见误判：

- "我在 `Gems/` 里看到它了，为什么用不了？" → 存在 ≠ 启用
- "我启用了，为什么链接找不到符号？" → 启用 ≠ 已编译（要重新 configure）
- "编译了，为什么日志里没加载？" → 检查启动日志的 `Attempting to load module`

## 18.6 本章的自检

- [ ] 你项目启用了几个 Gem？其余多少个没编进二进制？
- [ ] 想做存档，该开哪个 Gem？（`SaveData`）
- [ ] 想扩展资产管线、加自己的文件格式，该看哪个 Gem 的示例？（`CustomAssetExample`、`PythonAssetBuilder`）
- [ ] `Terrain` 的状态是什么？为什么不该在生产项目里依赖它？
- [ ] "存在 / 启用 / 已编译"三者分别怎么验证？

---

# 第十九部分 · 端到端实战：从零做一个能跑的功能

> **🎓 L2 ★核心 · 毕业设计** ｜ 前置：L1（构建树可用）+ 第七部分 + 第八部分 ｜ 读完能做什么：**独立完成一个能被验证的功能** ｜ 下一站 → 第二十部分（测试）

## 19.1 先把"完成"定义清楚

大多数教程失败在这里：**没有可验证的完成判据**，所以你永远不知道自己是不是做对了。

本机的 Editor GUI 跑不起来（坑 15），所以判据不能是"截个图"。我们用一个更硬的判据：

> **在 `HeadlessServer` 的日志里，出现 `[Heartbeat] count=N` 这一行。**

这个判据满足三个条件：**可自动验证、不依赖 GUI、失败时能定位**。

### 我们要做的东西

```mermaid
graph TD
    SC["MyProjectSystemComponent<br/>（系统组件，常驻）"]
    HC["HeartbeatComponent<br/>（运行时组件）"]
    TB["AZ::TickBus<br/>（每帧回调）"]
    RB["MyProjectRequestBus<br/>（单 handler 查询）"]
    NB["HeartbeatNotificationBus<br/>（多 handler 广播）"]

    SC -->|"Activate 时创建并挂载"| HC
    HC -->|"BusConnect"| TB
    TB -->|"OnTick(dt)"| HC
    HC -->|"Broadcast(count, time)"| NB
    NB -->|"OnHeartbeat"| SC
    SC -->|"GetHeartbeatCount()"| RB

    style HC fill:#ffe6cc
    style NB fill:#d5e8d4
```

**这一个例子同时覆盖了 L2 的全部核心机制**：组件生命周期、TickBus、请求总线、通知总线、服务依赖、反射、模块注册。

## 19.2 起点：你手上有什么

`/workspaces/MyProject/Gem` 的原始结构（MinimalProject 模板生成）：

```
Gem/
├── CMakeLists.txt                       两个目标：MyProject.Private.Object（静态） + MyProject（.so）
├── gem.json
├── myproject_files.cmake                ← 参与编译的文件清单（坑 18 的根源）
├── myproject_shared_files.cmake         ← .so 的文件清单
├── Include/MyProject/
│   ├── MyProjectBus.h                   ← 空的请求总线
│   └── MyProjectTypeIds.h               ← 3 个 GUID
└── Source/
    ├── MyProjectModule.cpp              ← 模块入口，注册 descriptor
    └── MyProjectSystemComponent.{h,cpp} ← 系统组件
```

**这就是全部起点。** 没有魔法，只有 6 个文件。

## 19.3 第 1 步：加 TypeId（两个新 GUID）

`Include/MyProject/MyProjectTypeIds.h` 末尾加：

```cpp
    // Heartbeat 相关 TypeIds
    inline constexpr const char* HeartbeatComponentTypeId = "{9F2B7C41-3D5A-4E88-B6C1-7A0D4F9E2B13}";
    inline constexpr const char* HeartbeatNotificationsTypeId = "{4E8D6A05-C731-49B2-8F5D-1C93B7E4A260}";
```

**为什么必须自己造 GUID**：O3DE 用 UUID 做类型身份（2.2 讲过为什么不用 `typeid`）。
两个 GUID 必须全局唯一——随便生成，但**不要复制别人的**，否则两个类会互相覆盖。

生成方法：

```bash
python3 -c "import uuid;print('{'+str(uuid.uuid4()).upper()+'}')"
```

## 19.4 第 2 步：扩展请求总线 + 加通知总线

`Include/MyProject/MyProjectBus.h`，把空的 `MyProjectRequests` 变成有方法的接口：

```cpp
    class MyProjectRequests
    {
    public:
        AZ_RTTI(MyProjectRequests, MyProjectRequestsTypeId);
        virtual ~MyProjectRequests() = default;

        virtual int GetHeartbeatCount() const = 0;   // 心跳次数
        virtual double GetTotalTime() const = 0;     // 累计运行秒数
    };
```

再在同一个文件末尾加**第二个总线**：

```cpp
    // 通知总线：多 handler，任何模块都能订阅
    class HeartbeatNotifications
    {
    public:
        AZ_RTTI(HeartbeatNotifications, HeartbeatNotificationsTypeId);
        virtual ~HeartbeatNotifications() = default;

        virtual void OnHeartbeat(int count, double totalTime) = 0;
    };

    class HeartbeatNotificationTraits
        : public AZ::EBusTraits
    {
    public:
        static constexpr AZ::EBusHandlerPolicy HandlerPolicy = AZ::EBusHandlerPolicy::Multiple;
        static constexpr AZ::EBusAddressPolicy AddressPolicy = AZ::EBusAddressPolicy::Single;
    };

    using HeartbeatNotificationBus = AZ::EBus<HeartbeatNotifications, HeartbeatNotificationTraits>;
```

### 为什么是两个总线，不是一个

这是第八部分的核心思想，在这里落地：

| | 请求总线 | 通知总线 |
|---|---|---|
| `HandlerPolicy` | `Single`（只能有一个实现者） | `Multiple`（任意多个订阅者） |
| 方向 | 调用方 → 服务方 | 事件源 → 所有关心的人 |
| 谁实现 | `SystemComponent` | 任意组件 |
| 编译期后果 | 单个函数指针（16.3） | 侵入式链表 |

**搞反的后果**：如果通知总线用 `Single`，第二个订阅者 `Connect()` 时会把第一个顶掉，你会得到"莫名其妙只有一个监听器生效"的 bug。

## 19.5 第 3 步：写 HeartbeatComponent

`Source/HeartbeatComponent.h`：

```cpp
#pragma once

#include <AzCore/Component/Component.h>
#include <AzCore/Component/TickBus.h>

namespace MyProject
{
    class HeartbeatComponent
        : public AZ::Component
        , public AZ::TickBus::Handler          // ← 同时继承两个基类
    {
    public:
        AZ_COMPONENT_DECL(HeartbeatComponent);

        static void Reflect(AZ::ReflectContext* context);
        static void GetProvidedServices(AZ::ComponentDescriptor::DependencyArrayType& provided);
        static void GetIncompatibleServices(AZ::ComponentDescriptor::DependencyArrayType& incompatible);
        static void GetRequiredServices(AZ::ComponentDescriptor::DependencyArrayType& required);
        static void GetDependentServices(AZ::ComponentDescriptor::DependencyArrayType& dependent);

        HeartbeatComponent() = default;
        ~HeartbeatComponent() override = default;

    protected:
        void Init() override;
        void Activate() override;
        void Deactivate() override;
        void OnTick(float deltaTime, AZ::ScriptTimePoint time) override;

    private:
        float m_intervalSeconds = 2.0f;   // 会被序列化，编辑器里能改
        float m_accumulated = 0.0f;       // 运行期状态，不序列化
        int m_count = 0;
        double m_totalTime = 0.0;
    };
}
```

`Source/HeartbeatComponent.cpp` 的关键部分：

```cpp
AZ_COMPONENT_IMPL(HeartbeatComponent, "HeartbeatComponent", HeartbeatComponentTypeId);

void HeartbeatComponent::Reflect(AZ::ReflectContext* context)
{
    if (auto* serializeContext = azrtti_cast<AZ::SerializeContext*>(context))
    {
        serializeContext->Class<HeartbeatComponent, AZ::Component>()
            ->Version(1)
            ->Field("IntervalSeconds", &HeartbeatComponent::m_intervalSeconds)
            ;

        // EditContext 依附于 SerializeContext（16.7 讲过为什么）
        if (auto* editContext = serializeContext->GetEditContext())
        {
            editContext->Class<HeartbeatComponent>("Heartbeat", "每隔固定时间广播一次心跳")
                ->ClassElement(AZ::Edit::ClassElements::EditorData, "")
                    ->Attribute(AZ::Edit::Attributes::AppearsInAddComponentMenu, AZ_CRC_CE("Game"))
                    ->Attribute(AZ::Edit::Attributes::Category, "MyProject")
                ->DataElement(AZ::Edit::UIHandlers::Default, &HeartbeatComponent::m_intervalSeconds,
                    "Interval (s)", "心跳间隔，单位秒")
                    ->Attribute(AZ::Edit::Attributes::Min, 0.1f)
                ;
        }
    }
}

void HeartbeatComponent::Activate()
{
    AZ::TickBus::Handler::BusConnect();
    AZ_Printf("MyProject", "[Heartbeat] component activated, interval=%.2fs", m_intervalSeconds);
}

void HeartbeatComponent::Deactivate()
{
    AZ::TickBus::Handler::BusDisconnect();
    AZ_Printf("MyProject", "[Heartbeat] component deactivated, total heartbeats=%d", m_count);
}

void HeartbeatComponent::OnTick(float deltaTime, AZ::ScriptTimePoint /*time*/)
{
    m_accumulated += deltaTime;
    m_totalTime += deltaTime;

    if (m_accumulated < m_intervalSeconds)
    {
        return;                      // 注意：这里没有循环、没有定时器，只是累加
    }

    m_accumulated -= m_intervalSeconds;
    ++m_count;

    AZ_Printf("MyProject", "[Heartbeat] count=%d total=%.2fs", m_count, m_totalTime);
    HeartbeatNotificationBus::Broadcast(&HeartbeatNotifications::OnHeartbeat, m_count, m_totalTime);
}
```

### 三个容易写错的地方

| 错误 | 后果 | 正确做法 |
|---|---|---|
| `Init()` 里 `BusConnect()` | 运行时崩溃或重复连接断言 | **只在 `Activate()` 连，`Deactivate()` 断** |
| `Deactivate()` 忘了 `BusDisconnect()` | 组件销毁后 Tick 还在调用野指针 | 成对出现 |
| 用 `m_count` 做定时器判断 | 帧率一变频率就错 | 用 `deltaTime` 累加 |

## 19.6 第 4 步：注册（**两处，缺一不可**）

这一步是新手最容易漏的。**加一个组件要改两个地方**：

### ① 加进文件清单 `myproject_files.cmake`

```cmake
set(FILES
    Include/MyProject/MyProjectBus.h
    Include/MyProject/MyProjectTypeIds.h
    Source/HeartbeatComponent.cpp      # ← 新增
    Source/HeartbeatComponent.h        # ← 新增
    Source/MyProjectSystemComponent.cpp
    Source/MyProjectSystemComponent.h
)
```

> ⚠️ **漏了这一步：文件完全不参与编译，而且没有报错**（坑 18）。你会以为"改了没生效"。

### ② 加进模块描述符 `MyProjectModule.cpp`

```cpp
#include "HeartbeatComponent.h"     // ← 新增

// ...
m_descriptors.insert(m_descriptors.end(), {
    MyProjectSystemComponent::CreateDescriptor(),
    HeartbeatComponent::CreateDescriptor(),   // ← 新增
});
```

> ⚠️ **漏了这一步：编译通过、链接通过，但运行时"找不到这个组件"**。因为组件必须先在 `ComponentDescriptorRegistry` 注册，才能被反射、被序列化、被 `CreateComponent<T>()` 找到。

**两处的关系**：

```mermaid
graph LR
    A["myproject_files.cmake<br/>决定：这个 .cpp 会不会被编译"]
    B["MyProjectModule.cpp<br/>决定：编译出来的组件会不会被注册"]
    C["可用的组件"]

    A --> C
    B --> C
    A -.->|"漏了"| X1["文件不在构建目标里<br/>（静默）"]
    B -.->|"漏了"| X2["符号在 .so 里<br/>但没有 descriptor（静默）"]

    style X1 fill:#ffcccc
    style X2 fill:#ffcccc
```

## 19.7 第 5 步：挂载（两条路）

组件写好了，还得**挂在某个 Entity 上**才会 `Activate()`。

### 路径 A：程序化挂载（本机可验证）

在 `MyProjectSystemComponent::Activate()` 里创建一个临时实体：

```cpp
#include <AzCore/Component/Entity.h>
#include "HeartbeatComponent.h"

void MyProjectSystemComponent::Activate()
{
    MyProjectRequestBus::Handler::BusConnect();
    HeartbeatNotificationBus::Handler::BusConnect();

    // 演示用：没有编辑器时手动创建
    m_demoEntity = aznew AZ::Entity("MyProject.HeartbeatDemo");
    m_demoEntity->CreateComponent<HeartbeatComponent>();
    m_demoEntity->Init();
    m_demoEntity->Activate();

    AZ_Printf("MyProject", "[MyProject] SystemComponent activated");
}

void MyProjectSystemComponent::Deactivate()
{
    if (m_demoEntity)
    {
        m_demoEntity->Deactivate();
        delete m_demoEntity;
        m_demoEntity = nullptr;
    }

    HeartbeatNotificationBus::Handler::BusDisconnect();
    MyProjectRequestBus::Handler::BusDisconnect();
}
```

**注意三点**：`CreateComponent` → `Init()` → `Activate()` 顺序不能反；销毁顺序相反；必须自己 `delete`（`aznew` 对应 `delete`）。

### 路径 B：编辑器里拖拽（正常项目做法）

有了 Editor GUI，正常流程是：打开 Level → 选中 Entity → `Add Component` → 搜索 `Heartbeat` → 调整 `Interval`。

`Reflect()` 里那行 `AppearsInAddComponentMenu` 就是控制它出不出现：

```cpp
->Attribute(AZ::Edit::Attributes::AppearsInAddComponentMenu, AZ_CRC_CE("Game"))
```

改成 `AZ_CRC_CE("Game")` 表示"游戏运行时组件"；编辑器专用组件写 `AZ_CRC_CE("Editor")`。

**两条路的关系**：路径 A 只是"没有编辑器时的替代方案"，它的数据不会存进 Level。生产项目里组件应该由 Prefab 承载（17.8）。

## 19.8 第 6 步：编译与验证

> **本章代码的验证状态（本机实测，2026-11-08）**
>
> | 项 | 状态 | 证据 |
> |---|---|---|
> | 三个 `.cpp` 能编译 | ✅ **已验证** | `clang++-18 -fsyntax-only`（用项目 compdb 的真实参数）三个文件 `exit 0` |
> | **能链接成静态库** | ✅ **已验证** | `ninja MyProject.Private.Object` → `libMyProject.Private.Object.a`（2.1 MB），`nm` 查到 **225 个 Heartbeat 符号** |
> | **能链接成模块 `.so`** | ✅ **已验证** | `ninja MyProject` → `bin/profile/libMyProject.so`（302 KB），导出 `CreateModuleClass` / `InitializeDynamicModule` |
> | **模块能被加载** | ✅ **已验证** | 启动日志：`Module: Attempting to load module:.../libMyProject.so` |
> | **组件能激活** | ✅ **已验证** | 启动日志：`MyProject: [Heartbeat] component activated, interval=2.00s` |
> | 心跳 `count=N` 能打印 | ⚠️ **未达成** | 本机无 Vulkan 设备，引擎卡在 shader 变体反序列化，进不到 tick 循环（见下） |
>
> **换句话说：代码正确性已经验到底，只差"进 tick 循环"这一步——而它卡在 GPU，不是卡在你的代码。**

### 实测运行时日志（本机真实输出）

```bash
cd /workspaces/o3de-build/bin/profile
timeout 70 ./O3DE.HeadlessServerLauncher --project-path /workspaces/MyProject > /tmp/hb.log 2>&1
grep -iE "heartbeat|Attempting to load module.*MyProject" /tmp/hb.log
```

```
Module: Attempting to load module:/workspaces/MyProject/build/linux/bin/profile/libMyProject.so
MyProject: [Heartbeat] component activated, interval=2.00s
MyProject: [MyProject] SystemComponent activated
RHISystem: Initializing RHI...
RHISystem:      Enumerated physical device:       ← 空！本机没有可用 Vulkan 设备
RHISystem:      Using physical device:            ← 也是空
```

**为什么 `count` 没出现**：`OnTick` 要靠引擎主循环，而主循环在 RHI 初始化之后。
设备名为空 → 后续 shader 变体加载全部失败 → 卡住（`timeout` 返回 124）。

> 💡 **这恰好证明了判据设计的价值**：`[Heartbeat] component activated` 已经出现，
> 说明**你的组件、EBus、反射、模块注册全部正确**；没出现 `count` 是环境问题。
> **能区分"我的代码错了"和"环境不支持"，正是一个好判据的作用。**
>
> 想真正跑到 `count=N`：换一台有 GPU 的机器，或者做一个不启用 `Atom` 的项目
> （`Atom_RHI` 依赖 `DX12`/`Metal`/`Vulkan`/`Null` 四个后端，无 GPU 时会枚举失败）。

```bash
# ① 只编你的 Gem（比全项目快几个数量级）
cd /workspaces/MyProject/build/linux
time ninja MyProject

# ② 确认符号真的编出来了
#    ⚠️ 不要在 .so 里 grep heartbeat！-fvisibility=hidden 会把你的组件符号变 local，
#       .so 只导出模块入口（CreateModuleClass 等 4 个），grep 一定是空。
#       要看符号，查中间静态库：
nm --defined-only lib/profile/libMyProject.Private.Object.a | grep -ci heartbeat
# 期望：200 左右（实测 225）

#    确认 .so 确实是"可被加载的模块"：
nm -D --defined-only bin/profile/libMyProject.so | grep -E "CreateModuleClass|InitializeDynamicModule"
# 期望：4 个 T 符号

# ③ 跑起来（本机用 HeadlessServer，因为 Editor GUI 会崩，见坑 15）
#    ⚠️ 用引擎自带的 Launcher 也能跑（它会读 project.json 并加载你的 Gem）
cd /workspaces/o3de-build/bin/profile
timeout 70 ./O3DE.HeadlessServerLauncher --project-path /workspaces/MyProject > /tmp/hb.log 2>&1

# ④ 验证判据
grep "\[Heartbeat\]" /tmp/hb.log
```

> ⚠️ **冷构建树会很慢**。如果 `bin/profile` 里文件很少，说明这个项目的构建树还没建起来，
> `ninja MyProject` 会连带编译大量引擎库（实测本机从 4 个产物开始，跑了 20 分钟仍未完成）。
> 想快速验证语法，用这一招：
>
> ```bash
> # 从项目 compdb 抄一条命令，把源文件换掉，加 -fsyntax-only
> python3 - <<'EOF'
> import json, subprocess, shlex
> db = json.load(open('/workspaces/MyProject/compile_commands.json'))
> e = next(x for x in db if x['file'].endswith('MyProjectSystemComponent.cpp'))
> parts = shlex.split(e['command']); out=[]; skip=False
> for p in parts:
>     if skip: skip=False; continue
>     if p == '-o': skip=True; continue
>     if p == '-c' or p.endswith('.cpp'): continue
>     out.append(p)
> r = subprocess.run(out + ['-fsyntax-only', '/workspaces/MyProject/Gem/Source/HeartbeatComponent.cpp'],
>                    cwd=e['directory'], capture_output=True, text=True)
> print('exit', r.returncode); print(r.stderr[:2000])
> EOF
> ```
>
> 这就是 clangd 在做的事（第十部分），**不需要完整构建树**。

**期望输出**（有 GPU 的机器上，时间取决于 `Interval` 与运行时长）：

```
Module: Attempting to load module:/workspaces/MyProject/build/linux/bin/profile/libMyProject.so
MyProject: [Heartbeat] component activated, interval=2.00s
MyProject: [Heartbeat] count=1 total=2.01s
MyProject: [Heartbeat] count=2 total=4.02s
...
MyProject: [Heartbeat] component deactivated, total heartbeats=9
```

> ⚠️ **无 GPU 的机器上会停在第二行之后**（本机实测）：`component activated` 有，
> `count` 没有。原因见本章开头的验证状态表——引擎卡在 RHI/shader 阶段，进不到 tick 循环。
> **这不是你的代码问题。**

### 为什么用 `timeout`

`HeadlessServer` 是**常驻进程**（它等客户端连接），不会自己退出。用 `timeout` 给它一段时间，让它在收到 SIGTERM 时走 `Deactivate()`——顺便验证了清理逻辑。本机实测 `timeout 70` 后返回 124（被 SIGTERM 杀掉），符合预期。

## 19.9 失败清单：对着症状查

| 症状 | 最可能的原因 | 怎么确认 |
|---|---|---|
| 编译直接报"文件不存在" | `myproject_files.cmake` 路径写错（相对 Gem 根） | 对照 `find . -name HeartbeatComponent.cpp` |
| 编译过了，但 `nm` 找不到符号 | 文件没进 `myproject_files.cmake`（坑 18） | `grep Heartbeat myproject_files.cmake` |
| `nm` 有符号，但运行时报"组件未注册" | `MyProjectModule.cpp` 漏了 `CreateDescriptor()` | `grep CreateDescriptor Source/MyProjectModule.cpp` |
| 完全没有日志输出 | Gem 没在 `project.json` 的 `gem_names` 里 | 见 18.5 的三个状态 |
| 有 `SystemComponent activated` 但没有 Heartbeat | `CreateComponent` 失败（descriptor 未注册） | 看日志里有没有 `[Heartbeat] component activated` |
| 心跳间隔不对 | 用了帧数而不是 `deltaTime` | 检查 `OnTick` |
| 退出时崩溃 | `Deactivate()` 顺序错，或忘了 `BusDisconnect()` | 看 `deactivated` 之后有没有崩溃栈 |
| 日志里 `count` 只出现一次 | `Broadcast` 前提前 `return` | 检查 `m_accumulated` 的重置 |

## 19.10 这次实战你实际学到了什么

回头看，你刚才做的每一步都对应文档里的一个概念：

| 你做的事 | 背后的机制 | 对应章节 |
|---|---|---|
| 造两个 GUID | Uuid 做类型身份 | 2.2 |
| 写 `MyProjectRequests` | 请求总线（Single handler） | 8.x / 16.3 |
| 写 `HeartbeatNotifications` | 通知总线（Multiple handler） | 8.x / 16.3 |
| `TickBus::Handler` | 每帧回调总线 | 7.4 |
| `Reflect()` 里两个分支 | 序列化 + 编辑器元数据 | 16.7 |
| `myproject_files.cmake` | 显式文件清单（unity build 的代价） | 3.9 / 坑 18 |
| `CreateDescriptor()` | 组件注册 | 4.4 |
| `CreateComponent` → `Init` → `Activate` | 组件生命周期状态机 | 2.6 |
| `nm -D` 验证 | 符号可见性 `-fvisibility=hidden` | 4.7 |
| `HeadlessServer` | Launcher 变体 | 1.4 / 4.3 |

**这就是"端到端"的意义**：一个 150 行的例子，把所有抽象串成了一条能被验证的链。

---

# 第二十部分 · 自动化测试

> **🎓 L2 / L5** ｜ 前置：第十九部分（先能做出东西，才谈得上测） ｜ 读完能做什么：给自己的 Gem 加测试并在 CI 里跑 ｜ 下一站 → 第二十一部分（性能）

## 20.1 为什么你的项目里没有测试

`MinimalProject` 模板刻意精简掉了。但引擎里**测试是一等公民**：

```bash
ls /workspaces/o3de/Code/Framework/AzTest/AzTest
# AzTest.h  AzTest.cpp  GemTestEnvironment.h  ColorizedOutput.cpp  Printers.cpp …

ls -d /workspaces/o3de/Templates/*/Template/Code/Tests
# CppToolGem  DefaultGem  GraphicsGem  PythonToolGem  UnifiedMultiplayerGem …

ls /workspaces/o3de/Templates/AddTestsToProject/Template/Gem/Tests
# custom_google_test.cmake  test_files.cmake  testmain.cpp  custom_pytest.cmake
```

**证据很明确**：官方为"给已有项目加测试"专门做了一个模板 `AddTestsToProject`。

## 20.2 三件套结构

一个 Gem 的测试由三个文件构成：

```
Gem/Tests/
├── testmain.cpp              ← 测试入口 + AZ_UNIT_TEST_HOOK
├── test_files.cmake          ← 参与编译的测试文件清单
└── custom_google_test.cmake  ← 定义 Targets + 注册到 ctest
```

`testmain.cpp` 的全部内容（官方模板原文）：

```cpp
#include <AzTest/AzTest.h>

TEST(MyTestSuiteName, ExampleTest)
{
    ASSERT_TRUE(true);
}

// If you need to have your own environment preconditions
// you can replace the test env with your own.
AZ_UNIT_TEST_HOOK(DEFAULT_UNIT_TEST_ENV);
```

**两个关键点**：

| 元素 | 作用 | 漏了会怎样 |
|---|---|---|
| `TEST(Suite, Name)` | GoogleTest 宏，定义一个用例 | 没有用例，测试跑 0 个 |
| `AZ_UNIT_TEST_HOOK(...)` | 让测试进程拥有完整的 AZ 环境（分配器、EBus、反射…） | 崩溃在 `AZ::AllocatorInstance` 未初始化 |

**为什么需要 Hook**：O3DE 的代码假设 `AZ::SystemAllocator` 已存在、EBus 上下文已建好。裸 GoogleTest 进程没有这些，所以必须用宏生成自定义 `main`。

## 20.3 加测试的完整步骤

### ① 建文件

```bash
mkdir -p /workspaces/MyProject/Gem/Tests
```

把官方模板三个文件复制过去：

```bash
cp /workspaces/o3de/Templates/AddTestsToProject/Template/Gem/Tests/* \
   /workspaces/MyProject/Gem/Tests/
```

### ② 在 `Gem/CMakeLists.txt` 末尾引入

```cmake
# 放在文件最后
include(Tests/custom_google_test.cmake)
```

### ③ ⚠️ 让测试能找到 Gem 自己的头文件（官方模板缺这一步）

官方模板的 `custom_google_test.cmake` **只给了 `AZ::AzTest` 依赖，没有加 include 目录**。
所以你直接 `#include "Source/HeartbeatComponent.h"` 会**找不到文件**。

两条修法，选一条：

**修法 A（推荐）：改 `Tests/custom_google_test.cmake`，加上 include 目录**

```cmake
if (NOT DISABLE_GEM_TESTS AND PAL_TRAIT_TEST_GOOGLE_TEST_SUPPORTED)
    ly_add_target(
        NAME ${gem_name}.Tests ${PAL_TRAIT_TEST_TARGET_TYPE}
        NAMESPACE Gem
        FILES_CMAKE
            ${CMAKE_CURRENT_LIST_DIR}/test_files.cmake
        INCLUDE_DIRECTORIES
            PRIVATE
                ${CMAKE_CURRENT_LIST_DIR}/..          # ← Gem/ 根，这样 "Source/X.h" 能解析
                ${CMAKE_CURRENT_LIST_DIR}/../Include  # ← 也可以直接 include 公开头
        BUILD_DEPENDENCIES
            PRIVATE
                AZ::AzTest
                Gem::${gem_name}.Private.Object       # ← 你的实现（可选，但常常需要）
    )

    ly_add_googletest(
        NAME Gem::${gem_name}.Tests
    )
endif()
```

**修法 B：用相对路径 include**

```cpp
#include "../Source/HeartbeatComponent.h"   // 从 Gem/Tests/ 出发
```

> 💡 **为什么官方 Gem 的测试不需要这么改**：它们要么把测试目标显式写在
> `Code/CMakeLists.txt` 里并加了 `INCLUDE_DIRECTORIES PRIVATE . Tests`
> （如 `Gems/Atom/RPI`），要么被测代码已经由 `.Public` 目标导出了 include 路径。
> **本项目的 `MyProject` 是模板生成的，没有这些，所以要自己补。**
> 这就是"模板能用 ≠ 模板够用"的典型例子。

### ④ 重新 configure + 编译

```bash
cd /workspaces/MyProject
cmake -B build/linux -S . -G Ninja -DLY_3RDPARTY_PATH=/workspaces/o3de-packages
ninja -C build/linux MyProject.Tests
```

### ⑤ 改 `test_files.cmake` 加自己的测试文件

```cmake
set(FILES
    testmain.cpp
    HeartbeatTests.cpp      # ← 你的测试
)
```

> ⚠️ 又是**显式文件清单**。新测试文件不加进来就不编译（坑 18 的同一条规律）。

## 20.4 写一个真正有用的测试

不要写 `ASSERT_TRUE(true)`。测**第十九部分那个心跳组件**的行为：

`Gem/Tests/HeartbeatTests.cpp`：

```cpp
#include <AzTest/AzTest.h>
#include <AzCore/UnitTest/TestTypes.h>
#include <AzCore/Component/Entity.h>

#include "Source/HeartbeatComponent.h"
#include <MyProject/MyProjectBus.h>

namespace MyProject
{
    // 每个用例一个干净的实体
    class HeartbeatComponentTests : public ::testing::Test
    {
    protected:
        void SetUp() override
        {
            m_entity = aznew AZ::Entity("TestEntity");
            m_component = m_entity->CreateComponent<HeartbeatComponent>();
            ASSERT_NE(m_component, nullptr);
            m_entity->Init();
            m_entity->Activate();
        }

        void TearDown() override
        {
            m_entity->Deactivate();
            delete m_entity;
            m_entity = nullptr;
        }

        AZ::Entity* m_entity = nullptr;
        HeartbeatComponent* m_component = nullptr;
    };

    TEST_F(HeartbeatComponentTests, ComponentActivates)
    {
        // 完整的实体状态机：Constructed → Initializing → Init → Activating → Active
        EXPECT_EQ(m_entity->GetState(), AZ::Entity::State::Active);
    }

    TEST_F(HeartbeatComponentTests, NotificationCarriesIncreasingCount)
    {
        // 订阅通知总线，验证广播参数
        struct Listener : public HeartbeatNotificationBus::Handler
        {
            void OnHeartbeat(int count, double totalTime) override
            {
                m_lastCount = count;
                m_lastTime = totalTime;
                ++m_calls;
            }
            int m_calls = 0;
            int m_lastCount = 0;
            double m_lastTime = 0.0;
        } listener;

        HeartbeatNotificationBus::Handler::BusConnect();
        HeartbeatNotificationBus::Broadcast(&HeartbeatNotifications::OnHeartbeat, 7, 14.0);
        HeartbeatNotificationBus::Handler::BusDisconnect();

        EXPECT_EQ(listener.m_calls, 1);
        EXPECT_EQ(listener.m_lastCount, 7);
        EXPECT_DOUBLE_EQ(listener.m_lastTime, 14.0);
    }

    TEST_F(HeartbeatComponentTests, ServiceIsRegistered)
    {
        // 提供了 MyProjectHeartbeatService 才说明依赖声明正确
        AZ::ComponentDescriptor::DependencyArrayType provided;
        HeartbeatComponent::GetProvidedServices(provided);
        EXPECT_EQ(provided.size(), 1u);
        EXPECT_EQ(provided[0], AZ_CRC_CE("MyProjectHeartbeatService"));
    }
} // namespace MyProject
```

### 这个测试真的在测什么

| 用例 | 验证的是 | 能抓到的真实 bug |
|---|---|---|
| `ComponentActivates` | 生命周期能跑通 | `Activate()` 里 `BusConnect` 写错导致崩溃 |
| `NotificationCarriesIncreasingCount` | EBus 参数传递正确 | `Broadcast` 的参数顺序写反 |
| `ServiceIsRegistered` | 服务依赖声明正确 | 复制粘贴后忘改 service key（会导致两个组件互斥） |

**最后一条最有价值**：`GetProvidedServices` 写错是**编译期查不出来、运行时才冲突**的典型 bug。

## 20.5 跑测试

```bash
# 方式一：直接跑测试二进制
cd /workspaces/MyProject/build/linux
./bin/profile/MyProject.Tests --gtest_filter='Heartbeat*'

# 方式二：通过 ctest（custom_google_test.cmake 已经注册好了）
ctest -C profile --test-dir . -R MyProject
```

期望：

```
[==========] Running 3 tests from 1 test suite.
[----------] 3 tests from HeartbeatComponentTests
[ RUN      ] HeartbeatComponentTests.ComponentActivates
[       OK ] HeartbeatComponentTests.ComponentActivates (0 ms)
...
[  PASSED  ] 3 tests.
```

### 加进 CI

```bash
ninja -C build/linux MyProject.Tests && ctest -C profile --test-dir build/linux -R MyProject
```

**这一步做完，你在 L5（改引擎）阶段才敢动手**——因为改完能立刻知道有没有破坏行为。

## 20.6 测试的边界

| 能测 | 不能测 |
|---|---|
| 纯逻辑（数学、序列化、状态机） | 需要 GPU 的渲染结果 |
| EBus 连通性、参数传递 | 需要 Editor GUI 的交互 |
| 组件生命周期 | 真实网络延迟 |
| 资产加载（用小测试资产） | 需要人眼判断的视觉效果 |
| 反序列化兼容性 | 平台相关的着色器编译 |

**经验法则**：**一个函数如果只依赖输入参数就能判定对错，就值得测。** 需要外部世界才能判断的，留给集成测试/手动验证。

---

# 第二十一部分 · 性能剖析

> **🎓 L4 / L5** ｜ 前置：L3（懂运行时链路） ｜ 读完能做什么：主动找出"哪里慢"，而不是猜 ｜ 下一站 → 第二十二部分（发布）

## 21.1 先分清三种"慢"

性能问题常被混为一谈，但修法完全不同：

| 类型 | 症状 | 工具 | 修法 |
|---|---|---|---|
| **CPU 慢** | 帧时间高、单帧卡 | 采样/统计剖析 | 减少工作量、换算法、并行 |
| **GPU 慢** | GPU 时间高、分辨率敏感 | RHI 的 GPU 计时 | 降 draw call、降分辨率、优化 shader |
| **加载慢** | 进关卡久、卡顿 | 资产管线日志、Streamer | 预加载、拆包、异步 |

**先分清再动手**——大部分人一上来就优化 CPU，结果瓶颈在 GPU。

## 21.2 `AZ_PROFILE` 宏：零成本插桩

O3DE 的剖析入口在 `AzCore/Debug/Profiler.h`：

```cpp
// AzCore/Debug/Profiler.h:31
#define AZ_PROFILE_FUNCTION(category) AZ_PROFILE_SCOPE(category, AZ_FUNCTION_SIGNATURE)

// 用法一：函数级
void MySystem::Update()
{
    AZ_PROFILE_FUNCTION(AzCore);     // 自动记录整个作用域
    ...
}

// 用法二：代码块级
{
    AZ_PROFILE_SCOPE(AzCore, "PhysicsStep");
    ...
}

// 用法三：跨作用域（手动配对）
AZ_PROFILE_BEGIN(AzCore, "Frame");
...
AZ_PROFILE_END(AzCore);
```

### 关键：它默认是"永远开启"的

源码注释写得很清楚：

> `by default we never disable the profiler registers as their overhead should be minimal, you can still do that for your code though.`

所以：

| 事实 | 含义 |
|---|---|
| 默认不关 | 生产构建里也在插桩 |
| 可以整体关掉 | 定义 `AZ_PROFILER_MACRO_DISABLE` 即可，宏变空 |
| 引擎里已有数百处 | `grep -rn "AZ_PROFILE_FUNCTION" Code/Framework/AzCore \| wc -l` |

**这解释了为什么"零成本"需要这么讲究**（16.4 的 `CallstackEntry` 手写 `if` 而不是 `AZ_Assert`）——因为插桩代码一直在热路径上。

### 加到你自己的代码里

```cpp
#include <AzCore/Debug/Profiler.h>

void HeartbeatComponent::OnTick(float deltaTime, AZ::ScriptTimePoint)
{
    AZ_PROFILE_FUNCTION(MyProject);   // ← 加这一行
    ...
}
```

**注意 category 参数必须是一个已经注册的 budget**（见 21.4），否则会断言。

## 21.3 Profiler Gem

`Gems/Profiler` 提供可视化界面（基于 ImGui）：

| 文件 | 功能 |
|---|---|
| `CpuProfiler.cpp` | CPU 采样剖析 |
| `ImGuiCpuProfiler.cpp` | CPU 剖析的 ImGui 面板 |
| `ImGuiHeapMemoryProfiler.cpp` | **堆内存剖析** |
| `ImGuiTreemap.cpp` | 内存树状图 |

启用：

```bash
cd /workspaces/o3de
./scripts/o3de.sh enable-gem -gn Profiler -pp /workspaces/MyProject
```

然后重新 configure + 编译 + 启动，在 ImGui 菜单里找 Profiler 面板。

> ⚠️ 本机 Editor GUI 跑不起来（坑 15），所以 ImGui 面板只能在 HeadlessServer 里看（如果它带 ImGui 渲染）或换一台有真 GPU 的机器。**命令行的统计剖析仍然可用**（见 21.4）。

## 21.4 预算系统（Budget）：另一种测量方式

`AZ_PROFILE_*` 是"事件式"（记录每次进入/退出），还有一种是"统计式"：

```cpp
#include <AzCore/Statistics/StatisticalProfilerProxy.h>

void MySystem::Update()
{
    AZ_PROFILE_INTERVAL_START(MyProject, "MySystem::Update");
    DoWork();
    AZ_PROFILE_INTERVAL_END(MyProject);
}
```

或作用域版：

```cpp
AZ_PROFILE_INTERVAL_SCOPED(MyProject, AZ_CRC_CE("MySystem::Update"));
```

**区别**：

| | `AZ_PROFILE_SCOPE` | `AZ_PROFILE_INTERVAL_*` |
|---|---|---|
| 记录内容 | 每次调用的时间戳 | 累计统计（次数、均值、最大） |
| 适合 | 分析调用树 | 监控长期趋势 |
| 开销 | 略高 | 极低（只累加） |

### 注册自己的 budget

`AZ_PROFILE_SCOPE(MyProject, ...)` 里的 `MyProject` 必须是一个已注册的 budget。注册位置在 SystemComponent 里：

```cpp
#include <AzCore/Debug/Budget.h>

// 在 SystemComponent::Activate() 中
AZ::Debug::Budget* budget = nullptr;
AZ::Debug::Budget::PerformanceIssueType::Create(...);   // 不同版本 API 略有差异
```

> **实用建议**：先复用已有 category（`AzCore`、`AzFramework`、`AzToolsFramework`），
> 确认流程跑通后再注册自己的 budget。这样能避开 API 细节的坑。

## 21.5 一个可复现的测量流程

不要凭感觉优化。按这五步走：

```mermaid
flowchart TD
    A["① 建立基线<br/>记录当前帧时间/加载时间"]
    B["② 找热点<br/>AZ_PROFILE / 采样"]
    C["③ 形成假设<br/>'慢在 X 因为 Y'"]
    D["④ 只改一处<br/>其他都不动"]
    E["⑤ 重测对比<br/>数字说话"]

    A --> B --> C --> D --> E
    E -->|"没改善"| C
    E -->|"改善了"| F["记录结论"]

    style A fill:#e8f4f8
    style E fill:#d5e8d4
```

### 具体到本机

```bash
# ① 基线：HeadlessServer 的启动耗时（日志里有各阶段耗时）
timeout 30 ./build/linux/bin/profile/MyProject.HeadlessServerLauncher \
  --project-path /workspaces/MyProject > /tmp/perf_base.log 2>&1
grep -E "AssetProcessor|seconds|ms" /tmp/perf_base.log | head -20

# ② 编译期基线：改一个文件的影响面（第十一部分 11.5 有完整流程）
cd build/linux && ninja -n MyProject | tail -1

# ③ 运行期基线：如果开了 Profiler Gem，导出统计
grep -i "budget\|profile" /tmp/perf_base.log | head
```

**关键纪律**：每次只改一处。同时改三处，数字变好了你也不知道是哪一处的功劳。

## 21.6 五个常见误区

| 误区 | 为什么错 | 正确做法 |
|---|---|---|
| "我猜是这里慢" | 人的直觉在性能上极不可靠 | 先测，再改 |
| 优化没被调用的代码 | 白费力气 | 先确认热点在调用栈上 |
| 只看平均值 | 掩盖长尾卡顿 | 看 P99 / 最大帧 |
| 在 Debug 构建上测性能 | Debug 无优化，结论全错 | 用 `profile` 或 `release` |
| 一次改多处 | 无法归因 | 一次一处 |

## 21.7 自检

- [ ] CPU 慢和 GPU 慢怎么区分？（提示：改分辨率看帧时间变不变）
- [ ] `AZ_PROFILE_FUNCTION` 默认开启还是关闭？怎么整体关掉？
- [ ] `AZ_PROFILE_SCOPE` 和 `AZ_PROFILE_INTERVAL_SCOPED` 的区别？
- [ ] 为什么要在 `profile` 构建上测性能？
- [ ] 优化流程的第 ④ 步为什么强调"只改一处"？

---

# 第二十二部分 · 发布与打包

> **🎓 L2 / L5** ｜ 前置：L1（有构建产物）+ 第十七部分（懂资产四形态） ｜ 读完能做什么：把项目变成可分发的文件 ｜ 下一站 → 第二十三部分

## 22.1 发布 = 三件事

```mermaid
flowchart LR
    A["① 可执行文件<br/>Launcher + .so"] --> D["可分发的项目"]
    B["② 产品资产<br/>Cache/&lt;platform&gt;/"] --> D
    C["③ 资产包<br/>*.pak + 索引"] --> D

    style D fill:#d5e8d4
```

| 项 | 来源 | 体积参考（本机） |
|---|---|---|
| 可执行 | `build/linux/bin/profile/*Launcher` | 21 KB（真正的逻辑在 .so 里） |
| 动态库 | 同上 `*.so` | `libAzCore.so` 25 MB 等 |
| 产品资产 | `Cache/linux/` | 111 MB / 3042 个资产 |
| 资产包 | `AssetBundler` 生成 | 实测 8 个 `.pak` |

## 22.2 `export-project`：官方打包入口

你的项目根目录**已经有** `export.sh`（模板生成）。它的最后一行是：

```bash
${O3DE_PATH}/scripts/o3de.sh export-project \
  -es ExportScripts/export_source_built_project.py \
  --project-path ${O3DE_PROJECT_PATH} \
  --log-level INFO -out ${OUTPUT_PATH}
```

### 但它有三个前置条件

| 条件 | 现状（本机实测） | 不满足时 |
|---|---|---|
| ① 项目里有 `ExportScripts/` 目录 | ❌ **MinimalProject 没有**（`ls ExportScripts` 为空） | `Invalid export script ... File does not exist` |
| ② o3de CLI 的 Python 环境可用 | ⚠️ 系统 `python3` 缺 `resolvelib` | `ModuleNotFoundError: No module named 'resolvelib'` |
| ③ 有 tools 构建（Editor 等） | ✅ `build/linux` 存在 | 打包时找不到工具 |

### 条件 ①的解法（源码依据）

`scripts/o3de/o3de/export_project.py:347-351` 定义了相对路径的搜索顺序：

```python
possible_root_paths = [project_path,
                       project_path / 'ExportScripts',
                       LOCAL_ENGINE_PATH,
                       LOCAL_ENGINE_PATH / 'scripts' / 'o3de',
                       LOCAL_ENGINE_PATH / 'scripts' / 'o3de' / 'ExportScripts']
```

所以有两条路：

```bash
# 路 A：直接给引擎里的脚本（注意不要带 ExportScripts/ 前缀）
cd /workspaces/o3de
./scripts/o3de.sh export-project \
  -es export_source_built_project.py \
  -pp /workspaces/MyProject \
  -out /workspaces/MyProject/build/export

# 路 B：把脚本拷进项目（export.sh 才能原样跑）
mkdir -p /workspaces/MyProject/ExportScripts
cp /workspaces/o3de/scripts/o3de/ExportScripts/*.py /workspaces/MyProject/ExportScripts/
cd /workspaces/MyProject && ./export.sh
```

**为什么路 A 能成**：`export_source_built_project.py` 不带前缀时，正好命中搜索列表里的 `LOCAL_ENGINE_PATH/scripts/o3de/ExportScripts`。

### 条件 ②的解法

`o3de.sh` 会用 `~/.o3de/Python/venv/<hash>/` 里的解释器（有 `resolvelib`）。
如果直接用系统 `python3` 调 `o3de.py`，就会缺包。**所以始终用 `scripts/o3de.sh`，不要直接 `python3 scripts/o3de.py`。**

## 22.3 AssetBundler 与 seed 清单

引擎不会"把所有资产都打包"——那样包会巨大。它从 **seed** 出发抓依赖。

```
/workspaces/MyProject/AssetBundling/SeedLists/DefaultLevel.seed   ← 已有
```

**seed 是什么**：一组"起点资产"（通常是关卡）。AssetBundler 从这些起点递归抓所有引用到的资产。

```bash
# 生成 pak
cd /workspaces/MyProject
/workspaces/o3de/scripts/o3de.sh bundle-assets \
  --project-path . --platform linux \
  --seed-list AssetBundling/SeedLists/DefaultLevel.seed \
  --output-path build/export/bundles
```

| 概念 | 作用 | 类比 |
|---|---|---|
| **Seed** | 起点资产清单 | 链接时的入口符号 |
| **Bundle** | 一组被打进同一个 pak 的资产 | 一个 `.a` 静态库 |
| **Pak** | 实际打包文件（可加密/压缩） | `.zip` |
| **AssetValidation** | 校验 seed 里引用的资产都存在 | 链接时的未定义符号检查 |

**为什么要有 seed**：如果只按目录打包，你会带上大量用不到的资产（比如测试资产、其他平台的 shader）。从 seed 抓依赖，能精确到"这个关卡实际用到的东西"。

## 22.4 运行时的 pak 读取

打包后运行时不再读散文件，而是通过 `AZ::IO` 的 Archive 层读 pak：

```mermaid
flowchart LR
    Q["AssetManager::GetAsset(id)"] --> C["assetcatalog.xml<br/>（id → 路径）"]
    C --> F["AZ::IO::FileIOBase<br/>（虚拟文件系统）"]
    F --> P["*.pak<br/>（Archive）"]
    F --> D["Cache/&lt;platform&gt;/<br/>（散文件，开发时）"]

    style P fill:#ffe6cc
    style D fill:#d5e8d4
```

这就是 `Archive` Gem 的作用（`gem.json` 摘要：*"provides reading and writing support of file contents"*）。

**开发时读散文件，发布时读 pak——同一份代码。** 这正是第十七部分说的"路径不是身份"的回报：因为运行时用 `AssetId` 查找，所以底层是散文件还是 pak 完全透明。

## 22.5 最小发布检查清单

```bash
# ① 构建干净
ninja -C build/linux -n MyProject.GameLauncher | tail -1     # → no work to do

# ② 资产已处理（catalog 存在且非空）
ls -la Cache/linux/assetcatalog.xml                          # → 1.7 MB 左右

# ③ 符号完整（Launcher 的依赖都能找到）
ldd build/linux/bin/profile/MyProject.GameLauncher | grep "not found" | wc -l   # → 0

# ④ seed 里的资产都存在
/workspaces/o3de/scripts/o3de.sh validate-assets \
  --project-path . --platform linux

# ⑤ 导出
/workspaces/o3de/scripts/o3de.sh export-project \
  -es export_source_built_project.py -pp . -out build/export

# ⑥ 冒烟测试：用导出的产物启动一次
cd build/export && timeout 20 ./MyProject.GameLauncher ...    # 或 HeadlessServer
```

**第 ⑥ 步不能省。** 打包成功 ≠ 能跑起来，最常见的失败是"资产没打进 pak"。

## 22.6 五个常见失败

| 症状 | 原因 | 解法 |
|---|---|---|
| `Invalid export script ... File does not exist` | 项目缺 `ExportScripts/` | 见 22.2 路 A / 路 B |
| `ModuleNotFoundError: resolvelib` | 用了系统 python | 用 `scripts/o3de.sh` |
| 导出成功但启动报"资产找不到" | seed 里没包含该资产 | 加到 seed 或检查引用链 |
| 包特别大 | seed 抓到了测试/示例资产 | 检查 seed 内容，排除测试目录 |
| 换机器跑不起来 | 缺 `.so` 或平台不符 | 检查 `ldd`、确认 `--platform` |

## 22.7 自检

- [ ] 发布包含哪三部分？
- [ ] `ExportScripts/` 在 MinimalProject 里存在吗？不存在怎么办？
- [ ] 为什么不能直接 `python3 scripts/o3de.py`？
- [ ] Seed 的作用是什么？为什么不全量打包？
- [ ] 运行时怎么做到"散文件和 pak 用同一份代码"？

---

# 第二十三部分 · 迁移对照：从 Unity / Unreal 过来

> **🎓 L0 ｜ 前置：无 ｜ 读完能做什么：把已有经验映射到 O3DE，少走一周弯路 ｜ 下一站 → 第二部分**

## 23.1 概念对照

| 你熟悉的 | O3DE 对应 | 关键差异 |
|---|---|---|
| GameObject / Actor | **Entity** | Entity **没有行为**，只是 Id + 组件列表 |
| MonoBehaviour / ActorComponent | **Component**（`AZ::Component`） | 必须**成对**写编辑器版和运行时版（或用同一个） |
| Prefab / Blueprint | **Prefab** | 支持嵌套 + Override，**没有可视化脚本**（那是 ScriptCanvas） |
| Scene | **Level**（磁盘）+ **World**（内存）+ **Scene**（渲染） | 三层概念被拆开了（17.8） |
| Asset | **`AssetId` + 产品资产** | 运行时用 UUID 不是路径（17.4） |
| Asset Import Settings | **`.setreg` + Scene Processing** | 配置在 Gem/项目层，不在每个资产上 |
| Unity Package / UE Plugin | **Gem** | 更重：代码 + 资产 + 工具 + 清单 |
| Player Settings | **`project.json` + `.setreg`** | |
| `Debug.Log` | **`AZ_Printf` / `AZ_TracePrintf`** | 需要 category |
| `Update()` | **`AZ::TickBus::Handler::OnTick`** | 或者用 `AZ::TickBus::QueueFunction` |
| Singleton / Manager | **`AZ::Interface<T>`** 或 EBus | 有编译期策略可调 |
| Event System / Delegate | **EBus** | 策略是编译期的，不是运行时的 |
| `GetComponent<T>()` | **`entity->FindComponent<T>()`** | |
| ScriptableObject | **自定义资产类型**（`CustomAssetExample`） | 要写 Asset Builder |
| Build Settings | **Variant**（Editor/Game/Server/Headless） | 见 4.3 |
| Gizmo / Editor Extension | **`AzToolsFramework` + DocumentPropertyEditor** | |
| Timeline | **Maestro / Track View** | |
| NavMesh | **RecastNavigation** | |
| Shader Graph | **Atom 的 Material Canvas / `.azsl`** | |

## 23.2 五条心智差异（比概念表更重要）

| # | 你原来的习惯 | O3DE 的现实 | 为什么要这样 |
|---|---|---|---|
| 1 | 改引擎源码来定制 | **写 Gem，永远不改引擎** | 升级引擎时你的改动不会丢 |
| 2 | 运行时按路径加载 | **运行时只有 `AssetId`** | 重命名/移动不破坏引用 |
| 3 | 组件挂在 GameObject 上就会跑 | **必须先在模块里注册 descriptor** | 反射系统需要知道类型存在 |
| 4 | 新文件自动参与编译 | **必须加进 `*_files.cmake`** | unity build + 显式清单（坑 18） |
| 5 | 编译完就能跑 | **还要过 Asset Processor** | 资产是"编译"出来的（17.2） |

**第 4 条最坑人**：它静默失败，没有警告。这是从 Unity 过来的人第一周最常卡住的地方。

## 23.3 你原来的经验哪些还有效

| 仍然有效 | 需要重学 |
|---|---|
| C++ 基本功、调试技巧 | 构建系统（CMake + Ninja + unity build） |
| 图形学概念（PBR、阴影、后处理） | Atom 的 Pass/FeatureProcessor 组织方式 |
| 组件化思维 | 组件必须注册 + 成对写编辑器版 |
| 性能分析方法论 | O3DE 的剖析工具链 |
| 版本控制实践 | 哪些进版本控制（`Assets/` 进，`Cache/` 不进） |
| 网络同步的基本概念 | O3DE 的快照 + 增量模型（第十三部分） |

## 23.4 最容易踩的五个迁移陷阱

| 陷阱 | 表现 | 正确做法 |
|---|---|---|
| 想"先跑起来再理解" | 编译 3 小时就放弃了 | 先读第三部分，**分批编译** |
| 把 Gem 当 Unity Package | 期望拖进去就能用 | Gem 要 configure + 编译 |
| 改 `Cache/` 里的文件 | 一重编就被覆盖 | 只改 `Assets/` 源资产 |
| 用文件名找资产 | 换平台/重命名后崩 | 用 `AssetId` |
| 不看日志的 category | `AZ_Printf("MyProject", ...)` 被过滤掉 | 确认日志级别与 category |

## 23.5 最后一个建议

如果你已经会 Unity 或 Unreal，**不要试图用 O3DE 复刻你熟悉的工作流**。
O3DE 的设计选择（UUID 身份、编译期策略、Gem 隔离）是有代价的——它换来了**大团队协作和长期可维护性**。

先按它的方式做一遍（第十九部分的实战），再判断哪些地方你想改。**在理解之前改造，通常是在给自己挖坑。**

---

# 第二十四部分 · 引擎目录结构剖析

> **🎓 L0 / L1 ｜ 前置：无 ｜ 读完能做什么：拿到一个需求能立刻知道去哪个目录找代码 ｜ 下一站 → 第三部分（编译）**
>
> 本章所有数字都是在本机 `/workspaces/o3de` 上实测的（`du -sh` 与 `wc -l`）。

## 24.1 先看全貌

```
/workspaces/o3de/                      448 MB · 30103 个文件
├── Code/                               80 MB   ← 全部 C++ 框架与工具
├── Gems/                              244 MB   ← 全部功能插件（79 个）
├── AutomatedTesting/                   49 MB   ← 官方的"超级测试项目"
├── Assets/                            8.7 MB   ← 引擎内建资产（字体、图标）
├── scripts/                           4.1 MB   ← o3de CLI 与构建脚本（Python）
├── Templates/                         3.7 MB   ← 项目/Gem 模板（16 个）
├── cmake/                             2.0 MB   ← 构建系统的全部规则
├── Tools/                             1.4 MB   ← 独立小工具
├── Registry/                          208 KB   ← 引擎级 .setreg 配置
├── python/                            108 KB   ← 运行时的 Python 绑定辅助
├── Docker/                             28 KB   ← 容器化构建
├── engine.json                          4 KB   ← ★ 引擎清单（最该先读的一个文件）
└── CMakeLists.txt                      12 KB   ← ★ 构建根文件
```

**三个数字先记住**：

| 项 | 值 | 说明 |
|---|---|---|
| 源码总体积 | 448 MB | 其中 `.git` 58 MB，实际源码 ~390 MB |
| 文件数（不含 `.git`） | **30 103** | |
| C++ 文件数（仅 `Code/`） | **5 921** | `.h` / `.cpp` |
| 已编译产物 | 8.0 GB | 构建树是源码的 **18 倍** |

> ⚠️ **构建树比源码大 18 倍**是第一个反直觉点。所以第三部分强调"别删构建树，
> 删了要重编几小时"——它比源码更贵。

## 24.2 六个必读文件

进一个陌生仓库，先读这六个，胜过读一万行代码：

| 文件 | 读它得到什么 | 本机实测 |
|---|---|---|
| `engine.json` | 引擎的名字、版本、GUID、依赖 | 引擎版本 **2.6.0** |
| `CMakeLists.txt` | 构建入口：先 include 哪些 cmake 模块 | **30 个** `include(cmake/...)` |
| `cmake/PAL.cmake` | 平台抽象层的规则 | 决定 `Platform/` 目录怎么被找到 |
| `cmake/Gems.cmake` | Gem 如何被发现与装配 | 第四部分讲的就是它 |
| `Registry/bootstrap.setreg` | 启动时要加载哪些东西 | 运行时行为的源头 |
| `Templates/DefaultProject/Template/project.json` | 一个"标准项目"长什么样 | **23 个 Gem** |

`CMakeLists.txt` 的 include 顺序本身就是架构说明（实测 **30 行** `include(cmake/...)`）：

```cmake
include(cmake/Policy.cmake)             # CMake 策略
include(cmake/LySet.cmake)              # 变量与目录约定
include(cmake/GeneralSettings.cmake)    # 全局编译选项
include(cmake/Version.cmake)            # 版本号
include(cmake/OutputDirectory.cmake)    # 产物放哪（bin/profile 等）
include(cmake/CompilerSettings.cmake)   # 编译器选择（自动挑最高版本 clang）
include(cmake/CompilerLauncher.cmake)   # clang-scan-deps 启动器
include(cmake/PAL.cmake)                # 平台抽象层
include(cmake/Dependencies.cmake)       # 第三方包（o3de-packages）
include(cmake/3rdParty.cmake)           # 3rdParty:: 目标定义
include(cmake/LYPython.cmake)           # 内嵌 Python
include(cmake/LYWrappers.cmake)         # ly_add_target 等包装函数
include(cmake/Gems.cmake)               # Gem 系统
include(cmake/Monolithic.cmake)         # 单体构建支持
include(cmake/SettingsRegistry.cmake)   # 配置合并
```

**读法**：先看 `LYWrappers.cmake`（`ly_add_target` 的定义），因为**每个**模块的 CMakeLists 都在用它。

## 24.3 `Code/` —— 引擎本体（80 MB / 5921 个 C++ 文件）

```
Code/
├── Framework/       54 MB  ← ★ 可复用的框架层（不含 Editor UI）
├── Tools/           16 MB  ← 工具程序（AssetProcessor、ProjectManager…）
├── Editor/         8.7 MB  ← 编辑器主程序（O3DE 自己的"应用"）
├── Legacy/         2.1 MB  ← CryEngine 遗留代码（⚠️ 不要改）
└── LauncherUnified/ 404 KB ← 所有 Launcher 的公共代码
```

### `Code/Framework/` —— 分层最清晰的地方

| 模块 | 体积 | C++ 文件 | 行数 | 依赖 | 一句话 |
|---|---|---|---|---|---|
| **AzCore** | 24 MB | **1585** | **469 829** | 仅 3rdParty | 引擎的地基：内存、反射、EBus、容器、IO |
| **AzFramework** | 8.0 MB | 738 | 122 455 | AzCore + AzNetworking | 通用应用框架：组件、资产、输入、流式加载 |
| **AzToolsFramework** | 15 MB | **1221** | **245 701** | AzCore + AzQtComponents | **编辑器专用**框架：Prefab 编辑、属性面板、撤销栈 |
| **AzQtComponents** | 5.1 MB | 344 | — | Qt + AzFramework | Qt 控件库（样式、Dock、面包屑…） |
| **AzNetworking** | 1.4 MB | 170 | — | AzCore | 网络传输层（TCP/UDP，第十三部分） |
| **AzTest** | 340 KB | 37 | — | AzCore + googletest | 测试框架（第二十部分） |
| **AtomCore** | 196 KB | 20 | — | — | Atom 的极小核心（⚠️ 不是渲染器） |
| **AzGameFramework** | 56 KB | 5 | — | AzFramework | 游戏运行时框架（很薄） |
| **AzManipulatorTestFramework** | 184 KB | 21 | — | — | 操纵器测试辅助 |
| **AzAndroid** | 140 KB | 0 | — | — | 仅 CMake 与资源配置 |

**这张表最重要的信息是依赖方向**（源码验证，看各家 `CMakeLists.txt` 的 `BUILD_DEPENDENCIES`）：

```mermaid
graph BT
    CORE["<b>AzCore</b><br/>469 829 行<br/>主库只依赖 3rdParty"]
    NET["AzNetworking"]
    FW["<b>AzFramework</b><br/>122 455 行"]
    GFW["AzGameFramework<br/>（5 个文件）"]
    QTC["AzQtComponents"]
    TOOLS["<b>AzToolsFramework</b><br/>245 701 行<br/>⚠️ 仅编辑器"]

    CORE --> NET
    CORE --> FW
    NET --> FW
    FW --> GFW
    FW --> QTC
    CORE --> QTC
    QTC --> TOOLS
    CORE --> TOOLS

    style CORE fill:#ffe6cc
    style TOOLS fill:#e1d5e7
```

**读图规则：箭头从「被依赖者」指向「依赖者」。** 即 `AzCore --> AzFramework` 表示
**AzFramework 依赖 AzCore**（AzCore 在下层，不依赖任何上层模块）。
所以"箭头指向我"= "我依赖它"。

三条硬规律：

| 规律 | 验证方法 | 意义 |
|---|---|---|
| `AzCore` **主库**只依赖 3rdParty | `sed -n '/NAME AzCore /,/^)/p' AzCore/CMakeLists.txt \| grep "AZ::"` → 空 | 它能进任何进程，包括 AssetProcessor |
| `AzToolsFramework` **不被任何运行时库**依赖 | `grep -rl "AZ::AzToolsFramework" --include=CMakeLists.txt Code/Framework/ Gems/` → 只有 `AzManipulatorTestFramework`、`AzQtComponents` 的 **gallery 应用**、以及它自己的测试 | 发布版可以完全不带编辑器代码 |
| `AzFramework` **不依赖** Qt | `grep -i qt AzFramework/CMakeLists.txt` → 空 | 服务器/无头模式不需要 GUI |

> ⚠️ **验证时要注意 target 边界**：`grep AZ:: AzCore/CMakeLists.txt` **不返回空**——
> 那是 `AzCoreTests` 等**测试目标**依赖 `Az::AzTest` 与 `AZ::AzCore` 自身。
> 要只查主库，用上面第一条的 `sed` 命令框定 target 范围。
> 同理 `AzQtComponents` 里出现 `AZ::AzToolsFramework` 只属于 `O3DEQtControlGallery`
> 这个**演示应用**，不是库依赖，所以不构成循环依赖。

**第三条最实用**：如果你的代码只需要跑服务器，就绝不要 include `AzToolsFramework` 的头文件——那会把 Qt 拖进你的依赖树。

### `AzCore` 内部结构（最值得先读的模块）

```bash
ls /workspaces/o3de/Code/Framework/AzCore/AzCore | head -40
```

按"你会关心什么"分组：

| 子目录 | 内容 | 对应章节 |
|---|---|---|
| `EBus/` | 事件总线（8 个 policy 维度） | 第八 + 十六部分 |
| `Component/` | Entity / Component / 生命周期 | 第七 + 十九部分 |
| `Serialization/` | SerializeContext / EditContext / DataPatch | 16.7 |
| `RTTI/` | `AZ_RTTI`、BehaviorContext、类型信息 | 2.2 / 16.7 |
| `Memory/` | 分配器链（System / Pool / HPHA） | 2.5 |
| `std/` | **自研 STL**（`AZStd::vector` 等） | 2.11 |
| `Math/` | Vector3 / Matrix4x4 / Quaternion / Aabb | — |
| `Asset/` | `AssetId` / `Asset<T>` / AssetManager | 17.4 |
| `IO/` | 虚拟文件系统、Archive、Streamer | 22.4 |
| `Task/` | TaskGraph（依赖图并行） | 2.8 |
| `Jobs/` | 旧式 Job 系统（⚠️ 逐步被 Task 取代） | 2.8 |
| `Settings/` | Settings Registry（`.setreg` 合并） | 9.2 |
| `Console/` | CVar（`AZ_CVAR`） | 9.8 |
| `Debug/` | `AZ_Printf`、`AZ_PROFILE_*`、崩溃处理 | 21.2 |
| `Module/` | 动态模块加载 | 4.4 |
| `Name/` | `AZ::Name`（CRC32 名字） | 2.11 |
| `Interface/` | `AZ::Interface<T>`（轻量单例） | 8.6 |

**`std/` 是自研 STL**——这一点最容易让新手困惑：看到 `AZStd::vector` 不要以为是笔误，
它是 O3DE 自己实现的容器（为了统一分配器，见 2.11）。

### `Code/Tools/` —— 独立工具程序

| 子目录 | 体积 | 是什么 | 什么时候会碰到 |
|---|---|---|---|
| `AssetProcessor/` | 5.5 MB | **资产管线守护进程** | 每次改资产（17.5） |
| `SceneAPI/` | 3.2 MB | FBX/glTF 导入（Scene Builder） | 模型导入出问题 |
| `TestImpactFramework/` | 2.1 MB | 只跑"受改动影响"的测试 | CI 优化 |
| `ProjectManager/` | 1.9 MB | 项目选择器 GUI（**本机能跑**） | 启动 O3DE |
| `AssetBundler/` | 964 KB | 打 `.pak` 包（22.3） | 发布 |
| `LuaIDE/` | 948 KB | Lua 调试器 | 用 Lua 时 |
| `CrashHandler/` | 332 KB | 崩溃转储 | 线上问题 |
| `SerializeContextTools/` | 240 KB | 序列化诊断 | 存档不兼容 |
| `AzTestRunner/` | 216 KB | 测试运行器 | 第二十部分 |

### `Code/Editor/` vs `Code/Tools/ProjectManager/`

两个都是 GUI 程序，但职责完全不同：

| | `Code/Editor/` | `Code/Tools/ProjectManager/` |
|---|---|---|
| 是什么 | **O3DE 编辑器**（关卡、场景、组件） | **项目选择器**（启动页） |
| 体积 | 8.7 MB / 131 307 行 | 1.9 MB |
| 渲染依赖 | ✅ 链接 `Gem::Atom_RPI.*` + `Atom_Feature_Common`，**运行时必须有可用的 RHI 后端**（Linux = Vulkan） | ❌ 纯 Qt，不碰 GPU |
| 对应可执行 | `Editor` | `O3DEProjectManager` |
| 产物大小 | 21 KB（逻辑在 `libEditorLib.so` 32 MB） | 独立可执行 |

> 源码依据：`Code/Editor/CMakeLists.txt` 的 `BUILD_DEPENDENCIES` 里有
> `Gem::Atom_RPI.Edit` / `Gem::Atom_RPI.Public` / `Gem::Atom_Feature_Common.Public`；
> 而 `Code/Tools/ProjectManager/CMakeLists.txt` 里搜 `Vulkan` 为空。

**这也解释了为什么本机 ProjectManager 能跑而 Editor 不能**——前者不碰 GPU。

### `Code/Legacy/` —— 不要碰

```
Code/Legacy/
├── CryCommon/     ← CryEngine 的公共头
└── CrySystem/     ← CryEngine 的系统层
```

O3DE 从 Lumberyard / CryEngine 演化而来，这部分是历史包袱。**新代码绝不依赖它**，
但删掉会导致大量老代码编译失败（很多 Gem 还在 include）。

### `Code/LauncherUnified/` —— 所有可执行的"公共壳"

只有 404 KB，却生成了**全部 Launcher**：

```
LauncherUnified/
├── Launcher.cpp          通用启动逻辑
├── Game.cpp              游戏入口
├── Server.cpp            服务器入口
├── Unified.cpp           Unified 变体入口
├── LauncherProject.cpp   项目专属入口（每个项目一份）
└── launcher_generator.cmake  ← ★ 用 CMake 生成各 Launcher 的 main
```

**这就是为什么 `Editor` 只有 21 KB**（3.10 的问题）：绝大多数 Launcher 的 `main()`
都是从这些**通用源文件**编译出来的，真正逻辑在共享库里。

## 24.4 `Gems/` —— 功能插件（244 MB，最大的一块）

```
Gems/                                    83 个目录 / 79 个 gem.json
├── Atom/                                48 MB  ← 渲染器本体
│   ├── RHI/                             14 MB  ← 渲染硬件接口（Vulkan/DX12/Metal 抽象）
│   ├── RPI/                             7.2 MB ← 渲染管线接口（Pass / Material / Shader）
│   ├── Feature/                         19 MB  ← 27 个 FeatureProcessor（后处理、阴影…）
│   ├── Tools/                           4.7 MB ← 材质编辑器等 GUI
│   ├── Asset/                           3.3 MB ← 资产 Builder（shader 编译等）
│   ├── Component/                       168 KB ← 组件（Mesh、Light…）
│   └── Bootstrap/                       188 KB ← 渲染器初始化
├── AtomLyIntegration/                   10 MB  ← Atom 与组件层的桥
├── AtomContent/                         2.4 MB ← 材质类型等资产
├── PhysX/                                       ← 物理
├── EMotionFX/                                   ← 动画
├── LyShine/                                     ← 运行时 UI
├── ScriptCanvas/                                ← 可视化脚本
├── Multiplayer/                                 ← 联机（第十三部分）
└── ...                                          ← 共 79 个（第十八部分有全表）
```

### Atom 的五个子目录，对应五个不同的问题

```mermaid
graph TD
    RHI["<b>RHI</b>（14 MB）<br/>怎么跟 GPU 说话<br/>Vulkan / DX12 / Metal"]
    RPI["<b>RPI</b>（7.2 MB）<br/>怎么组织一次渲染<br/>Pass / Material / Shader / Scene"]
    FEAT["<b>Feature</b>（19 MB）<br/>渲染什么效果<br/>27 个 FeatureProcessor"]
    TOOLS["<b>Tools</b>（4.7 MB）<br/>怎么在编辑器里配<br/>Material Editor / Pass Canvas"]
    ASSET["<b>Asset</b>（3.3 MB）<br/>资产怎么编译<br/>shader 编译、材质转换"]

    RHI --> RPI
    RPI --> FEAT
    ASSET --> RPI
    TOOLS --> RPI
    FEAT --> TOOLS

    style RHI fill:#ffe6cc
    style FEAT fill:#d5e8d4
```

**这个划分回答了一个常见困惑**："我想加个新的后处理效果，改哪？"
→ 写一个 `FeatureProcessor` 放进 `Atom/Feature/`，**不需要碰 RHI**。

### `Gems/` 的通用内部结构

绝大多数 Gem 都是这个形状（以 `PhysX` 为例）：

```
Gems/<Name>/
├── gem.json                 ← 清单：名字、版本、依赖、summary
├── CMakeLists.txt           ← 构建规则
├── Code/
│   ├── Source/              ← 运行时 + 编辑器代码（常按 Editor/ 分）
│   └── Include/             ← 公开头文件（别的模块能 include 的）
├── Assets/                  ← 源资产（材质、贴图、prefab）
├── Registry/                ← .setreg（配置）
└── Platform/                ← 平台特化
```

**判断"能不能被别人用"看 `Code/Include/`**：只有放这里的头文件才是公开 API。
`Code/Source/` 里的是实现细节，别人 include 了就是耦合。

## 24.5 `cmake/` —— 构建系统全部规则（2.0 MB）

这是最容易被忽略、但**出问题最难查**的地方。

| 文件 | 作用 | 你会因为什么来找它 |
|---|---|---|
| `LYWrappers.cmake` | `ly_add_target` / `ly_add_googletest` / `ly_add_autogen` 的定义 | 想知道某个 CMake 函数能填什么参数 |
| `CompilerSettings.cmake` | 编译器选择与选项 | 想改 clang 版本、加编译选项 |
| `CompilerLauncher.cmake` | `clang-scan-deps` 启动器 | **坑 4**（`CLANG_SCAN_DEPS-NOTFOUND`） |
| `PAL.cmake` | 平台抽象层：`Platform/` 目录怎么被发现 | 加新平台 |
| `Gems.cmake` | Gem 发现与装配 | 第四部分 4.2 |
| `Configurations.cmake` | `debug` / `profile` / `release` 三种配置 | 产物为什么在 `bin/profile/` |
| `Dependencies.cmake` | 第三方包解析（`o3de-packages`） | 包下载失败 |
| `3rdParty.cmake` | 定义 `3rdParty::Xxx` 目标 | 想加第三方库 |
| `Monolithic.cmake` | 单体构建（把 Gem 编进可执行） | 发布包结构 |
| `SettingsRegistry.cmake` | `.setreg` 的构建期处理 | 配置没生效 |
| `UnitTest.cmake` | 测试目标注册 | 第二十部分 |
| `Packaging.cmake` | 打包规则 | 第二十二部分 |
| `3rdParty/Platform/Linux/*.cmake` | 各第三方包的版本与路径 | 特定包版本不对 |
| `Platform/Linux/CompilerSettings_linux.cmake` | Linux 专属编译选项 | 想改 `-fvisibility` 等 |

### 三个最该知道的 CMake 事实（实测）

```cmake
# ① 编译器自动选择（cmake/Platform/Linux/CompilerSettings_linux.cmake）
#    没设 CC/CXX 时，自动挑 /usr/bin/clang-[0-9]* 里版本最高的 → 本机 clang-18

# ② 产物目录由 OutputDirectory.cmake 决定
#    bin/profile/、lib/profile/  ← 这个 "profile" 就是配置名，不是"性能分析"

# ③ 每个模块必须显式列文件（LYWrappers.cmake 的 FILES_CMAKE 参数）
#    → 这就是坑 18 的制度根源：没有通配符，漏了就静默不编译
```

## 24.6 `scripts/` —— Python 工具链（4.1 MB）

```
scripts/
├── o3de.py            ← ★ CLI 入口（所有 o3de.sh 子命令）
├── o3de/o3de/*.py     ← 各子命令实现
├── build/             ← 构建相关的辅助脚本
├── ctest/             ← 测试运行
├── commit_validation/ ← 提交前检查（clang-format、license…）
├── license_scanner/   ← 许可证扫描
└── migration/         ← 版本迁移工具
```

`scripts/o3de/o3de/` 里的每个文件对应一个子命令：

| 文件 | 子命令 | 用途 |
|---|---|---|
| `enable_gem.py` | `enable-gem` | 改 `project.json` 的 `gem_names`（9.7） |
| `disable_gem.py` | `disable-gem` | 反向操作 |
| `export_project.py` | `export-project` | 发布打包（22.2） |
| `register.py` | `register` | 注册引擎/项目/Gem 到 manifest |
| `manifest.py` | — | `~/.o3de/` 下的清单管理 |
| `android.py` / `android_support.py` | `android-*` | Android 构建 |
| `download.py` / `git_utils.py` | `download` | 拉取依赖 |
| `engine_template.py` | `create` | **从模板创建项目/Gem** |

> ⚠️ **别直接 `python3 scripts/o3de.py`** —— 系统 Python 通常缺 `resolvelib` 等包。
> 始终用 `scripts/o3de.sh`（它会用 `~/.o3de/Python/venv/<hash>/`，见 22.2）。

## 24.7 `Templates/` —— 16 个模板

```
Templates/
├── MinimalProject/           ← 你用的就是这个（4 个 Gem）
├── DefaultProject/           ← 更完整（23 个 Gem）
├── ScriptOnlyProject/        ← 只有脚本，无 C++
├── DefaultGem/               ← 标准 Gem（含 Tests/）
├── CppToolGem/               ← 带 GUI 的 C++ 工具 Gem
├── PythonToolGem/            ← Python 工具 Gem
├── GraphicsGem/              ← 图形扩展 Gem
├── AssetGem/                 ← 只放资产的 Gem
├── PrebuiltGem/              ← 预编译 Gem
├── UnifiedMultiplayerGem/    ← 联机 Gem 模板
├── DefaultComponent/         ← 单个组件模板
├── ScriptCanvasNode/         ← ScriptCanvas 节点模板
├── AddTestsToProject/        ← ★ 给已有项目加测试（第二十部分）
├── GemRepo/                  ← Gem 仓库模板
└── RemoteRepo/               ← 远程仓库模板
```

**用法**：

```bash
# 看有哪些模板
./scripts/o3de.sh create-project --help

# 常用：从模板建 Gem
./scripts/o3de.sh create-gem -gn MyNewGem -gp /workspaces/MyProject/Gem \
  -tg DefaultGem
```

### 三个项目的 Gem 数量对比（实测）

| 项目 | `gem_names` 数量 | 用途 |
|---|---|---|
| `/workspaces/MyProject` | **4** | 最小可运行（MyProject + Atom + CameraFramework + ImGui） |
| `Templates/DefaultProject` | **23** | "标准"项目：物理、动画、音频、UI、脚本全带 |
| `AutomatedTesting` | **59** | 官方测试项目，几乎全开 |

**这三个数字是最好的"启用决策"参考**（18.3）：从 4 开始，按需往上加，别从 23 开始往下删。

## 24.8 `AutomatedTesting/` —— 49 MB 的"超级项目"

```
AutomatedTesting/
├── project.json            ← 59 个 Gem（几乎全开）
├── Assets/                 ← 大量测试资产
├── Gem/                    ← 测试专用 Gem
├── AutomationScripts/      ← 自动化脚本
├── Editor/ Config/ ...     ← 各类测试配置
└── CMakeLists.txt
```

**它不是示例，是官方的测试工程**。体积 49 MB 里绝大部分是测试资产。

| 你什么时候会用到它 | 怎么用 |
|---|---|
| 想知道某个功能"官方怎么用的" | 在它的 `Assets/` 里搜对应资产品类 |
| 想验证引擎改动没破坏行为 | 跑它的测试（第二十部分） |
| 想看 59 个 Gem 全开需要多少资源 | 直接编译它（很慢） |

## 24.9 `o3de-packages/` —— 第三方依赖（4.2 GB，**不在源码树里**）

```
/workspaces/o3de-packages/
├── packages/            4.2 GB · 68 个条目（34 个包 + 34 个 .stamp）
└── downloaded_packages/ 空（下载缓存）
```

**体积排名（实测）**：

| 包 | 体积 | 为什么这么大 |
|---|---|---|
| `qt-5.15.2` | **2.3 GB** | 编辑器 UI 全套（含 WebEngine、QML…） |
| `PhysX-4.1.2` | 888 MB | 物理引擎 + 预编译库 + 调试符号 |
| `PhysX-5.1.1` | 525 MB | 同时带两个大版本 |
| `assimp-5.4.3` | 118 MB | 模型导入（FBX/glTF/OBJ…） |
| `pyside2` | 115 MB | Qt 的 Python 绑定 |
| `SPIRVCross` | 98 MB | SPIR-V 反射/交叉编译 |
| `DirectXShaderCompilerDxc` | 72 MB | 在 Linux 上也能编 HLSL |
| `openimageio-opencolorio` | 43 MB | 图像与色彩管理 |
| `vulkan-validationlayers` | 36 MB | Vulkan 校验层（**调试用，发布不要**） |

**几条实用认知**：

| 认知 | 后果 |
|---|---|
| **Qt 占了一半以上的体积** | 不写编辑器时，Qt 是纯负担 |
| **PhysX 两个版本并存 1.4 GB** | 只用 5.1 的话另一个是浪费 |
| `vulkan-validationlayers` 只在调试需要 | 发布产物不含它 |
| 包是**预编译的**（带 `.stamp` 标记） | 不会在你机器上重新编译，所以首次 configure 只是下载/解压 |
| 目录**不在** `o3de/` 里 | 升级引擎不用重下第三方包——这是刻意设计 |

> 💡 **想省磁盘**：确认只用 PhysX 5.1 后，可删 `PhysX-4.1.2.29882248-rev8-linux`（888 MB）。
> 但如果某个 Gem 声明依赖 4.1，configure 会失败——**先备份或确认依赖再删**。

## 24.10 六个"目录为何这样分"的设计理由

| 划分 | 如果合并会怎样 | 所以必须分开 |
|---|---|---|
| `Code/Framework` vs `Code/Editor` | 运行时也得链 Qt + Vulkan | 服务器/无头构建能瘦下来 |
| `AzCore` vs `AzFramework` | 所有东西一个库，最小依赖变巨大 | `AzCore` 能进任何进程（如 AssetProcessor） |
| `Code/` vs `Gems/` | 加功能要改引擎源码 | Gem 独立编译、可裁剪（4.5） |
| `o3de/` vs `o3de-packages/` | 4.2 GB 二进制进 git | 升级引擎不重下依赖 |
| `Assets/` vs `Cache/` | 运行时解析源格式（17.2 的代价） | 加载快、跨平台 |
| `cmake/` 独立成目录 | 规则散落各处 | 一处修改全局生效，也一处出错全局出错 |

## 24.11 三条实用路线：拿到需求后怎么找代码

这是本章最该记住的部分。**不要靠目录名猜，用 grep 定位。**

### 路线 A：我要改渲染效果

```bash
A=/workspaces/o3de/Gems/Atom/Feature/Common

# ① 先找 FeatureProcessor（渲染功能的标准扩展点）
#    注意：不在顶层 Source/ 里直接列出，而是在各效果子目录中
grep -rln "class .*FeatureProcessor" $A/Code/Source/ | head -5
# → Code/Source/AuxGeom/AuxGeomFeatureProcessor.h
# → Code/Source/CubeMapCapture/CubeMapCaptureFeatureProcessor.h
# → Code/Source/Decals/DecalTextureArrayFeatureProcessor.h   ...

# ② 找具体效果（以景深为例）
grep -rn "class .*Pass" $A/Code/Source/PostProcess/ | head -3
# → Code/Source/PostProcess/DepthOfField/DepthOfFieldSettings.h:56: friend class DepthOfFieldBokehBlurPass;

# ③ 找 shader（注意：源码目录叫 PostProcess，资产目录叫 PostProcessing）
ls $A/Assets/Shaders/PostProcessing/ | head -4
# → AcesOutputTransformLut.azsl / AcesOutputTransformLut.shader ...
```
→ 落点：`Gems/Atom/Feature/Common/Code/Source/<效果名>/`

> ⚠️ **两处命名不一致，是实测踩到的**：代码侧 `Code/Source/PostProcess/`（单数），
> 资产侧 `Assets/Shaders/PostProcessing/`（动名词）。**别靠推测拼路径，先 `ls` 确认。**

### 路线 B：我要加一个组件/接口

```bash
# ① 找同类组件的实现当模板
grep -rln "AZ_COMPONENT_IMPL" /workspaces/o3de/Gems/ | head -5
# → Gems/Archive/Code/Source/Clients/ArchiveSystemComponent.cpp
# → Gems/SkyAtmosphere/Code/Source/Clients/SkyAtmosphereSystemComponent.cpp
# → Gems/LyShine/Code/Source/UiHierarchyInteractivityToggleComponent.cpp  ...
#   ⚠️ 别只在 Gems/Atom/Component/ 下搜——那里没有 AZ_COMPONENT_IMPL

# ② 找 EBus 接口定义（公开 API 都在 Include）
grep -rn "using .*Bus = AZ::EBus<" \
  /workspaces/o3de/Code/Framework/AzFramework/AzFramework/ --include=*.h | head -3
# → AzFramework/Entity/EntityOwnershipServiceBus.h:68: using EntityOwnershipServiceNotificationBus = ...
```
→ 落点：你自己的 `Gem/`（**不是** `Code/`）

### 路线 C：我要找引擎某个机制的实现

```bash
# ① 从名字搜（⚠️ 注意导出宏会插在 class 后面）
grep -rln "class AZCORE_API SettingsRegistryImpl" /workspaces/o3de/Code/Framework/
#   → AzCore/Settings/SettingsRegistryImpl.h

# ② 从函数名反查
grep -rn "SerializeContext::ReflectClassInternal" \
  /workspaces/o3de/Code/Framework/AzCore/AzCore/ | head -2
#   → AzCore/Serialization/SerializeContext.cpp:887
```
→ 落点：`Code/Framework/<模块>/`

> ⚠️ **`grep "class SettingsRegistry"` 为什么搜不到**：真实声明是
> `class AZCORE_API SettingsRegistryImpl final` —— **导出宏夹在 `class` 和类名之间**。
> 所以搜类名时，**只搜类名本身**（`grep -rln "SettingsRegistryImpl"`），
> 或者用 `class .*SettingsRegistry`（带 `.*` 跳过宏）。
> **这条经验对所有带 `AZCORE_API` / `AZFRAMEWORK_API` 的类都成立。**

### 一张速查表

| 你想找的东西 | 去哪 |
|---|---|
| 内存、反射、EBus、容器、IO、Task | `Code/Framework/AzCore/AzCore/` |
| 组件、资产、输入、流式加载、Spawnable | `Code/Framework/AzFramework/AzFramework/` |
| Prefab 编辑、属性面板、撤销栈 | `Code/Framework/AzToolsFramework/AzToolsFramework/` |
| Qt 控件与样式 | `Code/Framework/AzQtComponents/` |
| 渲染（RHI/RPI/Feature） | `Gems/Atom/` |
| 物理 | `Gems/PhysX/` |
| 动画 | `Gems/EMotionFX/` |
| UI | `Gems/LyShine/` |
| 可视化脚本 | `Gems/ScriptCanvas/` |
| 联机 | `Gems/Multiplayer/` |
| 资产管线 | `Code/Tools/AssetProcessor/` + `Code/Tools/SceneAPI/` |
| 构建规则 | `cmake/` |
| CLI 工具 | `scripts/o3de/o3de/` |
| 项目/Gem 模板 | `Templates/` |
| 引擎级配置 | `Registry/*.setreg` |

## 24.12 五条建议（按优先级）

### ① 先确认 `compile_commands.json` 可用，再读代码

没有它，clangd 的跳转/补全全会失效（第十部分）。**本机实测状态是好的**：

```bash
ls -la /workspaces/o3de/compile_commands.json
# lrwxrwxrwx → /workspaces/o3de-build/compile_commands.json

du -h /workspaces/o3de-build/compile_commands.json
# 31M
python3 -c "import json;print(len(json.load(open('/workspaces/o3de/compile_commands.json'))))"
# 8081  ← 条目数
```

| 项 | 值 |
|---|---|
| 符号链接 | `o3de/compile_commands.json → o3de-build/compile_commands.json` |
| 真实文件 | 31 MB |
| 条目数 | **8081**（已由 `tools/gen-compdb.py` 把 unity build 展开到单文件） |

**为什么需要展开**：unity build 下 compdb 只有 1454 条（每个 unity 块一条），
clangd 拿它去匹配单个 `.cpp` 会匹配不上。展开后 7977 条 → 现在 8081 条，才能精确命中。

**如果链接失效**（换机器、删了构建树）：

```bash
cd /home/hwg/tmp/ai/tmp/O3DE-学习文档
./tools/refresh-compdb.sh all      # 重新生成
```

**顺序很重要**：`compile_commands.json` 依赖构建树存在。**先编译（第三部分），再配 clangd**。

### ② 用符号索引代替读文件

30 103 个文件不可能读完。**只读你 grep 出来的那 3–5 个**：

```bash
# 找定义
grep -rn "class MyThing" Code/Framework/
# 找谁用了它
grep -rln "MyThing" Code/ Gems/ | head
```

### ③ 从 `AzCore` 开始，不要从 `Editor` 开始

`Editor` 是**消费者**——它调用所有框架。从它读会看到一堆"看不懂的调用"。
`AzCore` 是**被依赖者**——它不依赖任何东西，读完你在 `Editor` 里看到的调用都有解释。

**建议顺序**：`AzCore/EBus` → `AzCore/Component` → `AzCore/Serialization` → `AzFramework/Asset` → 你的领域。

### ④ 把 `Gems/<你关心的>` 当"最佳实践手册"

想看"一个成熟模块怎么写"，读 `PhysX` 或 `Atom` 的 `CMakeLists.txt` 和目录布局，
比读任何教程都准。**它们的结构就是模板**。

### ⑤ 不要碰的三个地方

| 目录 | 为什么 |
|---|---|
| `Code/Legacy/` | CryEngine 遗留，改了没人维护，且会牵连一堆老代码 |
| `cmake/3rdParty/` | 改错会导致 configure 全面失败，且很难回滚 |
| `Cache/`（在项目里） | 全是生成物，AP 会覆盖你的修改 |

## 24.13 自检

- [ ] `Code/Framework` 里哪个模块只依赖 3rdParty？为什么这个性质重要？
- [ ] `AzToolsFramework` 和 `AzFramework` 的分界线是什么？发布版需要前者吗？
- [ ] 为什么 `Code/Editor` 需要 Vulkan 而 `Code/Tools/ProjectManager` 不需要？
- [ ] `Gems/Atom/` 下 RHI 与 Feature 的职责分别是什么？想加后处理该改哪个？
- [ ] `o3de-packages/` 为什么不在 `o3de/` 目录里？
- [ ] `AutomatedTesting` 开了多少个 Gem？这对你的启用决策有什么启发？
- [ ] 拿到"我想加个自定义资产格式"的需求，按 24.11 的路线你会先 grep 什么？

---

# 第二十五部分 · 自顶向下的改造路线

> **🎓 L0 → L2 的"路线图"章 ★** ｜ 前置：无（本章就是告诉你从哪开始） ｜ 读完能做什么：**知道"改造 O3DE"分五级，并知道每一级该读哪章、改哪个文件**
>
> 这一章不引入新知识，它解决另一个问题：**你已经有 25 章资料了，但不知道按什么顺序用。**
> 本章把它们排成一条通往"能自己改造项目 / 定制 Editor"的路线。

## 25.1 先分清"改造"的五个层级

"改造 O3DE"是个太宽的词。实际有五个层级，**难度差 100 倍，混在一起谈必然失败**：

| 级 | 你要做的事 | 改哪里 | 会不会丢 | 需要什么前置 |
|---|---|---|---|---|
| **C1 配置** | 换分辨率、改键位、调参数 | `Registry/*.setreg`、`game.cfg` | 不会 | 会用文本编辑器 |
| **C2 加功能（用现成）** | 开关 Gem、用内置组件搭场景 | `project.json` 的 `gem_names` | 不会 | 懂 [18.3 启用决策](#183-启用决策不同项目该开哪些) |
| **C3 写自己的 Gem** | 新组件、新 EBus 接口、新资产类型 | `Gem/`（**你自己的目录**） | 不会 | 懂 [19 实战](#第十九部分--端到端实战从零做一个能跑的功能) |
| **C4 定制 Editor** | 加菜单、加面板、加视口交互 | `Gem/` 的 **Tools 变体** | 不会 | 懂 C3 + 变体机制（4.3） |
| **C5 改引擎** | 改 `AzCore` / `Atom` 源码 | `Code/`、`Gems/Atom/` | ⚠️ **升级引擎时会丢** | 懂 [16 EBus 内部](#第十六部分--深挖策略驱动的零成本抽象) + L5 |

```mermaid
graph LR
    C1["C1 配置<br/>改 .setreg"] --> C2["C2 加 Gem<br/>改 gem_names"]
    C2 --> C3["C3 写 Gem<br/>组件 + EBus"]
    C3 --> C4["C4 定制 Editor<br/>Tools 变体"]
    C4 --> C5["C5 改引擎<br/>⚠️ 会丢"]

    style C3 fill:#d5e8d4
    style C4 fill:#ffe6cc
    style C5 fill:#ffcccc
```

**90% 的需求停在 C3 或 C4。** 只有当 C4 做不到时，才考虑 C5——而 C4 几乎什么都能做。

> 💡 **判断你现在在第几级**：如果你的问题里出现"我要让编辑器里多个按钮/面板/菜单"→ C4；
> "我要让游戏里某东西动起来"→ C3；"我要改渲染/物理的核心行为"→ 先确认 C4 的扩展点是否够，
> 大概率够。

## 25.2 自顶向下的学习顺序（用现有资料）

"自顶向下"= **先看清整体，再决定改哪，最后才钻实现**。下面是按这个原则排出的顺序，
每一步都指向已有章节。

```mermaid
flowchart TD
    A["① 看整体<br/>1 天<br/>24章 目录结构 + 17章 概念地图"] --> B["② 跑起来<br/>1 天 + 5h<br/>25章 从零编译"]
    B --> C["③ 改第一处<br/>半天<br/>19章 端到端实战"]
    C --> D["④ 懂边界<br/>2 天<br/>4章 插件 + 8章 EBus"]
    D --> E["⑤ 定制 Editor<br/>1 周<br/>本章 25.4-25.6"]
    E --> F["⑥ 需要时再深入<br/>16章 EBus内部 + 12章 Atom + 21章 性能"]

    style C fill:#d5e8d4
    style E fill:#ffe6cc
```

### 每一"步"具体读什么、产出什么

| 步 | 读哪几章 | 产出（可验证） | 不要做的事 |
|---|---|---|---|
| **① 看整体** | [24 目录结构](#第二十四部分--引擎目录结构剖析) → [17 概念地图](#第十七部分--概念地图从资产讲起)（17.1–17.7）→ [18 子系统地图](#第十八部分--子系统地图79-个-gem-都在干什么) | 能回答"我想加的功能大概在哪个目录、属于哪个 Gem 类" | ❌ 别读 `Code/Framework` 的源码 |
| **② 跑起来** | [3 编译](#第三部分--编译步骤与原理)（照着做）→ 3.8–3.10（为什么） | `ninja -n Editor` → `no work to do` | ❌ 别一边编一边改代码 |
| **③ 改第一处** | [19 端到端实战](#第十九部分--端到端实战从零做一个能跑的功能)（**逐字跟做**）→ [3.11 加/删组件](#311-如何添加或移除组件与-gem) | `libMyProject.so` + 日志里 `component activated` | ❌ 别跳过"两处注册" |
| **④ 懂边界** | [4 插件式架构](#第四部分--插件式架构)（4.2/4.3/4.5）→ [8 通信机制](#第八部分--通信机制)（EBus + `AZ::Interface`） | 能画出"我的 Gem 如何被加载"的链路 | ❌ 别背 policy 的 8 个维度 |
| **⑤ 定制 Editor** | **本章 25.3–25.6** → 4.3（变体）→ 7 章（组件反射） | Editor 里出现你的菜单/面板 | ❌ 别在 runtime 变体里 include `AzToolsFramework` |
| **⑥ 按需深入** | 16（EBus 内部）/ 12（Atom）/ 21（性能）/ 13（网络） | — | ❌ 别为了"学完"而读 |

### 三条"不要"（比"要做什么"更重要）

1. **不要从第 1 章顺序读到第 25 章。** 那是参考手册的排法，不是学习路径。
2. **不要在没跑通 ② 之前读 ⑤。** 定制 Editor 需要能编译 Tools 变体。
3. **不要试图先"完全理解"再动手。** 第 ③ 步只有 150 行代码，但它建立的直觉比读 3000 行源码强。

## 25.3 加 Gem：从"想要一个能力"到"它真的在跑"

这是 C2 级操作，但**有四个环节，漏一个就白做**（3.11.5 讲过组件版，这里是 Gem 版全流程）。

```mermaid
flowchart TD
    A["① 找到对应 Gem<br/>18 章分类表 / grep gem.json"] --> B["② enable-gem<br/>改 project.json"]
    B --> C["③ 重新 configure<br/>生成新目标"]
    C --> D["④ 编译<br/>ninja"]
    D --> E["⑤ 验证：模块被加载<br/>看日志"]
    E --> F["⑥ 验证：功能可用<br/>用它的组件/资产"]

    style C fill:#ffe6cc
    style F fill:#d5e8d4
```

### 分步命令（以加 PhysX 为例，本机实测过路径）

```bash
# ① 确认 Gem 存在，并搞清它的目录层级（PhysX 是多层的！）
find /workspaces/o3de/Gems -maxdepth 4 -name gem.json | grep -i physx
# → Gems/PhysX/Core/PhysX5/gem.json 等 5 个

# ② 启用（自动改 project.json 的 gem_names）
cd /workspaces/o3de
./scripts/o3de.sh enable-gem -gn PhysX5 -pp /workspaces/MyProject

# ③ 重新 configure（这一步最容易漏）
cd /workspaces/MyProject
cmake -B build/linux -S . -G Ninja -DLY_3RDPARTY_PATH=/workspaces/o3de-packages

# ④ 编译（只要 Gem 自己，先不编 Launcher）
ninja -C build/linux -j3 MyProject

# ⑤ 验证模块被加载（这是唯一客观判据）
cd /workspaces/o3de-build/bin/profile
timeout 70 ./O3DE.HeadlessServerLauncher --project-path /workspaces/MyProject 2>&1 \
  | grep -iE "Attempting to load module.*PhysX"

# ⑥ 验证功能：PhysX 的组件是否出现在可用列表里
grep -rl "AZ_COMPONENT_IMPL" /workspaces/o3de/Gems/PhysX/Core/Code/Source/ | head
```

### 四个环节的"漏了会怎样"（都实测过）

| 漏了 | 现象 | 判据 |
|---|---|---|
| ② `enable-gem` | 完全没变化 | `grep PhysX project.json` 为空 |
| ③ 重新 configure | `ninja: error: unknown target 'Gem::PhysX5'` | 目标图没更新（3.4） |
| ④ 编译 | 运行时 `Failed to load module` | `.so` 不存在 |
| ⑤⑥ 验证 | 你以为成功了，其实没生效 | 日志里没有 `Attempting to load module` |

> ⚠️ **Gem 名字要精确**：`PhysX` 是父目录，真正的 `gem_name` 是 `PhysX5` / `PhysX4` / `PhysXCommon`。
> 用错名字 → `enable-gem` 报 `Gem not found`。**永远先 `python3 -c "import json;print(json.load(open('...gem.json'))['gem_name'])"` 确认。**

## 25.4 定制 Editor：四条路径，按门槛从低到高

这是 C4 级，也是你问题的重点。**"定制 Editor"不是一个技术，是四个不同门槛的技术**。

| 路径 | 能做什么 | 门槛 | 需要写 C++ 吗 | 本机能否验证 |
|---|---|---|---|---|
| **P1 组件 + 反射** | 组件出现在编辑器的 Add Component 菜单，属性面板可调 | ★☆☆ | 会写组件即可 | ⚠️ 需 GUI |
| **P2 Editor 系统组件 + ActionManager** | 加菜单项、工具栏按钮、快捷键 | ★★☆ | 是（约 60 行） | ⚠️ 需 GUI |
| **P3 自定义属性面板（DPE）** | 改组件在 Inspector 里的呈现方式 | ★★★ | 是（更多） | ⚠️ 需 GUI |
| **P4 ComponentMode / Manipulator** | 视口内的自定义交互（拖拽手柄等） | ★★★★ | 是（最复杂） | ⚠️ 需 GUI |

### 前置：Editor 代码必须放在 Tools 变体里（这是最容易错的地方）

O3DE 的 **runtime 二进制不能依赖 Qt / AzToolsFramework**（24.3 验证过 `AzFramework` 不依赖 Qt）。
所以你写 Editor 代码时，**必须放进 Tools 变体**，否则：

- 要么发布版被迫拖进整个 Qt + 编辑器框架
- 要么链接失败（runtime 目标里 include 了 `AzToolsFramework` 的头）

**标准做法**（`Templates/DefaultGem` 和 `Gems/Camera` 都是这个结构）：

```
Gem/Code/
├── Source/Clients/          ← 只进 Clients/Servers 变体（游戏运行时）
├── Source/Tools/            ← 只进 Tools 变体（Editor）★ 你的 Editor 代码放这
└── CMakeLists.txt           ← 用 PAL_TRAIT_BUILD_HOST_TOOLS 守护 Tools 目标
```

`Gems/Camera/Code/CMakeLists.txt:52-77` 的真实写法（**这就是模板**）：

```cmake
if (PAL_TRAIT_BUILD_HOST_TOOLS)
    ly_add_target(
        NAME ${gem_name}.Editor GEM_MODULE       # ← Editor 专用模块
        NAMESPACE Gem
        FILES_CMAKE
            camera_editor_files.cmake            # ← 只列 Editor 相关文件
        BUILD_DEPENDENCIES
            PRIVATE
                AZ::AzToolsFramework             # ← 关键：只有这里才能依赖它
                Legacy::EditorCommon
    )
    ly_create_alias(NAME ${gem_name}.Tools    NAMESPACE Gem TARGETS Gem::${gem_name}.Editor)
    ly_create_alias(NAME ${gem_name}.Builders NAMESPACE Gem TARGETS Gem::${gem_name}.Editor)
endif()
```

**三个关键点**：

| 元素 | 作用 | 漏了会怎样 |
|---|---|---|
| `PAL_TRAIT_BUILD_HOST_TOOLS` | 只在能跑工具的平台上构建（Linux/Windows，不含 Android/iOS） | 移动端构建失败 |
| `FILES_CMAKE ..._editor_files.cmake` | **Editor 文件单独一个清单** | Editor 代码被打进 runtime → 依赖爆炸 |
| `.Tools` / `.Builders` 别名指向它 | 让 `enable-gem` 时能连到 Editor | 你的 Editor 功能不会出现在编辑器里 |

> ⚠️ **你的 `MyProject` 目前没有这套结构**：`grep -c PAL_TRAIT_BUILD_HOST_TOOLS Gem/CMakeLists.txt` = **0**，
> 且 `Gem/Source/` 是扁平的（无 `Clients/`、`Tools/`）。
> 因为 `MinimalProject` 模板只给了最小运行时 Gem。**要做 C4，第一步就是补这个结构。**

## 25.5 P1：让组件出现在编辑器里（最低门槛）

如果你只做过 [19 的实战](#第十九部分--端到端实战从零做一个能跑的功能)，你已经具备 P1 了。
在 `Reflect()` 里加一行，组件就会出现在 Add Component 菜单：

```cpp
if (auto* editContext = serializeContext->GetEditContext())
{
    editContext->Class<HeartbeatComponent>("Heartbeat", "每隔固定时间广播心跳")
        ->ClassElement(AZ::Edit::ClassElements::EditorData, "")
            ->Attribute(AZ::Edit::Attributes::AppearsInAddComponentMenu, AZ_CRC_CE("Game"))
            //                                                            ↑ "Game" = 运行时组件
            //                                                    "Editor" = 编辑器专用组件
            ->Attribute(AZ::Edit::Attributes::Category, "MyProject")   // 菜单里的分组
        ->DataElement(AZ::Edit::UIHandlers::Default, &HeartbeatComponent::m_intervalSeconds,
            "Interval (s)", "心跳间隔")
            ->Attribute(AZ::Edit::Attributes::Min, 0.1f)               // 属性面板的限制
        ;
}
```

| 属性 | 效果 | 不加的后果 |
|---|---|---|
| `AppearsInAddComponentMenu` | 出现在 Add Component 菜单 | 组件存在但**搜不到** |
| `Category` | 菜单分组（默认 `Other`） | 挤在 `Other` 里，难找 |
| `Min` / `Max` | 属性面板的拖动范围 | 可以输入负数，运行时出错 |
| `AZ::Edit::UIHandlers::Default` | 用默认控件（数字框/文本框） | — |

**为什么这一级不需要 Tools 变体**：`EditContext` 在 `AzCore` 里（16.7 讲过它依附
`SerializeContext`），**不属于 `AzToolsFramework`**。所以 P1 代码可以直接放在普通
Gem 里，runtime 和 editor 共用。

> 💡 **这是最容易获得成就感的一步**：几十行代码，编辑器里就多出你的组件。
> 但它**必须能跑 Editor GUI**——本机跑不起来（[坑 15](#坑-15editor-段错误本机硬限制)），
> 所以本机只能验证到"编译通过 + 反射注册成功"，看不到界面。

## 25.6 P2：给 Editor 加一个菜单项（完整可抄）

这是"定制 Editor"最典型的入门任务。**完整机制在源码里是这样**：

```mermaid
flowchart TD
    A["你的 Editor 系统组件<br/>继承 ActionManagerRegistrationNotificationBus::Handler"] --> B["BusConnect<br/>（Activate 时）"]
    B --> C["O3DE 发出注册钩子<br/>OnActionRegistrationHook"]
    C --> D["你调 ActionManagerInterface<br/>RegisterAction"]
    C --> E["你调 MenuManagerInterface<br/>AddActionToMenu"]

    style A fill:#ffe6cc
    style D fill:#d5e8d4
```

### 完整的四个钩子（源码实证）

`AzToolsFramework/ActionManager/ActionManagerRegistrationNotificationBus.h` 提供 8 个钩子，
常用的四个是：

| 钩子 | 什么时候被调用 | 你在这里做什么 |
|---|---|---|
| `OnActionRegistrationHook()` | 注册动作时 | `RegisterAction` 定义"一个可执行的动作" |
| `OnMenuRegistrationHook()` | 注册菜单时 | `RegisterMenu` 新建菜单 |
| `OnMenuBindingHook()` | 绑定菜单项时 | `AddActionToMenu` 把动作挂到菜单 |
| `OnToolBarRegistrationHook()` | 注册工具栏时 | 加工具栏按钮 |

> ⚠️ **顺序很重要**：动作必须先注册，才能在 `OnMenuBindingHook` 里被引用。
> 这就是为什么有**两个不同的钩子**，而不是一个。

### 可照抄的最小实现

`Gems/Camera/Code/Source/CameraEditorSystemComponent.cpp` 是官方最干净的示例。
下面是它的**结构骨架**（去掉业务逻辑）：

```cpp
#include <AzToolsFramework/ActionManager/Action/ActionManagerInterface.h>
#include <AzToolsFramework/ActionManager/Menu/MenuManagerInterface.h>
#include <AzToolsFramework/ActionManager/ActionManagerRegistrationNotificationBus.h>
#include <AzToolsFramework/Editor/ActionManagerIdentifiers/EditorContextIdentifiers.h>
#include <AzToolsFramework/Editor/ActionManagerIdentifiers/EditorMenuIdentifiers.h>

class MyEditorSystemComponent
    : public AZ::Component
    , public AzToolsFramework::ActionManagerRegistrationNotificationBus::Handler
{
public:
    AZ_COMPONENT_DECL(MyEditorSystemComponent);

    void Activate() override
    {
        // 关键：连上"注册钩子"总线
        AzToolsFramework::ActionManagerRegistrationNotificationBus::Handler::BusConnect();
    }
    void Deactivate() override
    {
        AzToolsFramework::ActionManagerRegistrationNotificationBus::Handler::BusDisconnect();
    }

    // ① 注册一个动作
    void OnActionRegistrationHook() override
    {
        auto* actionManager = AZ::Interface<AzToolsFramework::ActionManagerInterface>::Get();
        if (!actionManager) return;

        const AZStd::string_view actionId = "o3de.action.myproject.doSomething";

        AzToolsFramework::ActionProperties props;
        props.m_name        = "Do Something";
        props.m_description = "我的第一个编辑器动作";
        props.m_category    = "My Project";          // 属性面板里的分类

        actionManager->RegisterAction(
            AzToolsFramework::EditorIdentifiers::MainWindowActionContextIdentifier,
            actionId,
            props,
            []() { AZ_Printf("MyProject", "[Editor] action triggered!"); });
    }

    // ② 把动作挂到已有菜单（这里是 Tools 菜单）
    void OnMenuBindingHook() override
    {
        auto* menuManager = AZ::Interface<AzToolsFramework::MenuManagerInterface>::Get();
        if (!menuManager) return;

        menuManager->AddActionToMenu(
            AzToolsFramework::EditorIdentifiers::ToolsMenuIdentifier,   // 已有菜单
            "o3de.action.myproject.doSomething",
            100);                                                       // 排序索引
    }
};
```

### 可用的菜单标识符（实测列表）

`AzToolsFramework/Editor/ActionManagerIdentifiers/EditorMenuIdentifiers.h` 里定义了现成菜单：

```
o3de.menu.editor.file        o3de.menu.editor.edit
o3de.menu.editor.file.recent o3de.menu.editor.edit.modify
o3de.menu.editor.game        o3de.menu.editor.edit.settings
...
```

**优先挂到已有菜单**（`AddActionToMenu`），比自己建菜单（`RegisterMenu` + `AddMenuToMenuBar`）省事得多。

### 为什么必须"系统组件"而不是普通组件

| | 普通组件（`AZ::Component`） | 系统组件（SystemComponent） |
|---|---|---|
| 何时创建 | 挂在 Entity 上，随场景加载 | **随应用启动**，不用场景 |
| 适合做什么 | 场景里的行为 | **编辑器级功能**（菜单、面板、全局钩子） |
| 注册位置 | `Module.cpp` 的 `m_descriptors` | 同上 + `GetRequiredSystemComponents()` |

菜单这种东西**不属于任何场景**，所以必须是系统组件。你的 `MyProjectSystemComponent`
已经是系统组件了（在 `GetRequiredSystemComponents()` 里返回），可以直接仿照它建一个
`MyProjectEditorSystemComponent`。

### 本机的验证边界（必须说清楚）

| 你能验证的 | 怎么验证 | 本机结果 |
|---|---|---|
| Editor 代码能编译 | `ninja MyProject.Editor` | ✅ 可以（语法 + 链接都可验） |
| 依赖没搞错（没把 Qt 拖进 runtime） | `ldd libMyProject.so \| grep -i qt` → 空 | ✅ 可以 |
| 菜单真的出现 | 打开 Editor，看菜单栏 | ❌ **本机 Editor 崩溃（坑 15）** |
| 动作被触发 | 点菜单，看日志 | ❌ 同上 |

> ⚠️ **诚实结论**：**定制 Editor 的"写"能在这台机器上完成并编译验证，
> 但"看效果"必须在有真 GPU 的机器上做。**
> 这是环境限制（lavapipe 软件 Vulkan 触发 HPHA 断言），不是你的代码问题。
> 替代验证手段：`clangd --check` 保证语法、`ninja` 保证链接、`ldd` 保证依赖隔离。

## 25.7 P3 / P4：更深的 Editor 定制（知道有这回事即可）

当你需要"改 Inspector 的呈现"或"视口里的交互手柄"时：

| 路径 | 核心概念 | 入口文件 | 什么时候需要 |
|---|---|---|---|
| **P3 DocumentPropertyEditor（DPE）** | 用 DOM 描述 UI，而不是手写 Qt 控件 | `AzFramework/DocumentPropertyEditor/`（21 个头文件）+ `AzToolsFramework/UI/DocumentPropertyEditor/` | 组件属性面板要特殊呈现（自定义行、内嵌按钮） |
| **P4 ComponentMode** | 编辑组件时接管视口交互（拖拽手柄） | `AzToolsFramework/ComponentMode/`（9 个头文件）+ `AzToolsFramework/Manipulators/` | 需要"在视口里直接拖"的编辑体验 |

**相关目录（真实存在，可 `ls` 确认）**：

```bash
ls /workspaces/o3de/Code/Framework/AzToolsFramework/AzToolsFramework/ComponentMode/
ls /workspaces/o3de/Code/Framework/AzFramework/AzFramework/DocumentPropertyEditor/
ls /workspaces/o3de/Code/Framework/AzToolsFramework/AzToolsFramework/Manipulators/
```

**建议：不要一开始就碰 P3/P4。** 先做 P2（菜单），它能把"Editor 扩展"的完整机制
（系统组件 + Tools 变体 + ActionManager 钩子）走一遍，之后 P3/P4 只是换扩展点。

## 25.8 改造项目时最容易失败的 8 个地方

| # | 错误 | 症状 | 正确做法 | 详见 |
|---|---|---|---|---|
| 1 | 新 `.cpp` 没进 `*_files.cmake` | 静默不编译 | 改清单 | [3.11.1](#3111-添加一个组件三处必改--一处可选) |
| 2 | 组件没进 `m_descriptors` | 运行时找不到组件 | 加 `CreateDescriptor()` | [19.6](#196-第-4-步注册两处缺一不可) |
| 3 | Editor 代码写进 runtime 变体 | 发布版拖进 Qt / 链接失败 | 放 `Source/Tools/` + `.Editor` 目标 | 25.4 |
| 4 | 加 Gem 后没重新 configure | `unknown target` | 重跑 `cmake` | 25.3 |
| 5 | Gem 名字用错（`PhysX` vs `PhysX5`） | `enable-gem` 报 not found | 读 `gem.json` 的 `gem_name` | 25.3 |
| 6 | 想改的效果其实有配置项 | 白改代码 | 先查 `.setreg` / CVar | [9.8](#98-cvar) |
| 7 | 直接改 `Code/` 引擎源码 | 升级引擎时全丢 | 先找 C4 扩展点 | 25.1 |
| 8 | 改 `Cache/` 里的文件 | 被 AP 覆盖 | 只改 `Assets/` | [17.3](#173-资产的四种形态) |

### 遇到问题时的排查顺序（别跳步）

```mermaid
flowchart TD
    A["现象不对"] --> B{"能编译吗"}
    B -->|不能| C["查第十五部分<br/>坑 1-12（编译期）"]
    B -->|能| D{"模块被加载吗"}
    D -->|否| E["查 gem_names / configure / 日志<br/>25.3 四个环节"]
    D -->|是| F{"组件被注册吗"}
    F -->|否| G["查 CreateDescriptor<br/>3.11.1 第 2 处"]
    F -->|是| H["查反射 / EditContext 属性<br/>25.5"]

    style C fill:#ffe6cc
    style H fill:#d5e8d4
```

## 25.9 现有资料的"使用说明书"

最后，把 25 章按"你遇到什么问题该翻哪章"重新索引一遍：

| 你现在的状态 | 翻这一章 | 一句话 |
|---|---|---|
| 刚拿到源码，不知从哪下手 | [24](#第二十四部分--引擎目录结构剖析) | 目录结构与规模实测 |
| 名词看不懂（资产 / Prefab / Gem…） | [17](#第十七部分--概念地图从资产讲起) | 概念地图 |
| 想做某功能，不知有没有现成 Gem | [18](#第十八部分--子系统地图79-个-gem-都在干什么) | 79 个 Gem 分类 |
| 要编译，照着做 | [3](#第三部分--编译步骤与原理) | 7 阶段 + 验证门 |
| 要理解为什么这样编译 | [3](#第三部分--编译步骤与原理) | 原理 + 加/删组件 |
| 要写第一个能跑的功能 | [19](#第十九部分--端到端实战从零做一个能跑的功能) | 150 行完整实战（已验证到"组件激活"） |
| 要给自己加测试 | [20](#第二十部分--自动化测试) | AzTest 三件套 |
| 要定制 Editor | **本章 25.4–25.6** | 四条路径 + 菜单示例 |
| 想懂插件怎么装配 | [4](#第四部分--插件式架构) | CMake 清单 + 三趟扫描 |
| 想懂 EBus 底层 | [16](#第十六部分--深挖策略驱动的零成本抽象) | 模板特化 + 零成本 |
| 想懂渲染 | [12](#第十二部分--atom-渲染管线代码走读) | RHI / Pass / FeatureProcessor |
| 想懂联机 | [13](#第十三部分--多人网络架构) | 快照 + 增量 |
| 要发布 | [22](#第二十二部分--发布与打包) | export + pak |
| 要测性能 | [21](#第二十一部分--性能剖析) | AZ_PROFILE |
| 出问题了 | [14](#第十四部分--踩坑与排错) | 19 个坑 |
| 从 Unity/UE 过来 | [23](#第二十三部分--迁移对照从-unity--unreal-过来) | 概念映射 |

## 25.10 你的第一个改造任务（建议顺序）

按这个顺序做，每个都能独立验证，**失败时能确定是哪一步的问题**：

| # | 任务 | 改哪个文件 | 验证方式 | 预计 |
|---|---|---|---|---|
| 1 | 加一个组件，让它出现在 Add Component 菜单 | `Source/Xxx.cpp` 的 `Reflect()` | 编译 + `nm` 查符号 | 1 h |
| 2 | 给组件加可调属性（`Min`/`Max`/`Description`） | 同上 | 编译 | 30 min |
| 3 | **补 Tools 变体结构**（`Source/Clients` + `Source/Tools` + `.Editor` 目标） | `CMakeLists.txt` + 新 `*_editor_files.cmake` | `ninja MyProject.Editor` 成功 | 2 h |
| 4 | 加一个 Editor 系统组件，注册一个动作 | `Source/Tools/XxxEditorSystemComponent.cpp` | 编译 + 链接 | 2 h |
| 5 | 把动作挂到已有菜单 | 同上 `OnMenuBindingHook` | 编译 | 30 min |
| 6 | （需 GPU 机器）打开 Editor，看到菜单并点击 | — | 日志出现 `action triggered` | 10 min |

**做完 3 和 4，你就已经"能定制 Editor"了。** 剩下的 P3/P4（DPE / ComponentMode）是同一套机制的不同扩展点。

## 25.11 自检

- [ ] "改造"的五个层级（C1–C5）分别是什么？你现在在哪一级？
- [ ] 为什么 Editor 代码必须放 Tools 变体？漏了会有什么后果？
- [ ] `MyProject` 目前缺哪套结构才做不了 P2？
- [ ] `AppearsInAddComponentMenu` 的 `"Game"` 和 `"Editor"` 有什么区别？
- [ ] `OnActionRegistrationHook` 和 `OnMenuBindingHook` 为什么要分开？
- [ ] 本机能验证到哪一步、哪一步必须换机器？
- [ ] 加 Gem 的四个环节，漏了第三个（重新 configure）会看到什么错误？

# 附录 A · 常用命令速查

## 编译

```bash
# 引擎 configure
cmake -B /workspaces/o3de-build -S /workspaces/o3de -G Ninja \
  -DCMAKE_BUILD_TYPE=Profile -DLY_3RDPARTY_PATH=/workspaces/o3de-packages

# 分批编译
ninja -C /workspaces/o3de-build -j4 AzCore
ninja -C /workspaces/o3de-build -j4 AzFramework AzGameFramework
ninja -C /workspaces/o3de-build -j4 AzQtComponents AzToolsFramework
ninja -C /workspaces/o3de-build -j4 Editor

# 项目 configure + build
cmake -B /workspaces/MyProject/build/linux -S /workspaces/MyProject -G Ninja \
  -DCMAKE_BUILD_TYPE=Profile -DLY_3RDPARTY_PATH=/workspaces/o3de-packages
ninja -C /workspaces/MyProject/build/linux -j3 MyProject.GameLauncher Editor

# 只编你的 Gem（最快的语法检查）
ninja -C /workspaces/MyProject/build/linux -j3 Gem::MyProject
```

## 诊断

```bash
ninja -C <build> -n <target>             # 干跑
ninja -C <build> -d explain -n           # 解释为什么重编
ninja -C <build> -t targets all          # 列出所有目标
ninja -C <build> -t compdb               # 导出编译数据库
ninja -C <build> -j4 -k 0                # 失败继续
ldd <binary> | grep "not found"          # 依赖检查
nm -D --defined-only <lib.so> | grep -c EBus   # 符号检查
gdb -batch -ex run -ex "bt 30" --args <binary> # 崩溃现场
```

## 项目与 Gem

```bash
./scripts/o3de.sh create-project -pp <路径> -pn <名> -tn MinimalProject
./scripts/o3de.sh enable-gem -gn PhysX -pp /workspaces/MyProject
./scripts/o3de.sh disable-gem -gn PhysX -pp /workspaces/MyProject
./scripts/o3de.sh register --this-engine
./scripts/o3de.sh edit-project-properties -pp <路径> --user --engine-path <引擎>
```

## 运行

```bash
cd /workspaces/o3de-build/bin/profile

./o3de                                         # ProjectManager（GUI，可用）
./AssetProcessor --project-path=/workspaces/MyProject
./O3DE.ServerLauncher --project-path=/workspaces/MyProject
./O3DE.HeadlessServerLauncher --project-path=/workspaces/MyProject
./Editor --project-path=/workspaces/MyProject  # ⚠️ 本机会崩溃
```

## clangd

```bash
/home/hwg/tmp/ai/tmp/O3DE-学习文档/tools/refresh-compdb.sh
clangd --check=<文件>
```

# 附录 B · 关键源码位置索引

| 想了解什么 | 看哪里 |
|---|---|
| 模块加载 5 阶段 | `AzCore/Module/ModuleManager.cpp:344` |
| 三趟横向扫描 | `AzCore/Component/ComponentApplication.cpp:1607` |
| Gem 路径注册 | `AzCore/Settings/SettingsRegistryMergeUtils.cpp:970` |
| 插件清单生成 | `cmake/SettingsRegistry.cmake:235` |
| `LY_PROJECTS` 定义 | `cmake/Projects.cmake:17` |
| 项目模式注入 | `cmake/Findo3de.cmake:64` |
| Gem 目录遍历 | `cmake/Subdirectories.cmake:470` |
| 编译器自动选择 | `cmake/Platform/Linux/CompilerSettings_linux.cmake` |
| 三方包下载 | `cmake/3rdPartyPackages.cmake:512-545` |
| Python venv 哈希 | `AzToolsFramework/API/PythonLoader.cpp:78` |
| HPHA 双重释放检测 | `AzCore/Memory/HphaAllocator.cpp:2079` |
| 引擎目录结构 | `Code/Framework/`、`Gems/`、`Templates/`、`cmake/` |

# 附录 C · 版本与链接

**当前环境**：O3DE 2605.0（引擎版本 2.6.0）· clang 18.1.3 · CMake 3.28.3 · Ninja 1.11.1 · Ubuntu 24.04.5

**官方资源**

| 名称 | 链接 |
|---|---|
| Key Concepts | https://docs.o3de.org/docs/welcome-guide/key-concepts/ |
| Programming Guide | https://docs.o3de.org/docs/user-guide/programming/ |
| Engine Developer Guide | https://docs.o3de.org/docs/engine-dev/ |
| Tutorials（教程在 learning-guide，不是 user-guide） | https://docs.o3de.org/docs/learning-guide/tutorials/ |
| AZ Bootstrapping | https://docs.o3de.org/docs/user-guide/programming/bootstrap/ |
| EBus | https://docs.o3de.org/docs/user-guide/programming/messaging/ebus/ |
| Components | https://docs.o3de.org/docs/user-guide/programming/components/ |
| Gems | https://docs.o3de.org/docs/user-guide/programming/gems/overview/ |
| Atom Dev Guide | https://docs.o3de.org/docs/atom-guide/dev-guide/ |
| API Reference | https://docs.o3de.org/docs/api/ |
| GitHub | https://github.com/o3de/o3de |

**中文资源**

| 名称 | 链接 | 说明 |
|---|---|---|
| DawnEngine 中文文档 | https://docs.dawnengine.com/zh-cn/docs/ | 唯一完整翻译，URL 与官方同构 |
| 知乎「O3de 引擎分析与小结」 | https://www.zhihu.com/column/c_1474846361003188224 | 质量最高的原创分析 |

⚠️ 中文站术语坑：Gem→"插件"、Spawnable→"生成物"、Asset Processor→"资源处理器"、Action Manager→"行动经理"
⚠️ `o3de.cn` 是抢注的建站模板占位页，不是官网

**其他英文资源**

| 名称 | 链接 |
|---|---|
| DeepWiki（最接近完整架构文档） | https://deepwiki.com/o3de/o3de |
| SIG-Core 会议资料 | https://o3de.github.io/sig-core/ |
| 《Game Programming with Open 3D Engine》（免费 PDF） | https://github.com/SelfishOlex/O3DEBookCode2111 |

**社区文章（中文，补充阅读）**

> ⚠️ 这些是**二手资料**，可作为多一个视角，但**不要当权威**。
> 它们描述的是 2505.1 / 通用版本，与本文档实测的 2605.0 有差异；
> 且部分内容未经源码验证（例如把 Gem 依赖写成 `{"name": ..., "dependencies": [...]}`，
> 而实际的 `gem.json` 用的是 `gem_name` 字段）。
> **冲突时以本文档或源码为准。**

| 文章 | 链接 | 值得看的部分 | 注意 |
|---|---|---|---|
| CSDN《系统性全面讲解 o3de 2505.1 源码》系列（第 8 篇） | https://blog.csdn.net/macpander/article/details/152456950 | 十五节全景：目录结构、分层抽象、四个实践案例、性能与规格清单 | 是系列中的一篇，前面还有 7 篇；部分 API 名与 2605.0 不同 |
| 百度智能云《O3DE 引擎：开源 3D 引擎的技术解析与实践指南》 | https://cloud.baidu.com/article/5573654 | 面向企业的概览：模块化、跨平台、脚本系统 | 偏宣传口径，代码片段有简化（如 `OnActivate()` 实际是 `Activate()`） |
| 知乎专栏文章（一） | https://zhuanlan.zhihu.com/p/1963220575892779930 | — | ⚠️ 抓取时返回 403，未能核实内容 |
| 知乎专栏文章（二） | https://zhuanlan.zhihu.com/p/1963218212549288228 | — | ⚠️ 同上 |

> 💡 **怎么判断一篇 O3DE 中文文章的质量**：
> 看它有没有提到 `AZ::Uuid` 做类型身份、`-fvisibility=hidden`、unity build 这三件事。
> 三件都提了 → 作者真读过源码；一件没提 → 大概率是编译整理。

---

> **一句话总结**：
> O3DE 的定制 = 往引擎里挂 Gem，而不是改引擎。
> 插件式的核心是 **CMake 按 (项目, 目标, 变体) 生成 `cmake_dependencies.*.setreg`**，
> 运行时 `ModuleManager` 分 5 阶段、3 趟横向扫描加载。
> 代价是项目构建要重编引擎（3 小时），换来的是项目自包含、多变体裁剪、可整体替换渲染器/物理/网络。
