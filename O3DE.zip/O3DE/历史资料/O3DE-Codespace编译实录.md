# 在 GitHub Codespace 上编译 O3DE 2605.0 实录

> 时间：2026-11-08
> 目标：`ideal-chainsaw-p7jr9gg4g5xwc7wg6`（repo `hwg-1999/mianjing`，machine `standardLinux32gb`）
> 结果：**成功**。`AzCore / AzFramework / AzGameFramework / AzToolsFramework / AzQtComponents / Editor` 全部编译并链接通过，`FAILED` 数 0。

---

## 一、最终成果

| 产物 | 大小 | 位置 |
|---|---|---|
| `libAzCore.so` | 25 MB | `o3de-build/bin/profile/` |
| `libAzFramework.so` | 36 MB | 同上 |
| `libAzFramework.NativeUI.so` | 451 KB | 同上 |
| `libAzQtComponents.so` | 3.2 MB | 同上 |
| `libAzToolsFramework.so` | 47 MB | 同上 |
| `libEditorLib.so` | 32 MB | 同上 |
| `Editor`（启动器） | 21 KB | 同上 |
| `libAzGameFramework.a` | 857 KB | `o3de-build/lib/profile/` |
| `libAzNetworking.a` | 9.2 MB | 同上 |

统计：**189 个可执行文件 / 81 个共享库 / 58 个静态库**，全部 `ldd` 无 `not found`。

符号抽查：

- `libAzCore.so` 中 EBus 相关导出符号 **2194 个**
- `libAzToolsFramework.so` 导出符号 **22610 个**

运行验证：`Editor` 能加载 `libEditorLib.so`、初始化 Qt、走到项目选择逻辑（输出 `ProjectManager: Project Manager launched successfully, requesting exit.`）。

---

## 二、环境实况

| 项 | 值 |
|---|---|
| OS | Ubuntu 24.04.5 LTS, x86_64 |
| CPU | **4 核** |
| RAM | **15 GiB**（available ~13 GiB） |
| 磁盘 | **32 GB 总量**（overlay，`/` 与 `/workspaces` 同一 loop 设备） |
| CMake | 3.28.3（要求 ≥ 3.24 ✓） |
| Ninja | **原缺失 → apt 安装 1.11.1** |
| 编译器 | gcc/g++ 13.3.0；**clang 18.1.3**（O3DE 自动选中） |
| Python | 系统 3.12.3；O3DE 自带 venv 用 3.10.13 |
| git / git-lfs | 2.56.0 / 3.8.1 |
| sudo | **NOPASSWD 可用** |
| 网络 | github 200（0.04 s）；packman 根路径 403（正常，说明存活） |

---

## 三、编译过程（时间线）

```
0. 探测环境          nproc/free/df/cmake/gcc/python   → 4 核 / 15G / 19G 可用
1. 装 ninja          apt-get install ninja-build        → 1.11.1
2. 克隆源码           GIT_LFS_SKIP_SMUDGE=1 git clone --depth=1 --branch 2605.0
                     → 448 MB / 30033 文件，秒级完成
3. configure         ✗ 缺 libunwind-dev
4. 装依赖            ✗ configure 又缺 xcb_xkb
5. 再装              ✗ configure 又缺 xkbcommon_X11
6. 再装              ✓ Configuring done (18.3s)，引擎版本 2.6.0
7. 编 AzCore         ✓ 41 目标，libAzCore.so
8. 编 AzFramework    ✓ 46 目标，含 AzNetworking / AzGameFramework
9. 编 Qt+Tools       ✓ 137 目标，libAzQtComponents.so + libAzToolsFramework.so
10. 编 Editor        ✗ 227/789 处 meshoptimizer 的 .ddi 规则失败
11. 修复 scan-deps   ✓ 补 clang-tools-18 + 软链 + 改缓存
12. 续编 Editor      ✓ 564/564，0 失败
13. 产物验证         ✓ 依赖 0 缺失，Editor 可启动
```

总耗时约 **2 小时**（configure 约 25 分钟，主要是下载 4.8 GB 三方包；编译约 85 分钟）。

---

## 四、踩到的所有问题（按出现顺序）

### 问题 1：缺 `libunwind-dev`，configure 直接 fatal

```
CMake Error at cmake/Platform/Linux/libunwind_linux.cmake:15 (message):
  Compiling on linux requires the unwind development libraries and headers as
  well as pkg-config.  Try using your package manager to install the
  libunwind-dev libraries.
Call Stack:
  cmake/Platform/Linux/PAL_linux.cmake:76 (include)
  cmake/PAL.cmake:448
  CMakeLists.txt:85
```

**原因**：Codespaces 基础镜像只有运行时库，没有 `-dev` 包。
**解决**：`apt-get install -y libunwind-dev`
**教训**：这是 configure 的**第 5 行就会触发**的检查，属于「第一道门」，应该最先装。

---

### 问题 2：`FindX11` 缺 `xcb_xkb`

```
CMake Error ... Could NOT find X11 (missing: xcb_xkb)
Call Stack:
  cmake/3rdParty/FindX11.cmake:29 (FindX11)
  cmake/LYWrappers.cmake:629 (find_package)
  Code/Framework/AzFramework/CMakeLists.txt:163
```

**原因**：缺 `libxcb-xkb-dev`。
**解决**：`libxcb-xkb-dev`

---

### 问题 3：`FindX11` 缺 `xkbcommon_X11`（同类问题的第二次）

```
CMake Error ... Could NOT find X11 (missing: xkbcommon_X11)
Call Stack:
  cmake/LYWrappers.cmake:569 (ly_parse_third_party_dependencies)
  CMakeLists.txt:179 (ly_delayed_target_link_libraries)
```

**原因**：之前只装了**运行时包** `libxkbcommon-x11-0`，CMake 要的是 **`-dev` 包**。
**解决**：`libxkbcommon-x11-dev`

**⚠️ 这三个问题本质是同一个**：依赖缺失是**逐个暴露**的，每失败一次都要重跑 configure，而 configure 前面已经下载了 2.7~4.8 GB 三方包（好在有缓存）。**应该一次性预装完整依赖表**（见第六节）。

---

### 问题 4：`CMAKE_CXX_COMPILER_CLANG_SCAN_DEPS-NOTFOUND`（唯一的编译期失败）

```
FAILED: _deps/meshoptimizer-build/CMakeFiles/meshoptimizer.dir/src/allocator.cpp.o.ddi
"CMAKE_CXX_COMPILER_CLANG_SCAN_DEPS-NOTFOUND" -format=p1689 -- /usr/bin/clang++-18 ...
/bin/sh: 1: CMAKE_CXX_COMPILER_CLANG_SCAN_DEPS-NOTFOUND: not found
```

**根因链条**：

1. Atom/RPI 通过 FetchContent 引入 `meshoptimizer`，其 CMakeLists 启用了 **C++20 模块依赖扫描**（生成 `.ddi` 规则）。
2. CMake 3.28 通过 `clang-scan-deps` 做扫描，并在**配置阶段**把路径写入 `CMakeCache.txt`。
3. Ubuntu 的 `clang-18` 包里**不含** `clang-scan-deps`（在独立包 `clang-tools-18` 里），于是 CMake 记为 `...-NOTFOUND`。
4. 生成 `rules.ninja` 时把这个字面量当成命令，构建时才炸——**错误延迟到编译期才暴露**。

**解决（分两步）**：

```bash
sudo apt-get install -y clang-tools-18
sudo ln -sf /usr/bin/clang-scan-deps-18 /usr/local/bin/clang-scan-deps
```

**关键技巧：不要重跑 configure，直接改缓存**

因为 `-NOTFOUND` 已经固化在 `CMakeCache.txt` 里，单纯重跑 configure 不一定重新探测。做法：

```bash
cp CMakeCache.txt CMakeCache.txt.bak
sed -i 's|^CMAKE_CXX_COMPILER_CLANG_SCAN_DEPS:FILEPATH=.*|CMAKE_CXX_COMPILER_CLANG_SCAN_DEPS:FILEPATH=/usr/local/bin/clang-scan-deps|' CMakeCache.txt
sed -i 's|^CMAKE_C_COMPILER_CLANG_SCAN_DEPS:FILEPATH=.*|CMAKE_C_COMPILER_CLANG_SCAN_DEPS:FILEPATH=/usr/local/bin/clang-scan-deps|' CMakeCache.txt
cmake -B <build> -S <src> ...   # 重新生成 rules.ninja
```

验证：

```bash
grep -o '[^ ]*clang-scan-deps[^ ]*' CMakeFiles/rules.ninja | head -1
# 期望: "/usr/local/bin/clang-scan-deps"   （而不是 ...-NOTFOUND）
```

**收益**：只重生成 build.ninja，**不丢已编译的 227 个目标**，省掉约 20 分钟重编译。

---

### 问题 5：磁盘几乎耗尽（32 GB 是真瓶颈）

| 阶段 | 可用空间 |
|---|---|
| 起始 | 19 GB |
| 装完依赖 | 19 GB |
| 三方包下载完 | 13 GB |
| AzCore+AzFramework 编完 | 12 GB |
| Editor 编到 542/564 | **1.4 GB** ⚠️ |
| 删掉压缩包后 | 1.9 GB |
| 最终 | 1.4 GB |

**解决**：在 Editor 最终链接前，删除**已解压的原始压缩包**：

```bash
find /workspaces/o3de-packages/downloaded_packages -name "*.tar.xz" -delete
# 释放 631 MB
```

安全性：`packages/` 下已是解压后的目录，configure 靠 **sha256 校验 `packages/`** 而非压缩包；只要不再 configure，删压缩包无影响。

**⚠️ 教训**：**32 GB 磁盘编 Editor 是极限操作**。若再少 2 GB 就会 ENOSPC 失败。预算参考（profile + clang）：

| 项 | 占用 |
|---|---|
| 源码 | 448 MB |
| 三方包（解压后） | 4.2 GB |
| build 目录 | **12 GB** |
| **合计** | **约 17 GB** |

建议 Codespace 至少 **48 GB** 磁盘才舒服。

---

### 问题 6（本机侧）：`api.github.com` 被 fake-ip 劫持，`gh` 全线报 EOF

```
$ gh api user/codespaces
Get "https://api.github.com/user/codespaces": EOF
```

**诊断**：

```bash
getent hosts api.github.com       # → 198.18.0.108   ← Clash fake-ip（RFC2544 保留段）
curl --noproxy '*' https://github.com          # → 200 ✓
curl --noproxy '*' https://api.github.com      # → SSL_ERROR_SYSCALL
curl --resolve api.github.com:443:20.205.243.168 https://api.github.com/   # → 403 ✓（仅缺认证）
```

DoH 查到真实 IP `20.205.243.168`，**强制该 IP 就能通**。而本地 7897 代理端口虽开放，走它一样失败；`sudo` 需密码 → 无法改 `/etc/hosts`。

**解决**：写一个本地 **HTTP CONNECT 代理**，只对特定域名做 IP 覆盖（`_gh_proxy.py`，约 100 行）：

```python
OVERRIDE = {"api.github.com": "20.205.243.168"}
# CONNECT api.github.com:443 → 连 20.205.243.168:443
```

然后：

```bash
setsid nohup python3 _gh_proxy.py 18080 > /tmp/gh_proxy.log 2>&1 < /dev/null & disown
export HTTPS_PROXY=http://127.0.0.1:18080 HTTP_PROXY=http://127.0.0.1:18080
gh api user/codespaces          # ✓ 恢复正常
gh codespace ssh -c <name> -- '...'   # ✓ 所有 gh codespace 命令恢复
```

**为什么不用 `--noproxy`**：问题不在代理，在 **DNS**。Go（gh 的语言）只读 `/etc/hosts` + 系统 resolver，而系统 resolver 被 fake-ip 污染；写 hosts 需要 root。本地代理是唯一无需 root 的解法。

**⚠️ 注意**：`github.com` 本身没被污染，所以 SSH 主连接正常；只有 `api.github.com` 挂了 —— 但 `gh codespace` 每条命令都要先调 API，所以整个工具失效。

---

### 问题 7：远端命令引号嵌套把终端挂死

```bash
# ✗ 错误写法：单引号内又用了双引号，且被换行截断 → PS2 续行，终端卡住
gh codespace ssh -c X -- 'cd /workspaces/o3de && sed -n "725,760p" cmake/3rdPartyPackages.cmake
```

**解决**：改用本地脚本 + stdin 管道：

```bash
gh codespace ssh -c X -- 'cat > /workspaces/do_x.sh' < local_script.sh
gh codespace ssh -c X -- 'chmod +x /workspaces/do_x.sh && /workspaces/do_x.sh'
# 或者
gh codespace ssh -c X -- 'bash -s' < local_script.sh
```

**收益**：
- 彻底规避引号地狱（远端命令里不再出现嵌套引号）
- 脚本可在本地版本管理、反复复用
- 多行脚本不会因换行被截断

---

### 问题 8：长任务被清理杀掉的预防

```bash
cd /workspaces && setsid nohup ./do_build.sh Editor < /dev/null > /dev/null 2>&1 & disown
```

- `nohup ... &` **不够**：SSH 会话结束/工具清理会向进程组发信号
- 必须 `setsid`（脱离进程组）+ 重定向 `< /dev/null` + `disown`

---

## 五、意外收获：clang-18 绕过了 GCC 13 的所有已知坑

O3DE 的 `cmake/Platform/Linux/CompilerSettings_linux.cmake` 在**未设置 `CC`/`CXX` 时**会主动搜索 `/usr/bin/clang-[0-9]*` 并**取最高版本**：

```cmake
file(GLOB clang_versions /usr/bin/clang-[0-9]*)
list(SORT clang_versions COMPARE NATURAL ORDER DESCENDING)
list(GET clang_versions 0 clang_higher_version_path)
```

因此本机自动选中 **clang-18**，并打印：

```
-- Clang 18 detected, adding workaround for __cpp_conditional_explicit bug
```

**结果对比**（同一台机器此前用 GCC 13 从源码编译时踩过的坑）：

| 历史问题（GCC 13） | clang-18 结果 |
|---|---|
| `-Werror` 让新警告变致命（`-Wunused-variable`、`-Wdangling-pointer`、`-Wnonnull`） | ✅ 未触发 |
| `-fvisibility=hidden` 导致 `AZ::EBus<...>::GetContext` 变成 local 符号，AzFramework 报 522 个 undefined reference | ✅ 未触发（`libAzCore.so` 有 2194 个 EBus 导出符号） |
| `extern template basic_fixed_string<char,1024>` 缺单参数构造 | ✅ 未触发 |
| GCC 13 concepts 求值 bug，`AzToolsFramework` 6 个 unity 目标失败 | ✅ **全部通过** |

**结论**：**O3DE 在 Linux 上优先用 clang，别用 GCC 13**。这是本次最大的「省坑」经验。

> 注意 configure 输出的编译选项中依然带 `-Werror`、`-fvisibility=hidden`、`-fvisibility-inlines-hidden`、`-fno-exceptions`、`-D_FORTIFY_SOURCE=2`、`-msse4.1`、`-std=c++20`、`-O2 -g`。也就是说这些「雷」还在，只是 clang 不触发。

---

## 六、下一次可直接复用的完整依赖表

```bash
sudo apt-get update -y
sudo apt-get install -y \
  build-essential ninja-build pkg-config \
  libunwind-dev libzstd-dev libssl-dev \
  libx11-dev libxext-dev libxrender-dev libxrandr-dev libxinerama-dev \
  libxcursor-dev libxi-dev libxfixes-dev libxss-dev libxtst-dev \
  libxcb1-dev libxcb-xkb-dev libxcb-xinerama0-dev libxcb-xinput-dev \
  libxcb-xfixes0-dev libxcb-icccm4-dev libxcb-keysyms1-dev \
  libxcb-shape0-dev libxcb-randr0-dev libxcb-util-dev \
  libxcb-image0-dev libxcb-render-util0-dev libxcb-sync-dev \
  libxcb-glx0-dev libxcb-shm0-dev libxcb-dri2-0-dev libxcb-dri3-dev \
  libxcb-present-dev libxcb-cursor0 \
  libfontconfig1-dev libpulse-dev \
  libxkbcommon-dev libxkbcommon-x11-dev \
  libglu1-mesa-dev libxt-dev \
  clang-18 clang-tools-18

# clang-scan-deps 必须能被 CMake 以无版本名探测到
sudo ln -sf /usr/bin/clang-scan-deps-18 /usr/local/bin/clang-scan-deps
```

---

## 七、可复用的完整流程

```bash
# ---------- 1. 依赖（见第六节） ----------
# ---------- 2. 克隆（跳过 LFS） ----------
cd /workspaces
GIT_LFS_SKIP_SMUDGE=1 git clone --depth=1 --single-branch \
  --branch 2605.0 https://github.com/o3de/o3de.git o3de      # 448 MB

# ---------- 3. configure ----------
cmake -B /workspaces/o3de-build -S /workspaces/o3de -G Ninja \
  -DCMAKE_BUILD_TYPE=Profile \
  -DLY_3RDPARTY_PATH=/workspaces/o3de-packages

# ---------- 4. 编译（分批，便于定位问题） ----------
ninja -C /workspaces/o3de-build -j4 AzCore
ninja -C /workspaces/o3de-build -j4 AzFramework AzGameFramework
ninja -C /workspaces/o3de-build -j4 AzQtComponents AzToolsFramework
ninja -C /workspaces/o3de-build -j4 Editor

# ---------- 5. 链接前腾磁盘 ----------
find /workspaces/o3de-packages/downloaded_packages -name "*.tar.xz" -delete

# ---------- 6. 验证 ----------
ldd /workspaces/o3de-build/bin/profile/Editor | grep "not found"   # 应为空
ls -lh /workspaces/o3de-build/bin/profile/Editor
```

**构建规模参考**（O3DE 2605.0 / Linux / clang-18 / Profile）：

| 目标 | ninja 目标数 | 说明 |
|---|---|---|
| 全部 | 12780 | 含所有 Gem 与工具 |
| `AzCore` | 41 | unity 构建，约 3 分钟 |
| `AzFramework` + `AzGameFramework` | 46 | 约 2 分钟 |
| `AzQtComponents` + `AzToolsFramework` | 137 | 约 15 分钟 |
| `Editor` | 789（分两段） | 约 70 分钟 |

---

## 八、经验总结（按重要性排序）

### 1. 先装全依赖，别玩打地鼠

三次 configure 失败（libunwind → xcb_xkb → xkbcommon_X11）花在重复 configure 与等待上的时间，够把整张依赖表装三遍。**O3DE 的 Linux 依赖检查是分散在各处的**：libunwind 在 `CMakeLists.txt:85`，X11 在 `AzFramework/CMakeLists.txt:163` 和 `CMakeLists.txt:179`，没有任何一处集中声明。

### 2. `-dev` 包和运行时包是两回事

`libxkbcommon-x11-0`（运行时）≠ `libxkbcommon-x11-dev`（头文件+`.pc`）。CMake 的 `FindX11` 要后者。同理 `libxcb-xkb-dev`。

### 3. 优先用 clang，别用 GCC 13 编 O3DE

GCC 13 会踩 4 类坑（`-Werror`、`-fvisibility`、`extern template`、concepts bug），clang-18 一个都不踩。O3DE 甚至会自动帮你选 clang。

### 4. 配置缓存可以手改，别动辄重配

`CMakeCache.txt` 里的 `-NOTFOUND` 用 `sed` 改掉 + 重新 `cmake` 生成 `rules.ninja`，比 `rm -rf build` 省掉整轮重编译。**前提**：确认改动只影响变量取值，不影响 target 图。

### 5. 磁盘要按阶段盯，不能只看初始值

初始 19 GB 看着够，实际 Editor 编到 542/564 时只剩 1.4 GB。**三方包 4.2 GB + build 12 GB = 17 GB** 是硬账。提前删压缩包能续命。

### 6. 长任务一律 `setsid nohup ... < /dev/null & disown`

不然 SSH 一断就被清理，且错误信息看起来像「用户中断」。

### 7. 远端命令一律用「本地脚本 + stdin」模式

```bash
gh codespace ssh -c X -- 'bash -s' < local.sh
```

比在命令行里拼引号可靠得多，也便于复用与审计。

### 8. 编译期错误可能源自配置期

`clang-scan-deps` 的失败在第 227/789 个目标才出现，但根因在 configure。**遇到 `.ddi` / 模块扫描相关错误，直接查 `CMAKE_CXX_COMPILER_*_SCAN_DEPS` 缓存值**，别从源码找原因。

### 9. 本机网络问题要用「最小可复现诊断」定位

按 `getent` → `curl --noproxy` → `curl --resolve 真实IP` → 代理 的顺序逐层验证，10 分钟内就能区分「DNS 污染 / 代理故障 / 服务端问题」。这次结论是 **DNS 污染**，所以修 DNS 而不是修代理。

---

## 九、可复用的辅助脚本

| 脚本 | 用途 |
|---|---|
| `o3de-codespace/_gh_proxy.py` | 本地 CONNECT 代理，域名→真实 IP 覆盖，恢复 `gh` API |
| `o3de-codespace/_o3de_deps.sh` | 系统依赖安装 |
| `o3de-codespace/_o3de_configure.sh` | CMake configure |
| `o3de-codespace/_o3de_build.sh` | 后台 ninja 编译（追加日志） |
| `o3de-codespace/_o3de_verify.sh` | 产物 + 依赖 + 符号验证 |
| `o3de-codespace/_o3de_editor_check.sh` | Editor 产物检查与启动探测 |

---

## 十、把构建树搬回本地做增量编译（成功）

目标：既然 Codespace 磁盘紧张（32 GB），把构建树拉回本机（746 GB 可用）做增量开发。

### 10.1 可行性前提：工具链必须逐字节一致

CMake/Ninja 的构建目录**不可重定位**——路径一改，`build.ninja` 里每条命令的 `-I` / `-isystem` / `-o` 全变，Ninja 判定「命令变了」→ 全量重编。

实测远端构建树的路径耦合度：

| 位置 | `/workspaces` 出现次数 |
|---|---|
| `build.ninja` | **8260** |
| `CMakeCache.txt` | 68 |
| 单个 `.o` 的调试信息 | 41 |

本机与远端的环境对照（**运气很好，几乎完全一致**）：

| 项 | Codespace | 本机 | 一致 |
|---|---|---|---|
| OS | Ubuntu 24.04.5 | Ubuntu 24.04.5 | ✅ |
| C++ 编译器 | clang 18.1.3 | clang 18.1.3 (1ubuntu1) | ✅ |
| CMake | 3.28.3 | 3.28.3 | ✅ |
| Ninja | 1.11.1 | 1.11.1 | ✅ |

> 若版本不一致，`.o` 无法复用，这条路直接走不通。

### 10.2 传输方案实测

| 方案 | 实测速率 | 结论 |
|---|---|---|
| `tar` 直传（无压缩） | 2.9 MB/s | 可用但慢 |
| `rsync -a --partial` 经 gh 隧道 | **1.5 MB/s** | 更慢，**弃用** |
| **`tar \| zstd -1 -T4`** | **4~5 MB/s** | ✅ 采用 |

最终命令形态：

```bash
gh codespace ssh -c $CS -- 'tar -C /workspaces -cf - o3de-build/Code | zstd -1 -T4 -q -c' \
  | zstd -d -q -c | tar -C /workspaces/o3de-build -xpf -
```

**分块策略**：按顶层目录（`bin` / `External` / `lib` / `Code` / `_deps`）逐块传，某块失败只重传该块。

**`-p` / `-a` 必须保留 mtime**——这是增量判断的唯一依据。实测 tar `-p` 与 rsync `-a` 都能正确保留（UTC 18:03:34 → 本地 02:03:34）。

### 10.3 传输踩到的坑

**坑 A：`tar -C <dir>` 要求本地目录已存在**

```
tar: /workspaces/o3de-build: Cannot open: No such file or directory
tar: Error is not recoverable: exiting now
```

脚本重试 20 次全部失败，**白等 20 分钟**（每次失败都在 3 秒后重试，但重试前提不成立）。
→ 脚本必须 `mkdir -p "$base"`。

**坑 B：隐藏文件用 `du -sh *` 看不到**

`.ninja_deps`（3.8 MB）和 `.ninja_log`（172 KB）是增量判断的核心，`du -sh *` 不显示以点开头的文件，很容易漏掉。
→ 必须单独 `tar -cf - --exclude=... .`（带 `.`）带走。

### 10.4 复刻后暴露的三处问题（逐个解决）

#### 问题 A：`/workspaces` 路径 —— 复刻成功

```bash
sudo mkdir -p /workspaces && sudo chown $USER:$USER /workspaces
```

> 注意：`unshare -r -m` 虽然可用，但创建 `/workspaces` 这个父目录仍需要真实 root。

验证：

```bash
cd /workspaces/o3de-build
cp build.ninja /tmp/build.ninja.bak
/usr/bin/cmake --regenerate-during-build -S/workspaces/o3de -B/workspaces/o3de-build
diff -q /tmp/build.ninja.bak build.ninja     # → 完全一致
```

`build.ninja` **一字不差**，说明 8260 处路径全部对齐。

#### 问题 B：第二处绝对路径 `/home/codespace/.o3de/Python/...`

`ninja -d explain -n` 报：

```
ninja explain: output /home/codespace/.o3de/Python/packages/python-3.10.13-rev2-linux/FindPython.cmake
                of phony edge with no inputs doesn't exist
```

在 `build.ninja` 中出现 **468 处**，用途有三：

- 编译宏 `-DDEFAULT_LY_PYTHONHOME=".../python"`
- Python 头文件 `include` 路径
- 链接 `libpython3.10.so.1.0`

**关键发现**：这是 O3DE 的 `LY_PYTHON_HOME`，默认取 `$HOME/.o3de/Python`，把**远端用户名**固化进了构建树。

本机 `~/.o3de/Python/packages/python-3.10.13-rev2-linux` 恰好已有同版本包（953 MB，此前 GCC 构建时装的），所以只需补一个软链：

```bash
sudo mkdir -p /home/codespace/.o3de
sudo ln -sfn /home/hwg/.o3de/Python /home/codespace/.o3de/Python
```

#### 问题 C：系统库 `-dev` 软链接缺失（两类，共 10 个）

`ninja` 一次只报一个，需要迭代：

1. `libunwind.so` —— 本机只有运行时包 `libunwind8` 提供的 `.so.8.0.1`，缺 `libunwind-dev` 的软链
2. `libxcb-xfixes.so` 等 8 个 xcb 库 + `libpulse.so` —— 同理

**有趣的是**：这些 `.so` 文件本机早就有了（在 `~/o3de-sysdeps/usr/lib/x86_64-linux-gnu/`，之前用 `dpkg -x` 免 sudo 解压的），只是没链到 `/usr/lib/x86_64-linux-gnu/`。

一次补齐：

```bash
sudo apt-get install -y libunwind-dev \
  libxcb-xfixes0-dev libxcb-xinerama0-dev libxcb-xinput-dev \
  libxcb-icccm4-dev libxcb-keysyms1-dev libxcb-shape0-dev \
  libxcb-randr0-dev libxcb-util-dev libpulse-dev
```

> **为什么必须补到系统路径，而不能改 `build.ninja` 指向 `~/o3de-sysdeps`？**
> 因为改路径会改变编译/链接命令文本 → Ninja 判定命令变化 → **全量重编**，得不偿失。

#### 附带问题：`/usr/share/cmake-3.28/Modules/*.cmake` 的 mtime 更新

`ninja` 报 `[0/1] Re-running CMake...`，原因是系统 CMake 模块文件的 mtime 比 `build.ninja` 新。

```bash
touch build.ninja      # build.ninja 不是编译规则的输入，touch 无副作用
```

> ⚠️ **必须让 `RERUN_CMAKE` 边保持 up-to-date，绝不能让 CMake 真的跑起来**：
> 实测 `--regenerate-during-build` 会在 googletest 的 FetchContent 处失败
> （`CMake step for googletest failed: 1`，`Code/Framework/AzTest/3rdParty/Findgoogletest.cmake:75`）。

### 10.5 最终验证

```bash
$ cd /workspaces/o3de-build
$ ninja -n Editor
ninja: no work to do.

$ ninja -n AzCore AzFramework AzToolsFramework AzQtComponents
ninja: no work to do.

$ ldd bin/profile/Editor | grep -c "not found"
0
```

**零重编，构建树完整可用。**

> 注意：`ninja -n`（不带目标）会报 1295 个待办——那是**默认目标集合**，包含从未编过的测试类 Gem（ScriptCanvasTesting 等）。只要指定已编目标就干净。

### 10.6 增量编译实测

```bash
# 改 1 个源文件（Vector3.cpp 追加一行注释）
$ ninja -n AzCore | grep -c "^\["
2          # ← 1 个 unity 重编 + 1 次链接，符合预期

$ time ninja -j3 AzCore
[1/2] Building CXX object .../unity_15_cxx.cxx.o
[2/2] Linking CXX shared library bin/profile/libAzCore.so
real    1m8.702s
```

修复后重新改回原文件，触发下游 87 个重链接：

```bash
$ time ninja -j3 Editor
[87/87] Linking CXX executable bin/profile/Editor
real    2m53.562s
```

**结论**：
- 改 1 个 `.cpp` → 影响 1 个 unity 文件 → **约 1 分钟**
- 若动到核心库（`libAzCore.so`）→ 下游全部重链接 → **约 3 分钟**
- 相比全量 2 小时，提速 **40~120 倍**

### 10.7 本地增量开发的实际配置

| 项 | 建议 |
|---|---|
| 并行度 | **`-j2` 或 `-j3`**（本机 7.7 GB / 可用 3.7 GB / swap 2 GB，比远端 15 GB 紧张） |
| 构建命令 | `ninja -C /workspaces/o3de-build -j3 Editor` |
| 不要跑 | 裸 `ninja`（会带上 1295 个默认目标，含测试类 Gem） |
| 磁盘 | 源码 448 MB + 三方包 4.2 GB + build 8.0 GB ≈ **12.6 GB** |

### 10.8 运行 Editor 时卡在「Running get_python script...」

**现象**：启动 `Editor`（或 `o3de` / ProjectManager）后弹出一个对话框：

```
Running get_python script...
/workspaces/o3de-build/bin/profile/python/get_python.sh
```

进度条走到一半**永远不动**，Cancel 也没反应。

**根因链条**（读源码定位，共三层）：

1. `Editor` 无项目启动时会转发给 **ProjectManager**（可执行文件叫 `o3de`）。
2. ProjectManager 启动时调用 `PythonBindings::StartPython()`
   （`Code/Tools/ProjectManager/Source/Application.cpp:90`）。
3. 失败则调用 `ProjectUtils::RunGetPythonScript(GetEngineRoot())`
   （`ProjectUtils_linux.cpp:169`）→ 执行 `<engineRoot>/python/get_python.sh`。

而 Python 为什么失败？`PythonLoader::GetPythonVenvPath()`（`PythonLoader.cpp:78`）用
**引擎路径的 SHA1 前 32 位**作为 venv 目录名：

```cpp
AZStd::string enginePath = AZ::IO::FixedMaxPath(engineRoot).StringAsPosix();
enginePath += '/';
AZStd::to_lower(enginePath.begin(), enginePath.end());
// SHA1 → digest[0] → format("%08x", digest[0])
```

| 引擎路径 | venv 目录名 |
|---|---|
| `/workspaces/o3de/` | `8dcc7d4d` |
| `/workspaces/o3de-build/bin/profile/` | **`3295a26a`** |
| `/home/hwg/o3de/` | `04a8dd57` |

日志里能直接看到（`~/.o3de/Logs/O3DE.log`）：

```
python~~Missing python venv file at /home/hwg/.o3de/Python/venv/3295a26a/pyvenv.cfg.
python~~Python home path does not exist:
```

**关键点**：在**构建树**里跑 ProjectManager 时，`GetEngineRoot()` 解析成
`bin/profile/`（因为 `build.ninja` 所在目录向上找不到 `engine.json`），
所以它要的是 `3295a26a` 这个 venv —— 而 `cmake --regenerate-during-build`
只为源码路径 `/workspaces/o3de/` 创建了 `8dcc7d4d`。

**修复**（一行软链，341 MB 不用复制）：

```bash
cd ~/.o3de/Python/venv && ln -sfn 8dcc7d4d 3295a26a
```

验证：

```bash
~/.o3de/Python/venv/3295a26a/bin/python -c "import sys; print(sys.version, sys.prefix)"
# → 3.10.13 /home/hwg/.o3de/Python/venv/3295a26a
```

之后再启动，`Missing python venv` 报错消失，日志错误数归零，ProjectManager 正常出界面。

> **为什么对话框会「卡死」而不是报错**：
> `get_python.sh` 在 `bin/profile/python/` 下根本不存在（那是 SDK 安装布局，
> 构建树没有这份拷贝），`QProcess` 启动失败后模态对话框没有正确终止 —— 属于 O3DE 的 UX 缺陷。

### 10.9 关于 venv 目录名的通用结论

`~/.o3de/Python/venv/<hash>` 的 `<hash>` **只取决于引擎路径字符串**，与 O3DE 版本、编译器无关。
所以同一台机器上可以并存多个 venv（源码目录不同 → 哈希不同），也可以安全地软链复用。

**推论**：如果构建树被搬到新路径，除了 `build.ninja` 里的路径，还要检查
`<新engineRoot>` 对应的 venv 哈希是否存在。本例中 `bin/profile` 被当作 engineRoot，
所以需要额外准备 `3295a26a`。

### 10.10 这条路的通用价值

**「在云端大机器上全量编译一次，把构建树搬到本地做增量」**是一个可复用的模式，前提是：

1. 两端 OS + 编译器 + CMake + Ninja 版本**完全一致**
2. 复刻**所有**绝对路径（不止项目路径，还有 `$HOME` 派生路径）
3. 保留 **mtime**
4. 补齐**所有**系统 `-dev` 软链接（不能改构建脚本绕过）

代价是前期排查（本次约 1 小时），收益是长期增量提速 40~120 倍。

---

## 十一、一句话结论

> **在 4 核 / 15 GB / 32 GB 磁盘的 Codespace 上，O3DE 2605.0 可以完整编出 Editor，前提是：一次性装全 `-dev` 依赖、用 clang-18 而非 GCC 13、补 `clang-scan-deps`、并在最终链接前腾出磁盘。全流程约 2 小时，`FAILED` 数 0。**
>
> **构建树可以搬回本地做增量：只要工具链版本一致、复刻 `/workspaces` 与 `$HOME/.o3de` 两处绝对路径、保留 mtime、补齐系统 `-dev` 软链，即可实现 `ninja: no work to do`。改一个 `.cpp` 约 1 分钟，动核心库约 3 分钟。**
