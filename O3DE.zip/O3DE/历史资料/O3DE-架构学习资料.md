# O3DE 架构学习资料汇编（中英文）

> 收集时间：2026-11-08
> 目标：讲清 O3DE 的「架构」——有哪些文档、哪些是真货、中文资料在哪、怎么读源码。

---

## 0. 先说结论

| 问题 | 结论 |
|---|---|
| 官方有架构文档吗？ | 有，但 `engine-dev/architecture/` 这一章基本是 **stub**（页首明写 `To do: This section is currently incomplete`），只有 Project bootstrapping + Prefab System 两个子条目 |
| 官方有中文文档吗？ | **没有**。`docs.o3de.org` 只有英文 |
| 有可用的中文全量翻译吗？ | 有，第三方维护的镜像站 **DawnEngine 中文文档**，结构与官方一一对应，机翻质量、术语偶有偏差 |
| 中文原创技术分析多吗？ | 少。知乎有少量真实从业者笔记（质量最高），CSDN/部分站点有大量 **AI 生成的长文**，需交叉验证 |
| 最靠谱的路线？ | 中文站建概念 → 英文官方补精确语义 → 直接读源码（本机已有源码与构建经验） |

### 可信度分级（本文档全程使用）

- **A 级**：官方英文文档、官方源码
- **B 级**：第三方中文翻译（内容源自 A 级，但术语/机翻有损）
- **C 级**：个人技术博客/笔记（有真实经验，但版本可能过期）
- **D 级**：AI 生成文章（结构完整、细节不可靠，**不可直接照抄命令与路径**）

---

## 1. 中文资源清单

### 1.1 中文文档站（B 级，最推荐）

**DawnEngine 破晓引擎 · O3DE 文档中文版**
<https://docs.dawnengine.com/zh-cn/docs/>

- 性质：DawnEngine 是一家基于 O3DE 的商业引擎，把 `o3de.org` 文档整体翻译后镜像。页脚声明：文档内容为 O3DE 文档的衍生作品，遵循 CC BY 4.0，且**与 Linux Foundation / O3DE 项目无隶属、背书或赞助关系**。
- 价值：**目前唯一覆盖完整的 O3DE 中文文档**，URL 路径与官方一致（把 `docs.o3de.org/docs/` 换成 `docs.dawnengine.com/zh-cn/docs/` 即可）。
- 已验证可读的关键页：

| 章节 | 中文链接 |
|---|---|
| 关键概念（架构总览） | <https://docs.dawnengine.com/zh-cn/docs/welcome-guide/key-concepts/> |
| 编程指南（核心模块表） | <https://docs.dawnengine.com/zh-cn/docs/user-guide/programming/> |
| 开发者指南（架构章索引） | <https://docs.dawnengine.com/zh-cn/docs/engine-dev/> |
| AZ 引导过程 | <https://docs.dawnengine.com/zh-cn/docs/user-guide/programming/bootstrap/> |
| 用户指南总目录 | <https://docs.dawnengine.com/zh-cn/docs/user-guide/> |
| 原子渲染器（Atom） | <https://docs.dawnengine.com/zh-cn/docs/atom-guide/> |
| 教程 / 学习指南 | <https://docs.dawnengine.com/zh-cn/docs/learning-guide/> |

**⚠️ 术语坑（机翻导致的，务必对照英文）**

| 英文原文 | DawnEngine 译法 | 正确/通用译法 |
|---|---|---|
| Gem | **插件** | Gem（保留英文最好） |
| Spawnable | **生成物** | 动态预制体 / 可生成物 |
| Prefab | 预制件 | 预制体（尚可） |
| Asset Processor | 资源处理器 | 资产处理器 |
| Action Manager | **行动经理** | 动作管理器 |
| Component Entity System | 组件实体系统 | ✅ |
| EBus | EBus / 事件总线 | ✅ 两种混用 |

→ **建议：概念用中文看，凡是出现类名、路径、参数、API 名，一律回到英文页核对。**

### 1.2 中文技术文章（C / D 级，按可用度排序）

| 资源 | 链接 | 评价 |
|---|---|---|
| 知乎专栏「O3de 引擎分析与小结」 | <https://www.zhihu.com/column/c_1474846361003188224> | **C 级，最值得看**。真实从业者笔记，含 Raytracing、DiffuseGI 等实现细节；需登录，服务端抓取会 403 |
| 知乎「七十五、O3DE（一）：Component 与 EBus」 | <https://zhuanlan.zhihu.com/p/696638526> | C 级，带源码路径（`MaterialComponentBus.h`）的实操理解 |
| 知乎「粒子系统架构 - o3de」 | <https://zhuanlan.zhihu.com/p/78246475406> | C 级，粒子 Gem 分层骨架 |
| 知乎「O3de 的构建方法」 | <https://zhuanlan.zhihu.com/p/614632037> | C 级，构建/平台相关 |
| 知乎「【0-全面技术-O3DE】」系列 | <https://zhuanlan.zhihu.com/p/1963218212549288228> | D 级，AI 生成的大纲式长文，可当目录用 |
| CSDN `macpander` 专栏 | <https://blog.csdn.net/macpander/category_13058416.html> | D 级，AI 辅助的「2505.1 源码讲解」系列，覆盖面广、细节需核实 |
| CSDN「O3DE 引擎架构解构：基于 Gem 的组件化设计…」 | <https://blog.csdn.net/gitblog_00528/article/details/154810243> | D 级 |
| CSDN「O3de 架构深度剖析：模块化设计与插件系统」 | <https://blog.csdn.net/gitblog_00939/article/details/140984562> | D 级 |
| 博客园「O3DE 全解析：开源的 AAA 级 3D 路线」 | <https://www.cnblogs.com/corysoft/p/22736919> | D 级，选型科普，**不含架构内容** |
| 晓之笔记《O3DE C++ 开发》17 章 | <https://www.i32n.com/m/EE8A6E60215FB586FB0D010B3B8AFB5BEC035C646DF91D46CFD2EF677863C014> | D 级，作者自挂免责声明「由 Gemini 生成，不保证准确性」。**已知错误**：`git clone --recursive`（O3DE 不靠 submodule，靠 packman 拉三方包）、目录写成 `Engine/Code`（实际是 `Code/Framework`） |

### 1.3 中文 README / 构建资料

- **机器小白知识库：O3DE（开放3D引擎）** <https://docs.robotnewbie.com/guide/simulation/o3de/README_zh.html>
  - 官方 `o3de/o3de` README 的中译（2026-09-20 抓取），构建步骤/CMake 参数可对照，**B 级**。

### 1.4 视频

| 资源 | 链接 | 说明 |
|---|---|---|
| B 站《O3DE - 什么是 O3DE》 | <https://www.bilibili.com/video/BV1uo4y1X7c1/> | Sunniy Studio，概览级；简介里提到的 `o3de.sunniystudio.com` 目前抓取失败，疑似已下线 |
| B 站《14. O3DE 快速入门》 | <https://www.bilibili.com/video/BV1JFfvBjE1A/> | UP「引擎世界」，入门操作 |

> 结论：B 站**没有**成体系的架构课程，全是入门/资讯类。想学架构只能看文字 + 源码。

### 1.5 中文社区

- **没有**官方中文论坛、中文 Discord 频道、官方 QQ/微信群。
- 中文讨论散落在 知乎 / CSDN / 博客园，且 AI 生成内容占比很高 → **任何具体 API 结论都要回源码验证**。
- 真正的社区：GitHub Discussions（<https://github.com/o3de/o3de/discussions>）、O3DE Discord、SIG-Core / SIG-Build 例会记录。
- ⚠️ `o3de.cn` / `www.o3de.cn` 是**抢注的建站模板占位页**，与 O3DE 无关，别当官网。

---

## 2. 英文官方资源清单（A 级）

### 2.1 主线三篇

| 顺序 | 文档 | 讲什么 |
|---|---|---|
| 1 | [Key Concepts](https://docs.o3de.org/docs/welcome-guide/key-concepts/) | 全景：SDK 核心模块依赖图、Gem 插件模型、EBus、组件实体系统、资产管线、Launcher / 专用服务器 |
| 2 | [Programming Guide](https://docs.o3de.org/docs/user-guide/programming/) | 五个核心框架职责表 + 源码目录含义 + 学习路径 |
| 3 | [Engine Developer Guide](https://docs.o3de.org/docs/engine-dev/) | 面向改引擎内部的人；**大部分是 stub** |

### 2.2 关键机制单篇（架构真正的零件说明书）

- [The AZ Bootstrapping Process](https://docs.o3de.org/docs/user-guide/programming/bootstrap/) ← **理解执行流最重要**
- [EBus](https://docs.o3de.org/docs/user-guide/programming/messaging/ebus/)、[AZ::Interface](https://docs.o3de.org/docs/user-guide/programming/messaging/az-interface/)、[AZ::Event](https://docs.o3de.org/docs/user-guide/programming/messaging/az-event/)
- [Component 开发](https://docs.o3de.org/docs/user-guide/programming/components/)
- [Gem 模块系统](https://docs.o3de.org/docs/user-guide/programming/gems/overview/)
- [Settings Registry](https://docs.o3de.org/docs/user-guide/settings/)
- [Serialization](https://docs.o3de.org/docs/user-guide/programming/serialization/)
- [Assets](https://docs.o3de.org/docs/user-guide/assets/)
- [Atom Renderer Dev Guide](https://docs.o3de.org/docs/atom-guide/dev-guide/)
- [API Reference](https://docs.o3de.org/docs/api/)

### 2.3 社区与视频（英文）

- O3DE 官方 YouTube 频道 + 历年 **O3DECon** 演讲：搜 `architecture` / `SIG-Core` / `engine internals` / `AzCore`。**文档 stub 的部分基本只在演讲里补全。**
- GitHub RFC / Discussions：架构决策的原始出处。

---

## 3. 架构正文（中英文资料合并整理）

### 3.1 分层与核心模块

O3DE 是「一个公共内核 + 插件/扩展系统」的结构。SDK 提供 5 个核心模块，所有高层产品都依赖它们。

```mermaid
graph TD
  P["高层产品<br/>O3DE Editor · Asset Processor · Launcher · CLI 工具"]
  P --> T["AzToolsFramework + AzQtComponents<br/>（仅工具侧）"]
  P --> G["AzGameFramework<br/>（仅运行时侧）"]
  T --> F["AzFramework<br/>（应用/输入/实体代理等公共层）"]
  G --> F
  F --> C["AzCore<br/>数学 · 内存 · 序列化 · EBus · RTTI · 模块加载"]
  N["AzNetworking<br/>（专用子系统）"] --> F
```

| 模块 | 职责 | 位置 |
|---|---|---|
| `AzCore` | 数学、序列化、内存管理、事件与发布/订阅接口、加载插件模块；提供**组件实体模型**；自带一套 C++ STL 实现（内存对齐感知容器） | `Code/Framework/AzCore` |
| `AzFramework` | 更高层结构，大多数 O3DE 应用通用的代码 | `Code/Framework/AzFramework` |
| `AzGameFramework` | **仅运行时**用的核心函数：主循环管理、运行时专用引导序列 | `Code/Framework/AzGameFramework` |
| `AzToolsFramework` | **仅工具**用的核心功能：对象选择器、属性编辑器、源码控制集成、工具专用引导序列 | `Code/Framework/AzToolsFramework` |
| `AzQtComponents` | 统一观感的 Qt 控件（滚动条、按钮、对话框…） | `Code/Framework/AzQtComponents` |

> 记忆点：**Game 侧只要 `AzGameFramework`，工具侧要 `AzToolsFramework` + `AzQtComponents`，二者都压在 `AzFramework` → `AzCore` 上。**

### 3.2 引导（Bootstrapping）流程

官方 13 步，归纳为 5 个阶段：

```mermaid
flowchart LR
  A["1. 可执行文件启动"] --> B["2-3. 初始化 AzFramework::Application<br/>拿到 描述符路径 + CreateStaticModules 函数指针<br/>先只引导到「能读描述符」"]
  B --> C["4-5. 读应用描述符：内存分配器设置 + 动态库列表<br/>关掉已引导的系统 → 按新设置重配 → 重启"]
  C --> D["6-9. 加载动态库<br/>InitializeDynamicModule() 挂到全局 AZ::Environment<br/>静态库/动态库各自创建 AZ::Module 实例"]
  D --> E["10-12. RegisterComponentDescriptors()<br/>再读一次描述符拿 系统实体<br/>GetRequiredSystemComponents() 补齐缺失组件"]
  E --> F["13. 系统实体激活<br/>所有系统组件按正确顺序激活 → 游戏运行"]
```

关键点（很多人卡在这）：

1. **描述符文件被读两次**：第一次只取内存分配器 + 动态库列表；第二次才取 system entity。
2. 第一次读完会**关掉再重启**已引导的系统（因为分配器配置变了）。
3. `RegisterComponentDescriptors()` 注册完，应用才「知道怎么序列化某个组件」——这是组件能被系统实体描述的前置条件。
4. `GetRequiredSystemComponents()` 是 Gem 声明「我必须有这个系统组件」的机制，缺了会自动补。

### 3.3 EBus（事件总线）

Gem 和系统通常编译成 DLL，EBus 提供**跨 DLL 的调用与通知**机制。

| 类型 | 作用 |
|---|---|
| **Request bus** | 注册一个可被其他系统调用的方法（一对一寻址） |
| **Notification bus** | 发布/订阅式通知（一对多广播） |

优势：抽象（减少硬依赖）、事件驱动（消除轮询）、并发（可跨线程排队）、可预测（handler 顺序可控）、可调试（可拦截消息）。

> 官方明确建议：**单例场景不要用 EBus**，改用更轻的 `AZ::Interface<T>` / `AZ::Event<T>`。

### 3.4 组件实体系统（CES）

```
Spawnable（动态预制体） > Prefab（预制体） > Entity（实体） > Component（组件）
```

- **Entity**：唯一 ID + 容器，本身不含逻辑。
- **Component**：提供具体功能（Mesh、PhysX Collider、Audio Trigger、Script Canvas…）。**唯一对所有实体都通用的是 Transform**。
- **Prefab**：带 Transform 的容器，里面装的是「配置好的实体」+ 可嵌套其他 prefab。
- **Spawnable**：动态 prefab（NPC、抛射物、动态场景物件）。
- 行为可从上层**级联向下**，反向不成立。

> 注意：O3DE 的 CES 是「组件化对象模型」，**不是** Unity DOTS / 纯 ECS 那种面向数据的内存布局。中文文章里把它直接等同于 ECS 的说法要打折看。

### 3.5 Gem 模块系统

- Gem = 可复用的功能打包单元：C++ 代码、资产、组件、库、工具、编辑器扩展，**甚至整个游戏项目**都可以是 Gem。
- 在项目配置里启用/禁用，构建时自动检测并编译。
- 有核心 Gem（所有项目必需）和扩展 Gem（依赖其他 Gem）。
- 引擎自带 83 个左右（Code 63 / Tool 12 / Asset 4），`engine.json` 默认启用 9 个。

### 3.6 资产管线

- **源资产**（.fbx/.png/.source）→ **Asset Processor** 后台进程按规则转换 → **产品资产**进 asset cache。
- 运行时**只从 asset cache 加载**，从不直接读源目录。
- 发布前用 **Asset Bundler** 基于依赖关系自动挑选要打包的资产。

### 3.7 配置：Settings Registry

- 统一配置系统，`.setreg` 文件 + `AZ::SettingsRegistryInterface`。
- 分层合并（引擎 → Gem → 项目 → 用户 → 命令行），越靠后优先级越高。
- 引导流程里读的「应用描述符」本质上也是这套 JSON 体系的一员。

### 3.8 渲染：Atom

- 独立一大套：`Atom`（高层）→ `RPI`（Render Pipeline Interface）→ `RHI`（Render Hardware Interface）→ 后端（DX12 / Vulkan / Metal）。
- Feature Processor 是 Atom 里「按功能挂到场景上」的扩展点。
- 见 [Atom Dev Guide](https://docs.o3de.org/docs/atom-guide/dev-guide/)。

### 3.9 源码地图（读码入口）

> 路径以 `development` 分支为准，随版本可能微调。

| 想了解什么 | 去哪看 |
|---|---|
| 核心模块 | `Code/Framework/AzCore`、`AzFramework`、`AzGameFramework`、`AzToolsFramework`、`AzQtComponents` |
| 模块加载机制 | `AzCore/Module/`（`ModuleManager` / `IModule` / `DynamicModuleHandle`） |
| 应用启动 | `AzFramework/Application/`、`AzGameFramework/Application/` |
| 组件与实体 | `AzCore/Component/`（`Component` / `Entity` / `ComponentApplication`） |
| EBus | `AzCore/EBus/`（`EBus.h` / `Event.h` / `Environment.h`） |
| 设置系统 | `AzCore/Settings/`（`SettingsRegistryImpl`） |
| 构建脚本 | `cmake/`（含 `3rdPartyPackages.cmake`、`LYPython.cmake`） |
| 官方 Gem | `Gems/`（Atom 内部还嵌套多个 Gem） |
| 项目/Gem 模板 | `Templates/` |
| 渲染 | `Gems/Atom/RPI`、`Gems/Atom/RHI` |

---

## 4. 中英术语对照表（读中文站必备）

| English | 中文通用 | DawnEngine 译法 | 备注 |
|---|---|---|---|
| Open 3D Engine (O3DE) | — | 破晓引擎（指其自家分支） | 注意区分 |
| SDK | 软件开发套件 | 软件开发套件 | |
| Gem | Gem（建议不译） | 插件 | **最大歧义源**，"插件"易与 Plugin 混淆 |
| Module | 模块 | 模块 | |
| EBus / Event Bus | 事件总线 | 事件总线 | |
| Request bus | 请求总线 | 请求总线 | |
| Notification bus | 通知总线 | 通知总线 | |
| Entity | 实体 | 实体 | |
| Component | 组件 | 组件 | |
| System component | 系统组件 | 系统组件 | |
| Prefab | 预制体 | 预制件 | |
| Spawnable | 动态预制体 | **生成物** | 词不达意 |
| Asset Processor | 资产处理器 | **资源处理器** | |
| Asset Bundler | 资产打包器 | 资产捆绑器 | |
| Asset Pipeline | 资产管线 | 资产管道 | |
| Settings Registry | 设置注册表 | 设置注册表 | |
| Bootstrap | 引导 / 自举 | 引导 | |
| Launcher | 启动器 | 启动器 | 客户端运行时 |
| Dedicated Server | 专用服务器 | 专用服务器 | |
| Reflection / Behavior Context | 反射 / 行为上下文 | 反射 / 行为上下文 | |
| AzAutoGen | 源生成器 | 源生成器 | Jinja2 模板代码生成 |
| RPI / RHI | 渲染管线接口 / 渲染硬件接口 | 同 | 建议保留缩写 |
| Feature Processor | 特性处理器 | 特征处理器 | Atom 扩展点 |

---

## 5. 学习路径

### 5.1 三天速通（建立心智模型）

| 时间 | 做什么 |
|---|---|
| Day 1 上午 | 中文站读 [关键概念](https://docs.dawnengine.com/zh-cn/docs/welcome-guide/key-concepts/)（40 min），只记 5 个词：Gem / EBus / Component / Prefab / Asset Processor |
| Day 1 下午 | 中文站读 [编程指南](https://docs.dawnengine.com/zh-cn/docs/user-guide/programming/) 的核心模块表 + 学习路径 |
| Day 2 上午 | 中文站读 [AZ 引导过程](https://docs.dawnengine.com/zh-cn/docs/user-guide/programming/bootstrap/)，对照英文原文核一遍术语 |
| Day 2 下午 | 读 [EBus](https://docs.o3de.org/docs/user-guide/programming/messaging/ebus/) + [AZ::Interface](https://docs.o3de.org/docs/user-guide/programming/messaging/az-interface/)，理解「为什么单例不用 EBus」 |
| Day 3 | 读 [Component 开发](https://docs.o3de.org/docs/user-guide/programming/components/) + [Gem 模块系统](https://docs.o3de.org/docs/user-guide/programming/gems/overview/)，动手写一个空 Component + 空 Gem |

### 5.2 两周进阶（能改引擎）

- 第 1 周：按 3.9 源码地图，把「引导 13 步」在 `AzFramework/Application/` 里逐行走一遍；把 `RegisterComponentDescriptors` / `GetRequiredSystemComponents` 的调用点找出来。
- 第 2 周：选一条纵向切片打通（推荐 **Atom 的 Feature Processor**，或 **PhysX Gem 的组件注册链**），再看 [O3DECon](https://www.youtube.com/@o3de) 对应演讲。

### 5.3 针对本机的特化建议

本机已从源码编过 O3DE（见 `memories/repo/o3de-build-notes.md`），可直接做「文档 ↔ 源码」对照：

- 构建踩过的 `-Werror`、`-fvisibility=hidden`、`extern template`、GCC 13 concepts bug，全部落在 `cmake/Platform/Common/GCC/Configurations_gcc.cmake` 和 `AzCore/std/string/*` → 正好是「核心模块表」里 AzCore 那一行的实证。
- `engine.json` 的 `external_subdirectories` / `gem_names` / `projects` → 对应 3.5 的 Gem 加载。
- `cmake/3rdPartyPackages.cmake` 里 `ly_parse_third_party_dependencies(3rdParty::Qt)` → 解释了「为什么编 Editor 必然拉 Qt」。
- 构建产物 `libAzCore.so`(32MB) / `libAzFramework.so`(44MB) → 直观感受模块体量。

---

## 6. 检索与查阅技巧

### 6.1 本地全文检索官方文档（最快）

```bash
git clone --depth=1 https://github.com/o3de/o3de.org
rg -n "EBus|bootstrap|AzFramework" o3de.org/content/docs
```

### 6.2 中英对照定位

把官方 URL 的 `https://docs.o3de.org/docs/` 换成 `https://docs.dawnengine.com/zh-cn/docs/`，即可拿到对应中文页。

### 6.3 源码定位

```bash
# 找 EBus 定义
rg -n "class EBus" Code/Framework/AzCore/AzCore/EBus
# 找模块加载
rg -n "InitializeDynamicModule|CreateModuleClass" Code/Framework/AzCore
# 找系统组件注册
rg -n "GetRequiredSystemComponents" --glob '!**/3rdParty/**'
```

### 6.4 网络受限时的注意

本机 Clash TUN 会劫持 IP 层，`no_proxy` 无效（见用户笔记）。抓这些文档站若超时，优先：
1. 直接用浏览器（VS Code 内置 Simple Browser 或外部浏览器）
2. 需要 CLI 抓取时，换公共 DNS 解析确认不是 fake-ip 后再试
3. 知乎返回 403 是反爬，不是链接失效

---

## 7. 链接总表

### 中文

| 名称 | 链接 | 级别 |
|---|---|---|
| DawnEngine 中文文档（总入口） | https://docs.dawnengine.com/zh-cn/docs/ | B |
| ├ 关键概念 | https://docs.dawnengine.com/zh-cn/docs/welcome-guide/key-concepts/ | B |
| ├ 编程指南 | https://docs.dawnengine.com/zh-cn/docs/user-guide/programming/ | B |
| ├ AZ 引导过程 | https://docs.dawnengine.com/zh-cn/docs/user-guide/programming/bootstrap/ | B |
| ├ 开发者指南 | https://docs.dawnengine.com/zh-cn/docs/engine-dev/ | B |
| └ 用户指南目录 | https://docs.dawnengine.com/zh-cn/docs/user-guide/ | B |
| O3DE README 中文 | https://docs.robotnewbie.com/guide/simulation/o3de/README_zh.html | B |
| 知乎专栏「O3de 引擎分析与小结」 | https://www.zhihu.com/column/c_1474846361003188224 | C |
| 知乎「Component 与 EBus」 | https://zhuanlan.zhihu.com/p/696638526 | C |
| 知乎「粒子系统架构」 | https://zhuanlan.zhihu.com/p/78246475406 | C |
| 知乎「O3de 的构建方法」 | https://zhuanlan.zhihu.com/p/614632037 | C |
| 知乎「【0-全面技术-O3DE】」 | https://zhuanlan.zhihu.com/p/1963218212549288228 | D |
| CSDN `macpander` O3DE 专栏 | https://blog.csdn.net/macpander/category_13058416.html | D |
| CSDN「Gem 组件化与事件驱动」 | https://blog.csdn.net/gitblog_00528/article/details/154810243 | D |
| CSDN「模块化设计与插件系统」 | https://blog.csdn.net/gitblog_00939/article/details/140984562 | D |
| 博客园「O3DE 全解析」 | https://www.cnblogs.com/corysoft/p/22736919 | D |
| 晓之笔记《O3DE C++ 开发》17 章 | https://www.i32n.com/m/EE8A6E60215FB586FB0D010B3B8AFB5BEC035C646DF91D46CFD2EF677863C014 | D |
| B 站「什么是 O3DE」 | https://www.bilibili.com/video/BV1uo4y1X7c1/ | — |
| B 站「O3DE 快速入门」 | https://www.bilibili.com/video/BV1JFfvBjE1A/ | — |

### 英文

| 名称 | 链接 |
|---|---|
| Key Concepts | https://docs.o3de.org/docs/welcome-guide/key-concepts/ |
| Programming Guide | https://docs.o3de.org/docs/user-guide/programming/ |
| Engine Developer Guide | https://docs.o3de.org/docs/engine-dev/ |
| Architecture（stub） | https://docs.o3de.org/docs/engine-dev/architecture/ |
| Frameworks | https://docs.o3de.org/docs/engine-dev/frameworks/ |
| AZ Bootstrapping | https://docs.o3de.org/docs/user-guide/programming/bootstrap/ |
| EBus | https://docs.o3de.org/docs/user-guide/programming/messaging/ebus/ |
| AZ::Interface | https://docs.o3de.org/docs/user-guide/programming/messaging/az-interface/ |
| AZ::Event | https://docs.o3de.org/docs/user-guide/programming/messaging/az-event/ |
| Components | https://docs.o3de.org/docs/user-guide/programming/components/ |
| Gems（编程向） | https://docs.o3de.org/docs/user-guide/programming/gems/overview/ |
| Settings Registry | https://docs.o3de.org/docs/user-guide/settings/ |
| Serialization | https://docs.o3de.org/docs/user-guide/programming/serialization/ |
| Assets | https://docs.o3de.org/docs/user-guide/assets/ |
| Atom Dev Guide | https://docs.o3de.org/docs/atom-guide/dev-guide/ |
| API Reference | https://docs.o3de.org/docs/api/ |
| GitHub Discussions | https://github.com/o3de/o3de/discussions |
| 文档仓库（本地 grep 用） | https://github.com/o3de/o3de.org |
| 引擎仓库 | https://github.com/o3de/o3de |

---

## 8. 已知坑与错误清单

1. **`o3de.cn` 不是官网**：占位模板页，内容是 Lorem ipsum。
2. **官方无中文站**：任何声称「官方中文」的都需核对。
3. **DawnEngine 是商业分支**：文档可读，但引擎本体是闭源商业产品，不要混淆。
4. **中文站术语偏差**：Gem→"插件"、Spawnable→"生成物"、Action Manager→"行动经理"，检索时会漏。
5. **AI 生成文章的通病**：目录漂亮、术语正确、**命令与路径错误**。已确认的两处：`git clone --recursive`、`Engine/Code` 路径。
6. **`engine-dev/architecture/` 至今是 stub**：别把它当权威设计文档，官方自己写着待补。
7. **升级到新版本后中文站可能滞后**：DawnEngine 镜像同步有延迟，`0.3.2` 之类版本号与官方不一定对齐。
8. **CES ≠ 纯 ECS**：中文文章常混用，实际是组件化对象模型。
9. **本机构建的特殊性**：GCC 13 + development 分支的编译问题不具普适性（官方只支持 GCC 11/12），别把本地补丁当成架构共识。

---

## 9. 英文讲解 / 教程资源（「教你怎么做」类）

> 关键区分：**`user-guide/` 是手册（是什么），`learning-guide/` 才是教程（怎么做）**。
> 找讲解文档时先看 `learning-guide`，很多人只知道 `user-guide` 所以觉得"官方没教程"。

### 9.1 官方书面教程：[Learning Guide](https://docs.o3de.org/docs/learning-guide/)

分四块，结构如下：

| 板块 | 内容 |
|---|---|
| **Video Tutorials** | 11 个官方视频（见 9.3） |
| **Tutorials** | 按主题划分的逐步书面教程（见下表） |
| **Samples** | Follow Along / Templates / Prototypes / Benchmark / Feature Showcase / Advanced / Robotic |
| **Made With O3DE** | 商业项目展示（找参考案例用） |

**Tutorials 已覆盖的主题**（[总目录](https://docs.o3de.org/docs/learning-guide/tutorials/)）：

| 主题 | 代表教程 | 说明 |
|---|---|---|
| Entities & Prefabs | Entity and Prefab Basics、Override a Prefab、Spawn/Despawn a Prefab | **入门必做**，理解 CES 的最短路径 |
| Extend the Editor | Create a Custom Tool Gem **in C++** / **in Python** | 官方唯一的工具 Gem 教程，涉及 Qt + Tools UI API |
| Multiplayer | Your First Network Component | C++ 网络组件入门 |
| Rendering | Create a StandardPBR material、Material Types and Shaders、Vertex Deformation for Vegetation Bending | Atom 材质/AZSL 着色器入门 |
| Assets | Customize Mesh / Actor / PhysX Collider Asset Processing | Scene Settings 管线 |
| AI | 2D Navigation with Kythera AI | 含行为树 |
| Animation | Data Driven Root Motion | |
| Environments | Create a Level、Create Terrain from Images | |
| Input | Grid-based Movement | |
| PhysX | Create Wind Forces | |
| PostFX | PostFX Shape Weight Modifier | |
| Remote Repositories | Your First Remote Repository | 分发 Gem/项目 |

### 9.2 Follow Along 与社区精选（性价比最高）

<https://docs.o3de.org/docs/learning-guide/samples/follow-along/>

| 资源 | 形式 | 说明 |
|---|---|---|
| **Pong** | 视频 + 文档 | 官方入门第一课，Script Canvas |
| **Protect the Moon** | 视频 | 横版射击，Space Invaders 风格 |
| ⭐ **O3DE Book** | 书 + 源码 | 《Game Programming with Open 3D Engine》，见 9.4 |
| **Multiplayer Workshop** | 视频 + 代码 | 第三人称多人移动 |
| **Lua Pong** | 纯文本 | Pong 的 Lua 版改写 |
| **GameLift Demo** | 文档 + 视频 | AWS GameLift 托管多人服务器 |

### 9.3 官方视频

- 频道：<https://www.youtube.com/@o3de>
- **Getting Started** 播放列表：<https://www.youtube.com/playlist?list=PLCQwFpnHSZQgr8Qfq-gNv3AcZ8VLv9d5s>
- **Tutorials & Workshops** 播放列表：<https://www.youtube.com/playlist?list=PLCQwFpnHSZQg_4lCmfXhCB5EjxieUbipk>

官方 11 个视频主题：What is O3DE / Installing O3DE for Windows / Creating Projects Using Project Manager / Setting up O3DE from GitHub / Creating Projects Using the Command Line / **O3DE Developer Overview** / **Atom Renderer** / **O3DE Networking Overview** / AWS Gems / Editor Tour / **Script Canvas Overview**。

> 加粗的四个是唯一带「架构/系统讲解」性质的，其余是操作演示。
> **另：历年 O3DECon 的技术演讲是 `engine-dev` 那堆 stub 的实际替代品**，搜 `O3DECon architecture` / `SIG-Core` / `AzCore deep dive`。

### 9.4 英文书（唯一一本，且免费）

**《Game Programming with Open 3D Engine》** — Oleksandr (Olex) Lozitskiy，2022

| 项 | 内容 |
|---|---|
| 官网 | <https://o3debook.com/> |
| 免费 PDF | [GitHub: SelfishOlex/O3DEBookCode2111](https://github.com/SelfishOlex/O3DEBookCode2111/blob/main/O3DE_Book_Final_2111.pdf)（作者自己公开的） |
| 配套代码 | **每个章节一个 git 分支**（如 `ch02_new_project`），主分支只有 README |
| 基线版本 | O3DE **21.11.2**（老，API 有变化，但概念不过时） |
| 作者背景 | Amazon Lumberyard / New World 出身，另著有《Game Programming with Amazon Lumberyard》 |

覆盖内容（正好是架构链条）：entities & components → modules → **inter-component communication** → player character → physics → animation → audio → UI → 改造成多人（含本地预测）。

> 这是英文世界里**唯一一本**系统性讲 O3DE 编程的书。因为基于 21.11.2，代码不能直接跑，但**讲组件通信、模块划分的那几章值得看**。

### 9.5 第三方英文深度解读

| 资源 | 链接 | 说明 |
|---|---|---|
| ⭐ **DeepWiki：o3de/o3de** | <https://deepwiki.com/o3de/o3de> | 对仓库自动生成的架构 wiki，按子系统分页（含 [AzCore Framework](https://deepwiki.com/o3de/o3de/7-azcore-framework)）。**这是目前最接近「完整架构文档」的英文材料**。⚠️ 实测多次返回 **HTTP 429（限流）**，需浏览器打开或错峰访问 |
| **SIG-Core 会议资料** | <https://o3de.github.io/sig-core/> | 维护 AzCore / AzFramework / AzToolsFramework / Gem System / Unified Launcher / AZStd / 反射 / 归档 / VFS / Settings Registry。含月度议程、triage 记录、[governance 下的 standards & best practices](https://github.com/o3de/sig-core/tree/main/governance) |
| **Pavel Guzenfeld 性能深挖** | [Chasing 18 Milliseconds](https://pavelguzenfeld.com/posts/o3de-performance-deep-dive-readback-bottleneck/) | 真实实测：测了 8 种优化方案，定位到 `AttachmentReadback` scope 有 18ms 固定开销。**英文里少见的一手工程分析** |
| **API Reference 的 Related Pages** | [AzCore /pages](https://docs.o3de.org/docs/api/frameworks/azcore/pages) | 不是纯签名列表：含 **AZCore Math Overview**、Allocators、Parallel Processing、Type Traits 等**讲解性页面**（版本 26.05.0，Doxygen 1.9.8） |
| GitHub Discussions | <https://github.com/o3de/o3de/discussions> | 架构决策讨论的原始出处 |
| O3DE Discord | <https://discord.com/invite/o3de> | `#sig-core` 等频道 |
| ossls/O3DE_tutorials | <https://github.com/ossls/O3DE_tutorials> | 小众但实用：用 Lua + Script Canvas 做 JSON 存档系统 |

### 9.6 不必浪费时间的地方

| 找什么 | 结论 |
|---|---|
| Coursera / Udemy / Pluralsight 的 O3DE 课程 | **没有**成体系的付费课程 |
| O'Reilly / Packt 的 O3DE 书 | 除 9.4 那一本外，**没有** |
| 官方「架构总览」白皮书 | **不存在**，`engine-dev/architecture/` 至今是 stub |
| GameFromScratch 等大 V 的 O3DE 教程 | 只有版本评测视频（如 25.10 / 26.05 的"Another Big Step Forward"），**不是教程** |

### 9.7 英文材料推荐阅读顺序

```mermaid
flowchart TD
  A["1. Learning Guide → Follow Along: Pong<br/>（先动手，建立界面感）"] --> B["2. Key Concepts<br/>（回头补概念，此时能对上号）"]
  B --> C["3. Tutorials → Entities and Prefabs<br/>（把 CES 吃透）"]
  C --> D["4. The AZ Bootstrapping Process<br/>（理解执行流）"]
  D --> E["5. DeepWiki: o3de/o3de<br/>（按子系统读架构）"]
  E --> F["6. 书《Game Programming with Open 3D Engine》<br/>第 2-5 章（模块与组件通信）"]
  F --> G["7. SIG-Core governance 文档 + O3DECon 演讲<br/>（补齐 stub 部分）"]
  G --> H["8. 回到源码 Code/Framework + DebugWiki 对照"]
```

> 与中文路线的差别：**英文材料应当「先做后读」**——因为操作类教程多、架构类材料少，先跑通 Pong 再读概念，效率明显高于先啃 `user-guide`。

### 9.8 中英文资源定位对照

| 需求 | 优先看 |
|---|---|
| 快速搞懂概念名词 | 中文站 Key Concepts |
| 精确 API / 语义 | 英文 `user-guide/` |
| 动手做一个东西 | 英文 `learning-guide/tutorials/` |
| 系统级架构 | **DeepWiki** + 源码（中英文都缺） |
| 真实工程经验 | 英文博客 + SIG-Core；中文看知乎专栏 |
| 完整项目范例 | 英文 O3DE Book + Samples |

---

## 10. 一句话备忘

> **中文只用来建立概念，架构准确性以 `docs.o3de.org` 为准，最终以 `o3de/o3de` 源码为唯一事实来源。**
> **英文的"讲解"在 `learning-guide`，不在 `user-guide`；而真正的架构说明，DeepWiki 比官方文档更完整。**
