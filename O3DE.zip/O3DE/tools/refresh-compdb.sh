#!/usr/bin/env bash
# 重新生成 O3DE 的 clangd 编译数据库
#
# 何时需要重跑：
#   - 改了 CMakeLists.txt / *.cmake / project.json（目标或 include 路径变化）
#   - 拉了新的引擎代码
#   - 重新 configure 过构建树
#
# 用法：
#   ./refresh-compdb.sh            # 两个都更新
#   ./refresh-compdb.sh engine     # 只更新引擎
#   ./refresh-compdb.sh project    # 只更新项目
set -u

HERE="$(cd "$(dirname "$0")" && pwd)"
GEN="$HERE/gen-compdb.py"
ENGINE_BUILD=/workspaces/o3de-build
PROJECT_BUILD=/workspaces/MyProject/build/linux
WHAT="${1:-all}"

run() {
    local name="$1" build="$2"
    if [ ! -f "$build/build.ninja" ]; then
        echo "[跳过] $name：$build/build.ninja 不存在（还没 configure）"
        return 0
    fi
    echo "========== $name =========="
    python3 "$GEN" "$build" || return 1
    echo
}

case "$WHAT" in
    engine)  run "引擎 (o3de-build)" "$ENGINE_BUILD" ;;
    project) run "项目 (MyProject)" "$PROJECT_BUILD" ;;
    all)
        run "引擎 (o3de-build)" "$ENGINE_BUILD"
        run "项目 (MyProject)" "$PROJECT_BUILD"
        ;;
    *)
        echo "用法: $0 [all|engine|project]" >&2
        exit 1
        ;;
esac

echo "===== 符号链接检查 ====="
for link in /workspaces/o3de/compile_commands.json /workspaces/MyProject/compile_commands.json; do
    if [ -L "$link" ]; then
        printf '  OK  %s -> %s\n' "$link" "$(readlink "$link")"
    else
        echo "  缺失: $link"
    fi
done

echo
echo "验证："
echo "  clangd --check=/workspaces/o3de/Code/Framework/AzCore/AzCore/Math/Vector3.cpp"
