# 文档维护脚本

这 4 个脚本分两类：**文档维护**（2 个）和 **clangd 配置**（2 个）。
它们不是学习内容，只是让这套文档可持续维护的工具。

```
tools/
├── split-guide.py       ← 主文档 → 分章节版（每次改完主文档都要跑）
├── insert-chapter.py    ← 插入新章节 + 自动重编号（写新内容时用）
├── gen-compdb.py        ← 生成 clangd 用的 compilation database
└── refresh-compdb.sh    ← 上面那个的一键封装（推荐用这个）
```

---

## 文档维护类

### `split-guide.py` —— 单文件 → 分章节

**这是你最常用的脚本。** 改了 `O3DE-完全指南.md` 之后跑一次：

```bash
cd /home/hwg/tmp/ai/tmp/O3DE-学习文档
python3 tools/split-guide.py
```

它做四件事：

| 步 | 动作 | 细节 |
|---|---|---|
| 1 | 按一级标题 `#` 切分 | ⚠️ **跳过代码块内的 `#` 注释**（否则 bash 注释会被当成章节，第一版曾拆出 77 个假文件） |
| 2 | 生成 `NN-章节名.md` | 序号前缀保证排序；文件名去掉 `·`、`/` 等非法字符 |
| 3 | **重写跨文件锚点** | `](#锚点)` → `](NN-其他章.md#锚点)`。不重写的话，拆分后链接全断 |
| 4 | 生成 `00-索引.md` | 按 L0–L5 分组，`★` 标出核心章节 |

同时会单独导出 `00-前言-学习路线.md`（正文第一个 `#` 到第一个章节之间的内容）。

**可选参数**：

```bash
python3 tools/split-guide.py 源文件.md 输出目录/
```

**改了章节级别时要同步改映射表**：脚本顶部的 `LEVEL_MAP` 决定每个部分归到哪一级，
`CORE` 集合决定谁带 `★`。新增一章如果不加进 `LEVEL_MAP`，索引里会归到「— 参考」。

### `insert-chapter.py` —— 插入章节并重编号

往主文档中间插一章时用。它会：

1. 把新章节内容插到指定位置
2. **自动把后面所有 `# 第X部分` 的序号 +1**
3. **自动把后面所有 `X.Y` 小节号重编号**（如 `3.8` → `3.9`）
4. 提示你需要手动检查的交叉引用（正文里写死的"见 3.8"）

> 💡 **为什么需要它**：文档里散落着大量"见 3.8"、"3.9 讲过"这类**写死的数字引用**。
> 手工插一章要改几十处，漏一处就指向错误内容。脚本至少保证标题层的编号是连续的。
>
> ⚠️ **它不会改正文里的数字引用**——插章后必须自己 grep 一遍：
> ```bash
> grep -n "3\.8\|3\.9\|3\.10" O3DE-完全指南.md
> ```

---

## clangd 配置类

这两个脚本解决**第十部分**讲的问题：O3DE 的 unity build 会让 clangd 失效。

### `gen-compdb.py` —— 展开 unity build 生成 compdb

**问题**：`ninja -t compdb` 只能导出 **unity 块**级别的条目（约 1454 条），
而 clangd 是按**单个 `.cpp`** 匹配的——匹配不上就退化成"推断模式"（没有准确的 include 路径）。

**做法**：读每个 `unity_N_cxx.cxx` 的内容，正则提取里面 `#include "绝对路径"` 的行，
为每个真实 `.cpp` **复制一份 unity 的编译命令**。

```
ninja -t compdb  →  8268 条原始条目
      ↓ 过滤 command 为空的（CUSTOM_COMMAND / phony）
    3605 条有效
      ↓ 识别 unity_N_cxx.cxx，提取 #include
    8081 条（每个真实 .cpp 一条）   ← 实测
```

**用法**：

```bash
python3 tools/gen-compdb.py <构建目录>
# 例：
python3 tools/gen-compdb.py /workspaces/o3de-build
```

输出写到 `<构建目录>/compile_commands.json`。

### `refresh-compdb.sh` —— 一键刷新（推荐）

上面那个脚本的封装，带参数检查和构建树存在性校验。

```bash
./tools/refresh-compdb.sh all       # 引擎 + 项目，都刷一遍
./tools/refresh-compdb.sh engine    # 只刷引擎
./tools/refresh-compdb.sh project   # 只刷项目（MyProject）
```

**什么时候需要重跑**：

| 场景 | 为什么 |
|---|---|
| 改了 `CMakeLists.txt` / `*.cmake` / `project.json` | 目标或 include 路径变了 |
| 重新 configure 过构建树 | compdb 被覆盖成 unity 版 |
| 拉了新引擎代码 | 新增文件没有条目 |
| **新增了 `.cpp` 但没重新编译** | compdb 里没有它 → clangd 只能"推断"（见下） |

**怎么判断 compdb 是否生效**：

```bash
clangd --check=/workspaces/o3de/Code/Framework/AzCore/AzCore/Component/Entity.cpp \
  2>&1 | grep -E "Loaded compilation database|Compile command from CDB|All checks"
```

期望看到 `Compile command from CDB`。
如果看到 `Compile command **inferred from** 某个邻居文件` → **compdb 里没有这个文件**，
clangd 靠猜，结果是假的正常或假报错。

> ⚠️ **实测案例**：本机新增 `HeartbeatComponent.cpp` 后没重编，clangd 报的是
> `Compile command inferred from MyProjectModule.cpp`。虽然碰巧 0 errors，
> 但参数不同就会出错。**新增源文件后一定要重跑一次 `ninja` 或本脚本。**

---

## 一句话速查

| 你想做什么 | 命令 |
|---|---|
| 改完主文档，同步分章版 | `python3 tools/split-guide.py` |
| 中间插一章 | `python3 tools/insert-chapter.py`（然后手动 grep 数字引用） |
| clangd 补全/跳转失效 | `./tools/refresh-compdb.sh all` |
| 确认 clangd 用的是真 compdb | `clangd --check=<某个.cpp>` 找 `from CDB` |
