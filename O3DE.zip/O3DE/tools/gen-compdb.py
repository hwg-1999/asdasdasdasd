#!/usr/bin/env python3
"""从 ninja 的 compdb 生成 clangd 可用的 compile_commands.json。

处理两个 O3DE 特有的问题：

1. `ninja -t compdb` 会把 CUSTOM_COMMAND/phony 也导出（command 为空）→ 过滤掉
2. **O3DE 默认启用 unity build**：构建时编译的是 `unity_N_cxx.cxx`（聚合文件），
   原始 .cpp 在 compile_commands.json 里没有条目 → clangd 打开单个 .cpp 时
   找不到编译参数，智能提示退化成纯文本。
   → 解析 unity 文件里的 `#include "..."`，为每个被包含的 .cpp 复制一条条目。

用法：
    python3 gen-compdb.py <build_dir> [output_path]

输出同时保留 unity 文件本身和展开后的单文件条目（clangd 会优先精确匹配）。
"""
import json
import re
import subprocess
import sys
from pathlib import Path

INCLUDE_RE = re.compile(r'^\s*#include\s+"([^"]+)"', re.MULTILINE)
SRC_EXTS = (".c", ".cc", ".cpp", ".cxx", ".c++")
UNITY_RE = re.compile(r"unity_\d+_(cxx|cc|c)\.(cxx|cc|c)$")


def main() -> int:
    build_dir = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
    out_path = Path(sys.argv[2]) if len(sys.argv) > 2 else build_dir / "compile_commands.json"

    raw = subprocess.run(
        ["ninja", "-C", str(build_dir), "-t", "compdb"],
        capture_output=True, text=True, check=True,
    ).stdout

    entries = json.loads(raw)
    valid = [e for e in entries if e.get("command")]

    out = []
    unity_cmd_by_src: dict[str, str] = {}
    unity_files = 0
    expanded = 0

    for e in valid:
        f = e.get("file", "")
        if not f.endswith(SRC_EXTS):
            continue
        out.append({"directory": e["directory"], "command": e["command"], "file": f})

        if not UNITY_RE.search(Path(f).name):
            continue

        unity_files += 1
        upath = Path(f)
        if not upath.is_absolute():
            upath = Path(e["directory"]) / upath

        try:
            text = upath.read_text(errors="ignore")
        except OSError:
            continue

        for inc in INCLUDE_RE.findall(text):
            inc_path = Path(inc)
            if inc_path.suffix not in (".c", ".cpp", ".cc", ".cxx"):
                continue
            if not inc_path.is_absolute():
                inc_path = (upath.parent / inc_path).resolve()
            if not inc_path.exists():
                continue
            key = str(inc_path)
            if key in unity_cmd_by_src:
                continue
            unity_cmd_by_src[key] = e["command"]
            out.append({
                "directory": e["directory"],
                "command": e["command"],
                "file": key,
            })
            expanded += 1

    out_path.write_text(json.dumps(out, indent=1, ensure_ascii=False))

    real_srcs = {e["file"] for e in out}
    print(f"原始有效条目      : {len(valid)}")
    print(f"unity 聚合文件    : {unity_files}")
    print(f"展开出的真实 .cpp : {expanded}")
    print(f"最终写入条目      : {len(out)}")
    print(f"覆盖唯一源文件    : {len(real_srcs)}")
    print(f"输出              : {out_path}")

    probe_marker = "/Code/Framework/AzCore/AzCore/Math/Vector3.cpp"
    hits = [s for s in real_srcs if s.endswith(probe_marker)]
    print(f"\n抽查 AzCore/Math/Vector3.cpp 的条目：")
    if hits:
        print(f"  -> OK  {hits[0]}")
    else:
        print("  -> NO  未找到（引擎源码可能未参与本次构建）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
