#!/usr/bin/env python3
"""把单文件 O3DE-完全指南.md 拆回分章节版本。

规则：
  - 按一级标题(# )切分
  - 第一个 # 是文章标题，不作为章节
  - 章节序号 → 文件名前缀（第X部分 → "第X部分"，附录 → "附录X"）
  - 自动生成 00-索引.md，包含全部章节链接

用法：
    python3 split-guide.py [源文件] [输出目录]
"""
import re
import sys
from pathlib import Path

src = Path(sys.argv[1] if len(sys.argv) > 1 else "O3DE-完全指南.md")
out_dir = Path(sys.argv[2] if len(sys.argv) > 2 else "分章节版")

text = src.read_text(encoding="utf-8")
lines = text.splitlines(keepends=True)

# ---- 找出所有一级标题的位置（必须跳过代码块内的 "# 注释"）----
h1_positions = []
in_fence = False
for i, ln in enumerate(lines):
    stripped = ln.lstrip()
    # 代码块围栏切换（``` 或 ~~~）
    if stripped.startswith("```") or stripped.startswith("~~~"):
        in_fence = not in_fence
        continue
    if in_fence:
        continue
    if re.match(r"^# \S", ln):
        h1_positions.append((i, ln.rstrip("\n")))

if not h1_positions:
    sys.exit("未找到一级标题")

# 第一个 # 是文章标题
title_line = h1_positions[0]
body_start = h1_positions[0][0]
chapters = h1_positions[1:]

out_dir.mkdir(parents=True, exist_ok=True)

# ---- 清理旧的分章节文件（保留归档目录）----
for old in out_dir.glob("*.md"):
    old.unlink()

def safe_name(h: str) -> str:
    """把标题变成安全的文件名"""
    s = h.lstrip("# ").strip()
    s = s.replace(" · ", "-")
    s = re.sub(r"[\\/:*?\"<>|]", "", s)
    s = re.sub(r"\s+", "-", s)
    return s

def slug(t: str) -> str:
    """GitHub 风格锚点：小写 → 去标点 → 逐空格替换为 -"""
    t = t.strip().lower()
    t = re.sub(r"[`*\[\]()]", "", t)
    t = re.sub(r"[^\w\s\u4e00-\u9fff-]", "", t)
    return t.replace(" ", "-")

# ---- 先算好每章包含哪些锚点（跨文件链接重写需要）----
def collect_headings(chunk: str):
    """收集一段 markdown 里的标题（跳过代码块）"""
    out, fence = [], False
    for ln in chunk.splitlines():
        s = ln.lstrip()
        if s.startswith("```") or s.startswith("~~~"):
            fence = not fence
            continue
        if fence:
            continue
        m = re.match(r"^#{1,6}\s+(.*)$", ln)
        if m:
            out.append(m.group(1).strip())
    return out

# ---- 切分 ----
written = []
chapter_anchors = {}  # fname -> set(slug)
for idx, (start, heading) in enumerate(chapters):
    end = chapters[idx + 1][0] if idx + 1 < len(chapters) else len(lines)
    chunk = "".join(lines[start:end]).rstrip() + "\n"

    name = safe_name(heading)
    # 加数字前缀保证排序
    prefix = f"{idx + 1:02d}"
    fname = f"{prefix}-{name}.md"
    chapter_anchors[fname] = {slug(h) for h in collect_headings(chunk)}
    written.append((fname, heading.lstrip("# ").strip(), chunk))

# ---- 跨文件锚点重写：](#x) → ](NN-某章.md#x) ----
anchor_owner = {}
for fname, _, _ in written:
    for a in chapter_anchors[fname]:
        anchor_owner.setdefault(a, fname)

def add_nav(chunk: str, prev_name: str, next_name: str) -> str:
    """在一级标题下方插入「返回索引 / 上一篇 / 下一篇」导航条。

    分章节版的最大痛点是「翻进去就出不来」——每章末尾没有回头路。
    这里统一在开头加一行，读者随时能回索引或翻相邻章。
    """
    nav_parts = ["[← 返回索引](00-索引.md)"]
    if prev_name:
        nav_parts.append(f"[上一篇]({prev_name})")
    if next_name:
        nav_parts.append(f"[下一篇]({next_name})")
    nav = "> " + " ｜ ".join(nav_parts) + "\n"

    lines = chunk.split("\n")
    # 找到第一个一级标题，插在它后面（跳过紧随的空行，只留一个空行）
    for i, ln in enumerate(lines):
        if ln.startswith("# "):
            j = i + 1
            while j < len(lines) and lines[j].strip() == "":
                j += 1
            return "\n".join(lines[:i + 1] + ["", nav.rstrip("\n"), ""] + lines[j:])
    return nav + "\n" + chunk


rewritten_links = 0
final_written = []
for idx, (fname, heading, chunk) in enumerate(written):
    own = chapter_anchors[fname]

    def fix(m, _fname=fname, _own=own):
        global rewritten_links
        text, anchor = m.group(1), m.group(2)
        if anchor in _own:
            return m.group(0)                      # 同章内，保持原样
        owner = anchor_owner.get(anchor)
        if owner:
            rewritten_links += 1
            return f"[{text}]({owner}#{anchor})"
        return m.group(0)                          # 找不到就保留，交给校验脚本报错

    chunk = re.sub(r"\[([^\]]+)\]\(#([^)]+)\)", fix, chunk)

    # ---- 仓库级相对链接修正：主文档在根目录，分章版在子目录 ----
    # 主文档里的 [README.md](README.md#...) / [tools/x](tools/x) 在分章版中
    # 少一层 `../`，必须补上，否则 30 个文件里会出现坏链。
    chunk = re.sub(r"\]\((README\.md|tools/|历史资料/)", r"](../\1)", chunk)

    prev_name = written[idx - 1][0] if idx > 0 else ""
    next_name = written[idx + 1][0] if idx + 1 < len(written) else ""
    chunk = add_nav(chunk, prev_name, next_name)

    (out_dir / fname).write_text(chunk, encoding="utf-8")
    final_written.append((fname, heading, len(chunk.splitlines())))
written = final_written

# ---- 生成索引 ----
# 章节 → 所属级别（供分章节版按学习阶梯组织）
LEVEL_MAP = {
    "第一部分": ("L0", "认识"),
    "第二部分": ("L3", "懂架构"),
    "第三部分": ("L1", "跑起来"),
    "第四部分": ("L3", "懂架构"),
    "第五部分": ("L0/L1", "认识 + 跑起来"),   # 解剖 MinimalProject（原第二十七部分上提）
    "第六部分": ("L3", "懂架构"),
    "第七部分": ("L2", "能改"),
    "第八部分": ("L2", "能改"),
    "第九部分": ("L2", "能改"),
    "第十部分": ("L2", "能改"),
    "第十一部分": ("L4", "读源码"),
    "第十二部分": ("L4", "读源码"),
    "第十三部分": ("L4", "读源码"),
    "第十四部分": ("L1/L5", "跑起来 / 改引擎"),
    "第十五部分": ("L1–L4", "动手实验"),
    "第十六部分": ("L4", "读源码"),
    "第十七部分": ("L0", "认识"),
    "第十八部分": ("L0", "认识"),
    "第十九部分": ("L2", "能改"),
    "第二十部分": ("L2/L5", "能改 / 改引擎"),
    "第二十一部分": ("L4/L5", "读源码 / 改引擎"),
    "第二十二部分": ("L2/L5", "能改 / 改引擎"),
    "第二十三部分": ("L0", "认识"),
    "第二十四部分": ("L0", "认识"),
    "第二十五部分": ("L0→L2", "自顶向下改造"),   # 原第二十六部分，合并后前移
    "附录 A": ("L1", "跑起来"),
    "附录 B": ("L4", "读源码"),
    "附录 C": ("—", "参考"),
}
CORE = {
    "第二部分",
    "第三部分",
    "第四部分",
    "第七部分",
    "第八部分",
    "第十六部分",
    "第十七部分",
    "第十九部分",
    "第二十四部分",
    "第二十五部分",
    "第五部分",
}

def level_of(heading: str):
    for key, val in LEVEL_MAP.items():
        if heading.startswith(key):
            return val
    return ("—", "参考")

index = ["# O3DE 学习文档 · 分章节版", ""]
index.append(f"> 由 `{src.name}` 自动拆分，共 {len(written)} 个章节。")
index.append("> 单文件完整版见同目录上级的 `O3DE-完全指南.md`。")
index.append("> **学习路线图（五级阶梯）见 [`00-前言-学习路线.md`](00-前言-学习路线.md)。**")
index.append("")
index.append("## 按学习阶梯组织")
index.append("")
index.append("| 级别 | 名称 | 对应章节 |")
index.append("|---|---|---|")

order = ["L0", "L1", "L0/L1", "L2", "L3", "L4", "L1/L5", "L2/L5", "L4/L5", "L1–L4", "—"]
# 兜底：LEVEL_MAP 里新加的级别忘登记 order 时，自动追加，避免章节从索引里消失
for _, h, _ in written:
    lv = level_of(h)[0]
    if lv not in order:
        order.append(lv)
for lv in order:
    items = [f"[{h}]({f})" + (" ★" if any(h.startswith(c) for c in CORE) else "")
             for f, h, _ in written if level_of(h)[0] == lv]
    if items:
        index.append(f"| **{lv}** | {level_of(items[0].split(']')[0][1:])[1]} | {'<br/>'.join(items)} |")
index.append("")
index.append("> ★ = 该级别的核心章节，建议精读")
index.append("")
index.append("## 章节列表（顺序版）")
index.append("")
index.append("| # | 章节 | 级别 | 行数 |")
index.append("|---|---|---|---|")
for fname, heading, nlines in written:
    lv = level_of(heading)[0]
    star = " ★" if any(heading.startswith(c) for c in CORE) else ""
    index.append(f"| {fname[:2]} | [{heading}]({fname}){star} | {lv} | {nlines} |")
index.append("")

# ---- 前言（学习路线图）单独成文 ----
preface = "".join(lines[body_start:chapters[0][0]]).strip()
if preface:
    # 前言里的 (](#锚点) 同样需要指向具体章节文件
    def fix_preface(m):
        global rewritten_links
        text, anchor = m.group(1), m.group(2)
        owner = anchor_owner.get(anchor)
        if owner:
            rewritten_links += 1
            return f"[{text}]({owner}#{anchor})"
        return m.group(0)

    preface = re.sub(r"\[([^\]]+)\]\(#([^)]+)\)", fix_preface, preface)
    preface = re.sub(r"\]\((README\.md|tools/|历史资料/)", r"](../\1)", preface)
    (out_dir / "00-前言-学习路线.md").write_text(preface + "\n", encoding="utf-8")
    index.append("## 前言")
    index.append("")
    index.append("完整的**五级学习阶梯**（学习目标 / 前置 / 阅读清单 / 动手练习 / 自检问题）"
                 "见 [`00-前言-学习路线.md`](00-前言-学习路线.md)。")
    index.append("")

(out_dir / "00-索引.md").write_text("\n".join(index), encoding="utf-8")

print(f"跨文件锚点重写: {rewritten_links} 处")
print(f"源文件: {src}  ({len(lines)} 行)")
print(f"输出目录: {out_dir}")
print(f"拆出章节: {len(written)}")
for fname, heading, nlines in written:
    print(f"  {nlines:5d} 行  {fname}")
print(f"  {len(index):5d} 行  00-索引.md")
