#!/usr/bin/env python3
"""把新章节插入主文档，并重编号后续所有"第X部分"与"X.Y"小节编号。

用法：
    python3 insert-chapter.py <主文档> <新章节文件> <插入到哪个一级标题之前> <新章节编号>

示例：
    python3 insert-chapter.py O3DE-完全指南.md _新章节-设计架构.md "第二部分" 2
"""
import re
import sys
from pathlib import Path

CN = ["零", "一", "二", "三", "四", "五", "六", "七", "八", "九", "十",
      "十一", "十二", "十三", "十四", "十五", "十六", "十七", "十八", "十九", "二十"]

def cn(n: int) -> str:
    return CN[n] if n < len(CN) else str(n)

def find_h1(lines, keyword):
    """在代码块外找包含 keyword 的一级标题行号"""
    in_fence = False
    for i, ln in enumerate(lines):
        s = ln.lstrip()
        if s.startswith("```") or s.startswith("~~~"):
            in_fence = not in_fence
            continue
        if in_fence:
            continue
        if re.match(r"^# 第.*部分", ln) and keyword in ln:
            return i
    return -1

def main():
    main_path = Path(sys.argv[1])
    new_path = Path(sys.argv[2])
    before_kw = sys.argv[3]
    new_num = int(sys.argv[4])

    lines = main_path.read_text(encoding="utf-8").splitlines(keepends=True)
    new_chapter = new_path.read_text(encoding="utf-8").splitlines(keepends=True)

    # ---- 1. 重编号：从"插入点之后"的所有 第X部分 与 X.Y ----
    ins = find_h1(lines, before_kw)
    if ins < 0:
        sys.exit(f"未找到包含 '{before_kw}' 的一级标题")

    in_fence = False
    for i, ln in enumerate(lines):
        s = ln.lstrip()
        if s.startswith("```") or s.startswith("~~~"):
            in_fence = not in_fence
            continue
        if in_fence:
            continue
        if i < ins:
            continue

        # 一级标题 "第X部分" → "第X+1部分"
        m = re.match(r"^(# 第)([一二三四五六七八九十]+)(部分.*)$", ln)
        if m:
            cur = CN.index(m.group(2)) if m.group(2) in CN else None
            if cur is not None:
                lines[i] = f"{m.group(1)}{cn(cur + 1)}{m.group(3)}\n"
            continue

        # 二级标题 "X.Y ..." → "(X+1).Y ..."
        m = re.match(r"^(## )(\d+)\.(\d+)( .*)$", ln)
        if m:
            new_x = int(m.group(2)) + 1
            lines[i] = f"{m.group(1)}{new_x}.{m.group(3)}{m.group(4)}\n"
            continue

        # 三级标题 "X.Y.Z"
        m = re.match(r"^(### )(\d+)\.(\d+)\.(\d+)( .*)$", ln)
        if m:
            new_x = int(m.group(2)) + 1
            lines[i] = f"{m.group(1)}{new_x}.{m.group(3)}.{m.group(4)}{m.group(5)}\n"

    # ---- 2. 给新章节重编号（它内部是"第二部分"和"2.x"）----
    in_fence = False
    for i, ln in enumerate(new_chapter):
        s = ln.lstrip()
        if s.startswith("```") or s.startswith("~~~"):
            in_fence = not in_fence
            continue
        if in_fence:
            continue
        m = re.match(r"^(# 第)([一二三四五六七八九十]+)(部分.*)$", ln)
        if m:
            new_chapter[i] = f"{m.group(1)}{cn(new_num)}{m.group(3)}\n"
            continue
        m = re.match(r"^(## )(\d+)\.(\d+)( .*)$", ln)
        if m:
            new_chapter[i] = f"{m.group(1)}{new_num}.{m.group(3)}{m.group(4)}\n"
            continue
        m = re.match(r"^(### )(\d+)\.(\d+)\.(\d+)( .*)$", ln)
        if m:
            new_chapter[i] = f"{m.group(1)}{new_num}.{m.group(3)}.{m.group(4)}{m.group(5)}\n"

    # ---- 3. 插入 ----
    before_line = ins
    # 往前跳过 "---" 分隔行，让新章节前也有分隔
    while before_line > 0 and lines[before_line - 1].strip() in ("", "---"):
        before_line -= 1

    result = lines[:before_line] + ["\n"] + new_chapter + ["\n", "---\n", "\n"] + lines[before_line:]
    main_path.write_text("".join(result), encoding="utf-8")

    print(f"已插入新章节：第{cn(new_num)}部分（{len(new_chapter)} 行）")
    print(f"插入位置：原 '{before_kw}' 之前（行 {ins + 1}）")
    print(f"文档现共 {len(result)} 行")

if __name__ == "__main__":
    main()
